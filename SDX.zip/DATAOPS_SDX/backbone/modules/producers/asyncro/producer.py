from azure.eventhub import EventData
from azure.eventhub.aio import EventHubProducerClient

import datetime
import logging
import sys

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
logger.addHandler(logging.StreamHandler(sys.stdout))


class Producer:
    __instance = None

    def __init__(self, connection_str: str, event_hub_name: str, consumer_group: str):
        Producer.__instance = self
        self.__producer = EventHubProducerClient.from_connection_string(
            conn_str=connection_str,
            eventhub_name=event_hub_name,
            consumer_group=consumer_group,
        )

    @staticmethod
    def get_instance(connection_str: str, event_hub_name: str, consumer_group: str):
        if Producer.__instance is None:
            Producer(connection_str=connection_str, event_hub_name=event_hub_name, consumer_group=consumer_group)
            return Producer.__instance
        else:
            return Producer.__instance

    async def publish(self, message: str):
        logger.info(f'Dummy Producer 1 Received Event {datetime.datetime.utcnow()}')
        await self.__producer.send_event(event_data=EventData(message))
