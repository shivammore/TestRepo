import dataclasses
import datetime
from typing import List, Union, Tuple, Dict


@dataclasses.dataclass(frozen=True)
class LineageEdge:
    source_id: str
    destination_id: str
    products: List[str] = dataclasses.field(default_factory=list)

    def to_sql(self, table_name: str) -> str:
        return """ 
        INSERT INTO {} ( [source_id], [destination_id], [products])
        VALUES ('{}', '{}', '{}') """.format(table_name, self.source_id, self.destination_id,
                                             ','.join(set(self.products)))


@dataclasses.dataclass(frozen=False)
class LineageNode:
    project_name: str
    dataset_name: str
    landing_zone: str
    takeoff_zone: str = None
    context_id: str = None
    context_products: List[str] = dataclasses.field(default_factory=list)
    timestamp: float = int(datetime.datetime.now(tz=datetime.timezone.utc).timestamp())
    last_updated: float = None
    ttl: float = None
    context_status: Union[None, float] = dataclasses.field(init=False)  # between 0 and 1 (0 == KO)

    def __post_init__(self):
        self.context_id = self.get_context_id(
            context_project_name=self.project_name,
            context_landing_zone=self.landing_zone,
            context_dataset_name=self.dataset_name) if self.context_id is None else self.context_id

        if self.ttl is None or self.last_updated is None:
            self.context_status = None

        elif self.timestamp > self.last_updated + self.ttl:
            self.context_status = 0
        else:
            self.context_status = 1 - 1. * (self.timestamp - self.last_updated) / self.ttl

    def add_product(self, product_name: str):
        self.context_products.append(product_name)

    def add_products(self, products_name: List[str]):
        self.context_products = self.context_products + products_name

    @staticmethod
    def get_context_id(context_project_name, context_dataset_name: str, context_landing_zone: str) -> str:
        return f'{context_project_name}_{context_dataset_name}_{context_landing_zone}'.lower()

    @staticmethod
    def get_artificial_nodes(lineage_nodes: List, static_zones: List[Tuple[str, str]]):

        __hash_dict: Dict[str, LineageNode] = {node.context_id: node for node in lineage_nodes}
        __final_list = []
        __generated_nodes = [[LineageNode(project_name=node.project_name,
                                          dataset_name=node.dataset_name,
                                          context_products=node.context_products,
                                          landing_zone=zone[1],
                                          takeoff_zone=zone[0],
                                          ),
                              LineageNode(project_name=node.project_name,
                                          dataset_name=node.dataset_name,
                                          context_products=node.context_products,
                                          landing_zone=zone[0],
                                          )
                              ] for node in lineage_nodes for zone in static_zones]
        __flat_generated_nodes = [item for sublist in __generated_nodes for item in sublist]
        for node in __flat_generated_nodes:
            if node.context_id not in __hash_dict:
                __hash_dict = {**__hash_dict, **{node.context_id: node}}
                __final_list.append(node)
            else:
                existed_node = __hash_dict.get(node.context_id)
                existed_node.takeoff_zone = existed_node.takeoff_zone if existed_node.takeoff_zone is not None else node.takeoff_zone
                existed_node.context_products = existed_node.context_products if len(
                    existed_node.context_products) != 0 else node.context_products

        return __final_list

    def get_edge(self) -> LineageEdge:
        return LineageEdge(source_id=self.get_context_id(context_project_name=self.project_name,
                                                         context_dataset_name=self.dataset_name,
                                                         context_landing_zone=self.takeoff_zone),
                           destination_id=self.get_context_id(context_project_name=self.project_name,
                                                              context_dataset_name=self.dataset_name,
                                                              context_landing_zone=self.landing_zone),

                           products=self.context_products
                           )

    @staticmethod
    def get_gold_nodes(silver_nodes: List):

        products = [node.context_products for node in silver_nodes]
        products = list(set([item for sublist in products for item in sublist]))

        return [LineageNode(project_name="",
                            dataset_name=product,
                            landing_zone='gold',
                            takeoff_zone='silver', context_products=[product]) for product in products]

    @staticmethod
    def get_gold_edges(gold_nodes: List , silver_nodes: List ):

        __bucket = []
        for gold in gold_nodes :
            for silver in silver_nodes:
                if gold.dataset_name in silver.context_products :
                    __bucket.append(LineageEdge(source_id=silver.context_id,
                                                destination_id=gold.context_id,
                                                products=[gold.dataset_name]))

        return __bucket

    def to_sql(self, table_name: str) -> str:

        status = 'NULL' if self.context_status is None else self.context_status
        ttl = 'NULL' if self.ttl is None else self.ttl
        last_updated = 'NULL' if self.last_updated is None else self.last_updated
        return """ 
        INSERT INTO {} (timestamp, context_id, project_name, dataset_name,
         landing_zone, products, last_update ,ttl, status)
        VALUES ({}, '{}', '{}', '{}', '{}', '{}', {}, {}, {});
        """.format(table_name, self.timestamp, self.context_id, self.project_name, self.dataset_name,
                   self.landing_zone, ','.join(set(self.context_products)), last_updated, ttl, status)


@dataclasses.dataclass(frozen=False)
class LineageDependency:
    project_name: str
    dataset_name: str
    landing_zone: str

    dependency_project_name: str
    dependency_dataset_name: str
    dependency_landing_zone: str

    dependency_metric_name: str
    dependency_metric_value: float

    context_id: str = dataclasses.field(init=False)
    dependency_context_id: str = dataclasses.field(init=False)
    timestamps: float = int(datetime.datetime.now(tz=datetime.timezone.utc).timestamp())

    def __post_init__(self):
        self.context_id = self.get_context_id(
            context_project_name=self.project_name,
            context_landing_zone=self.dataset_name,
            context_dataset_name=self.landing_zone)

        self.dependency_context_id = self.get_context_id(
            context_project_name=self.dependency_project_name,
            context_landing_zone=self.dependency_dataset_name,
            context_dataset_name=self.dependency_landing_zone)

    @staticmethod
    def from_event(project_name: str, dataset_name: str, landing_zone: str, takeoff_zone: str):
        return LineageDependency(project_name=project_name, dataset_name=dataset_name, landing_zone=landing_zone,
                                 dependency_project_name=project_name, dependency_dataset_name=dataset_name,
                                 dependency_landing_zone=takeoff_zone, dependency_metric_name='auto_dependency',
                                 dependency_metric_value=1)

    @staticmethod
    def get_context_id(context_project_name, context_dataset_name: str, context_landing_zone: str) -> str:
        return f'{context_project_name}_{context_dataset_name}_{context_landing_zone}'.lower()

    def to_sql(self, table_name: str) -> str:
        return f'INSERT INTO {table_name} (timestamps ,project_name, dataset_name, landing_zone,' \
               f'dependency_project_name , dependency_dataset_name, dependency_landing_zone,' \
               f'dependency_metric_name, dependency_metric_value ) values (' \
               f'{self.timestamps} , \'{self.project_name}\', \'{self.dataset_name}\', \'{self.landing_zone}\',' \
               f' \'{self.dependency_project_name}\',\'{self.dependency_dataset_name}\',' \
               f'\'{self.dependency_landing_zone}\',' \
               f' \'{self.dependency_metric_name}\', {self.dependency_metric_value})'
