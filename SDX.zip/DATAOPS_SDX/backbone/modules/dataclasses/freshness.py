import logging
from typing import Optional

from modules.abstract.customdataclass import MyDataclass
import dataclasses
import datetime
from datetime import timezone

logger = logging.getLogger(__name__)


class InvalidTimestamp(Exception):
    pass


class InvalidJobID(Exception):
    pass


class InvalidMetricValue(Exception):
    pass


@dataclasses.dataclass
class FreshnessMetric(MyDataclass):
    """
    Dataclass to get metric send in event
    :attribute timestamp:        metadata.timestamp in event message (get from message metadata)
    :attribute publisher_name:   contexts.publisher_name in event message (get from message contexts)
    :attribute dataset_name:     contexts.dataset_name in event message (get from message contexts)
    :attribute landing_zone:     contexts.landing_zone in event message (get from message contexts)
    :attribute takeoff_zone:     contexts.takeoff_zone in event message(get from message contexts)
    :attribute event_type:       contexts.event_type in event message (get from message contexts)
    :attribute job_id:           contexts.job_id in event message (get from message contexts)
    :attribute kind:             contexts.kind in event message (get from message contexts)
    :attribute metric_name:      name of the metric in event message (get from message metrics)
    :attribute metric_value:     value of the metric in event message (get from message metrics)

    For more details see https://sdxcloud.visualstudio.com/IST.GLB.GLB.GDS_DATAPLATFORM/_wiki/wikis/IST.GLB.GLB.GDS_DATAPLATFORM.wiki/4153/Events-Draft
    """
    timestamp: int
    publisher_name: str
    project_name: str
    dataset_name: str
    landing_zone: str
    takeoff_zone: str
    event_type: str
    job_id: str
    kind: str
    metric_name: str
    metric_value: float
    subscription_id: str = ""

    def __post_init__(self):
        if not self.valid_timestamp():
            raise InvalidTimestamp("timestamp isn't in a valid format")
        self.valid_publisher_name()
        self.valid_project_name()
        self.valid_dataset_name()
        self.valid_landing_zone()
        self.valid_takeoff_zone()
        self.valid_event_type()
        self.valid_kind()
        if not self.valid_job_id():
            raise InvalidJobID("job_id isn't in a valid format")
        self.valid_metric_name()
        if not self.valid_metric_value():
            raise InvalidMetricValue("metric_value of {} isn't in a valid format".format(self.metric_name))
        self.valid_type(self)

    def valid_timestamp(self):
        try:
            self.timestamp = int(float(self.timestamp))
            datetime.datetime.utcfromtimestamp(self.timestamp)
            if self.timestamp > datetime.datetime.now(timezone.utc).timestamp():
                return False
        except Exception:
            return False
        return True

    def valid_publisher_name(self):
        self.publisher_name = self.publisher_name.lower()

    def valid_project_name(self):
        self.project_name = self.project_name.lower()

    def valid_dataset_name(self):
        self.dataset_name = self.dataset_name.lower()

    def valid_landing_zone(self):
        self.landing_zone = self.landing_zone.lower()

    def valid_takeoff_zone(self):
        self.takeoff_zone = self.takeoff_zone.lower()

    def valid_event_type(self):
        self.event_type = self.event_type.lower()

    def valid_kind(self):
        self.kind = self.kind.lower()

    def valid_job_id(self):
        try:
            self.job_id = str(self.job_id)
        except Exception:
            return False
        return True

    def valid_metric_name(self):
        self.metric_name = self.metric_name.lower()

    def valid_metric_value(self):
        try:
            self.metric_value = float(self.metric_value)
        except Exception:
            return False
        return True
