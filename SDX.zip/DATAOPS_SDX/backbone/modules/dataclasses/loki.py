import logging
from modules.abstract.customdataclass import MyDataclass
import dataclasses

logger = logging.getLogger(__name__)


@dataclasses.dataclass
class LokiDataclass(MyDataclass):
    """
    Dataclass to get logs send in event
    :attribute labels:           event contexts is used for the labels (get from event contexts)
    :attribute messages:         log message in event message (get from event logs)
    :attribute level:            log level in event message (get event level)

    """
    labels: dict
    message: str
    level: str

    def __post_init__(self):
        self.valid_type(self)
        self.valid_labels()
        self.valid_message()
        self.valid_level()
        self.level = self.level.lower()

    def valid_labels(self):
        if set(map(type, self.labels.keys())) != {str} or set(map(type, self.labels.values())) != {str}:
            raise TypeError

    def valid_message(self):
        if not isinstance(self.message, str):
            raise TypeError

    def valid_level(self):
        if not isinstance(self.level, str):
            raise TypeError
