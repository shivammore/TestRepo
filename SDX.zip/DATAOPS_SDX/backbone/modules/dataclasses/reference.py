import dataclasses
import datetime
from typing import Dict, Union

from modules.dataclasses.lineage import LineageNode


@dataclasses.dataclass
class Reference:

    project_name: str
    dataset_name: str
    landing_zone: str

    metric_name: str
    metric_value: float

    takeoff_zone: str = None
    publisher_name: str = ""
    timestamps: float = datetime.datetime.utcnow().timestamp()
    timestamp: float = datetime.datetime.utcnow().timestamp()

    @staticmethod
    def from_dict(dict_object: Dict[str, Union[float, datetime.time]]):
        return Reference(**dict_object)

    def get_context_id(self):
        return LineageNode.get_context_id(
                                          context_project_name=self.project_name,
                                          context_landing_zone=self.landing_zone,
                                          context_dataset_name=self.dataset_name)

    def to_sql(self, table_name: str) -> str:
        takeoff_zone = "'{}'".format(self.takeoff_zone) if self.takeoff_zone is not None else 'NULL'

        return f'INSERT INTO {table_name}(timestamps,publisher_name,project_name,dataset_name,landing_zone' \
               f',takeoff_zone,metric_name,metric_value) values ({self.timestamps}, \'{self.publisher_name}\', ' \
               f' \'{self.project_name}\' ,  \'{self.dataset_name}\',  \'{self.landing_zone}\' , ' \
               f'{takeoff_zone} ,  \'{self.metric_name}\', {self.metric_value})'
