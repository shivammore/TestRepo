from logging import Logger
from typing import Dict
import functools
import time


def verbose(logger: Logger, tags: Dict):
    """
    A centralised logger decorator that handle class method execution
    :param tags:
    :param logger: logger to record the execution error
    :return: None
    """

    def decorator(function):
        @functools.wraps(function)
        def wrapper(self, *args, **kwargs):
            start_time = time.time()
            __result = function(self, *args, **kwargs)
            total_time = (time.time() - start_time) * 1000

            tags_ = {**tags, **{'Duration': f'{total_time}ms'}}
            extra = ', '.join([f' {key}={value}' for key, value in tags_.items()])
            message = f'Executed \'{function.__name__}\' ({extra})'
            logger.debug(message)
            return __result

        return wrapper

    return decorator
