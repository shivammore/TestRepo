import logging
import logging_loki


class LokiLogger:
    def __init__(self, url):
        # logging_loki.LokiHandler.emitters. = "level"  emitter.LokiEmitter.level_tag
        # assign to a variable named handler
        self.handler = logging_loki.LokiHandler(
            url=url,
            version="1"
        )
        # create a new logger instance, name it whatever you want
        self.logger = logging.getLogger("Logger_push")

        self.logger.addHandler(self.handler)
        self.logger.setLevel(logging.DEBUG)

    # now use the logging object's functions as you normally would
    def log_publish(self, labels, message, level):
        if level == "error":
            self.logger.error(
                message,
                extra={"tags": labels}
            )
        elif level == "warning":
            self.logger.warning(
                message,
                extra={"tags": labels}
            )
        elif level == "info":
            self.logger.info(
                message,
                extra={"tags": labels}
            )
        elif level == "debug":
            self.logger.debug(
                message,
                extra={"tags": labels}
            )
        elif level == "critical":
            self.logger.critical(
                message,
                extra={"tags": labels}
            )


'''
import aioloki

class AsyncLokiLogger:
    def __init__(self, url, session):
        # logging_loki.LokiHandler.emitters. = "level"  emitter.LokiEmitter.level_tag
        # assign to a variable named handler
        self.handler = aioloki.AioLokiHandler(
            url,
            session=session
        )
        # create a new logger instance, name it whatever you want
        self.logger = logging.getLogger("Logger_push")

        self.logger.addHandler(self.handler)
        self.logger.setLevel(logging.DEBUG)

    async def log_publish(self, labels, message, level):
        if level == "error":
            self.logger.error(
                message,
                extra={"tags": labels}
            )
        elif level == "warning":
            self.logger.warning(
                message,
                extra={"tags": labels}
            )
        elif level == "info":
            self.logger.info(
                message,
                extra={"tags": labels}
            )
        elif level == "debug":
            self.logger.debug(
                message,
                extra={"tags": labels}
            )
        elif level == "critical":
            self.logger.critical(
                message,
                extra={"tags": labels}
            )
'''