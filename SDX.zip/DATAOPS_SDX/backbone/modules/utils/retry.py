import time
import random
import functools
import logging

logger = logging.getLogger()


class MaxTriesExceededError(Exception):
    pass


def retry_with_backoff(retries=5, backoff_in_seconds=1, stop=False):
    """
    Decorator to retry a function with a exponential backoff
    :param retries: number of retry
    :param backoff_in_seconds: current backoff in second
    :param stop: determine if we raise an error and stop process, or we ignore and continue process
    """

    def decorator(function):
        @functools.wraps(function)
        def wrapper(*args, **kwargs):
            x = 1
            while True:
                try:
                    return function(*args, **kwargs)
                except Exception as error:
                    logger.error('Error: {}'.format(error))
                    if x == retries:
                        if not stop:
                            break
                        else:
                            raise MaxTriesExceededError
                    sleep = (backoff_in_seconds * 2 ** x + random.uniform(0, 1))
                    time.sleep(sleep)
                    x += 1

        return wrapper

    return decorator
