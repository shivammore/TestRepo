import hashlib


def compute_dataset_hash_id(project_name: str, dataset_name: str, landing_zone: str) -> int:
    """
    Function to compute sha256 hash from string input
    :param project_name: project name in event message (see modules.dataclasses.freshness.py)
    :param dataset_name: dataset name in event message (see modules.dataclasses.freshness.py)
    :param landing_zone: landing zone in event message (see modules.dataclasses.freshness.py)
    :return: an int in the plage of mssql bigint
    """

    __string_id = project_name+'-'+dataset_name+'-'+landing_zone
    return int(hashlib.sha256(__string_id.encode('utf-8')).hexdigest(), base=16) % (2 ** 63) - 1
