from logging import Logger
import functools
import warnings
import sys


def catch(logger: Logger, raise_exception: bool = True):
    """
    Safe class method execution decorator
    :param logger: logger to record the execution error
    :param raise_exception: if True an error will raise if False a warning instead
    :return: None
    """

    def decorator(function):
        @functools.wraps(function)
        def wrapper(self, *args, **kwargs):
            try:
                return function(self, *args, **kwargs)

            except Exception as exception:
                error_type, error_value, error_traceback = sys.exc_info()
                message = f'Type ({error_type}) , Value ({error_traceback} , Trace back ({error_traceback})'
                # logger.exception(message)

                if raise_exception:
                    raise exception
                else:
                    #warnings.warn(message)
                    return None

        return wrapper

    return decorator
