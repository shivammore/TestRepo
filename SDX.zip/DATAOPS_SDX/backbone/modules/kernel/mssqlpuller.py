from typing import Dict, Union, List


class MssqlPuller:
    """

    """

    def __init__(self, connexion_pyodbc):
        self.connexion_pyodbc = connexion_pyodbc

    def query_from_dict(self, table_name: str, dict_schema: Dict[str, str]) -> List[Dict[str, Union[int, float, str]]]:
        """

        """
        cursor = self.connexion_pyodbc.cursor()
        column_query = ", ".join([f'{k}' for k in dict_schema.keys()])
        sql_query = f'select {column_query} from {table_name}'
        cursor.execute(sql_query)

        return [dict(zip(dict_schema.values(), row)) for row in cursor.fetchall()]

    def query_from_str(self, query: str) -> List[Dict[str, Union[int, float, str]]]:
        cursor = self.connexion_pyodbc.cursor()
        cursor.execute(query)

        header = [column_name for column_name, *_ in cursor.description]

        return [dict(zip(header, row)) for row in cursor.fetchall()]
