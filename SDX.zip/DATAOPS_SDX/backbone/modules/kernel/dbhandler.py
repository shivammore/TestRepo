import struct
import os
import logging
from threading import Lock
import pyodbc
from pyodbc import Connection

logger = logging.getLogger(__name__)

server = "dataops-db.database.windows.net"
database = "dataops"
local_driver = "{ODBC Driver 18 for SQL Server}"

"""
Class to manage pyodbc connection:
- AzureSQLConnectorManager: context manager for pyodbc connection
- AzureSQLConnectionManager: singleton for pyodbc connection
"""


class AzureSQLConnectorManager(object):
    """
    Context manager to handle azureSQL db connection
    :param autocommit: enable autocommit for mssql
    :parma timeout: connection timeout for mssql
    :param connection_string: connection string to connect on mssql
    """

    # To choose encoding select serverproperty('collation') on sql side
    # cnxn.setencoding(pyodbc.SQL_CHAR, encoding='latin1', to=str')  # (Python 3.x syntax)
    def __init__(self, **kwargs):
        self._conn: Connection = None
        self._autocommit = kwargs.get("autocommit")
        self._timeout = kwargs.get("timeout")
        self._connection_string = kwargs.get("connection_string")
        self.access_token = kwargs.get("access_token")

    def use_token(self):
        sql_copt_ss_access_token = 1256
        exptoken = b''
        for i in bytes(self.access_token, "UTF-8"):
            exptoken += bytes({i})
            exptoken += bytes(1)
        tokenstruct = struct.pack("=i", len(exptoken)) + exptoken
        self._conn = pyodbc.connect(self._connection_string, attrs_before={sql_copt_ss_access_token: tokenstruct})

    def create_connection(self):
        try:
            if os.getenv("MSI_SECRET"):
                logger.info("Creating connection with MSI_SECRET...")
                self._conn = pyodbc.connect(self._connection_string + ';Authentication=ActiveDirectoryMsi')
                logger.info("Connection created with MSI_SECRET")
                return self._conn
            else:
                # TO DO: local token usage
                if self.access_token is not None:
                    logger.info("Creating connection with local token...")
                    self.use_token()
                    logger.info("Connection created with local token")
                    return self._conn
                else:
                    logger.info("Creating connection with connection string...")
                    self._conn = pyodbc.connect(self._connection_string)
                    logger.info("Connection created with connection string")

        except pyodbc.Error as e:
            logger.error("create connection error: {}".format(e))

    def __enter__(self):
        self.create_connection()
        return self._conn

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_tb is None:
            logger.info("Commit request change")
            self._conn.commit()
        else:
            logger.info("Rolingback request change")
            self._conn.rollback()
        self._conn.close()
        logger.info("Connection closed")


class AzureSQLConnectionManager(object):
    """
    Singleton azureSQL db connection
    """
    __instance = None
    __connection: Connection = None
    __lock = Lock()

    def __new__(cls, *args, **kwargs):
        if AzureSQLConnectionManager.__instance is None:
            with cls.__lock:
                if AzureSQLConnectionManager.__instance is None:
                    AzureSQLConnectionManager.__instance = super(AzureSQLConnectionManager, cls).__new__(cls, *args,
                                                                                                         **kwargs)
        return AzureSQLConnectionManager.__instance

    def get_connection(self):
        with self.__lock:
            if self.__connection is None:
                self.__connection = AzureSQLConnectorManager().create_connection()
            return self.__connection

    def get_conn(self):
        return self.__connection

    def close_connection(self):
        with self.__lock:
            try:
                self.__connection.close()
                self.__connection = None
                logger.info('Closed connection')
            except:
                logger.info('Failed to close connection')
                self.__connection = None
            finally:
                self.__connection = None

    def reset_connection_if_broken(self):
        try:
            self.close_connection()
            self.__connection = None
        except Exception as error:
            logger.error('Error during reset connection {}'.format(error))
        finally:
            self.get_connection()

    def execute_insertquery(self, query, params):
        try:
            cursor = self.__connection.cursor()
            cursor.fast_executemany = True
            cursor.executemany(query, params)
            self.__connection.commit()
        except pyodbc.Error as error:
            self.__connection.rollback()
            self.reset_connection_if_broken()
            logger.error("Error during execute insert query (rollback): {}".format(error))
