import datetime
from typing import List

from modules.dataclasses.indicator import Indicator


class DeltaTime:
    METRIC_NAME = "last_processing_finished_delta_time"

    @staticmethod
    def get_delta_time_indicators(indicators: List[Indicator], timestamp: float) -> List[Indicator]:
        return [DeltaTime.get_delta_time_indicator_from_metric(indicator=indicator, timestamp=timestamp)
                for indicator in indicators]

    @staticmethod
    def get_delta_time_indicator_from_metric(indicator: Indicator,
                                             timestamp: float) -> Indicator:

        delta_time = int(timestamp - indicator.metric_value)

        return Indicator(timestamp=timestamp, publisher_name=indicator.publisher_name,
                         project_name=indicator.project_name, dataset_name=indicator.dataset_name,
                         landing_zone=indicator.landing_zone, takeoff_zone=indicator.takeoff_zone,
                         metric_name=DeltaTime.METRIC_NAME, metric_value=delta_time)
