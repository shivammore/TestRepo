from abc import ABC
import dataclasses


class MyDataclass(ABC):
    """
    An abstract class that all the dataclass need to implement
    """

    @classmethod
    def from_dict(cls, dict_):

        class_fields = {f.name for f in dataclasses.fields(cls)}
        return cls(**{k: v for k, v in dict_.items() if k in class_fields})

    @classmethod
    def valid_type(cls, self):

        for field in dataclasses.fields(cls):
            if field.type is not type(self.__getattribute__(field.name)):
                raise TypeError("{} value of attribute {} type must be {} and not a {} ".
                                format(self.__getattribute__(field.name), field.name, field.type,
                                       type(self.__getattribute__(field.name))))

    @classmethod
    def to_dict(cls):
        return cls.__dict__
