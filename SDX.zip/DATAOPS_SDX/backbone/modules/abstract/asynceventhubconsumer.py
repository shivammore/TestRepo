import asyncio
import json
import logging
from dataclasses import dataclass
from typing import List, Dict
from abc import ABC

from azure.eventhub import EventData
from azure.eventhub.aio import EventHubConsumerClient
from azure.eventhub.extensions.checkpointstoreblobaio import BlobCheckpointStore

from modules.utils.catcher import catch
from modules.utils.verbose import verbose

logger = logging.getLogger(__name__)
YamlExpression, JsonExpression = str, str


@dataclass
class EventMetaDataTuple:
    Event: Dict
    MetaData: Dict = None


class AsyncEventhubConsumer(ABC):
    """
    Abstract class to consume event in eventhub
    :attribute connection_string: The connection string to use for connecting to the Event Hub instance
    :attribute consumer_group: The name of the consumer group from which you want to process events
    :attribute eventhub_name: Gets the name of the EventHub
    :attribute storage_connection_str: The connection string to use for connecting to the checkpoint of Event Hub instance
    :attribute blob_container_name: The blob container name to use for the checkpoint
    :attribute retry_total: Configures the retry policy for all the operations on the client
    :attribute retry_backoff_factor: Configures the retry policy for all the operations on the client
    :attribute retry_mode: Configures the retry policy for all the operations on the client
    :attribute max_batch_size: Configures the way events are received
    :attribute max_wait_time: Configures the way events are received
    """

    @verbose(logger=logger, tags={'class_name': 'AsyncEventhubDispatcher'})
    def __init__(self, connection_string: str, consumer_group: str, eventhub_name: str, storage_connection_str: str,
                 blob_container_name: str, retry_total: int = 5, retry_backoff_factor: int = 1,
                 retry_mode: str = "exponential", max_batch_size: int = 100, max_wait_time: int = 5) -> None:

        self._connection_string = connection_string
        self._consumer_group = consumer_group
        self._eventhub_name = eventhub_name
        self._retry_total = retry_total
        self._retry_backoff_factor = retry_backoff_factor
        self._retry_mode = retry_mode
        self.max_batch_size = max_batch_size
        self.max_wait_time = max_wait_time

        self.storage_connection_str = storage_connection_str
        self.blob_container_name = blob_container_name

    def run_async_listen(self):
        asyncio.run(self.listen())

    @verbose(logger=logger, tags={'class_name': 'AsyncEventhubDispatcher'})
    async def listen(self) -> None:
        """

        """
        bloblogger = logging.getLogger('azure.core.pipeline.policies.http_logging_policy').setLevel(logging.WARNING)
        checkpoint_store = BlobCheckpointStore.from_connection_string(self.storage_connection_str,
                                                                      self.blob_container_name, logging=bloblogger)
        client = EventHubConsumerClient.from_connection_string(
            conn_str=self._connection_string,
            consumer_group=self._consumer_group,
            eventhub_name=self._eventhub_name,
            checkpoint_store=checkpoint_store,
            retry_total=self._retry_total,
            retry_backoff_factor=self._retry_backoff_factor,
        )
        async with client:
            await self.receive_batch(client)

    @verbose(logger=logger, tags={'class_name': 'AsyncEventhubDispatcher'})
    async def receive_batch(self, client: EventHubConsumerClient, max_batch_size: int = 500,
                            max_wait_time: int = 10, starting_position: int = -1):
        """

        """
        await client.receive_batch(
            on_event_batch=self.on_event_batch,
            on_error=self.on_error,
            max_batch_size=self.max_batch_size,
            max_wait_time=self.max_wait_time,
            starting_position=starting_position,
        )

    @catch(logger=logger, raise_exception=False)
    def load_dict_from_event(self, event: EventData) -> EventMetaDataTuple:
        meta_data_dict = {k: v for k, v in event.__dict__.items() if k != 'body'}

        return EventMetaDataTuple(Event=json.loads(event.body_as_str()), MetaData=meta_data_dict)

    @verbose(logger=logger, tags={'class_name': 'AsyncEventhubDispatcher'})
    async def on_event_batch(self, partition_context, event_batch):
        """

        """
        partition_id = partition_context.partition_id
        logging.info("Partition {}, Received events count: {}".format(partition_id, len(event_batch)))
        if len(event_batch) == 0:
            return

        event_batch = [self.load_dict_from_event(event=event) for event in event_batch]
        event_batch = [event for event in event_batch if event is not None]
        await self.on_event_batch_processing(events_metadatalist=event_batch)
        await partition_context.update_checkpoint()

    @verbose(logger=logger, tags={'class_name': 'AsyncEventhubDispatcher'})
    async def on_event_batch_processing(self, events_metadatalist: List[EventMetaDataTuple]):
        raise NotImplementedError

    @staticmethod
    async def on_partition_initialize(partition_context):
        logging.info("Partition: {} has been initialized.".format(partition_context.partition_id))

    @staticmethod
    async def on_partition_close(partition_context, reason):
        logging.info("Partition: {} has been closed, reason for closing: {}.".format(
            partition_context.partition_id,
            reason
        ))

    @staticmethod
    async def on_error(partition_context, error):
        if partition_context:
            logging.info("An exception: {} occurred during receiving from Partition: {}.".format(
                partition_context.partition_id,
                error
            ))
        else:
            logging.info("An exception: {} occurred during the load balance process.".format(error))
