import logging
import dataclasses
from typing import List
from cerberus import Validator
from modules.abstract.asynceventhubconsumer import AsyncEventhubConsumer, EventMetaDataTuple
from modules.dataclasses.freshness import FreshnessMetric
from modules.kernel.dbhandler import AzureSQLConnectorManager
from modules.utils.verbose import verbose
from modules.utils.retry import retry_with_backoff

logger = logging.getLogger(__name__)


class InvalidSchema(Exception):
    pass


class MetricsToSqlConsumer(AsyncEventhubConsumer):
    """
    Consumer class to consume event in eventhub and send in mssql
    Heritage attributes:
    :attribute connection_string: The connection string to use for connecting to the Event Hub instance
    :attribute consumer_group: The name of the consumer group from which you want to process events
    :attribute eventhub_name: Gets the name of the EventHub
    :attribute storage_connection_str: The connection string to use for connecting to the checkpoint of Event Hub instance
    :attribute blob_container_name: The blob container name to use for the checkpoint
    :attribute retry_total: Configures the retry policy for all the operations on the client
    :attribute retry_backoff_factor: Configures the retry policy for all the operations on the client
    :attribute retry_mode: Configures the retry policy for all the operations on the client
    :attribute max_batch_size: Configures the way events are received
    :attribute max_wait_time: Configures the way events are received
    Self attributes:
    :attribute SCHEMA: Schema to follow to validate an event
    :attribute ALLOW_UNKNOWN: With true, it is enable to have other fields
    :attribute tabel_name: The table name where insert the date
    :attribute _schema_validator: A validator to valid input data schema
    :attribute qmarks: Create qmarks to prepare the insert query
    :attribute fields: Get list of field to insert
    :attribute rq_insert: Get the insert query "insert into table_name(field1, field2, field3...) values (?,?,?...)""
    """
    SCHEMA = {
        'metadata': {
            'type': 'dict',
            'schema': {
                'timestamp': {'type': ['number', 'string'], 'required': True}
            },
            'required': True
        },
        'contexts': {
            'type': 'dict',
            'schema': {
                'job_id': {'type': ['number', 'string'], 'required': True},
                'event_type': {'type': 'string', 'required': True},
                'project_name': {'type': 'string', 'required': True},
                'dataset_name': {'type': 'string', 'required': True},
                'publisher_name': {'type': 'string', 'required': True},
                'landing_zone': {'type': 'string', 'required': True},
                'takeoff_zone': {'type': 'string', 'required': True},
                'subscription_id': {'type': 'string', 'required': False, 'nullable': True},
                'kind': {'type': 'string', 'required': True, 'allowed': ['file', 'column', 'table']}
            },
            'required': True
        },
        "metrics": {
            'type': 'dict',
            'required': True,
            'empty': False
        }
    }

    ALLOW_UNKNOWN = True

    def __init__(self, table_name: str, mssql_connection_string, connection_string: str, consumer_group: str,
                 eventhub_name: str, storage_connection_str: str,
                 blob_container_name: str, retry_total: int = 5, retry_backoff_factor: int = 1,
                 retry_mode: str = "exponential", max_batch_size: int = 100, max_wait_time: int = 5) -> None:

        self.tabel_name = table_name
        self.mssql_connection_string = mssql_connection_string
        self._schema_validator = Validator(schema=self.SCHEMA, allow_unknown=self.ALLOW_UNKNOWN)
        self.qmarks = ', '.join('?' * len(dataclasses.fields(FreshnessMetric)))
        self.fields = ', '.join(str(f.name).replace('/', '_') for f in dataclasses.fields(FreshnessMetric))
        self.rq_insert = "insert into %s(%s) values (%s)" % (self.tabel_name, self.fields, self.qmarks)
        super().__init__(connection_string=connection_string, consumer_group=consumer_group,
                         eventhub_name=eventhub_name,
                         storage_connection_str=storage_connection_str, blob_container_name=blob_container_name,
                         retry_total=retry_total, retry_backoff_factor=retry_backoff_factor, retry_mode=retry_mode,
                         max_batch_size=max_batch_size, max_wait_time=max_wait_time)

    @retry_with_backoff(retries=3, backoff_in_seconds=0.1, stop=True)
    def mssql_insert(self, params):
        with AzureSQLConnectorManager(connection_string=self.mssql_connection_string) as conn:
            curs = conn.cursor()
            curs.fast_executemany = True
            logger.info('Insert data to azure SQL database')
            curs.executemany(self.rq_insert, params)
            curs.close()

    @verbose(logger=logger, tags={'ClassName': 'MetricsSqlConsumer'})
    async def on_event_batch_processing(self, events_metadatalist: List[EventMetaDataTuple]):
        """
        Event structure in eventhub: body, properties, offset, sequence_number, enqueued_time
        EventMetaDataTuple structure: [body, properties+offset+sequence_number+enqueued_time]
        """
        params = []  # list of params to insert in mssql
        for event in events_metadatalist:
            logger.info("Parse event: {}".format(event.Event))
            try:
                # validate macro schema
                body_json = event.Event
                if not self._schema_validator(body_json):
                    raise InvalidSchema("Macro schema of the event is invalid {}".format(self._schema_validator.errors))
                # Get metadata timestamp, contexts and metrics fields
                metrics_list = [{'metric_name': k, 'metric_value': v, **body_json['contexts'],
                                 'timestamp': body_json['metadata']['timestamp']} for k, v in
                                body_json['metrics'].items() if v is not None]
                metrics_dataclass = [FreshnessMetric.from_dict(metric) for metric in metrics_list]
                # Add to params
                for metric_dict in [metric.__dict__ for metric in metrics_dataclass]:
                    params.append(list(metric_dict.values()))
            except Exception as error:
                logger.error("Parse event: {} hasn't been execute: {}".format(body_json, error))
                # Insert in mssql
        if len(params) > 0:
            try:
                self.mssql_insert(params)
            except Exception as error:
                logger.error("Event batch: {} hasn't been execute: {}".format(events_metadatalist, error))
