import datetime
import logging
import sys
import schedule
import time
import pyodbc

from modules.dataclasses.indicator import Indicator
from modules.kernel.mssqlpuller import MssqlPuller
from modules.indicators.deltatime import DeltaTime
from itertools import groupby

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
logger.addHandler(logging.StreamHandler(sys.stdout))


def get_connexion_string():
    server = 'dataops-db.database.windows.net'
    database = 'dataops'
    username = 'CloudSA3991b56c'
    password = 'f.QJ2B5xn$'
    driver = '{ODBC Driver 17 for SQL Server}'

    return 'DRIVER=' + driver + ';SERVER=' + server + ';DATABASE=' + database + ';UID=' + username + ';PWD=' + password


def run():
    logger.info("SLI cron job started at :{}".format(datetime.datetime.utcnow()))

    current_timestamp = datetime.datetime.now(tz=datetime.timezone.utc).timestamp()
    connexion = pyodbc.connect(get_connexion_string())
    mysql_puller, cursor = MssqlPuller(connexion_pyodbc=connexion), connexion.cursor()

    last_accepted_ts = current_timestamp - 60 * 60

    sql_query_sli_ref = """ 
    SELECT context_id ,  metric_value, project_name,dataset_name, landing_zone 
              FROM (
              SELECT 
              * , ROW_NUMBER() OVER(PARTITION BY context_id ORDER BY timestamps DESC) rowNumber
              FROM [dataops].[datasetsRef] where metric_name = 'sli_condition_secs'
              )datasetsRef 
                WHERE datasetsRef.rowNumber =1;
    """
    sli_reference_list = mysql_puller.query_from_str(query=sql_query_sli_ref)
    sli_reference_list = [row for row in sli_reference_list if row.get("metric_value", None) is not None]
    sli_reference_dict = {row.get('context_id', ''): row for row in sli_reference_list}
    context_referenced_list = ["'{}'".format(row.get('context_id', '')) for row in sli_reference_list]

    sql_query_indicators = """
            SELECT context_id , metric_value
            FROM [dataops].[indicators]
            WHERE metric_name = 'last_processing_finished_delta_time' and timestamp >= {}
            AND context_id in ({})
    """.format(last_accepted_ts, ",".join(context_referenced_list))

    last_records_list = mysql_puller.query_from_str(query=sql_query_indicators)

    for context, group in groupby(sorted(last_records_list, key=lambda row: row['context_id']),
                                  lambda row: row['context_id']):

        sli_ref_secs = sli_reference_dict.get(context, {}).get('metric_value', 1000000)
        sli_ref_secs = sli_ref_secs if sli_ref_secs is not None else 0

        publisher_name = sli_reference_dict.get(context, {}).get('publisher_name', '')
        project_name = sli_reference_dict.get(context, {}).get('project_name', '')
        dataset_name = sli_reference_dict.get(context, {}).get('dataset_name', '')
        landing_zone = sli_reference_dict.get(context, {}).get('landing_zone', '')
        accepted_indicators = [1 if row.get('metric_value') <= sli_ref_secs else 0 for row in group]

        percentage = round(1. * sum(accepted_indicators) * 100 / len(accepted_indicators), 2)
        sql_insert = Indicator(project_name=project_name, dataset_name=dataset_name, landing_zone=landing_zone,
                               publisher_name=publisher_name, metric_name='aggregated_sli_per_hour',
                               metric_value=percentage).to_sql(table_name='[dataops].[indicators]')

        logger.info("context_id : ({})  percentage ({})".format(context, percentage))

        logger.info(sql_insert)
        cursor.execute(sql_insert)

    _, _, _ = cursor.commit(), cursor.close(), connexion.close()
    logger.info("SLI cron job ended at :{}".format(datetime.datetime.utcnow()))


if __name__ == '__main__':
    SLEEP_TIME_SEC = 60
    while True:
        run()
        time.sleep(SLEEP_TIME_SEC)

