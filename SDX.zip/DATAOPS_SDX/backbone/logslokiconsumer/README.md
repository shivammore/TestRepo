## Overview
***

Logslokiconsumer directory enables to create a container consumer to consume data in eventhub and write it in loki backend. The directory contains two main files:
- Dockerfile: describe the build step to create the container
- \_\_init__.py: contains the main function of the application

Metricsmssqlconsumer has in input an event, check the event schema, parse it, process it and write to mssql backend. The event schema processed is :
```json
{
  'metadata': 
  {
    'timestamp':'number',
  },
  'contexts': 
  {
    'job_id':'string',
    'event_type':'string',
    'project_name':'string', 
    'dataset_name':'string', 
    'publisher_name':'string', 
    'landing_zone':'string', 
    'takeoff_zone':'string', 
    'kind':'string',
  },
  'logs': 
  { 
    [
      'message':'string',
      'level':'string',
    ]
  }
}
```
For every logs in this event a push is done in loki: 
```python
loki_logger.log_publish(
    label={
        'publisher_name':'data_core_services','project_name':'oss.fr.fr.jes', 'dataset_name':'activities',
        'takeoff_zone':'bronze','landing_zone':'silver','event_type':'processingstarted','kind':'table',                                                                                        
        'job_id':'oss_fr_fr_jes:staging_to_bronze:1234'
    },
    message="this is an Error", 
    level="error"
)
```

## Code architecture
***

The main architecture focus is to provide a tech dependency free, transparent & dev friendly. This application is divided in three main piece:
- A consumer: it must implement an abstract async consumer (AsyncEventhubConsumer) that consume event in eventhub. Only the method on_event_batch_processing is overwrite to provide custom processed to push data in loki. 
- A validator: At first the event schema is parsed and validated by cerberus package in the consumer and then data is validated by a dataclass (LokiDataclass).
- A loki logger: to push log in loki

