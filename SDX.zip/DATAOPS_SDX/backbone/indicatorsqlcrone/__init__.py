import datetime
import logging
import sys
import schedule
import time
import pyodbc

from modules.dataclasses.indicator import Indicator
from modules.kernel.mssqlpuller import MssqlPuller
from modules.indicators.deltatime import DeltaTime

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
logger.addHandler(logging.StreamHandler(sys.stdout))


def get_connexion_string():
    server = 'dataops-db.database.windows.net'
    database = 'dataops'
    username = 'CloudSA3991b56c'
    password = 'f.QJ2B5xn$'
    driver = '{ODBC Driver 17 for SQL Server}'

    return 'DRIVER=' + driver + ';SERVER=' + server + ';DATABASE=' + database + ';UID=' + username + ';PWD=' + password


def run():

    sql_query, table_name = """
                WITH ok_last_event  as (
        
        select *
        
        from [dataops].[event]
        
        where ID in (
        
        SELECT ID
        
        FROM (
        
          select
        
            *,
        
            ROW_NUMBER() OVER(PARTITION BY context_id ORDER BY timestamp desc) AS rn
        
          from [dataops].[event]
        
          where
        
            event_type = 'ProcessingFinished' and
        
            metric_name = 'processing_exit_code' and
        
            metric_value = 0
        
        
        ) aa
        
        WHERE rn = 1
        
        )
        
        )
        
        

    SELECT

    publisher_name,project_name,dataset_name,landing_zone,takeoff_zone
    ,metric_name,metric_value  

    FROM ok_last_event  where metric_name = 'processing_finished_date'      ;
    """, "[dataops].[indicators]"

    logger.info("Indicators cron job started at :{}".format(datetime.datetime.utcnow()))
    current_timestamp = datetime.datetime.now(tz=datetime.timezone.utc).timestamp()

    connexion = pyodbc.connect(get_connexion_string())
    mysql_puller, cursor = MssqlPuller(connexion_pyodbc=connexion), connexion.cursor()

    events_list = mysql_puller.query_from_str(query=sql_query)

    print(events_list)
    events_list = [Indicator.from_dict(event) for event in events_list]
    logger.info("Indicators cron job total events :{}".format(len(events_list)))

    delta_time_indicators = DeltaTime.get_delta_time_indicators(indicators=events_list, timestamp=current_timestamp)
    sql_insert_queries = [indicator.to_sql(table_name=table_name) for indicator in delta_time_indicators]

    for indicator in delta_time_indicators:
        print(indicator.get_context_id(), indicator.timestamp, indicator.metric_name, indicator.metric_value/(3600*24))
        logger.info('')

    [cursor.execute(sql_query) for sql_query in sql_insert_queries]
    _, _, _ = cursor.commit(), cursor.close(), connexion.close()
    logger.info("Indicators cron job finished at :{}".format(datetime.datetime.utcnow()))


if __name__ == '__main__':
    SLEEP_TIME_SEC = 60
    run()
    while True:
        print(datetime.datetime.utcnow())
        run()
        time.sleep(SLEEP_TIME_SEC)
