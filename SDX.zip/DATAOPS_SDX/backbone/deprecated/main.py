import datetime
import itertools
import time
from typing import Dict, List, Tuple

import networkx as nx
import pyodbc
from collections import Counter

from modules import dataclasses
from modules.dataclasses.lineage import LineageNode, LineageDependency, Edge
from modules.kernel.mssqlpuller import MssqlPuller

from dataclasses import replace


def get_connexion_string():
    server = 'dataops-db.database.windows.net'
    database = 'dataops'
    username = 'CloudSA3991b56c'
    password = 'f.QJ2B5xn$'
    driver = '{ODBC Driver 17 for SQL Server}'

    return 'DRIVER=' + driver + ';SERVER=' + server + ';DATABASE=' + database + ';UID=' + username + ';PWD=' + password


def get_nodes(mssql_puller: MssqlPuller) -> List[LineageNode]:
    sql_query = """
    select 
            
            last_updated as 'context_last_ingestion_ts' ,
            project_name,
            dataset_name,
            landing_zone,
            sli_condition_secs as 'context_condition_reference'
            from (
            select context_id ,
            metric_value as 'processing_finished_date',
            project_name,
            dataset_name,
            landing_zone,
            sli_condition_secs,
            DATEDIFF(SECOND,'1970-01-01', GETUTCDATE ()) - metric_value as 'last_updated',
            
        
        rn from (
            select *, ROW_NUMBER() OVER(PARTITION BY context_id ORDER BY timestamp desc) as 'rn'
             from [dataops].[event]
            where metric_name = 'processing_finished_date'
        ) AS AA
        
        LEFT JOIN (
            select context_id as 'reference', metric_value as 'sli_condition_secs'
            from [dataops].[datasetsRef] where metric_name = 'sli_condition_secs' and metric_value IS NOT NULL
        ) AS BB
        ON AA.context_id = BB.reference 
        WHERE AA.rn = 1 
        ) CC

    """
    nodes_from_events_list = mssql_puller.query_from_str(query=sql_query)
    nodes_list = [LineageNode(**row) for row in nodes_from_events_list]

    return nodes_list


def get_auto_dependencies_from_events(mssql_puller: MssqlPuller) -> List[LineageDependency]:
    sql_query = 'select distinct project_name , dataset_name, landing_zone, takeoff_zone from [dataops].[event]' \
                ' where metric_name = \'processing_finished_date\' '
    lineage_edge_list = mssql_puller.query_from_str(query=sql_query)
    lineage_edge_list = [LineageDependency.from_event(**row) for row in lineage_edge_list]

    return lineage_edge_list


def get_products_nodes(mssql_puller: MssqlPuller) -> List[LineageNode]:
    sql_query = "SELECT DISTINCT [project_name] ,[dataset_name] ,[landing_zone] FROM [dataops].[dependecies]" \
                " where landing_zone = 'gold'"

    products_list = mssql_puller.query_from_str(query=sql_query)
    nodes_list = [LineageNode(**row) for row in products_list]

    return nodes_list


def get_edges(mssql_puller: MssqlPuller) -> List[Edge]:
    sql_query = 'select DISTINCT context_id, dependency_context_id from [dataops].[dependecies]'
    edges_list = mssql_puller.query_from_str(query=sql_query)
    edges_list = [Edge(source_id=row.get('dependency_context_id'),
                       destination_id=row.get('context_id')) for row in edges_list]
    return edges_list


def update_dependencies(connexion):
    current_ts = int(datetime.datetime.now(tz=datetime.timezone.utc).timestamp())

    cursor = connexion.cursor()
    puller = MssqlPuller(connexion_pyodbc=connexion)

    lineage_dependencies = get_auto_dependencies_from_events(mssql_puller=puller)
    queries = [row.to_sql(table_name='[dataops].[dependecies]') for row in lineage_dependencies]
    __ = [cursor.execute(query) for query in queries]

    cursor.commit()

    clean_up_query = f'delete from [dataops].[dependecies] where timestamps < {current_ts}' \
                     f' and dependency_metric_name = \'auto_dependency\' '
    cursor.execute(clean_up_query)
    cursor.commit()
    cursor.close()


def update_nodes(nodes: List[LineageNode], products: List[LineageNode], edges: List[Edge], connexion, current_ts):
    cursor = connexion.cursor()

    clean_up_query = f'delete from [dataops].[nodes] where timestamp < {current_ts} '
    cursor.execute(clean_up_query)

    nodes_contexts = [row.context_id for row in nodes] + [row.context_id for row in products]
    edges_context = [(edge.source_id, edge.destination_id) for edge in edges]

    graph: nx.DiGraph = nx.DiGraph()
    graph.add_nodes_from(nodes_contexts), graph.add_edges_from(edges_context)

    for combo in list(itertools.product(nodes, products)):
        node, product = combo
        link = nx.has_path(graph, node.context_id, product.context_id)
        if link:
            node.add_product(product_name=product.context_id)

    nodes_sl = [node for node in nodes if
                node.landing_zone == 'silver' and len(node.context_products) > 0
                and node.dataset_name in ['lfa1', 'lfb1', 'adrc']]
    br, edges, mino = [], [], []

    print(len(nodes_sl))

    for node in nodes_sl:
        copy = LineageNode(project_name=node.project_name,
                           dataset_name=node.dataset_name,
                           landing_zone='bronze',
                           context_products=node.context_products)

        event = {'project_name': node.project_name, 'dataset_name': node.dataset_name,
                 'landing_zone': 'silver', 'takeoff_zone': 'bronze'
                 }
        edge = LineageDependency.from_event(**event)

        br.append(copy)
        edges.append(edge)
        if node.context_status is not None:
            mino.append(node.context_status)

    for x in products:
        x.context_status = min(mino)

    [cursor.execute(node.to_sql(table_name='[dataops].[nodes]')) for node in nodes_sl]
    [cursor.execute(node.to_sql(table_name='[dataops].[nodes]')) for node in br]
    [cursor.execute(node.to_sql(table_name='[dataops].[nodes]')) for node in products]

    [cursor.execute(edge.to_sql(table_name='[dataops].[dependecies]')) for edge in edges]

    cursor.commit()
    cursor.close()


if __name__ == "__main__":

    SLEEP_TIME_SEC = 120
    while True:
        print(datetime.datetime.utcnow())

        ts = int(datetime.datetime.now(tz=datetime.timezone.utc).timestamp()) - 60
        connexion = pyodbc.connect(get_connexion_string())
        puller = MssqlPuller(connexion_pyodbc=connexion)

        _____ = update_dependencies(connexion=connexion)

        nodes, products = get_nodes(mssql_puller=puller), get_products_nodes(mssql_puller=puller)
        edges = get_edges(mssql_puller=puller)

        #
        update_nodes(nodes=nodes, products=products, edges=edges, connexion=connexion, current_ts=ts)

        connexion.close()

        time.sleep(SLEEP_TIME_SEC)
        print(datetime.datetime.utcnow())
