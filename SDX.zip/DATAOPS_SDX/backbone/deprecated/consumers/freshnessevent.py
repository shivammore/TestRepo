import logging
import sys
from abc import ABC
import dataclasses
from typing import Dict,  Any
from modules.abstract.consumer import Consumer
from modules.dataclasses.freshness import FreshnessMetric

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
logger.addHandler(logging.StreamHandler(sys.stdout))

class FreshnessEventHandler(Consumer, ABC):
    SCHEMA = {
        'metadatas': {

            'type': 'dict',

            'required': True

        },

        'contexts': {

            'type': 'dict',

            'schema': {

                'job_id': {'required': True},

                'event_type': {'type': 'string', 'required': True},

                'project_name': {'type': 'string', 'required': True},

                'dataset_name': {'type': 'string', 'required': True},

                'publisher_name': {'type': 'string', 'required': True},

                'landing_zone': {'type': 'string', 'required': True},

                'takeoff_zone': {'type': 'string', 'required': True},

            },

            'required': True

        },

        "metrics": {

            'type': 'dict',

            'required': True

        }

    }

    ALLOW_UNKNOWN = True

    def __init__(self, table_name: str):

        self._table_name = table_name

    async def emit(self, event:  Dict[str, Any], meta_data: Dict = None) -> None:

        logger.info('-----------------------------')
        logger.info(event)
        return None
        freshness_context = {k: v for k, v in event.items() if k in self.SCHEMA.keys()}
        metrics_dict = {k: v for k, v in event.items() if k not in self.SCHEMA.keys()}
        metrics_list = [{'metric_name': k, 'metric_value': v} for k, v in metrics_dict.items()]

        metrics_list = [{**metric, **freshness_context} for metric in metrics_list]
        metrics_dataclass = [FreshnessMetric.from_dict(metric) for metric in metrics_list]

        # sql_values = [metric.__dict__.values() for metric in metrics_dataclass]
        logger.info([metric.to_dict() for metric in metrics_dataclass])
        #
        # fields = ', '.join(str(f.name).replace('/', '_') for f in dataclasses.fields(FreshnessMetric))
        #
        # sql_queries = [f'insert into {self._table_name}({fields}) values ({",".join([str(x) for x in value])})'
        #                for value in sql_values]
        # logger.info(sql_queries)
        # # logger.info("--------------")
        # # for query in sql_queries:
        # #     logger.info(query)
        # # logger.info("--------------")


