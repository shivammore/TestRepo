import datetime
import logging
import json
import sys
import time
from abc import ABC
from typing import Dict, List, Union, Any
from modules.abstract.consumer import Consumer
from modules.producers.asyncro.producer import Producer


logger = logging.getLogger(__name__)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
logger.addHandler(logging.StreamHandler(sys.stdout))


class DummyConsumer(Consumer, ABC):

    SCHEMA = {
        'publisher_name': {'type': 'string', 'required': True},
        'event_type': {'type': 'string', 'required': True}
    }

    ALLOW_UNKNOWN = True

    def __init__(self):
        pass

    async def emit(self, event:  Dict[str, Any], meta_data: Dict = None) -> None:
        eventhub_connection_str = "Endpoint=sb://data-dataops.servicebus.windows.net/;SharedAccessKeyName=" \
                                  "gatewaytosqldatabase-admin;SharedAccessKey=Vdbgk8DOIm9PU4B9LnOCgq3QIwKADxeVpn" \
                                  "4bcrFGkw4=;EntityPath=gatewaytosqldatabase"

        event_hub_name = "gatewaytosqldatabase"

        logger.info(f'DummyConsumer 1 Received Event {datetime.datetime.utcnow()}')
        producer = Producer.get_instance(connection_str=eventhub_connection_str,
                                         event_hub_name=event_hub_name,
                                         consumer_group='thibault')

        return await producer.publish(message=json.dumps(event))
