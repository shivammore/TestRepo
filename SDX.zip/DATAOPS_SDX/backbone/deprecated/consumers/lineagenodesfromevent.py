import logging
from abc import ABC

from typing import Dict

from deprecated import Consumer

logger = logging.getLogger(__name__)


class LineageNodeFromEventHandler(Consumer, ABC):
    SCHEMA = {

        'project_name': {'type': 'string', 'required': True},
        'dataset_name': {'type': 'string', 'required': True},
        'publisher_name': {'type': 'string', 'required': True},
        'landing_zone': {'type': 'string', 'required': True},
        'takeoff_zone': {'type': 'string', 'required': True},

    }

    ALLOW_UNKNOWN = True

    def emit(self, event: Dict) -> None:
        # @todo
        logger.info("Omar Deps")
        logger.info(event)
