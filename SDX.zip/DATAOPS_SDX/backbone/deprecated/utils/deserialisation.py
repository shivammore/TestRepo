from typing import List, Dict, Any, Union
import azure.functions as func
import json


def deserialization_events(events: Union[List[func.EventHubEvent], func.EventHubEvent]) -> List[Dict[str, Any]]:
    """

    """

    if isinstance(events, func.EventHubEvent):

        events_json = json.loads(events.get_body().decode('utf-8'))
        events_json = [events_json] if isinstance(events_json, list) else [[events_json]]
    else:
        events_json = [json.loads(event.get_body().decode('utf-8')) for event in events]
        events_json = [event if isinstance(event, list) else [event] for event in events_json]

    return [event for sub_events_json in events_json for event in sub_events_json]
