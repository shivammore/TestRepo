from abc import ABC, abstractmethod
from typing import Dict, Union, List


class Consumer(ABC):
    """
    an abstract class that all the consumer need to implement
    """

    SCHEMA: Dict = {}
    ALLOW_UNKNOWN: bool = False

    @abstractmethod
    async def emit(self, event: Union[List, Dict], meta_data: Dict = None) -> None:
        raise NotImplementedError("Please Implement this method")
