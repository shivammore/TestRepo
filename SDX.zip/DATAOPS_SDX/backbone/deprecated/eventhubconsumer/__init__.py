import asyncio

from modules.kernel.asyncro.batch_consumer import AsyncEventhubDispatcher

from modules.consumers.sql.freshnessevent import FreshnessEventHandler


if __name__ == '__main__':

    eventhub_name = "omartest"
    consumer_group = "$Default"
    eventhub_connection_str = "Endpoint=sb://data-dataops.servicebus.windows.net/;" \
                              "SharedAccessKeyName=admin_user;SharedAccessKey=FHuVbE3LDBxriVY//" \
                              "EdpqRWC6dfWHoIbFJPeS2NoOn0=;EntityPath=omartest"

    async_dispatcher = AsyncEventhubDispatcher(
        connection_string=eventhub_connection_str,
        eventhub_name=eventhub_name,
        consumer_group=consumer_group,
    )
    event_consumer = FreshnessEventHandler(table_name="Thibault.event")
    async_dispatcher.add_consumer(consumer=event_consumer)

    asyncio.run(async_dispatcher.listen())