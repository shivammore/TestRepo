from modules.abstract.consumer import Consumer
from modules.utils.singleton import Singleton
from modules.utils.verbose import verbose

from typing import Dict, List, Union, Any
from dataclasses import dataclass
from cerberus import Validator

import logging
import json

logger = logging.getLogger(__name__)
YamlExpression, JsonExpression = str, str


@dataclass
class ConsumerSchemaTuple:
    consumer: Consumer
    validator: Validator = None


@Singleton
class Dispatcher:
    """
    A non thread safe app that handle, format and forward pub/sub events to consumers
    """
    __consumers_tuples: List[ConsumerSchemaTuple] = []

    def __init__(self):
        pass

    @verbose(logger=logger, tags={'class_name': 'dispatcher'})
    def load_from_json(self, json_expression: str) -> Union[List, Dict]:
        """
        load from a json expression into python dict or list
        :param json_expression: yaml str expression to evaluate
        :return: python dict or list
        """
        return json.loads(json_expression)

    def add_consumer(self, consumer: Consumer) -> None:
        """
        add an event consumer , if schema matched the event he will be notified
        :param consumer: consumer that handle the event (implement the consumer abstract class)
        :return: None
        """
        consumer_tuple = ConsumerSchemaTuple(
            consumer=consumer,
            validator=Validator(consumer.SCHEMA, allow_unknown=consumer.ALLOW_UNKNOWN),
        )
        self.__consumers_tuples.append(consumer_tuple)

    def notify(self, events: List[Dict[str, Any]]):
        """
        convert and notify the concerned consumers about the message
        :param events: str that will be cast into a python object
        :return: None
        """
        logger.info(f'Dispatcher events {type(events)}')
        logger.info(events)
        logger.info("-----------------------")
        events = events if isinstance(events, list) else [events]
        logger.info(f' Dispatcher events {type(events)}')
        logger.info(events)
        return [self.notify_by_event(event=event) for event in events]

    def notify_by_event(self, event: Dict):
        """

        """
        filtered_consumers = [_tuple.consumer for _tuple in self.__consumers_tuples if _tuple.validator.validate(event)]

        logger.info('event')
        logger.info(filtered_consumers)
        logger.info(event)
        return [self.notify_consumer(consumer=consumer, event=event) for consumer in filtered_consumers]

    def notify_consumer(self, consumer: Consumer, event: Union[List, Dict]):
        """
        an error safe execution method that notify the consumer
        :param consumer: the
        :param event: event that matched the consumer schema
        :return:
        """

        logger.info(event)
        return consumer.emit(event=event)
