## Overview
***

Metricsmssqlconsumer directory enables to create a container consumer to consume data in eventhub and write it in mssql backend. The directory contains two main files:
- Dockerfile: describe the build step to create the container
- \_\_init__.py: contains the main function of the application

Metricsmssqlconsumer has in input an event, check the event schema, parse it, process it and write to mssql backend. The event schema processed is :
```json
{
  'metadata': 
  {
    'timestamp':'number',
  },
  'contexts': 
  {
    'job_id':'string',
    'event_type':'string',
    'project_name':'string', 
    'dataset_name':'string', 
    'publisher_name':'string', 
    'landing_zone':'string', 
    'takeoff_zone':'string', 
    'kind':'string',
  },
  "metrics": 
  {
    'content_latest_date':'numerical',
    'content_oldest_date':'numerical', 
    'delta_content_latest_date':'numerical',
    'delta_content_oldest_date':'numerical',
    'processing_started_date':'numerical',
    'processing_finished_date':'numerical',
    'processing_exit_code':'numerical',
    'rejected_records':'numerical',
    'rows_count':'numerical',
    'columns_count':'numerical',
    'file_size':'numerical',
    'file_creation_date':'numerical',
    'file_last_modification_date':'numerical',
    'file_format':'string',
  }
}
```
For every metrics in this event a row is inserted in mssql backend: 

| timestamp  | publisher_name     | project_name    | dataset_name | landing_zone | takeoff_zone | event_type        | kind     | job_id                                         | metric_name             | metric_value     | dataset_id                      | context_id            |
|------------|--------------------|-----------------|--------------|--------------|--------------|-------------------|----------|------------------------------------------------|-------------------------|------------------|---------------------------------|-----------------------|
| 1672050352 | data_core_services | oss.fr.fr.jes   | activities   | bronze       | silver       | processingstarted | table    | oss_fr_fr_jes:staging_to_bronze:1234           | processing_started_date | 1672050352.00604 | oss.fr.fr.jes_activities_bronze | -1099149791672050352  |     
| 1672050355 | data_core_services | oss.fr.fr.jes   | tickets      | bronze       | staging      | processingstarted | table    | oss_fr_fr_jes:staging_to_bronze:3-ee6051bc515a | processing_started_date | 1672050355.65566 | oss.fr.fr.jes_tickets_bronze    | -11380243851672050355 |
 | ...        | ...                | ...             | ...          | ...          | ...          | ...               | ...      | ...                                            | ...                     | ...              | ...                             | ...                   |



## Code architecture
***

The main architecture focus is to provide a tech dependency free, transparent & dev friendly. This application is divided in three main piece:
- A consumer: it must implement an abstract async consumer (AsyncEventhubConsumer) that consume event in eventhub. Only the method on_event_batch_processing is overwrite to provide custom processed to write in mssql. 
- A validator: At first the event schema is parsed and validated by cerberus package in the consumer and then data is validated by a dataclass (FreshnessMetric).
- A mssql connection manager: Context manager to handle azureSQL db connection

