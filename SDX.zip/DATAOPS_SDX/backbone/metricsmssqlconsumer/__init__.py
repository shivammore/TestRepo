import os
import sys
import logging
from modules.consumers.freshnessevent import MetricsToSqlConsumer


if __name__ == '__main__':
    # create logger
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    # create console handler and set level to debug
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)
    # create formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    # add formatter to ch
    ch.setFormatter(formatter)
    # add ch to logger
    logger.addHandler(ch)
    logger.info("--------------")
    logger.info(os.environ['MSSQL_CONNECTION_STR'])

    # Eventhub info
    eventhub_name = os.environ['EVENT_HUB_NAME_SPACE']
    consumer_group = os.environ['EVENT_HUB_CONSUMER_GROUP']
    eventhub_connection_str = os.environ['EVENT_HUB_CONNEXION_STR']

    retry_total = 5
    retry_backoff_factor = 1
    retry_mode = 'exponential'
    # Eventhub checkpoint info

    storage_connection_str = os.environ['EVENT_HUB_STORAGE_CONNECTION_STR']
    blob_container_name = os.environ['EVENT_HUB_STORAGE_CONTAINER_NAME']  # Please make sure the blob container
    # resource exists.

    # Mssql info
    table_name = os.environ['MSSQL_TABLE_NAME']
    mssql_connection_string = os.environ['MSSQL_CONNECTION_STR']

    test = MetricsToSqlConsumer(
        connection_string=eventhub_connection_str,
        consumer_group=consumer_group,
        eventhub_name=eventhub_name,
        retry_total=retry_total,
        retry_mode=retry_mode,
        retry_backoff_factor=retry_backoff_factor,
        storage_connection_str=storage_connection_str,
        blob_container_name=blob_container_name,
        table_name=table_name,
        mssql_connection_string=mssql_connection_string
    )
    test.run_async_listen()
