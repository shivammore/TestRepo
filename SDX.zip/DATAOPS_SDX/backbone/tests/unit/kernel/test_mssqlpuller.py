import unittest
from modules.kernel.mssqlpuller import MssqlPuller
from unittest.mock import MagicMock

tested_module = "modules.kernel.mssqlpuller."


class TestMssqlPuller(unittest.TestCase):
    def setUp(self, *_) -> None:
        dbc = MagicMock(name="mssql_conn")
        cursor = MagicMock(name="cursor")
        cursor.description = (('project_name', "<class 'str'>", None, 255, 255, 0, False),
                              ('dataset_name', "<class 'str'>", None, 255, 255, 0, False))
        cursor.fetchall.return_value = [('oss.uki.gb.fourth', 'ingredients'),
                                        ('oss.uki.gb.fourth', 'ingredientspricebands')]
        dbc.cursor.return_value = cursor

        self.obj = MssqlPuller(dbc)

    def test_query_from_str(self):
        """
        Test query_from_str() method
        """
        result = self.obj.query_from_str("select * from test")
        assert result == [{'dataset_name': 'ingredients', 'project_name': 'oss.uki.gb.fourth'},
                          {'project_name': 'oss.uki.gb.fourth', 'dataset_name': 'ingredientspricebands'}]

    # TODO
    def test_query_from_dict(self):
        pass
