import pyodbc
import unittest
import pytest
import os
import logging
from unittest import mock
from unittest.mock import patch, PropertyMock
from modules.kernel.dbhandler import AzureSQLConnectorManager, AzureSQLConnectionManager

tested_module = "modules.kernel.mssqlpuller."


class TestAzureSQLConnectorManager:
    """
    Test class for AzureSQLConnectorManager
    """

    @pytest.fixture
    def _connection_string(self):
        return "DRIVER={ODBC Driver 17 for SQL Server};SERVER=tcp:test.database.windows.net,1433;DATABASE=test"

    @pytest.fixture
    def access_token(self):
        return "my_token"

    def test_context_handler_connection(self, _connection_string):
        """
        Test create connection and close connection with the context manager
        """
        with mock.patch("pyodbc.connect") as mock_connect:
            with AzureSQLConnectorManager(connection_string=_connection_string) as conn:
                mock_connect.assert_called_once_with(_connection_string)
                assert conn == mock_connect.return_value
                conn.close.assert_not_called()

            conn.close.assert_called_once()

    @mock.patch.dict(os.environ, {"MSI_SECRET": "test_msi"})
    def test_create_connection_with_msi(self, _connection_string):
        """
        Test create connection with token
        """
        with mock.patch("pyodbc.connect") as mock_connect:
            with AzureSQLConnectorManager(connection_string=_connection_string) as conn:
                mock_connect.assert_called_once_with(_connection_string + ";Authentication=ActiveDirectoryMsi")
                assert conn == mock_connect.return_value

            conn.close.assert_called_once()

    def test_create_connection_with_token(self, _connection_string, access_token, caplog):
        """
        Test create connection with token
        """
        caplog.set_level(logging.INFO)
        with mock.patch("pyodbc.connect") as mock_connect:
            with AzureSQLConnectorManager(connection_string=_connection_string, access_token=access_token) as conn:
                assert "token" in caplog.text
                assert conn == mock_connect.return_value

            conn.close.assert_called_once()

    def test_exit_without_exception(self, _connection_string):
        """
        Test __exit__ method
        """
        with mock.patch("pyodbc.connect") as mock_connect:
            with AzureSQLConnectorManager(connection_string=_connection_string) as conn:
                mock_connect.assert_called_once_with(_connection_string)

            conn.commit.assert_called_once()
            conn.close.assert_called_once()

    def test_exit_with_exception(self, _connection_string):
        """
        Test __exit__ method with exception
        """
        with mock.patch("pyodbc.connect") as mock_connect:
            with pytest.raises(Exception):
                with AzureSQLConnectorManager(connection_string=_connection_string) as conn:
                    mock_connect.assert_called_once_with(_connection_string)
                    raise
            conn.rollback.assert_called_once()
            conn.close.assert_called_once()


class TestAzureSQLConnectionManager(unittest.TestCase):
    @patch('modules.kernel.dbhandler.AzureSQLConnectorManager.create_connection', return_value="first connection")
    def test_singleton_can_be_instantiated_once(self, mock_create_connection):
        """
        Test is singleton is instanciared once
        """
        azure_singleton1_sql_connection_manager = AzureSQLConnectionManager()
        azure_singleton2_sql_connection_manager = AzureSQLConnectionManager()
        assert azure_singleton1_sql_connection_manager is not None
        assert azure_singleton1_sql_connection_manager.get_connection() is not None
        assert azure_singleton1_sql_connection_manager is azure_singleton2_sql_connection_manager
        assert azure_singleton1_sql_connection_manager.get_connection() == azure_singleton2_sql_connection_manager.get_connection()

        del azure_singleton1_sql_connection_manager
        del azure_singleton2_sql_connection_manager

    @patch('modules.kernel.dbhandler.AzureSQLConnectorManager.create_connection', return_value="first connection")
    def test_close_connection(self, mock_create_connection):
        """
        Test close_connection() method
        """
        azure_singleton_sql_connection_manager = AzureSQLConnectionManager()
        assert azure_singleton_sql_connection_manager.get_connection() is not None
        assert azure_singleton_sql_connection_manager.get_conn() is not None
        azure_singleton_sql_connection_manager.close_connection()
        assert azure_singleton_sql_connection_manager.get_conn() is None

        del azure_singleton_sql_connection_manager

    def test_reset_connection_if_broken(self):
        """
        Test reset_connection_if_broken() method
        """
        with mock.patch("modules.kernel.dbhandler.AzureSQLConnectorManager.create_connection",
                        return_value="first connection"):
            azure_singleton_sql_connection_manager = AzureSQLConnectionManager()
            azure_singleton_sql_connection_manager.get_connection()
            conn1 = azure_singleton_sql_connection_manager.get_conn()
            assert conn1 is not None

        with mock.patch("modules.kernel.dbhandler.AzureSQLConnectorManager.create_connection",
                        return_value="second connection"):
            azure_singleton_sql_connection_manager.reset_connection_if_broken()
            conn2 = azure_singleton_sql_connection_manager.get_conn()
            assert conn2 is not None

        assert conn1 != conn2
        del azure_singleton_sql_connection_manager

    @patch.object(AzureSQLConnectionManager, '_AzureSQLConnectionManager__connection', new_callable=PropertyMock)
    def test_execute_insertquery_ok(self, private_mock):
        """
        Test ok execute_insertquery() method
        """
        query = "INSERT INTO table (a, b) VALUES (?, ?)"
        params = [(1, 2), (3, 4), (5, 6)]

        with mock.patch("pyodbc.connect") as mock_connect:
            azure_singleton_sql_connection_manager = AzureSQLConnectionManager()
            azure_singleton_sql_connection_manager.get_connection()
            azure_singleton_sql_connection_manager.execute_insertquery(query, params)
            private_mock().commit.assert_called_once()

            del azure_singleton_sql_connection_manager

    def test_execute_insertquery_ko(self):
        """
        Test ko execute_insertquery() method
        """
        query = "INSERT INTO table (a, b) VALUES (?, ?)"
        params = [(1, 2), (3, 4), (5, 6)]

        with mock.patch("pyodbc.connect") as mock_connect:
            with mock.patch.object(AzureSQLConnectionManager, '_AzureSQLConnectionManager__connection', new_callable=PropertyMock, return_value=mock_connect):
                mock_connect.commit.side_effect = pyodbc.Error
                azure_singleton_sql_connection_manager = AzureSQLConnectionManager()
                azure_singleton_sql_connection_manager.get_connection()
                azure_singleton_sql_connection_manager.execute_insertquery(query, params)

        mock_connect.rollback.assert_called_once()
        del azure_singleton_sql_connection_manager
