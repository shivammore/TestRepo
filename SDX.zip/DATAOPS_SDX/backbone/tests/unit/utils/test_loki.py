import pytest
import logging
from unittest import TestCase
from unittest.mock import patch
from modules.utils.loki import LokiLogger

tested_module = "modules.dataops.loki."

dummy = LokiLogger('https://test')


class TestLokiLogger(TestCase):
    def setUp(self):
        self.url = "http://localhost:3100/loki/api/v1/push"
        self.labels = {
            "test": "test"
        }
        self.logger = LokiLogger(self.url)

    def tearDown(self):
        self.logger = None

    @patch("logging.getLogger")
    def test_init(self, mock_logger):
        """
        Test create loki instance
        """
        self.logger.__init__(self.url)
        mock_logger.assert_called_with("Logger_push")
        mock_logger().addHandler.assert_called_once_with(self.logger.handler)
        mock_logger().setLevel.assert_called_once_with(logging.DEBUG)

    @patch('logging.Logger.error')
    @patch('logging.Logger.warning')
    @patch('logging.Logger.debug')
    @patch('logging.Logger.critical')
    @patch('logging.Logger.info')
    def test_log_publish_info(self, mock_info, mock_critical, mock_debug, mock_warning, mock_error):
        """
        Test log_publish() method with info
        """
        level = "info"
        message = "This is a test message: {}".format(level)

        self.logger.log_publish(self.labels, message, level)
        mock_info.assert_called_once_with(
            message,
            extra={"tags": self.labels}
        )
        mock_critical.assert_not_called
        mock_debug.assert_not_called
        mock_warning.assert_not_called
        mock_error.assert_not_called

    @patch('logging.Logger.error')
    @patch('logging.Logger.warning')
    @patch('logging.Logger.debug')
    @patch('logging.Logger.critical')
    @patch('logging.Logger.info')
    def test_log_publish_error(self, mock_info, mock_critical, mock_debug, mock_warning, mock_error):
        """
        Test log_publish() method with error
        """
        level = "error"
        message = "This is a test message: {}".format(level)

        self.logger.log_publish(self.labels, message, level)
        mock_error.assert_called_once_with(
            message,
            extra={"tags": self.labels}
        )
        mock_critical.assert_not_called
        mock_debug.assert_not_called
        mock_warning.assert_not_called
        mock_info.assert_not_called

    @patch('logging.Logger.error')
    @patch('logging.Logger.warning')
    @patch('logging.Logger.debug')
    @patch('logging.Logger.critical')
    @patch('logging.Logger.info')
    def test_log_publish_warning(self, mock_info, mock_critical, mock_debug, mock_warning, mock_error):
        """
        Test log_publish() method with warning
        """
        level = "warning"
        message = "This is a test message: {}".format(level)

        self.logger.log_publish(self.labels, message, level)
        mock_warning.assert_called_once_with(
            message,
            extra={"tags": self.labels}
        )
        mock_critical.assert_not_called
        mock_debug.assert_not_called
        mock_info.assert_not_called
        mock_error.assert_not_called

    @patch('logging.Logger.error')
    @patch('logging.Logger.warning')
    @patch('logging.Logger.debug')
    @patch('logging.Logger.critical')
    @patch('logging.Logger.info')
    def test_log_publish_debug(self, mock_info, mock_critical, mock_debug, mock_warning, mock_error):
        """
        Test log_publish() method with warning
        """
        level = "debug"
        message = "This is a test message: {}".format(level)

        self.logger.log_publish(self.labels, message, level)
        mock_debug.assert_called_once_with(
            message,
            extra={"tags": self.labels}
        )
        mock_critical.assert_not_called
        mock_info.assert_not_called
        mock_warning.assert_not_called
        mock_error.assert_not_called

    @patch('logging.Logger.error')
    @patch('logging.Logger.warning')
    @patch('logging.Logger.debug')
    @patch('logging.Logger.critical')
    @patch('logging.Logger.info')
    def test_log_publish_critical(self, mock_info, mock_critical, mock_debug, mock_warning, mock_error):
        """
        Test log_publish() method with warning
        """
        level = "critical"
        message = "This is a test message: {}".format(level)

        self.logger.log_publish(self.labels, message, level)
        mock_critical.assert_called_once_with(
            message,
            extra={"tags": self.labels}
        )
        mock_info.assert_not_called
        mock_debug.assert_not_called
        mock_warning.assert_not_called
        mock_error.assert_not_called
