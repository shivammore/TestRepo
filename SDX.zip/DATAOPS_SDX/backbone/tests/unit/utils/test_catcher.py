import logging
import sys
import warnings
import unittest
import pytest
from modules.utils.catcher import catch

tested_module = "modules.dataops.catcher."

# create logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)
# create console handler and set level to debug
ch = logging.StreamHandler(sys.stdout)
ch.setLevel(logging.INFO)
# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# add formatter to ch
ch.setFormatter(formatter)
# add ch to logger
logger.addHandler(ch)


class Dummy:
    @catch(logger, raise_exception=True)
    def no_error_raise_True(self):
        return "expected_result"

    @catch(logger, raise_exception=False)
    def no_error_raise_False(self):
        return "expected_result"

    @catch(logger, raise_exception=True)
    def error_raise_True(self):
        raise AttributeError()

    @catch(logger, raise_exception=False)
    def error_raise_False(self):
        raise AttributeError()


dummy = Dummy()


def test_safe_run_raise_exception(caplog):
    """
    Test catch decorator with a safe run.jsonnet and raise_exeption = True
    """
    caplog.set_level(logging.INFO)
    dummy.no_error_raise_True()
    assert caplog.text == ''


def test_safe_run_noraise_exception(caplog):
    """
    Test catch decorator with a safe run.jsonnet and raise_exeption = False
    """
    caplog.set_level(logging.INFO)
    dummy.no_error_raise_False()
    assert caplog.text == ''


def test_raise_noraise_exception(caplog):
    """
    TODO
    Test catch decorator with an error raised and raise_exeption = False
    """
    pass


def test_raise_raise_exception(caplog):
    """
    TODO
    Test catch decorator with an error raised and raise_exeption = True
    """
    pass
