import logging
import pytest
from modules.utils.verbose import verbose

tested_module = "modules.dataops.verbose."
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)
logger.propagate = True


class Dummy:
    @verbose(logger=logger, tags={'class': 'Dummy', 'function': 'noerror_raise'})
    def noerror_raise(self):
        return "expected_result"

    @verbose(logger=logger, tags={'class': 'Dummy', 'function': 'error_raise'})
    def error_raise(self):
        raise AttributeError()


dummy = Dummy()


def test_safe_run(caplog):
    """
    Test verbose decorator with a safe run.jsonnet
    """
    caplog.set_level(logging.DEBUG)
    dummy.noerror_raise()
    assert "DEBUG" in caplog.text
    assert "Executed 'noerror_raise' ( class=Dummy,  function=noerror_raise,  Duration=" in caplog.text


def test_raise(caplog):
    """
    Test verbose decorator with an error raise
    """
    caplog.set_level(logging.INFO)
    with pytest.raises(AttributeError):
        dummy.error_raise()
    assert "" in caplog.text
