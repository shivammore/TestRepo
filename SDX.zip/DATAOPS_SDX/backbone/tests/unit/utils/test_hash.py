import pytest
from modules.utils.hash import compute_dataset_hash_id


@pytest.mark.parametrize(
    "project_name,dataset_name,landing_zone,expected",
    [
        pytest.param("oss.glb.sap.fr", "sap_articles_certificates", "staging", 600189214223049243),
        pytest.param("oss.glb.sap.fr", "sap_articles_certificates", "staging", 600189214223049243)
    ]
)
def test_string_compute_dataset_hash_id(project_name, dataset_name, landing_zone, expected):
    """
    Test compute_dataset_hash_id() function
    """
    assert compute_dataset_hash_id(project_name, dataset_name, landing_zone) == expected


@pytest.mark.parametrize(
    "project_name,dataset_name,landing_zone",
    [
        pytest.param("oss.glb.sap.fr".encode('utf-8'), "sap_articles_certificates".encode('utf-8'),
                     "staging".encode('utf-8')),
        pytest.param("oss.glb.sap.fr".encode('latin-1'), "sap_articles_certificates", "staging".encode('latin-1')),
        pytest.param("oss.glb.sap.fr", "sap_articles_certificates", True),
        pytest.param("oss.glb.sap.fr", "sap_articles_certificates", 10),
    ]
)
def test_nostring_compute_dataset_hash_id(project_name, dataset_name, landing_zone):
    """
    Test compute_dataset_hash_id() function
    """
    with pytest.raises(TypeError):
        compute_dataset_hash_id(project_name, dataset_name, landing_zone)

