import unittest
from unittest.mock import patch
from modules.utils.retry import retry_with_backoff, MaxTriesExceededError

tested_module = "modules.dataops.retry."


class TestRetryWithBackoff(unittest.TestCase):
    def setUp(self):
        self.count = 0

    @patch(f"{tested_module}retry_with_backoff")
    def test_retry_success_single_try(self, *_):
        """
        Test retry decorator with one retry
        """
        @retry_with_backoff(retries=1, backoff_in_seconds=0.001, stop=False)
        def to_be_decorated():
            self.count += 1
            return "expected_result"

        self.assertEqual(to_be_decorated(), "expected_result")
        self.assertEqual(self.count, 1)

    @patch(f"{tested_module}retry_with_backoff")
    def test_retry_success_third_tries(self, *_):
        """
        Test retry decorator with three retry
        """
        @retry_with_backoff(retries=3, backoff_in_seconds=0.001, stop=False)
        def to_be_decorated():
            self.count += 1
            return "expected_result"

        self.assertEqual(to_be_decorated(), "expected_result")
        self.assertEqual(self.count, 1)

    @patch(f"{tested_module}retry_with_backoff")
    def test_retry_failure_two_tries_withstopfalse(self, *_):
        """
        Test retry decorator with option: stop = false
        """
        @retry_with_backoff(retries=2, backoff_in_seconds=0.001, stop=False)
        def to_be_decorated():
            self.count += 1
            raise Exception()

        try:
            to_be_decorated()
            self.assertEqual(self.count, 2)
        except MaxTriesExceededError:
            self.assertEqual(self.count, 2)

    @patch(f"{tested_module}retry_with_backoff")
    def test_retry_failure_two_tries_withstoptrue(self, *_):
        """
        Test retry decorator with option: stop = true
        """
        @retry_with_backoff(retries=2, backoff_in_seconds=0.001, stop=True)
        def to_be_decorated():
            self.count += 1
            raise Exception()

        try:
            to_be_decorated()
        except MaxTriesExceededError:
            self.assertEqual(self.count, 2)
