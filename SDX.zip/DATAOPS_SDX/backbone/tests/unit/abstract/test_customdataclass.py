from modules.abstract.customdataclass import MyDataclass
import dataclasses
import pytest

tested_module = "modules.abstract.customdataclass."


@dataclasses.dataclass
class Dummy(MyDataclass):
    name: str
    number: int
    number_float: float
    boolean: bool
    list: list
    dict: dict


@pytest.mark.parametrize(
    "tested,expected",
    [
        pytest.param(
            Dummy.from_dict({'name': 'dummy', 'number': 1, 'number_float': 10.02, 'boolean': True, 'list': [1, 2, 3],
                             'dict': {'name': 'toto'}}),
            Dummy(name="dummy", number=1, number_float=10.02, boolean=True, list=[1, 2, 3], dict={'name': 'toto'})
        ),
    ]
)
def test_from_dict_ok(tested, expected):
    """
    Test create dataclass from dict in MyDataclass
    """
    tested.valid_type(tested)
    assert tested == expected


@pytest.mark.parametrize(
    "tested",
    [
        pytest.param({'name': 0, 'number': 1, 'number_float': 10.02, 'boolean': True, 'list': [1, 2, 3], 'dict': {'name': 'toto'}}),
        pytest.param({'name': 'dummy', 'number': 'hello', 'number_float': 10.02, 'boolean': True, 'list': [1, 2, 3], 'dict': {'name': 'toto'}}),
        pytest.param({'name': 'dummy', 'number': 1, 'number_float': True, 'boolean': True, 'list': [1, 2, 3], 'dict': {'name': 'toto'}}),
        pytest.param({'name': 'dummy', 'number': 1, 'number_float': 10.02, 'boolean': [1], 'list': [1, 2, 3], 'dict': {'name': 'toto'}}),
        pytest.param({'name': 'dummy', 'number': 1, 'number_float': 10.02, 'boolean': True, 'list': {}, 'dict': {'name': 'toto'}}),
        pytest.param({'name': 'dummy', 'number': 1, 'number_float': 10.02, 'boolean': True, 'list': {}, 'dict': False}),
    ]
)
def test_valid_type(tested):
    """
    Test valid_type method MyDataclass
    """
    with pytest.raises(TypeError):
        Dummy.valid_type(Dummy.from_dict(tested))


# TODO
def test_to_dict():
    pass
