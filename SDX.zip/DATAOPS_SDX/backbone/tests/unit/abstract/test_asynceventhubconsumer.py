import logging
from typing import List
from modules.abstract.asynceventhubconsumer import AsyncEventhubConsumer, EventMetaDataTuple
from azure.eventhub import EventData
import pytest
from unittest.mock import AsyncMock, MagicMock

tested_module = "modules.abstract.asynceventhubconsumer."


class Dummy(AsyncEventhubConsumer):
    async def on_event_batch_processing(self, events_metadatalist: List[EventMetaDataTuple]):
        return events_metadatalist


@pytest.mark.asyncio
async def test_on_event_batch_size_0(caplog):
    """
    Test AsyncEventhubConsumer with batch size of 0
    """
    eventhub_consumer = Dummy(connection_string='test', consumer_group='test', eventhub_name='test',
                              storage_connection_str='test', blob_container_name='test')
    partition_context = AsyncMock()
    partition_context.update_checkpoint = AsyncMock()
    partition_context.partition_id = 0
    caplog.set_level(logging.INFO)
    await eventhub_consumer.on_event_batch(partition_context, [])
    assert "INFO     root:asynceventhubconsumer.py:105 Partition 0, Received events count: 0" in caplog.text


@pytest.mark.asyncio
async def test_on_event_batch_size_2(caplog):
    """
    Test AsyncEventhubConsumer with batch size of 2
    """
    eventhub_consumer = Dummy(connection_string='test', consumer_group='test', eventhub_name='test',
                              storage_connection_str='test', blob_container_name='test')
    partition_context = MagicMock()
    partition_context.update_checkpoint = AsyncMock()
    partition_context.partition_id = 0
    event_data1 = MagicMock()
    event_data2 = MagicMock()
    caplog.set_level(logging.INFO)
    await eventhub_consumer.on_event_batch(partition_context, [event_data1, event_data2])
    assert "INFO     root:asynceventhubconsumer.py:105 Partition 0, Received events count: 2" in caplog.text


def test_load_dict_from_event():
    """
    Test load_dict_from_event() function in AsyncEventhubConsumer
    """
    eventhub_consumer = Dummy(connection_string='test', consumer_group='test', eventhub_name='test',
                              storage_connection_str='test', blob_container_name='test')
    tested = EventData(
        body='{"metadata": {"timestamp": 1673441647.888195, "timezone": "epochutc"}, "contexts": {"publisher_name": "publisher1", "event_type": "ProcessingFinished", "project_name": "project5", "dataset_name": "dataset2", "landing_zone": "silver", "takeoff_zone": "bronze", "job_id": "app_1373592073", "kind": "table"}, "metrics": {"content_latest_date": 1673441647.889012, "content_oldest_date": 1665665647.889012, "delta_content_latest_date": 1673441647.8890123, "delta_content_oldest_date": 1673441647.8890123, "processing_started_date": 1673440447.889012, "processing_finished_date": 1673441647.889012, "rows_count": 180, "columns_count": 4, "processing_exit_code": 0}, "logs": [{"timestamp": null, "message": "Hello world", "level": "DEBUG"}, {"timestamp": null, "message": "Hello world", "level": "ERROR"}]}')
    t = eventhub_consumer.load_dict_from_event(tested)
    assert t.Event == {"metadata": {"timestamp": 1673441647.888195, "timezone": "epochutc"},
                       "contexts": {"publisher_name": "publisher1", "event_type": "ProcessingFinished",
                                    "project_name": "project5", "dataset_name": "dataset2", "landing_zone": "silver",
                                    "takeoff_zone": "bronze", "job_id": "app_1373592073", "kind": "table"},
                       "metrics": {"content_latest_date": 1673441647.889012, "content_oldest_date": 1665665647.889012,
                                   "delta_content_latest_date": 1673441647.8890123,
                                   "delta_content_oldest_date": 1673441647.8890123,
                                   "processing_started_date": 1673440447.889012,
                                   "processing_finished_date": 1673441647.889012, "rows_count": 180, "columns_count": 4,
                                   "processing_exit_code": 0},
                       "logs": [{"timestamp": None, "message": "Hello world", "level": "DEBUG"},
                                {"timestamp": None, "message": "Hello world", "level": "ERROR"}]}
    assert t.MetaData is not None


def test_informatica_event():
    """
    Test load_dict_from_event() function in AsyncEventhubConsumer with informatica event
    """
    eventhub_consumer = Dummy(connection_string='test', consumer_group='test', eventhub_name='test',
                              storage_connection_str='test', blob_container_name='test')
    tested = EventData(
        body='{"metadata": {"timestamp": "1674054465"}, "contexts": {"publisher_name": "Informatica_mt_sap_azsql_T007A_data_load_full_Europe", "project_name": "SAP_Data_Ingestion_Europe", "dataset_name": "T007A", "landing_zone": "transient", "takeoff_zone": "DataSource", "event_type": "processing_end", "kind": "table", "job_id": "01181Q0Z000000000077_160_01181QC1000000006EQZ" }, "metrics": { "content_latest_date": null, "content_oldest_date": null, "delta_content_latest_date": null, "delta_content_oldest_date": null, "processing_started_date": "1673835472", "processing_finished_date": "1673835479", "processing_exit_code": "status_success", "rows_count": "1121", "columns_count": null },  "columns": {"column_name": "", "column_type": "", "column_min_observed_value": "", "column_max_observed_value": "", "column_lower_threshold": "", "column_upper_threshold": "", "Column_null_records_count": ""}}')
    t = eventhub_consumer.load_dict_from_event(tested)
    assert t.Event == {
        'metadata': {'timestamp': '1674054465'},
        'contexts': {
            'publisher_name': 'Informatica_mt_sap_azsql_T007A_data_load_full_Europe',
            'project_name': 'SAP_Data_Ingestion_Europe',
            'dataset_name': 'T007A',
            'landing_zone': 'transient',
            'takeoff_zone': 'DataSource', 'event_type': 'processing_end',
            'kind': 'table',
            'job_id': '01181Q0Z000000000077_160_01181QC1000000006EQZ'
        },
        'metrics': {
            'content_latest_date': None,
            'content_oldest_date': None,
            'delta_content_latest_date': None,
            'delta_content_oldest_date': None,
            'processing_started_date': '1673835472',
            'processing_finished_date': '1673835479',
            'processing_exit_code': 'status_success',
            'rows_count': '1121',
            'columns_count': None
        },
        'columns': {
            'column_name': '',
            'column_type': '',
            'column_min_observed_value': '',
            'column_max_observed_value': '',
            'column_lower_threshold': '',
            'column_upper_threshold': '',
            'Column_null_records_count': ''
        }
    }
    assert t.MetaData is not None
