import pytest
from modules.dataclasses.loki import LokiDataclass

tested_module = "modules.dataclasses.loki."


@pytest.mark.parametrize(
    "loki_dataclass_object",
    [
        pytest.param(
            LokiDataclass(labels={'name': 'Test', 'project_name': 'Dummy'}, message="Hello World", level="info")
        ),
        pytest.param(
            LokiDataclass.from_dict(
                {'labels': {'name': 'Test', 'project_name': 'Dummy'}, 'message': "Hello World", 'level': "info"})
        )
    ]
)
def test_loki_dataclass_with_ok_input(loki_dataclass_object):
    """
    Test create loki dataclass from dict
    """
    assert loki_dataclass_object.labels == {'name': 'Test', 'project_name': 'Dummy'}
    assert loki_dataclass_object.message == "Hello World"
    assert loki_dataclass_object.level == "info"


@pytest.mark.parametrize(
    "loki_dict",
    [
        pytest.param({'labels': "Test", 'message': "Hello World", 'level': "info"}),
        pytest.param({'labels': {'name': 'Test', 'project_name': 'Dummy'}, 'message': 1, 'level': "info"}),
        pytest.param({'labels': {'name': 'Test', 'project_name': 'Dummy'}, 'message': "Hello World", 'level': 1}),
        pytest.param({'labels': {1: 'Test', 'project_name': 'Dummy'}, 'message': "Hello World", 'level': "info"}),
        pytest.param({'labels': {'name': 1, 'project_name': 'Dummy'}, 'message': "Hello World", 'level': "info"})
    ]
)
def test_loki_dataclass_valid_type(loki_dict):
    """
    Test valid_type() function of loki dataclass
    """
    with pytest.raises(TypeError):
        LokiDataclass.from_dict(loki_dict)



