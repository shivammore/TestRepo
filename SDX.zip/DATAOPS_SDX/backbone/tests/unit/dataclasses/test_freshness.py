import pytest
from modules.dataclasses.freshness import FreshnessMetric, InvalidTimestamp

tested_module = "modules.dataclasses.freshness."


@pytest.mark.parametrize(
    "freshness_dataclass_object",
    [
        pytest.param(
            FreshnessMetric(
                timestamp=1665871823.0000,
                publisher_name='informatica',
                project_name='sap',
                dataset_name='client',
                landing_zone="bronze",
                takeoff_zone="oracle_sap",
                event_type='processing_end',
                job_id='app_1234',
                kind='file',
                metric_name='processing_finished_date',
                metric_value=1665871823.0000,
            )
        ),
        pytest.param(
            FreshnessMetric.from_dict(
                {
                    'timestamp': 1665871823.0000,
                    'publisher_name': 'informatica',
                    'project_name': 'sap',
                    'dataset_name': 'client',
                    'landing_zone': "bronze",
                    'takeoff_zone': "oracle_sap",
                    'event_type': 'processing_end',
                    'job_id': 'app_1234',
                    'kind': 'file',
                    'metric_name': 'processing_finished_date',
                    'metric_value': 1665871823.0000,
                }
            )
        )
    ]
)
def test_freshness_dataclass_with_ok_input(freshness_dataclass_object):
    """
    Test create freshness dataclass from dict
    """
    assert freshness_dataclass_object.timestamp == 1665871823
    assert freshness_dataclass_object.publisher_name == "informatica"
    assert freshness_dataclass_object.project_name == "sap"
    assert freshness_dataclass_object.dataset_name == "client"
    assert freshness_dataclass_object.landing_zone == "bronze"
    assert freshness_dataclass_object.takeoff_zone == "oracle_sap"
    assert freshness_dataclass_object.event_type == "processing_end"
    assert freshness_dataclass_object.job_id == "app_1234"
    assert freshness_dataclass_object.kind == "file"
    assert freshness_dataclass_object.metric_name == "processing_finished_date"
    assert freshness_dataclass_object.metric_value == 1665871823.0000


@pytest.mark.parametrize(
    "freshness_dataclass_object",
    [
        pytest.param(
            FreshnessMetric.from_dict(
                {
                    'timestamp': 1665871823.0000,
                    'publisher_name': 'Informatica',
                    'project_name': 'sAp',
                    'dataset_name': 'CLIENT',
                    'landing_zone': 'BRONZE',
                    'takeoff_zone': 'Oracle_SAP',
                    'event_type': 'Processing_END',
                    'job_id': '01185Q0Z00000000032J801185QC10000000027JZ',
                    'kind': 'File',
                    'metric_name': 'processing_FINISHED_DATE',
                    'metric_value': 1665871823.0000,
                }
            )
        )
    ]
)
def test_freshness_dataclass_lower(freshness_dataclass_object):
    """
    Test create freshness dataclass from dict and check if output is in lower case
    """
    assert freshness_dataclass_object.publisher_name == 'informatica'
    assert freshness_dataclass_object.project_name == 'sap'
    assert freshness_dataclass_object.dataset_name == 'client'
    assert freshness_dataclass_object.landing_zone == 'bronze'
    assert freshness_dataclass_object.takeoff_zone == 'oracle_sap'
    assert freshness_dataclass_object.event_type == 'processing_end'
    assert freshness_dataclass_object.job_id == '01185Q0Z00000000032J801185QC10000000027JZ'
    assert freshness_dataclass_object.kind == 'file'
    assert freshness_dataclass_object.metric_name == 'processing_finished_date'


@pytest.mark.parametrize(
    "freshness_dataclass_valid_timestamp_ok,expected",
    [
        pytest.param(1665871823, 1665871823),
        pytest.param(1665871823.0000, 1665871823),
        pytest.param(1665871823.123421, 1665871823),
        pytest.param("1665871823", 1665871823),
        pytest.param("1665871823.123421", 1665871823),
    ]
)
def test_freshness_dataclass_valid_timestamp_ok(freshness_dataclass_valid_timestamp_ok, expected):
    """
    Test valid_timestamp() function in freshness dataclass with ok timestamp
    """
    assert FreshnessMetric(
        timestamp=freshness_dataclass_valid_timestamp_ok,
        publisher_name='informatica',
        project_name='sap',
        dataset_name='client',
        landing_zone="bronze",
        takeoff_zone="oracle_sap",
        event_type='processing_end',
        job_id='app_1234',
        kind='file',
        metric_name='processing_finished_date',
        metric_value=1665871823.0000,
    ).timestamp == expected


@pytest.mark.parametrize(
    "freshness_dataclass_valid_timestamp_ko",
    [
        pytest.param("A1665871823"),
        pytest.param(32665871823),
    ]
)
def test_freshness_dataclass_valid_timestamp_ko(freshness_dataclass_valid_timestamp_ko):
    """
    Test valid_timestamp() function in freshness dataclass with ko timestamp
    """
    with pytest.raises(InvalidTimestamp):
        FreshnessMetric(
            timestamp=freshness_dataclass_valid_timestamp_ko,
            publisher_name='informatica',
            project_name='sap',
            dataset_name='client',
            landing_zone="bronze",
            takeoff_zone="oracle_sap",
            event_type='processing_end',
            job_id='app_1234',
            kind='file',
            metric_name='processing_finished_date',
            metric_value=1665871823.0000,
        )
