## Introduction 
Data ops is a serverless  zero down-time architecture aim to reduce the workload and cost associated with data
and cost management. 
 
Using functions allows us you to write less code, maintain less infrastructure, and save on costs. Instead of worrying
about deploying and maintaining servers, the cloud infrastructure provides all the up-to-date resources needed to keep
our applications running.


## Architecture

The main architecture focus is to provide a tech dependency free, transparent & dev friendly , all the consumers must
implement a shared interface that communicat with a unique dispatcher , each consumer need also to provide a schema that
will be matched with the incoming event , if matched the consumer will receive the deserializes event (events) as a 
dict (list of dicts) and handle it (them)


![Architecture](.img/azfunc.png)


## Dependencies

| Name | Description                                                                                                                                                                                                                                                                                                                                                                                                 | Required |
| --- |-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------| --- |
| [Poetry](https://python-poetry.org/docs/) | a popular packaging and dependency manager,the Python community tends to adopt it even if it is not standard for the community. It allows you to declare the libraries your project depends on, and it will manage (install/update) them for you.                                                                                                                                                           | True |
| [Azure Functions Core Tools](https://learn.microsoft.com/en-us/azure/azure-functions/functions-run-local) | Azure Functions Core Tools lets you develop and test your functions on your local computer from the command prompt or terminal. Your local functions can connect to live Azure services, and you can debug your functions on your local computer using the full Functions runtime                                                                                                                           | True |
| [Azure Storage Emulator](https://learn.microsoft.com/en-us/azure/storage/common/storage-use-emulator)| The Microsoft Azure Storage Emulator is a tool that emulates the Azure Blob, Queue, and Table services for local development purposes. You can test your application against the storage services locally without creating an Azure subscription or incurring any costs. When you're satisfied with how your application is working in the emulator, switch to using an Azure storage account in the cloud. | True |
| [VictoriaMetrics](https://github.com/VictoriaMetrics/VictoriaMetrics) | a fast, cost-effective and scalable monitoring solution and time series database.                                                                                                                                                                                                                                                                                                                           | False |
| [Docker](https://www.docker.com/)| Docker is a platform designed to help developers build, share, and run modern applications                                                                                                                                                                                                                                                                                                                  | True |

## Installation



**Poetry Installation**
```bash
curl -sSL https://install.python-poetry.org | python3 -
```

**Using PIP**
```bash
pip install poetry 
```

As a first step of every python project , you need to declare your initial dependencies , poetry 
use pyproject.toml file to track them and resolve any conflict if exists. this will generate a
poetry lock file ( poetry . lock ) that will be used to track the current state of the project .

**Install dependencies**
```bash
poetry install # -v to install them in the current env else it will create a new env
```

**Adding/Removing dependency**
To add a new dependency, you need to edit the pyproject.toml file , and run the poetry update to re-exam
the dependencies and generate a new pinned lock file peotry . lock 
```bash
poetry update
```
