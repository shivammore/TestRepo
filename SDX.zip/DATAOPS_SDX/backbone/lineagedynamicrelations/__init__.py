import datetime
import itertools
import logging
import os
import time
from typing import Dict, List, Union

import networkx as nx
import pyodbc

from modules.dataclasses.lineage import LineageNode, LineageEdge
from modules.kernel.mssqlpuller import MssqlPuller


def get_connexion_string():
    mssql_connection_string = os.environ['MSSQL_CONNECTION_STR']

    return mssql_connection_string


def get_nodes(mssql_puller: MssqlPuller) -> List[LineageNode]:
    sql_query = """
            WITH last_ingestions_events AS (
              select context_id ,
              max(project_name) as 'project_name',
              max(dataset_name) as 'dataset_name',
              max(landing_zone) as 'landing_zone',
              max(takeoff_zone) as 'takeoff_zone',
     MAX(CASE WHEN metric_name = 'processing_exit_code'  AND event_type = 'processingfinished'
     AND metric_value in (0, 1) THEN [timestamp] END) AS timestamp,
     MAX(CASE WHEN metric_name = 'content_latest_date'   THEN [metric_value] END) AS content_latest_date
    
    from dataops.event
     GROUP by context_id ),
      ttl AS (
                  SELECT *, ROW_NUMBER() OVER (PARTITION BY context_id, metric_name ORDER BY timestamp DESC) AS rn
                  FROM dataops.[references]
                  WHERE metric_name = 'ttl'
                )
                SELECT 
                  a.context_id,
                  a.project_name,
                  a.dataset_name,
                  a.landing_zone,
                  a.takeoff_zone,
                  a.[timestamp] AS 'last_updated',
                  t.metric_value AS 'ttl'
                FROM last_ingestions_events AS a
                LEFT JOIN ttl AS t ON a.context_id = t.context_id
                WHERE 
                t.rn = 1
    """
    nodes_from_events_list = mssql_puller.query_from_str(query=sql_query)
    nodes_list = [LineageNode(**row) for row in nodes_from_events_list]

    return nodes_list


def get_consumers(mssql_puller: MssqlPuller) -> Dict[str, List[str]]:
    """
    Returns a dictionary of dataset IDs and their corresponding consumers.

    Args:
        mssql_puller (MssqlPuller): An instance of the MssqlPuller class that is used to query data from the database.

    Returns:
        A dictionary with dataset IDs as keys and a list of consumers as values.

    Raises:
        Any exceptions raised by the MssqlPuller instance will be propagated to the caller.

    This function queries the 'dataops.references' table in the database to get the consumers that use each dataset.
    The SQL query used for this purpose is:

    SELECT context_id, STUFF(metric_name, 1, 9, '') AS product_name
    FROM [dataops].[references]
    WHERE metric_name LIKE 'consumer_%'

    The results of this query are sorted based on the context_id and then grouped by the same context_id.
    The resulting dictionary has the context_id as the key and a list of product names as the value.
    The returned dictionary has the following format:
    {
        'dataset_id_1': ['product_name_1', 'product_name_2', ...],
        'dataset_id_2': ['product_name_3', 'product_name_4', ...],
        ...
    }

    Note that the consumers are products in the gold zone that consume the dataset.
    """

    sql_query = """
    SELECT context_id, STUFF(metric_name, 1, 9, '') AS product_name
    FROM [dataops].[references]
    WHERE metric_name LIKE 'consumer_%'
    """
    consumers = mssql_puller.query_from_str(query=sql_query)
    consumers = sorted(consumers, key=lambda x: x['context_id'])
    consumers = {k: list(g) for k, g in itertools.groupby(consumers, key=lambda x: x['context_id'])}

    return {k: [value.get('product_name') for value in v] for k, v in consumers.items()}


def update_graph_status(nodes: List[LineageNode], edges: List[LineageEdge]):

    nodes_dict = {node.context_id: node for node in nodes}
    edges_context = [(edge.source_id, edge.destination_id) for edge in edges]

    graph: nx.DiGraph = nx.DiGraph()
    graph.add_nodes_from(nodes_dict.keys()), graph.add_edges_from(edges_context)

    leaf_nodes = [node for node in nodes_dict.keys() if graph.in_degree(node) == 0]

    def walk_and_update(nodes_dict: Dict[str, LineageNode],
                        graph: nx.DiGraph,
                        node_context: str,
                        parent_status: Union[None, float]) -> None:

        if parent_status is not None and parent_status == 0:
            nodes_dict.get(node_context).context_status = 0

        _ = [walk_and_update(
            nodes_dict=nodes_dict,
            graph=graph,
            node_context=node,
            parent_status=nodes_dict.get(node_context).context_status

        ) for node in graph.neighbors(node_context)]

    for leaf_node in leaf_nodes:
        __ = [walk_and_update(nodes_dict=nodes_dict,
                              graph=graph,
                              node_context=node_context,
                              parent_status=nodes_dict.get(leaf_node).context_status
                              )
              for node_context in graph.neighbors(leaf_node)]


def run():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    ts = int(datetime.datetime.now(tz=datetime.timezone.utc).timestamp())
    logger.info("Started at {}".format(ts))

    connexion = pyodbc.connect(get_connexion_string())
    puller = MssqlPuller(connexion_pyodbc=connexion)

    nodes = get_nodes(mssql_puller=puller)
    consumers = get_consumers(mssql_puller=puller)

    nodes = [node for node in nodes if node.ttl is not None]

    _ = [node.add_products(products_name=consumers.get(node.context_id, [])) for node in nodes]
    silver_nodes = [node for node in nodes if node.landing_zone == 'silver']

    # gold_nodes = LineageNode.get_gold_nodes(silver_nodes=silver_nodes)
    # gold_edges = LineageNode.get_gold_edges(gold_nodes=gold_nodes, silver_nodes=silver_nodes)

    art_nodes = LineageNode.get_artificial_nodes(
        lineage_nodes=nodes,
        static_zones=[('bronze', 'silver'), ('staging', 'bronze'), ('source', 'staging')]
    )

    nodes = nodes + art_nodes

    __hash = {node.context_id: node for node in nodes}
    edges = [node.get_edge() for node in nodes]

    edges = [edge for edge in edges if edge.source_id in __hash and edge.destination_id in __hash]
    cursor = connexion.cursor()

    # update_graph_status(nodes=nodes, edges=edges)

    clean_up_query = f'delete from [dataops].[lineageNodes] where timestamp < {ts} '
    cursor.execute(clean_up_query)

    clean_up_query = f'delete from [dataops].[lineageEdges] where timestamp < {ts} '
    cursor.execute(clean_up_query)

    _ = [cursor.execute(node.to_sql(table_name="[dataops].[lineageNodes]")) for node in nodes]
    _ = [cursor.execute(edge.to_sql(table_name="[dataops].[lineageEdges]")) for edge in edges]

    cursor.commit()
    cursor.close()
    connexion.close()


if __name__ == "__main__":
    SLEEP_TIME_SEC = 60

    while True:
        run()
        time.sleep(SLEEP_TIME_SEC)


