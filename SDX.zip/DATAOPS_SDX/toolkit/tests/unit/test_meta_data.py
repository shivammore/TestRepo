import unittest
from datetime import datetime
from unittest.mock import patch, PropertyMock

import pytz

from dataops.context import MetaData


class TestContext(unittest.TestCase):

    def setUp(self):
        pass

    def test_time_stamp(self):
        meta_data = MetaData()
        self.assertAlmostEqual(
            datetime.now(tz=pytz.utc).timestamp(), meta_data.timestamp, delta=2
        )
