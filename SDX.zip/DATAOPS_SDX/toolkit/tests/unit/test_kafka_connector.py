import unittest
from unittest.mock import patch
from dataops.connector.stream import KafkaConnector


class TestKafkaConnector(unittest.TestCase):

    def setUp(self):
        self.event_hub_connection_string = (
            "Endpoint=sb://sre-dev-eventhub-namespace.servicebus.windows.net/"
            ";SharedAccessKeyName=databricks-write-identity-rule;SharedAccessKey="
            "GlGwNtYA9cH24qtWkXGu31fpk5tIZ5JbA+AEhPRtHW0="
        )
        self.event_hub_name = "myeventhub"

    @patch("os.getenv")
    def test_init_with_missing_connection_string(self, mock_getenv):
        mock_getenv.return_value = None
        with self.assertRaises(ValueError):
            KafkaConnector()

    @patch("os.getenv")
    @patch("dataops.connector.stream.KafkaProducer")
    def test_init_with_environment_variables(self, mock_kafka_producer, mock_getenv):
        # Set up the mocked os.getenv
        mock_getenv.side_effect = lambda key, default=None: {
            "EVENT_HUB_CONNECTION_STRING": self.event_hub_connection_string,
            "EVENT_HUB_NAME": self.event_hub_name,
        }.get(key, default)

        # Test the __init__ method with the environment variables
        kafka_connector = KafkaConnector()

        # Verify the producer is called with the actual values
        fqdn, username, password = KafkaConnector.parse_connection_string(
            self.event_hub_connection_string
        )

        mock_kafka_producer.assert_called_with(
            bootstrap_servers=fqdn,
            security_protocol="SASL_SSL",
            sasl_mechanism="PLAIN",
            sasl_plain_username=username,
            sasl_plain_password=password,
        )

    def test_parse_connection_string(self):
        # Test valid connection string
        connection_str = "Endpoint=sb://sre-dev-eventhub-namespace.servicebus.windows.net/;SharedAccessKeyName=databricks-write-identity-rule;SharedAccessKey=GlGwNtYA9cH24qtWkXGu31fpk5tIZ5JbA+AEhPRtHW0="
        expected_fqdn = "sre-dev-eventhub-namespace.servicebus.windows.net"
        expected_username = "databricks-write-identity-rule"
        expected_password = "GlGwNtYA9cH24qtWkXGu31fpk5tIZ5JbA+AEhPRtHW0="

        fqdn, username, password = KafkaConnector.parse_connection_string(
            connection_str
        )

        self.assertEqual(expected_fqdn, fqdn)
        self.assertEqual(expected_username, username)
        self.assertEqual(expected_password, password)

        # Test missing FQDN
        connection_str = (
            "SharedAccessKeyName=databricks-write-identity-rule;"
            "SharedAccessKey=GlGwNtYA9cH24qtWkXGu31fpk5tIZ5JbA+AEhPRtHW0="
        )
        with self.assertRaises(ValueError):
            KafkaConnector.parse_connection_string(connection_str)

        # Test missing SharedAccessKeyName
        connection_str = (
            "Endpoint=sb://sre-dev-eventhub-namespace.servicebus.windows.net/;SharedAccessKey="
            "GlGwNtYA9cH24qtWkXGu31fpk5tIZ5JbA+AEhPRtHW0="
        )
        with self.assertRaises(ValueError):
            KafkaConnector.parse_connection_string(connection_str)

        # Test missing SharedAccessKey
        connection_str = (
            "Endpoint=sb://sre-dev-eventhub-namespace.servicebus.windows.net/;SharedAccessKeyName="
            "databricks-write-identity-rule;"
        )
        with self.assertRaises(ValueError):
            KafkaConnector.parse_connection_string(connection_str)

        # Test malformed connection string
        connection_str = (
            "Endpoint=sb://sre-dev-eventhub-namespace.servicebus.windows.net/"
            "SharedAccessKeyName=databricks-write-identity-rule;SharedAccessKey"
            "=GlGwNtYA9cH24qtWkXGu31fpk5tIZ5JbA+AEhPRtHW0"
        )
        with self.assertRaises(ValueError):
            KafkaConnector.parse_connection_string(connection_str)

    @patch("dataops.connector.stream.KafkaProducer")
    def test_init(self, mock_kafka_producer):
        # Test the __init__ method with the environment variables
        kafka_connector = KafkaConnector(
            event_hub_name=self.event_hub_name,
            event_hub_connection_string=self.event_hub_connection_string,
        )

        fqdn, username, password = KafkaConnector.parse_connection_string(
            self.event_hub_connection_string
        )

        mock_kafka_producer.assert_called_with(
            bootstrap_servers=fqdn,
            security_protocol="SASL_SSL",
            sasl_mechanism="PLAIN",
            sasl_plain_username=username,
            sasl_plain_password=password,
        )

    @patch("dataops.connector.stream.KafkaProducer")
    def test_send_message(self, mock_kafka_producer):
        # Create an instance of MyProducer with the mocked KafkaProducer
        my_producer = KafkaConnector(
            event_hub_name=self.event_hub_name,
            event_hub_connection_string=self.event_hub_connection_string,
        )

        # Set up the mocked KafkaProducer instance
        mock_producer = mock_kafka_producer.return_value
        message = "test_message"
        my_producer.send(value=message)
        #
        # # Check if KafkaProducer.send() was called with the correct arguments
        mock_producer.send.assert_called_with(
            self.event_hub_name, value=message.encode("utf-8"), key=None
        )
        #
        # Check if KafkaProducer.flush() was called
        mock_producer.flush.assert_called_once()

        my_producer.send(value=message, key=message)
        mock_producer.send.assert_called_with(
            self.event_hub_name,
            value=message.encode("utf-8"),
            key=message.encode("utf-8"),
        )


if __name__ == "__main__":
    unittest.main()
