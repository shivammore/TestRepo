import json
import unittest
from unittest.mock import patch

from dataops.context import Context, Zone, Kind, EventType


class TestContext(unittest.TestCase):

    def setUp(self):
        self.azure_id = "uuid"
        mock_azure_id_patcher = patch("dataops.context.get_azure_subscription_id")
        self.mock_azure_id = mock_azure_id_patcher.start()
        self.mock_azure_id.return_value = self.azure_id

        # Mocking other potential dependencies (you can add more if needed)
        self.publisher_name = "test_publisher"
        self.project_name = "test_project"
        self.dataset_name = "test_dataset"
        self.landing_zone = Zone.SILVER
        self.kind = Kind.TABLE
        self.job_id = "test_job_id"
        self.takeoff_zone = Zone.BRONZE

        self.context = Context(
            publisher_name=self.publisher_name,
            project_name=self.project_name,
            dataset_name=self.dataset_name,
            landing_zone=self.landing_zone,
            kind=self.kind,
            job_id=self.job_id,
            takeoff_zone=self.takeoff_zone,
            event_type=EventType.PROCESSING_STARTED,
        )

    def test_subscription_id(self):
        self.assertEqual(self.context.subscription_id, self.azure_id)

    def test_to_json(self):
        context_json = self.context.to_json()

        # Check if the generated string is valid JSON
        try:
            deserialized_data = json.loads(context_json)
        except json.JSONDecodeError:
            self.fail("to_json did not produce valid JSON")

        self.assertEqual(deserialized_data["publisher_name"], self.publisher_name)
        self.assertEqual(deserialized_data["project_name"], self.project_name)
        self.assertEqual(deserialized_data["dataset_name"], self.dataset_name)
        self.assertEqual(deserialized_data["landing_zone"], self.landing_zone)
        self.assertEqual(deserialized_data["kind"], self.kind.value)
        self.assertEqual(deserialized_data["job_id"], self.job_id)
        self.assertEqual(deserialized_data["takeoff_zone"], self.takeoff_zone)
        self.assertEqual(deserialized_data["subscription_id"], self.azure_id)

    def test_none_json(self):
        self.mock_azure_id.return_value = None
        self.context = Context(
            publisher_name=self.publisher_name,
            project_name=self.project_name,
            dataset_name=self.dataset_name,
            landing_zone=self.landing_zone,
            kind=self.kind,
            job_id=self.job_id,
            takeoff_zone=self.takeoff_zone,
            event_type=EventType.PROCESSING_STARTED,
        )
        deserialized_data = json.loads(self.context.to_json())
        self.assertEqual(deserialized_data.get("subscription_id"), None)
