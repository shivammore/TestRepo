import unittest
from unittest.mock import patch, MagicMock
from dataops.utils import get_azure_subscription_id


class TestDataObs(unittest.TestCase):

    @patch("dataops.utils.SparkSession")
    def test_get_azure_subscription_id(self, mock_session):
        return_uuid = "uuid"
        mock_spark = MagicMock()

        mock_spark.conf.get.return_value = return_uuid

        mock_session.getActiveSession.return_value = mock_spark
        mock_session.builder.getOrCreate.return_value = mock_spark
        mock_session.builder.appName.return_value.getOrCreate.return_value = mock_spark

        self.assertEqual(get_azure_subscription_id(), return_uuid)
