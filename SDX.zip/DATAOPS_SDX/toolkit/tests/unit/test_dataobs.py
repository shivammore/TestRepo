import datetime
import json
import unittest
from collections import Counter
from unittest.mock import patch, Mock, MagicMock

import pytz
from pyspark.sql.types import StructType, StructField, DateType

from dataops.context import Zone, Kind, EventType, ExitCode, MetricName
from cerberus import Validator
from observability import DataObs


class TestDataObs(unittest.TestCase):

    def setUp(self):
        # Mocking the EventHubConnector

        mock_connector_patcher = patch("observability.EventHubConnector")
        self.mock_connector = mock_connector_patcher.start()

        mock_functions_patcher = patch("observability.functions")
        self.mock_functions = mock_functions_patcher.start()

        mock_azure_id_patcher = patch("dataops.context.get_azure_subscription_id")
        self.mock_azure_id = mock_azure_id_patcher.start()
        self.mock_azure_id.return_value = "uuid"

        # Mocking other potential dependencies (you can add more if needed)
        self.mock_dataframe = Mock()

        self.publisher_name = "test_publisher"
        self.project_name = "test_project"
        self.dataset_name = "test_dataset"
        self.landing_zone = Zone.SILVER
        self.kind = Kind.TABLE
        self.job_id = "test_job_id"
        self.takeoff_zone = Zone.BRONZE
        self.event_type = EventType.PROCESSING_STARTED
        self.event_hub_connection_string = "test_connection_string"
        self.event_hub_name = "test_event_hub_name"

        self.data_obs = DataObs(
            publisher_name=self.publisher_name,
            project_name=self.project_name,
            dataset_name=self.dataset_name,
            landing_zone=self.landing_zone,
            kind=self.kind,
            job_id=self.job_id,
            takeoff_zone=self.takeoff_zone,
            event_hub_connection_string=self.event_hub_connection_string,
            event_hub_name=self.event_hub_name,
        )

        self.schema = {
            "metadata": {
                "type": "dict",
                "schema": {
                    "timestamp": {"type": ["number", "string"], "required": True}
                },
                "required": True,
            },
            "contexts": {
                "type": "dict",
                "schema": {
                    "job_id": {"type": ["number", "string"], "required": True},
                    "event_type": {"type": "string", "required": True},
                    "project_name": {"type": "string", "required": True},
                    "dataset_name": {"type": "string", "required": True},
                    "publisher_name": {"type": "string", "required": True},
                    "landing_zone": {"type": "string", "required": True},
                    "takeoff_zone": {"type": "string", "required": True},
                    "subscription_id": {"type": "string", "required": False},
                    "kind": {
                        "type": "string",
                        "required": True,
                        "allowed": ["file", "column", "table"],
                    },
                },
                "required": True,
            },
            "metrics": {"type": "dict", "required": True, "empty": False},
        }

    def tearDown(self):
        # Reset patches
        patch.stopall()

    def test_EventHubConnector_called(self):
        self.mock_connector.assert_called_with(
            event_hub_connection_string=self.event_hub_connection_string,
            event_hub_name=self.event_hub_name,
        )

    def test_send_processing_event(self):
        self.data_obs.send_processing_event()
        self.mock_connector.assert_called()
        self.mock_connector.return_value.send.assert_called()

        args, kwargs = self.mock_connector.return_value.send.call_args_list[0]
        value, encoding = kwargs.get("value"), kwargs.get("encoding")

        sent_message = json.loads(value)
        validator = Validator(schema=self.schema, allow_unknown=False)
        self.assertTrue(validator.validate(sent_message))

    def test_send_processing_event_meta_data(self):
        self.data_obs.send_processing_event()
        self.mock_connector.assert_called()
        self.mock_connector.return_value.send.assert_called()

        args, kwargs = self.mock_connector.return_value.send.call_args_list[0]
        value, encoding = kwargs.get("value"), kwargs.get("encoding")

        sent_message = json.loads(value)
        self.assertTrue(sent_message.get("metadata", False))
        self.assertTrue(sent_message.get("metadata", {}).get("timestamp", False))
        self.assertAlmostEqual(
            sent_message["metadata"]["timestamp"],
            datetime.datetime.now(tz=pytz.utc).timestamp(),
            delta=2,
        )

    def test_send_processing_event_context(self):
        self.data_obs.send_processing_event()
        self.mock_connector.assert_called()
        self.mock_connector.return_value.send.assert_called()

        args, kwargs = self.mock_connector.return_value.send.call_args_list[0]
        value, encoding = kwargs.get("value"), kwargs.get("encoding")

        sent_message = json.loads(value)
        self.assertTrue(sent_message.get("contexts", False))

        contexts = sent_message.get("contexts")

        # Now, assert the values for each attribute

        self.assertEqual(contexts.get("publisher_name"), self.publisher_name)
        self.assertEqual(contexts.get("project_name"), self.project_name)
        self.assertEqual(contexts.get("dataset_name"), self.dataset_name)
        self.assertEqual(
            contexts.get("landing_zone"), self.landing_zone
        )  # .value to get the enum's value
        self.assertEqual(
            contexts.get("kind"), self.kind
        )  # .value to get the enum's value
        self.assertEqual(contexts.get("job_id"), self.job_id)
        self.assertEqual(
            contexts.get("takeoff_zone"), self.takeoff_zone
        )  # .value to get the enum's value
        self.assertEqual(
            contexts.get("event_type"), self.event_type
        )  # .value to get the enum's value
        self.assertEqual(
            contexts.get("subscription_id"), "uuid"
        )  # .value to get the enum's value

    def test_send_processing_metrics(self):
        self.data_obs.send_processing_event()
        self.mock_connector.assert_called()
        self.mock_connector.return_value.send.assert_called()

        args, kwargs = self.mock_connector.return_value.send.call_args_list[0]
        value, encoding = kwargs.get("value"), kwargs.get("encoding")

        sent_message = json.loads(value)
        self.assertTrue(sent_message.get("metrics", False))

        metrics = sent_message.get("metrics")
        self.assertAlmostEqual(
            metrics["processing_started_date"],
            datetime.datetime.now(tz=pytz.utc).timestamp(),
            delta=2,
        )

    def test_send_finished_event_schema(self):
        self.data_obs.send_finished_event(exit_code=ExitCode.SUCCESS)
        self.mock_connector.assert_called()
        self.mock_connector.return_value.send.assert_called()

        args, kwargs = self.mock_connector.return_value.send.call_args_list[0]
        value, encoding = kwargs.get("value"), kwargs.get("encoding")

        sent_message = json.loads(value)
        validator = Validator(schema=self.schema, allow_unknown=False)
        self.assertTrue(validator.validate(sent_message))

    def test_send_finished_event_meta_data(self):
        self.data_obs.send_finished_event(exit_code=ExitCode.SUCCESS)
        self.mock_connector.assert_called()
        self.mock_connector.return_value.send.assert_called()

        args, kwargs = self.mock_connector.return_value.send.call_args_list[0]
        value, encoding = kwargs.get("value"), kwargs.get("encoding")

        sent_message = json.loads(value)
        self.assertTrue(sent_message.get("metadata", False))
        self.assertTrue(sent_message.get("metadata", {}).get("timestamp", False))
        self.assertAlmostEqual(
            sent_message["metadata"]["timestamp"],
            datetime.datetime.now(tz=pytz.utc).timestamp(),
            delta=2,
        )

    def test_send_finished_event_context(self):
        self.data_obs.send_finished_event(exit_code=ExitCode.SUCCESS)
        self.mock_connector.assert_called()
        self.mock_connector.return_value.send.assert_called()

        args, kwargs = self.mock_connector.return_value.send.call_args_list[0]
        value, encoding = kwargs.get("value"), kwargs.get("encoding")

        sent_message = json.loads(value)
        self.assertTrue(sent_message.get("contexts", False))

        contexts = sent_message.get("contexts")

        self.assertEqual(contexts.get("publisher_name"), self.publisher_name)
        self.assertEqual(contexts.get("project_name"), self.project_name)
        self.assertEqual(contexts.get("dataset_name"), self.dataset_name)
        self.assertEqual(
            contexts.get("landing_zone"), self.landing_zone
        )  # .value to get the enum's value
        self.assertEqual(
            contexts.get("kind"), self.kind
        )  # .value to get the enum's value
        self.assertEqual(contexts.get("job_id"), self.job_id)
        self.assertEqual(
            contexts.get("takeoff_zone"), self.takeoff_zone
        )  # .value to get the enum's value
        self.assertEqual(
            contexts.get("event_type"), EventType.PROCESSING_FINISHED
        )  # .value to get the enum's value
        self.assertEqual(
            contexts.get("subscription_id"), "uuid"
        )  # .value to get the enum's value

    def test_send_finished_event_metrics(self):
        for idx, (exit_code, expected_exit_code) in enumerate(
            [
                (ExitCode.NO_NEW_DATA, ExitCode.NO_NEW_DATA),
                (ExitCode.ERROR, ExitCode.ERROR),
            ]
        ):
            self.data_obs.send_finished_event(exit_code=exit_code)
            args, kwargs = self.mock_connector.return_value.send.call_args_list[idx]
            sent_message, encoding = json.loads(kwargs.get("value")), kwargs.get(
                "encoding"
            )
            self.assertEqual(
                sent_message.get("metrics")[MetricName.PROCESSING_EXIT_CODE],
                expected_exit_code,
            )

    def test_push_volume_metrics(self):
        # Mocking DataFrame
        self.mock_dataframe.count.return_value = 100
        self.mock_dataframe.columns = ["col1", "col2"]

        self.data_obs.push(
            self.mock_dataframe, volume=True, freshness_column=None, distribution=False
        )

        # Check the call arguments
        _, kwargs = self.mock_connector.return_value.send.call_args
        sent_message = json.loads(kwargs.get("value"))
        metrics = sent_message.get("metrics")

        self.assertEqual(metrics[MetricName.ROWS_COUNT], 100)
        self.assertEqual(metrics[MetricName.COLUMNS_COUNT], 2)

    def test_push_freshness_date(self):

        self.mock_dataframe.count.return_value = 100
        self.mock_dataframe.columns = ["date_column"]

        max_date, min_date = datetime.date(2023, 1, 1), datetime.date(2022, 1, 1)
        max_datetime = datetime.datetime(max_date.year, max_date.month, max_date.day)
        min_datetime = datetime.datetime(min_date.year, min_date.month, min_date.day)

        # Convert the datetime to UTC and get the timestamp
        max_utc_ts = max_datetime.replace(tzinfo=pytz.utc).timestamp()
        min_utc_ts = min_datetime.replace(tzinfo=pytz.utc).timestamp()

        # Mocking the schema and returned values for freshness checks
        self.mock_dataframe.schema = StructType(
            [StructField("date_column", DateType())]
        )
        self.mock_dataframe.select.return_value.collect.return_value = [
            {"col_min_date": min_date, "col_max_date": max_date}
        ]

        self.data_obs.push(self.mock_dataframe, freshness_column="date_column")

        _, kwargs = self.mock_connector.return_value.send.call_args
        sent_message = json.loads(kwargs.get("value"))
        metrics = sent_message.get("metrics")

        self.assertIn(MetricName.FRESHNESS_EARLIEST_UNIX_TIME_STAMP, metrics)
        self.assertIn(MetricName.FRESHNESS_LATEST_UNIX_TIME_STAMP, metrics)

        self.assertEqual(
            metrics[MetricName.FRESHNESS_EARLIEST_UNIX_TIME_STAMP], min_utc_ts
        )
        self.assertEqual(
            metrics[MetricName.FRESHNESS_LATEST_UNIX_TIME_STAMP], max_utc_ts
        )

    def test_push_freshness_date_time(self):

        self.mock_dataframe.count.return_value = 100
        self.mock_dataframe.columns = ["date_column"]

        max_date, min_date = datetime.date(2023, 1, 1), datetime.date(2022, 1, 1)
        max_datetime = datetime.datetime(max_date.year, max_date.month, max_date.day)
        min_datetime = datetime.datetime(min_date.year, min_date.month, min_date.day)

        # Convert the datetime to UTC and get the timestamp
        max_utc_ts = max_datetime.replace(tzinfo=pytz.utc).timestamp()
        min_utc_ts = min_datetime.replace(tzinfo=pytz.utc).timestamp()

        # Mocking the schema and returned values for freshness checks
        self.mock_dataframe.schema = StructType(
            [StructField("date_column", DateType())]
        )
        self.mock_dataframe.select.return_value.collect.return_value = [
            {"col_min_date": min_datetime, "col_max_date": max_datetime}
        ]

        self.data_obs.push(self.mock_dataframe, freshness_column="date_column")

        _, kwargs = self.mock_connector.return_value.send.call_args
        sent_message = json.loads(kwargs.get("value"))
        metrics = sent_message.get("metrics")

        self.assertIn(MetricName.FRESHNESS_EARLIEST_UNIX_TIME_STAMP, metrics)
        self.assertIn(MetricName.FRESHNESS_LATEST_UNIX_TIME_STAMP, metrics)

        self.assertEqual(
            metrics[MetricName.FRESHNESS_EARLIEST_UNIX_TIME_STAMP], min_utc_ts
        )
        self.assertEqual(
            metrics[MetricName.FRESHNESS_LATEST_UNIX_TIME_STAMP], max_utc_ts
        )

    def test_push_freshness_invalid_column(self):
        self.mock_dataframe.count.return_value = 100
        self.mock_dataframe.columns = ["date_column"]

        max_date, min_date = datetime.date(2023, 1, 1), datetime.date(2022, 1, 1)
        max_datetime = datetime.datetime(max_date.year, max_date.month, max_date.day)
        min_datetime = datetime.datetime(min_date.year, min_date.month, min_date.day)

        self.mock_dataframe.schema = StructType(
            [StructField("date_column", DateType())]
        )
        self.mock_dataframe.select.return_value.collect.return_value = [
            {"col_min_date": min_datetime, "col_max_date": max_datetime}
        ]

        with self.assertRaises(AttributeError):
            self.data_obs.push(
                self.mock_dataframe, freshness_column="date_column_not_found"
            )

    def test_push_with_age_category(self):
        class MockSparkDataFrame:
            def __init__(self, data):
                """
                Initialise le mock DataFrame avec une liste de dictionnaires.
                :param data: Liste de dictionnaires représentant les données du DataFrame.
                """
                self.data = data

            def collect(self):
                """
                Retourne les données sous forme de liste de dictionnaires.
                """
                return self.data

            def distinct(self):
                """
                Simule l'opération distinct() sur le DataFrame.
                """
                distinct_items = {frozenset(item.items()) for item in self.data}
                distinct_data = [dict(item) for item in distinct_items]
                return MockSparkDataFrame(distinct_data)

            def count(self):
                """
                Retourne le nombre de lignes dans le DataFrame.
                """
                return len(self.data)

            def groupby(self, col):
                """
                Simule l'opération groupby sur une colonne donnée.
                :param col: La colonne sur laquelle grouper.
                :return: Un MockGroupedData.
                """
                grouped_data = {}
                for row in self.data:
                    value = row[col]
                    grouped_data[value] = grouped_data.get(value, 0) + 1
                return MockGroupedData(grouped_data)

        class MockGroupedData:
            def __init__(self, grouped_data):
                """
                Initialise les données groupées.
                :param grouped_data: Dictionnaire des données groupées avec les clés et leurs comptes.
                """
                self.grouped_data = [
                    {"Age_Category": key, "count": value}
                    for key, value in grouped_data.items()
                ]

            def count(self):
                """
                Retourne un MockSparkDataFrame contenant les résultats du comptage.
                """
                return MockSparkDataFrame(self.grouped_data)

        # Création du mock DataFrame
        mock_data = [
            {"Age_Category": "Jeune"},
            {"Age_Category": "Adult"},
            {"Age_Category": "Senior"},
            {"Age_Category": "Jeune"},
            {"Age_Category": "Senior"},
        ]

        self.mock_dataframe = MockSparkDataFrame(mock_data)

        # Appel de la méthode push
        self.data_obs.push(
            self.mock_dataframe,
            volume=False,
            freshness_column=None,
            distribution=False,
            col_agregation="Age_Category",
        )

        self.data_obs.send_processing_event()

        # Vérification des appels
        self.mock_connector.assert_called()
        self.mock_connector.return_value.send.assert_called()

        # Extraction des arguments envoyés
        args, kwargs = self.mock_connector.return_value.send.call_args_list[0]
        value, encoding = kwargs.get("value"), kwargs.get("encoding")
        sent_message = json.loads(value)
        self.assertTrue(sent_message.get("metrics", False))

        metrics = sent_message.get("metrics")

        # Vérification des métriques
        self.assertIn("SITE_Jeune", metrics)
        self.assertIn("SITE_Adult", metrics)
        self.assertIn("SITE_Senior", metrics)
