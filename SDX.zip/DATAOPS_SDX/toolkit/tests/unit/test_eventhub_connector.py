import unittest
from unittest.mock import patch, MagicMock, AsyncMock
from dataops.connector.eventhub import (
    EventHubConnector,
)  # Replace 'your_module_name' with the actual module name


class TestEventHubConnector(unittest.TestCase):
    def setUp(self):
        self.event_hub_connection_string = (
            "Endpoint=sb://sre-dev-eventhub-namespace.servicebus.windows.net/"
            ";SharedAccessKeyName=databricks-write-identity-rule;SharedAccessKey="
            "GlGwNtYA9cH24qtWkXGu31fpk5sIZ5JbA+AEhPRtHW0="
        )
        self.event_hub_name = "myeventhub"

    @patch("os.getenv")
    def test_init_with_missing_connection_string(self, mock_getenv):
        mock_getenv.return_value = None
        with self.assertRaises(ValueError):
            EventHubConnector()

    @patch("azure.eventhub.EventHubProducerClient.from_connection_string")
    def test_init_with_connection_string_args(self, mock_from_connection_string):
        event_hub_connector = EventHubConnector(
            event_hub_connection_string=self.event_hub_connection_string,
            event_hub_name=self.event_hub_name,
        )

        # Verify the producer is called with the actual values
        mock_from_connection_string.assert_called_with(
            conn_str=self.event_hub_connection_string, eventhub_name=self.event_hub_name
        )

    @patch("os.getenv")
    @patch("azure.eventhub.EventHubProducerClient.from_connection_string")
    def test_init_with_environment_variables(
        self, mock_from_connection_string, mock_getenv
    ):
        # Set up the mocked os.getenv
        mock_getenv.side_effect = lambda key, default=None: {
            "EVENT_HUB_CONNECTION_STRING": self.event_hub_connection_string,
            "EVENT_HUB_NAME": self.event_hub_name,
        }.get(key, default)

        # Test the __init__ method with the environment variables
        event_hub_connector = EventHubConnector()

        # Verify the producer is called with the actual values
        mock_from_connection_string.assert_called_with(
            conn_str=self.event_hub_connection_string, eventhub_name=self.event_hub_name
        )

    @patch("dataops.connector.eventhub.EventHubProducerClient")
    def test_send(self, mock_producer_client):
        # Create an instance of EventHubConnector with the mocked EventHubProducerClient
        event_hub_connector = EventHubConnector(
            event_hub_name=self.event_hub_name,
            event_hub_connection_string=self.event_hub_connection_string,
        )

        # Set up the mocked EventHubProducerClient instance
        mock_producer = MagicMock()
        mock_producer_client.from_connection_string.return_value.__enter__.return_value = (
            mock_producer
        )
        mock_batch = MagicMock()
        mock_producer.create_batch.return_value = mock_batch

        message = "test_message"
        event_hub_connector.send(value=message)
        mock_producer.create_batch.assert_called_once()
        mock_batch.add.assert_called_once()
        mock_batch.add.call_args[0][0].message == "test_message"
        mock_producer.send_batch.assert_called_once_with(event_data_batch=mock_batch)


if __name__ == "__main__":
    unittest.main()
