import unittest
import json
from dataops.context import Context, EventType, Kind, Zone


class TestContext(unittest.TestCase):

    def test_to_json(self):
        context = Context(
            publisher_name="Publisher A",
            project_name="Project B",
            dataset_name="Dataset C",
            landing_zone=Zone.GOLD,
            takeoff_zone=Zone.BRONZE,
            event_type=EventType.PROCESSING_STARTED,
            kind=Kind.TABLE,
            job_id="JobID123",
        )

        json_string = context.to_json()
        json_data = json.loads(json_string)

        self.assertEqual(json_data["publisher_name"], "Publisher A")
        self.assertEqual(json_data["project_name"], "Project B")
        self.assertEqual(json_data["dataset_name"], "Dataset C")
        self.assertEqual(json_data["landing_zone"], Zone.GOLD.value)
        self.assertEqual(json_data["event_type"], EventType.PROCESSING_STARTED.value)
        self.assertEqual(json_data["kind"], Kind.TABLE.value)
        self.assertEqual(json_data["job_id"], "JobID123")
        self.assertEqual(json_data["takeoff_zone"], Zone.BRONZE.value)


if __name__ == "__main__":
    unittest.main()
