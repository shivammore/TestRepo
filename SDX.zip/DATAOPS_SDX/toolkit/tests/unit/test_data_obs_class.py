# # import json
# # import unittest
# # from datetime import datetime, date
# import unittest
# from unittest.mock import MagicMock, patch
#
# from dataops.context import Zone, Kind
# from observability import DataObs
#
#
# #
# # import pytz
# # from pyspark.sql.types import StructField, StringType, DateType, TimestampType
# # from pyspark.sql import functions as functions
# # from dataops.utils import get_azure_subscription_id
# #
# #
# # from dataops.context import Kind, Zone, EventType, MetricName, ExitCode
# # from observability import DataObs
#
#
# class TestDataObs(unittest.TestCase):
#
#     def setUp(self):
#         self.publisher_name = "test_publisher"
#         self.project_name = "test_project"
#         self.dataset_name = "test_dataset"
#         self.landing_zone = Zone.SILVER
#         self.kind = Kind.TABLE
#         self.job_id = "test_job_id"
#         self.takeoff_zone = Zone.BRONZE
#         self.event_hub_connection_string = "test_connection_string"
#         self.event_hub_name = "test_event_hub_name"
#
#         self.data_obs = DataObs(
#                 publisher_name=self.publisher_name,
#                 project_name=self.project_name,
#                 dataset_name=self.dataset_name,
#                 landing_zone=self.landing_zone,
#                 kind=self.kind,
#                 job_id=self.job_id,
#                 takeoff_zone=self.takeoff_zone,
#                 event_hub_connection_string=self.event_hub_connection_string,
#                 event_hub_name=self.event_hub_name
#         )
#
#     @patch('observability.EventHubConnector')
#     def test_send_processing_event(self, mock_connector):
#
#         data_obs = DataObs(
#             publisher_name=self.publisher_name,
#             project_name=self.project_name,
#             dataset_name=self.dataset_name,
#             landing_zone=self.landing_zone,
#             kind=self.kind,
#             job_id=self.job_id,
#             takeoff_zone=self.takeoff_zone,
#             event_hub_connection_string=self.event_hub_connection_string,
#             event_hub_name=self.event_hub_name
#         )
#
#         # data_obs.send_processing_event()
#         # mock_connector.assert_called_once()
#         print(mock_connector)
#
#     def test_send_processing_event_called_once(self):
#         # mock_send = MagicMock()
#         # mock_connector.return_value.send = mock_send
#         print('cxcw')
#
#     #     return True
#     #
#     #     data_obs = DataObs(
#     #         publisher_name=self.publisher_name,
#     #         project_name=self.project_name,
#     #         dataset_name=self.dataset_name,
#     #         landing_zone=self.landing_zone,
#     #         kind=self.kind,
#     #         job_id=self.job_id,
#     #         takeoff_zone=self.takeoff_zone,
#     #         event_hub_connection_string=self.event_hub_connection_string,
#     #         event_hub_name=self.event_hub_name
#     #     )
#     #
#     #     data_obs.send_processing_event()
#     #
#     #     # Verify the KafkaConnector is created with the correct arguments
#     #     mock_connector.assert_called_once_with(
#     #         event_hub_connection_string=self.event_hub_connection_string,
#     #         event_hub_name=self.event_hub_name
#     #     )
#     #
#     #     # Extract the expected message with the dynamic timestamp
#     #     expected_message = {
#     #         "metadata": {
#     #             "timestamp": datetime.now(tz=pytz.utc).timestamp()
#     #         },
#     #         "contexts": {
#     #             "publisher_name": self.publisher_name,
#     #             "project_name": self.project_name,
#     #             "dataset_name": self.dataset_name,
#     #             "landing_zone": self.landing_zone.value,
#     #             "event_type": EventType.PROCESSING_STARTED.value,
#     #             "kind": self.kind.value,
#     #             "job_id": self.job_id,
#     #             "takeoff_zone": self.takeoff_zone.value,
#     #             "subscription_name": get_azure_subscription_id(),
#     #         },
#     #         "metrics": {
#     #             MetricName.PROCESSING_STARTED_DATE.value: datetime.now(tz=pytz.utc).timestamp()
#     #         }
#     #     }
#     #     mock_send.assert_called_once()
#     #     args, kwargs = mock_send.call_args_list[0]
#     #
#     #     value, encoding = kwargs.get('value'), kwargs.get('encoding')
#     #     #
#     #     sent_message = json.loads(value)
#     #
#     #     self.assertAlmostEqual(sent_message['metadata']['timestamp'], expected_message['metadata']['timestamp'],
#     #                            delta=2)
#     #
#     #     print(expected_message.get('contexts'))
#     #     print(sent_message.get('contexts'))
#
#         # for key, value in expected_message.get('contexts').items():
#         #     print(key, value)
#         #     self.assertEqual(sent_message.get('contexts').get(key), value)
#         #
#         # self.assertAlmostEqual(
#         #     sent_message['metrics'][MetricName.PROCESSING_STARTED_DATE.value],
#         #     expected_message['metrics'][MetricName.PROCESSING_STARTED_DATE.value],
#         #     delta=2
#         # )
#
# #     @patch('observability.EventHubConnector')
# #     def test_send_processing_event_custom_ts_called_once(self, mock_connector):
# #         mock_send = MagicMock()
# #         mock_connector.return_value.send = mock_send
# #
# #         data_obs = DataObs(
# #             publisher_name=self.publisher_name,
# #             project_name=self.project_name,
# #             dataset_name=self.dataset_name,
# #             landing_zone=self.landing_zone,
# #             kind=self.kind,
# #             job_id=self.job_id,
# #             takeoff_zone=self.takeoff_zone,
# #             event_hub_connection_string=self.event_hub_connection_string,
# #             event_hub_name=self.event_hub_name
# #         )
# #
# #         ts = datetime.now(tz=pytz.utc).timestamp()
# #         data_obs.send_processing_event(timestamp=ts)
# #
# #         # Verify the KafkaConnector is created with the correct arguments
# #         mock_connector.assert_called_once_with(
# #             event_hub_connection_string=self.event_hub_connection_string,
# #             event_hub_name=self.event_hub_name
# #         )
# #
# #         # Extract the expected message with the dynamic timestamp
# #         expected_message = {
# #             "metadata": {
# #                 "timestamp": datetime.now(tz=pytz.utc).timestamp()
# #             },
# #             "contexts": {
# #                 "publisher_name": self.publisher_name,
# #                 "project_name": self.project_name,
# #                 "dataset_name": self.dataset_name,
# #                 "landing_zone": self.landing_zone.value,
# #                 "event_type": EventType.PROCESSING_STARTED.value,
# #                 "kind": self.kind.value,
# #                 "job_id": self.job_id,
# #                 "takeoff_zone": self.takeoff_zone.value
# #             },
# #             "metrics": {
# #                 MetricName.PROCESSING_STARTED_DATE.value: ts
# #             }
# #         }
# #         mock_send.assert_called_once()
# #         args, kwargs = mock_send.call_args_list[0]
# #
# #         value, encoding = kwargs.get('value'), kwargs.get('encoding')
# #         #
# #         sent_message = json.loads(value)
# #
# #         self.assertAlmostEqual(sent_message['metadata']['timestamp'], expected_message['metadata']['timestamp'],
# #                                delta=2)
# #         self.assertEqual(sent_message['contexts'], expected_message['contexts'])
# #         self.assertAlmostEqual(
# #             sent_message['metrics'][MetricName.PROCESSING_STARTED_DATE.value],
# #             expected_message['metrics'][MetricName.PROCESSING_STARTED_DATE.value],
# #             delta=2
# #         )
# #
# #     @patch('observability.EventHubConnector')
# #     def test_send_finished_event_called_once(self, mock_connector):
# #         mock_send = MagicMock()
# #         mock_connector.return_value.send = mock_send
# #
# #         data_obs = DataObs(
# #             publisher_name=self.publisher_name,
# #             project_name=self.project_name,
# #             dataset_name=self.dataset_name,
# #             landing_zone=self.landing_zone,
# #             kind=self.kind,
# #             job_id=self.job_id,
# #             takeoff_zone=self.takeoff_zone,
# #             event_hub_connection_string=self.event_hub_connection_string,
# #             event_hub_name=self.event_hub_name
# #         )
# #
# #         data_obs.send_finished_event(exit_code=ExitCode.SUCCESS)
# #
# #         # Verify the EventHubConnector is created with the correct arguments
# #         mock_connector.assert_called_once_with(
# #             event_hub_connection_string=self.event_hub_connection_string,
# #             event_hub_name=self.event_hub_name
# #         )
# #
# #         # Extract the expected message with the dynamic timestamp
# #         expected_message = {
# #             "metadata": {
# #                 "timestamp": datetime.now(tz=pytz.utc).timestamp()
# #             },
# #             "contexts": {
# #                 "publisher_name": self.publisher_name,
# #                 "project_name": self.project_name,
# #                 "dataset_name": self.dataset_name,
# #                 "landing_zone": self.landing_zone.value,
# #                 "event_type": EventType.PROCESSING_FINISHED.value,
# #                 "kind": self.kind.value,
# #                 "job_id": self.job_id,
# #                 "takeoff_zone": self.takeoff_zone.value
# #             },
# #             "metrics": {
# #                 MetricName.PROCESSING_EXIT_CODE.value: 0,
# #                 MetricName.PROCESSING_FINISHED_DATE.value: datetime.now(tz=pytz.utc).timestamp()
# #             }
# #         }
# #
# #         mock_send.assert_called_once()
# #         args, kwargs = mock_send.call_args_list[0]
# #
# #         value, encoding = kwargs.get('value'), kwargs.get('encoding')
# #
# #         sent_message = json.loads(value)
# #
# #         self.assertAlmostEqual(sent_message['metadata']['timestamp'], expected_message['metadata']['timestamp'],
# #                                delta=2)
# #         self.assertEqual(sent_message['contexts'], expected_message['contexts'])
# #         self.assertAlmostEqual(
# #             sent_message['metrics'][MetricName.PROCESSING_EXIT_CODE.value],
# #             expected_message['metrics'][MetricName.PROCESSING_EXIT_CODE.value],
# #             delta=2
# #         )
# #         self.assertAlmostEqual(
# #             sent_message['metrics'][MetricName.PROCESSING_FINISHED_DATE.value],
# #             expected_message['metrics'][MetricName.PROCESSING_FINISHED_DATE.value],
# #             delta=2
# #         )
# #
# #     @patch('observability.EventHubConnector')
# #     def test_send_finished_event_custom_time_stamp_called_once(self, mock_connector):
# #         mock_send = MagicMock()
# #         mock_connector.return_value.send = mock_send
# #
# #         data_obs = DataObs(
# #             publisher_name=self.publisher_name,
# #             project_name=self.project_name,
# #             dataset_name=self.dataset_name,
# #             landing_zone=self.landing_zone,
# #             kind=self.kind,
# #             job_id=self.job_id,
# #             takeoff_zone=self.takeoff_zone,
# #             event_hub_connection_string=self.event_hub_connection_string,
# #             event_hub_name=self.event_hub_name
# #         )
# #         ts = datetime.now(tz=pytz.utc).timestamp()
# #         data_obs.send_finished_event(exit_code=ExitCode.NO_NEW_DATA, timestamp=ts)
# #
# #         # Verify the EventHubConnector is created with the correct arguments
# #         mock_connector.assert_called_once_with(
# #             event_hub_connection_string=self.event_hub_connection_string,
# #             event_hub_name=self.event_hub_name
# #         )
# #
# #         # Extract the expected message with the dynamic timestamp
# #         expected_message = {
# #             "metadata": {
# #                 "timestamp": datetime.now(tz=pytz.utc).timestamp()
# #             },
# #             "contexts": {
# #                 "publisher_name": self.publisher_name,
# #                 "project_name": self.project_name,
# #                 "dataset_name": self.dataset_name,
# #                 "landing_zone": self.landing_zone.value,
# #                 "event_type": EventType.PROCESSING_FINISHED.value,
# #                 "kind": self.kind.value,
# #                 "job_id": self.job_id,
# #                 "takeoff_zone": self.takeoff_zone.value
# #             },
# #             "metrics": {
# #                 MetricName.PROCESSING_EXIT_CODE.value: 1,
# #                 MetricName.PROCESSING_FINISHED_DATE.value: ts
# #             }
# #         }
# #
# #         mock_send.assert_called_once()
# #         args, kwargs = mock_send.call_args_list[0]
# #
# #         value, encoding = kwargs.get('value'), kwargs.get('encoding')
# #
# #         sent_message = json.loads(value)
# #
# #         self.assertAlmostEqual(sent_message['metadata']['timestamp'], expected_message['metadata']['timestamp'],
# #                                delta=2)
# #         self.assertEqual(sent_message['contexts'], expected_message['contexts'])
# #         self.assertAlmostEqual(
# #             sent_message['metrics'][MetricName.PROCESSING_EXIT_CODE.value],
# #             expected_message['metrics'][MetricName.PROCESSING_EXIT_CODE.value],
# #             delta=2
# #         )
# #         self.assertAlmostEqual(
# #             sent_message['metrics'][MetricName.PROCESSING_FINISHED_DATE.value],
# #             expected_message['metrics'][MetricName.PROCESSING_FINISHED_DATE.value],
# #             delta=1
# #         )
# #
# #     @patch('observability.EventHubConnector')
# #     def test_send_finished_event_custom_time_stamp_called_once_fail(self, mock_connector):
# #         mock_send = MagicMock()
# #         mock_connector.return_value.send = mock_send
# #
# #         data_obs = DataObs(
# #             publisher_name=self.publisher_name,
# #             project_name=self.project_name,
# #             dataset_name=self.dataset_name,
# #             landing_zone=self.landing_zone,
# #             kind=self.kind,
# #             job_id=self.job_id,
# #             takeoff_zone=self.takeoff_zone,
# #             event_hub_connection_string=self.event_hub_connection_string,
# #             event_hub_name=self.event_hub_name
# #         )
# #         ts = datetime.now(tz=pytz.utc).timestamp()
# #         data_obs.send_finished_event(exit_code=ExitCode.ERROR, timestamp=ts)
# #
# #         # Verify the EventHubConnector is created with the correct arguments
# #         mock_connector.assert_called_once_with(
# #             event_hub_connection_string=self.event_hub_connection_string,
# #             event_hub_name=self.event_hub_name
# #         )
# #
# #         # Extract the expected message with the dynamic timestamp
# #         expected_message = {
# #             "metadata": {
# #                 "timestamp": datetime.now(tz=pytz.utc).timestamp()
# #             },
# #             "contexts": {
# #                 "publisher_name": self.publisher_name,
# #                 "project_name": self.project_name,
# #                 "dataset_name": self.dataset_name,
# #                 "landing_zone": self.landing_zone.value,
# #                 "event_type": EventType.PROCESSING_FINISHED.value,
# #                 "kind": self.kind.value,
# #                 "job_id": self.job_id,
# #                 "takeoff_zone": self.takeoff_zone.value
# #             },
# #             "metrics": {
# #                 MetricName.PROCESSING_EXIT_CODE.value: -1,
# #                 MetricName.PROCESSING_FINISHED_DATE.value: ts
# #             }
# #         }
# #
# #         mock_send.assert_called_once()
# #         args, kwargs = mock_send.call_args_list[0]
# #
# #         value, encoding = kwargs.get('value'), kwargs.get('encoding')
# #
# #         sent_message = json.loads(value)
# #
# #         self.assertAlmostEqual(sent_message['metadata']['timestamp'], expected_message['metadata']['timestamp'],
# #                                delta=2)
# #         self.assertEqual(sent_message['contexts'], expected_message['contexts'])
# #         self.assertAlmostEqual(
# #             sent_message['metrics'][MetricName.PROCESSING_EXIT_CODE.value],
# #             expected_message['metrics'][MetricName.PROCESSING_EXIT_CODE.value],
# #             delta=2
# #         )
# #         self.assertAlmostEqual(
# #             sent_message['metrics'][MetricName.PROCESSING_FINISHED_DATE.value],
# #             expected_message['metrics'][MetricName.PROCESSING_FINISHED_DATE.value],
# #             delta=1
# #         )
# #
# #     @patch('observability.EventHubConnector')
# #     def test_push_volume(self, mock_connector):
# #         # Mock DataFrame
# #         df = MagicMock()
# #         df.count.return_value = 100
# #         df.columns = ['Age', 'Test']
# #         df.select.return_value.collect.return_value = [
# #             {'col_min_date': date(2023, 1, 1), 'col_max_date': date(2023, 12, 31)}]
# #         df.schema.fields = [StructField("test", StringType(), True)]
# #
# #         data_obs = DataObs(
# #             publisher_name=self.publisher_name,
# #             project_name=self.project_name,
# #             dataset_name=self.dataset_name,
# #             landing_zone=self.landing_zone,
# #             kind=self.kind,
# #             job_id=self.job_id,
# #             takeoff_zone=self.takeoff_zone,
# #             event_hub_connection_string=self.event_hub_connection_string,
# #             event_hub_name=self.event_hub_name
# #         )
# #
# #         data_obs.push(df, volume=True, distribution=False)
# #
# #         # Assert that the send method of the mocked EventHubConnector was called once
# #         mock_connector.return_value.send.assert_called_once()
# #         args, kwargs = mock_connector.return_value.send.call_args_list[0]
# #
# #         value, encoding = kwargs.get('value'), kwargs.get('encoding')
# #
# #         sent_message = json.loads(value)
# #
# #         self.assertEqual(sent_message['metrics'][MetricName.ROWS_COUNT.value], df.count.return_value)
# #         self.assertEqual(sent_message['metrics'][MetricName.COLUMNS_COUNT.value], len(df.columns))
# #
# #     @patch('observability.EventHubConnector')
# #     @patch('pyspark.sql.DataFrame')
# #     @patch.object(functions, 'min')
# #     @patch.object(functions, 'max')
# #     def test_push_freshness(self, mock_max, mock_min, mock_df, mock_connector):
# #         # Mock DataFrame
# #         df = MagicMock()
# #         df.count.return_value = 100
# #         df.columns = ['Age', 'Test']
# #
# #         max_date, min_date = date(2023, 1, 1), date(2022, 1, 1)
# #
# #         max_utc_ts = datetime(max_date.year, max_date.month, max_date.day).replace(tzinfo=pytz.UTC).timestamp()
# #         min_utc_ts = datetime(min_date.year, min_date.month, min_date.day).replace(tzinfo=pytz.UTC).timestamp()
# #
# #         df.select.return_value.collect.return_value = [
# #             {'col_min_date': min_date, 'col_max_date': max_date}]
# #
# #         df.schema.fields = [StructField("test", DateType(), True)]
# #
# #         mock_df.select.return_value = df
# #         mock_min.return_value.alias.return_value = 'col_min_date'
# #         mock_max.return_value.alias.return_value = 'col_max_date'
# #
# #         data_obs = DataObs(
# #             publisher_name=self.publisher_name,
# #             project_name=self.project_name,
# #             dataset_name=self.dataset_name,
# #             landing_zone=self.landing_zone,
# #             kind=self.kind,
# #             job_id=self.job_id,
# #             takeoff_zone=self.takeoff_zone,
# #             event_hub_connection_string=self.event_hub_connection_string,
# #             event_hub_name=self.event_hub_name
# #         )
# #
# #         data_obs.push(df, volume=False, distribution=False, freshness_column='test')
# #
# #         mock_min.assert_called_once_with('test')
# #         mock_max.assert_called_once_with('test')
# #
# #         mock_connector.return_value.send.assert_called_once()
# #         args, kwargs = mock_connector.return_value.send.call_args_list[0]
# #
# #         value, encoding = kwargs.get('value'), kwargs.get('encoding')
# #
# #         sent_message = json.loads(value)
# #
# #         self.assertEqual(sent_message['metrics'][MetricName.FRESHNESS_LATEST_UNIX_TIME_STAMP.value], max_utc_ts)
# #         self.assertEqual(sent_message['metrics'][MetricName.FRESHNESS_EARLIEST_UNIX_TIME_STAMP.value], min_utc_ts)
# #
# #     @patch('observability.EventHubConnector')
# #     @patch('pyspark.sql.DataFrame')
# #     @patch.object(functions, 'min')
# #     @patch.object(functions, 'max')
# #     def test_push_freshness_date_time(self, mock_max, mock_min, mock_df, mock_connector):
# #         # Mock DataFrame
# #         df = MagicMock()
# #         df.count.return_value = 100
# #         df.columns = ['Age', 'Test']
# #
# #         max_date, min_date = date(2023, 1, 1), date(2022, 1, 1)
# #         max_date_time = datetime(max_date.year, max_date.month, max_date.day)
# #         min_date_time = datetime(min_date.year, min_date.month, min_date.day)
# #
# #         max_utc_ts = max_date_time.replace(tzinfo=pytz.UTC).timestamp()
# #         min_utc_ts = min_date_time.replace(tzinfo=pytz.UTC).timestamp()
# #
# #         df.select.return_value.collect.return_value = [
# #             {'col_min_date': min_date_time, 'col_max_date': max_date_time}]
# #
# #         df.schema.fields = [StructField("test", TimestampType(), True)]
# #
# #         mock_df.select.return_value = df
# #         mock_min.return_value.alias.return_value = 'col_min_date'
# #         mock_max.return_value.alias.return_value = 'col_max_date'
# #
# #         data_obs = DataObs(
# #             publisher_name=self.publisher_name,
# #             project_name=self.project_name,
# #             dataset_name=self.dataset_name,
# #             landing_zone=self.landing_zone,
# #             kind=self.kind,
# #             job_id=self.job_id,
# #             takeoff_zone=self.takeoff_zone,
# #             event_hub_connection_string=self.event_hub_connection_string,
# #             event_hub_name=self.event_hub_name
# #         )
# #
# #         data_obs.push(df, volume=False, distribution=False, freshness_column='test')
# #
# #         mock_min.assert_called_once_with('test')
# #         mock_max.assert_called_once_with('test')
# #
# #         mock_connector.return_value.send.assert_called_once()
# #         args, kwargs = mock_connector.return_value.send.call_args_list[0]
# #
# #         value, encoding = kwargs.get('value'), kwargs.get('encoding')
# #
# #         sent_message = json.loads(value)
# #
# #         self.assertEqual(sent_message['metrics'][MetricName.FRESHNESS_LATEST_UNIX_TIME_STAMP.value], max_utc_ts)
# #         self.assertEqual(sent_message['metrics'][MetricName.FRESHNESS_EARLIEST_UNIX_TIME_STAMP.value], min_utc_ts)
# #
# #     @patch('observability.EventHubConnector')
# #     def test_push_error_freshness(self, mock_connector):
# #
# #         df = MagicMock()
# #         df.schema.fields = [StructField("testString", StringType(), True), StructField("test", DateType(), True)]
# #
# #         data_obs = DataObs(
# #             publisher_name=self.publisher_name,
# #             project_name=self.project_name,
# #             dataset_name=self.dataset_name,
# #             landing_zone=self.landing_zone,
# #             kind=self.kind,
# #             job_id=self.job_id,
# #             takeoff_zone=self.takeoff_zone,
# #             event_hub_connection_string=self.event_hub_connection_string,
# #             event_hub_name=self.event_hub_name
# #         )
# #         with self.assertRaises(AttributeError):
# #             data_obs.push(df, volume=False, distribution=False, freshness_column='testString')
# #
# #         with self.assertRaises(AttributeError):
# #             data_obs.push(df, volume=False, distribution=False, freshness_column='testStringUnfound')
# #
# #
# # if __name__ == "__main__":
# #     unittest.main()
