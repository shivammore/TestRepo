import time
import unittest
from unittest.mock import patch
from dataclasses import asdict
from dataops.context import Event, EventType, Kind, Context, Zone
from datetime import datetime
import pytz
import json


class TestEvent(unittest.TestCase):

    def setUp(self):
        self.subscription_id = "uuid"
        self._sub_patcher = patch(
            "dataops.context.get_azure_subscription_id",
            return_value=self.subscription_id,
        )
        self._sub_patcher.start()

        self.context = Context(
            publisher_name="publisher",
            project_name="project",
            dataset_name="dataset",
            landing_zone=Zone.GOLD,
            takeoff_zone=Zone.SILVER,
            event_type=EventType.PROCESSING_STARTED,
            kind=Kind.TABLE,
            job_id="12345",
        )
        self.metrics = {"metric1": 1.0, "metric2": 2.0}

    def test_to_dict(self):
        event = Event(context=self.context, metrics=self.metrics)
        expected_dict = {
            "metadata": {"timestamp": event.metadata.timestamp},
            "contexts": asdict(self.context),
            "metrics": self.metrics,
        }
        self.assertEqual(event.to_dict(), expected_dict)

    @patch("dataops.context.CustomJSONEncoder")
    def test_to_json(self, mock_custom_json_encoder):
        event = Event(context=self.context, metrics=self.metrics)
        json_output = json.dumps(event.to_dict(), cls=mock_custom_json_encoder)
        self.assertEqual(event.to_json(), json_output)

    def test_default_timestamp(self):
        event = Event(context=self.context)
        now_utc = datetime.now(tz=pytz.utc)
        timestamp_difference = abs(event.metadata.timestamp - now_utc.timestamp())

        # Check if the difference between the event timestamp and now_utc timestamp is less than 1 second
        self.assertLess(timestamp_difference, 2)

    def test_add_metric(self):
        event = Event(context=self.context)

        # Add a new metric
        metric_name = "test_metric"
        metric_value = 42.0
        event.add_metric(metric_name, metric_value)

        # Check if the metric is added
        self.assertIn(metric_name, event.metrics)
        self.assertEqual(event.metrics[metric_name], metric_value)

        # Add another metric
        another_metric_name = "another_test_metric"
        another_metric_value = 13.0
        event.add_metric(another_metric_name, another_metric_value)

        # Check if both metrics are present
        self.assertIn(metric_name, event.metrics)
        self.assertEqual(event.metrics[metric_name], metric_value)
        self.assertIn(another_metric_name, event.metrics)
        self.assertEqual(event.metrics[another_metric_name], another_metric_value)

    def test_time_stamp_init_generation(self):
        event_one = Event(context=self.context)
        time.sleep(1)
        event_two = Event(context=self.context)

        self.assertLess(event_one.metadata.timestamp, event_two.metadata.timestamp)
        self.assertGreaterEqual(
            abs(event_two.metadata.timestamp - event_one.metadata.timestamp), 1
        )


if __name__ == "__main__":
    unittest.main()
