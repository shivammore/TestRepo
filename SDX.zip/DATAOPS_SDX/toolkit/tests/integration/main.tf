terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">=3.0.0"
    }
    databricks = {
      source = "databricks/databricks"
      version = "1.18.0"
    }
  }
    backend "local" {
    path = "./terraform.tfstate"
  }

}
provider "azurerm" {
  features {}
}

variable "resource_group_name" {
  default = "GRP-EU-IFM-DEV-RG67"
  description = ""
}

variable "resource_location" {
  default = "northeurope"
  description = ""
}

resource "azurerm_databricks_workspace" "ws" {
  name                        = "ObservabilityIntegrationTestDatabricksWorkspaceName"
  resource_group_name         = var.resource_group_name
  location                    = var.resource_location
  sku                         = "premium"
  managed_resource_group_name = "managed-${var.resource_group_name}"

  lifecycle {
    ignore_changes = [tags]
  }
}

# Use Azure CLI authentication.
provider "databricks" {
  host = "https://${azurerm_databricks_workspace.ws.workspace_url}"
}


resource "azurerm_eventhub_namespace" "ns" {
  name                = "ObservabilityIntegrationTestEventHubNamespace"
  location            = var.resource_location
  resource_group_name = var.resource_group_name
  sku                 = "Standard"
}

resource "azurerm_eventhub" "hub" {
  name                = "ObservabilityIntegrationTestEventHubName"
  namespace_name      = azurerm_eventhub_namespace.ns.name
  resource_group_name = var.resource_group_name
  partition_count     = 2
  message_retention   = 1
}

data "databricks_node_type" "smallest" {
  local_disk = true
}

data "databricks_spark_version" "latest" {

}

resource "databricks_cluster" "single_node" {
  cluster_name            = "Single Node"
  spark_version           = data.databricks_spark_version.latest.id
  node_type_id            = data.databricks_node_type.smallest.id
  autotermination_minutes = 10

  spark_conf = {
    # Single-node
    "spark.databricks.cluster.profile" : "singleNode"
    "spark.master" : "local[*]",
    "spark.databricks.python.virtualenv.bin.path" : "/databricks/python3/bin/",
    "spark.databricks.python.virtualenv.lib" : "/databricks/python3/lib/python3.8/site-packages"

  }
  spark_env_vars = {
    "EVENT_HUB_CONNECTION_STRING" = azurerm_eventhub_namespace.ns.default_primary_connection_string
    "EVENT_HUB_NAME" = azurerm_eventhub.hub.name
  }

  custom_tags = {
    "ResourceClass" = "SingleNode"
  }

  depends_on = [
    azurerm_eventhub.hub,
    azurerm_eventhub_namespace.ns,
  ]
}

output "eventhub_connection_string" {
  value       = azurerm_eventhub_namespace.ns.default_primary_connection_string
  description = "eventhub_connection_string "
}

output "eventhub_name" {
  value       = azurerm_eventhub.hub.name
  description = "azurerm_eventhub.hub.name"
}

output "databricks_ws_host" {
  value       = "https://${azurerm_databricks_workspace.ws.workspace_url}"
  description = "Databricks WS HOST "
}
