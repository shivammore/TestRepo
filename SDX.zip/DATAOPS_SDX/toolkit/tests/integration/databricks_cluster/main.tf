terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">=3.0.0"
    }
    databricks = {
      source = "databricks/databricks"
      version = "1.18.0"
    }
  }
    backend "local" {
    path = "./terraform.tfstate"
  }

}
provider "azurerm" {
  features {}
}

variable "resource_group_name" {
  default = "GRP-EU-IFM-DEV-RG67"
  description = ""
}

variable "resource_location" {
  default = "northeurope"
  description = ""
}

variable "databricks_host" {
  description = "databricks_host"
}

# Use Azure CLI authentication.
provider "databricks" {
  host = var.databricks_host
}


variable "wheel_path" {
  description = "Path to the wheel file"
  type        = string
  default = ""
}


#resource "azurerm_eventhub_namespace" "ns" {
#  name                = "ObservabilityIntegrationTestEventHubNamespace"
#  location            = var.resource_location
#  resource_group_name = var.resource_group_name
#  sku                 = "Standard"
#}
#
#resource "azurerm_eventhub" "hub" {
#  name                = "ObservabilityIntegrationTestEventHubName"
#  namespace_name      = azurerm_eventhub_namespace.ns.name
#  resource_group_name = var.resource_group_name
#  partition_count     = 2
#  message_retention   = 1
#}
#
#data "databricks_node_type" "smallest" {
#  local_disk = true
#}
#
#data "databricks_spark_version" "latest" {
#
#}
#
#resource "databricks_cluster" "single_node" {
#  cluster_name            = "Single Node"
#  spark_version           = data.databricks_spark_version.latest.id
#  node_type_id            = data.databricks_node_type.smallest.id
#  autotermination_minutes = 10
#
#  spark_conf = {
#    # Single-node
#    "spark.databricks.cluster.profile" : "singleNode"
#    "spark.master" : "local[*]",
#    "spark.databricks.python.virtualenv.bin.path" : "/databricks/python3/bin/",
#    "spark.databricks.python.virtualenv.lib" : "/databricks/python3/lib/python3.8/site-packages"
#
#  }
#  spark_env_vars = {
#    "EVENT_HUB_CONNECTION_STRING" = azurerm_eventhub_namespace.ns.default_primary_connection_string
#    "EVENT_HUB_NAME" = azurerm_eventhub.hub.name
#  }
#
#  custom_tags = {
#    "ResourceClass" = "SingleNode"
#  }
#
#  depends_on = [
#    azurerm_eventhub.hub,
#    azurerm_eventhub_namespace.ns,
#  ]
#}


data "azurerm_databricks_workspace" "ws" {
  name = "ObservabilityIntegrationTestDatabricksWorkspaceName"
  resource_group_name = var.resource_group_name
}

resource "databricks_dbfs_file" "python_script" {
  source = "../test_connection.py"
  path   = "/FileStore/test_connection.py"

  depends_on = [data.azurerm_databricks_workspace.ws]

}

#resource "databricks_job" "python_script_job" {
#  name = "python-script-job"
#
#  existing_cluster_id = databricks_cluster.single_node.id
#
#  spark_python_task {
#    python_file = "dbfs:${databricks_dbfs_file.python_script.path}"
#  }
#
#  depends_on = [
#    databricks_dbfs_file.python_script,
#  ]
#}
#
#resource "databricks_dbfs_file" "app" {
#  source = var.wheel_path
#  path   = "/FileStore/${basename(var.wheel_path)}"
#
#  depends_on = [
#    databricks_cluster.single_node
#  ]
#}
#
#resource "databricks_library" "app" {
#  cluster_id = databricks_cluster.single_node.id
#  whl        = "dbfs:${databricks_dbfs_file.app.path}"
#
#   depends_on = [
#    databricks_cluster.single_node
#  ]
#}
#
#output "databricks_job_id" {
#  value       = databricks_job.python_script_job.id
#  description = "Databricks JOB ID "
#}