terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">=3.0.0"
    }
    databricks = {
      source = "databricks/databricks"
      version = "1.18.0"
    }
  }
    backend "local" {
    path = "./terraform.tfstate"
  }

}
provider "azurerm" {
  features {}
}

variable "resource_group_name" {
  default = "GRP-EU-IFM-DEV-RG67"
  description = ""
}

variable "resource_location" {
  default = "northeurope"
  description = ""
}

resource "azurerm_databricks_workspace" "ws" {
  name                        = "ObservabilityIntegrationTestDatabricksWorkspaceName"
  resource_group_name         = var.resource_group_name
  location                    = var.resource_location
  sku                         = "premium"
  managed_resource_group_name = "managed-${var.resource_group_name}"

  lifecycle {
    ignore_changes = [tags]
  }
}

output "databricks_ws_host" {
  value       = "https://${azurerm_databricks_workspace.ws.workspace_url}"
  description = "Databricks WS HOST "
}