from datetime import datetime, date
from typing import Optional, Union

import pytz
from pyspark.sql import functions as functions
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.types import DateType, TimestampType

from dataops.connector.eventhub import EventHubConnector
from dataops.context import Event
from dataops.context import (
    EventType,
    Kind,
    Context,
    Zone,
    MetricName,
    ExitCode,
    Log,
    LogLevel,
)


class DataObs:
    """
    DataObs is a class that represents dataops for PySpark DataFrames.
    It captures information about various events and metrics related to data processing.
    It sends the events to an Azure Event Hub.

    Attributes:
        publisher_name (str): Name of the publisher.
        project_name (str): Name of the project.
        dataset_name (str): Name of the dataset.
        landing_zone (Zone): Enum value representing the landing zone (e.g., RAW, CURATED).
        kind (Kind): Enum value representing the kind of data (e.g., FILE, STREAM).
        job_id (str): Unique identifier of the job.
        takeoff_zone (Zone): Enum value representing the takeoff_zone , if any.
        event_hub_connection_string (Optional[str]): Connection string for the Event Hub.
        event_hub_name (Optional[str]): Name of the Event Hub.

    Methods:
        send_processing_event(): Sends a processing event to the Azure Event Hub.
    """

    __connector: EventHubConnector

    def __init__(
        self,
        publisher_name: str,
        project_name: str,
        dataset_name: str,
        landing_zone: Union[str, Zone],
        kind: Union[str, Kind],
        job_id: str,
        takeoff_zone: Union[str, Zone],
        event_hub_connection_string: Optional[str] = None,
        event_hub_name: Optional[str] = None,
    ):
        self.__publisher_name = publisher_name
        self.__project_name = project_name
        self.__dataset_name = dataset_name
        self.__landing_zone = landing_zone
        self.__kind = kind
        self.__job_id = job_id
        self.__takeoff_zone = takeoff_zone

        self.__connector = EventHubConnector(
            event_hub_connection_string=event_hub_connection_string,
            event_hub_name=event_hub_name,
        )

    def send_processing_event(self, timestamp: Optional[float] = None) -> None:
        """
         Creates a processing event and sends it to the Azure Event Hub.
        The event contains information about the publisher, project, dataset,
        landing zone, kind, job_id, takeoff_zone, and event_type.

        The event is serialized into JSON format before being sent to the Event Hub.
        """

        context = Context(
            publisher_name=self.__publisher_name,
            project_name=self.__project_name,
            dataset_name=self.__dataset_name,
            landing_zone=self.__landing_zone,
            kind=self.__kind,
            job_id=self.__job_id,
            takeoff_zone=self.__takeoff_zone,
            event_type=EventType.PROCESSING_STARTED,
        )

        event = Event(context=context)
        timestamp = (
            timestamp
            if timestamp is not None
            else datetime.now(tz=pytz.utc).timestamp()
        )
        event.add_metric(
            metric_name=MetricName.PROCESSING_STARTED_DATE, metric_value=timestamp
        )

        return self.__connector.send(value=event.to_json(), encoding="utf-8")

    def send_finished_event(
        self,
        exit_code: Union[int, ExitCode],
        error_message: Optional[str] = None,
        timestamp: Optional[float] = None,
        log_level: LogLevel = LogLevel.INFO,
    ) -> None:
        """
        Sends an event to the configured event hub indicating the completion of a processing job.This method allows
        for the inclusion of an optional error message and log level, providing the ability to record additional
        context about the job's outcome, especially in cases where the job did not complete successfully.

        Args:
            exit_code: An integer representing the exit code of the job.
            error_message: An optional string that provides details about any errors that occurred during the job's execution.
            timestamp: An float representing the current unix epochs
            log_level: Define the level of the log

        Raises:
            ConnectionError: If there was an error connecting to the event hub.
            TimeoutError: If the connection to the event hub timed out.

        Returns:
            None.
        """
        context = Context(
            publisher_name=self.__publisher_name,
            project_name=self.__project_name,
            dataset_name=self.__dataset_name,
            landing_zone=self.__landing_zone,
            kind=self.__kind,
            job_id=self.__job_id,
            takeoff_zone=self.__takeoff_zone,
            event_type=EventType.PROCESSING_FINISHED,
        )

        event = Event(context=context)
        timestamp = (
            timestamp
            if timestamp is not None
            else datetime.now(tz=pytz.utc).timestamp()
        )

        event.add_metric(
            metric_name=MetricName.PROCESSING_EXIT_CODE, metric_value=exit_code
        )
        event.add_metric(
            metric_name=MetricName.PROCESSING_FINISHED_DATE, metric_value=timestamp
        )

        if error_message:
            event.logs = [Log(message=error_message, level=log_level)]

        return self.__connector.send(value=event.to_json(), encoding="utf-8")

    def push(
        self,
        df: DataFrame,
        volume: bool = True,
        freshness_column: Union[None, str] = None,
        distribution: bool = True,
        col_agregation: str = None,
    ) -> None:
        """
        Sends a POST_PROCESSING event to the Observability Connector,
        including metrics calculated based on the given DataFrame.

        Args:
            df (pyspark.sql.dataframe.DataFrame): The DataFrame to be analyzed.
            volume (bool, optional): If True, includes the number of rows in the DataFrame as a metric.
            freshness_column (Union[None, str], optional): If not None, includes metrics about the freshness
             of the data in the specified column.
            distribution (bool, optional): If True, includes metrics about the distribution of values in the DataFrame.

        Raises:
            AttributeError: If the specified freshness column does not exist or is not of type DateType.

        """

        context = Context(
            publisher_name=self.__publisher_name,
            project_name=self.__project_name,
            dataset_name=self.__dataset_name,
            landing_zone=self.__landing_zone,
            kind=self.__kind,
            job_id=self.__job_id,
            takeoff_zone=self.__takeoff_zone,
            event_type=EventType.PROCESSING_FINISHED,
        )
        event = Event(context=context)

        if volume:
            event.add_metric(metric_name=MetricName.ROWS_COUNT, metric_value=df.count())
            event.add_metric(
                metric_name=MetricName.COLUMNS_COUNT, metric_value=len(df.columns)
            )

        if freshness_column:
            freshness_field = [
                field for field in df.schema.fields if field.name == freshness_column
            ]

            if len(freshness_field) != 1:
                raise AttributeError(
                    f"{freshness_column} column doesn't exist in the DataFrame"
                )

            freshness_field_pop = freshness_field.pop()

            if not (
                isinstance(freshness_field_pop.dataType, DateType)
                or isinstance(freshness_field_pop.dataType, TimestampType)
            ):
                raise AttributeError(
                    f"{freshness_column} is not a supported type. "
                    f"Only DateType or TimestampType is allowed."
                )

            col_min_date = functions.min(freshness_column).alias("col_min_date")
            col_max_date = functions.max(freshness_column).alias("col_max_date")

            list_rows = df.select(col_min_date, col_max_date).collect()
            col_min_date_value, col_max_date_value = (
                list_rows[0]["col_min_date"],
                list_rows[0]["col_max_date"],
            )

            if isinstance(col_min_date_value, date):
                min_datetime = datetime(
                    col_min_date_value.year,
                    col_min_date_value.month,
                    col_min_date_value.day,
                )
                min_utc_ts = min_datetime.replace(tzinfo=pytz.UTC).timestamp()

                event.add_metric(
                    metric_name=MetricName.FRESHNESS_EARLIEST_UNIX_TIME_STAMP,
                    metric_value=min_utc_ts,
                )

            elif isinstance(col_min_date_value, datetime):
                min_utc_ts = col_min_date_value.replace(tzinfo=pytz.UTC).timestamp()
                event.add_metric(
                    metric_name=MetricName.FRESHNESS_EARLIEST_UNIX_TIME_STAMP,
                    metric_value=min_utc_ts,
                )

            if isinstance(col_max_date_value, date):
                max_datetime = datetime(
                    col_max_date_value.year,
                    col_max_date_value.month,
                    col_max_date_value.day,
                )
                max_utc_ts = max_datetime.replace(tzinfo=pytz.UTC).timestamp()
                event.add_metric(
                    metric_name=MetricName.FRESHNESS_LATEST_UNIX_TIME_STAMP,
                    metric_value=max_utc_ts,
                )

            elif isinstance(col_max_date_value, datetime):
                max_utc_ts = col_max_date.replace(tzinfo=pytz.UTC).timestamp()  # type: ignore
                event.add_metric(
                    metric_name=MetricName.FRESHNESS_LATEST_UNIX_TIME_STAMP,
                    metric_value=max_utc_ts,
                )

        if col_agregation is not None:
            dict_cardinality = df.groupby(col_agregation).count().collect()
            cardinality = len(dict_cardinality)
            print("cardinality:", cardinality)

            if cardinality > 100:
                return
            df_metric = df.groupby(col_agregation).count()

            for line in df_metric.collect():
                metric_name = f"SITE_{str(line[col_agregation])}"
                metric_value = line["count"]
                event.add_metric(metric_name=metric_name, metric_value=metric_value)

        if len(event.metrics) != 0:
            self.__connector.send(value=event.to_json(), encoding="utf-8")
