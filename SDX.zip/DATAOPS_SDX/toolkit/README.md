# Data Observability Toolkit

This project provides a practical data observability toolkit for PySpark DataFrames. This means you can monitor your data processing pipelines, tracking various events and metrics, and conveniently communicate this information to an Azure Event Hub.

## Why a Common Library?

A shared library promotes consistency and standardization across all data processing projects. By adhering to a common standard, teams can enjoy easier management, maintenance, and troubleshooting. It also reduces redundant code, minimizing error likelihood and promoting easier understanding and maintenance.

## Usage

At the heart of this library, we have the `DataObs` class, which allows tracking of events and metrics for specific data processing tasks. Here's a brief overview of its methods:

### Initializing `DataObs`

The `DataObs` class requires the following details on initialization:

- Name of the publisher: name to identify who send the event (ex: publisher_name= data_asset_builder)
- Name of the project: name to identify the project {business_lines}.{region_code}.{country_code}.{source_name} (ex: project_name=oss.glb.coe.sap)
- Name of the datatet (ex: dataset_name=eina)
- The kind of data being handled (file, table ,stream, etc.)
- The landing zone (ex: landing_zone=Zone.SILVER )
- Unique identifier of the job (job_id="oss.glb.coe.sap:bronze_to_silver:4ab83fd7-1b0b-4e43-a301-86e68ae3174d")
- The take-off zone (optional, ex: takeoff_zone=Zone.BRONZE)
- Connection string and name for the Event Hub (optional)

Naming rules: https://sdxcloud.visualstudio.com/IST.GLB.GLB.GDS_DATAPLATFORM/_wiki/wikis/IST.GLB.GLB.GDS_DATAPLATFORM.wiki/7839/Event-Naming-rules

### Starting a Processing Event

The `send_processing_event` method is used to initiate a data processing event. It communicates this event to the Azure Event Hub. Optionally, a Unix timestamp can be added to log the exact time of the event.

### Indicating a Finished Event

`send_finished_event` method signals the completion of a data processing job. It requires the exit code of the job and can optionally include a Unix timestamp.This method has been enhanced to handle an optional error message and a log level parameter, providing detailed feedback in case of errors or specific outcomes. It ensures robust error handling and detailed event logging, enriching the observability data.

### Post-processing Event

The `push` method sends a POST_PROCESSING event, including metrics calculated from the DataFrame, to the Observability Connector. You can customize it to include:

- Number of rows (volume) in the DataFrame
- Freshness of the data (requires the name of the column)
- Distribution of values in the DataFrame

## Authentication

The toolkit uses the `EventHubConnector` class for authentication. This class connects with the Event Hub using a connection string and the Event Hub's name.

### Setting up `EventHubConnector`

When initializing the `EventHubConnector`, you will need:

- Event Hub connection string: This can be provided directly or retrieved from the `EVENT_HUB_CONNECTION_STRING` environment variable.
- Event Hub name: Similar to the connection string, this can be directly given or fetched from the `EVENT_HUB_NAME` environment variable.

Once these values are provided, the `EventHubConnector` will establish a connection with the Event Hub, allowing your application to communicate events and metrics.

## Usage Example

The following code provides a simple demonstration of how to use the `DataObs` class and its methods.

```python
from observability import DataObs
from dataops.context import Zone, Kind, ExitCode, LogLevel
from pyspark.sql import SparkSession

# Initialize SparkSession
spark = SparkSession.builder.getOrCreate()

# Create a sample DataFrame
data = [("John", "Doe", 30), ("Jane", "Doe", 25)]
df = spark.createDataFrame(data, ["FirstName", "LastName", "Age"])

# Initialize the DataObs object
dataobs = DataObs(
  publisher_name="DemoPublisher",
  project_name="DemoProject",
  dataset_name="DemoDataset",
  landing_zone=Zone.SILVER,
  takeoff_zone=Zone.BRONZE,
  kind=Kind.TABLE,
  job_id="Job1",
  event_hub_connection_string="<Your Azure Event Hub Connection String>",
  event_hub_name="<Your Azure Event Hub Name>"
)

# Send a processing started event
dataobs.send_processing_event()


# Check processing outcome and determine appropriate exit code and error message
processing_success = True  
exit_code = ExitCode.SUCCESS if processing_success else ExitCode.ERROR
error_message = None if processing_success else "An error occurred during processing."
 
# Send a finished event with an appropriate exit code
# and an optional error message for failed processing
dataobs.send_finished_event(exit_code=exit_code, error_message=error_message, log_level= LogLevel.ERROR)

# Send post processing metrics
dataobs.push(df, volume=True, freshness_column=None, distribution=True)
```

Remember to replace the "<Your Azure Event Hub Connection String>" and 
"<Your Azure Event Hub Name>" placeholders with your actual Azure Event Hub credentials.

This snippet first creates a sample DataFrame using PySpark. It then initializes
the `DataObs` object with necessary details. It sends a `PROCESSING_STARTED` event,
processes the DataFrame, and then sends a `PROCESSING_FINISHED` event. Finally,
it calculates post processing metrics and sends them to the Azure Event Hub.

The ExitCode enumeration introduced in this commit solves this problem by giving meaningful names to each exit code. 
- SUCCESS: Represents a successful execution with an exit code of 0.
- ERROR: Represents a generic error state with an exit code of -1.
- NO_NEW_DATA: Represents a state where no new data was found, with an exit code of 1.

# Toolkit Testing

We strongly believe in the importance of testing to deliver high-quality software. This toolkit is tested thoroughly through a mix of unit tests, integration tests, and functional tests.

## Test Types

### Unit Tests

Unit tests ensure that individual components of the system work as expected. They target small, isolated pieces of the codebase to ensure that they function correctly in isolation.

### Integration Tests

Integration tests aim to test the system as a whole, checking the interactions between different components of the application. They ensure that the system works as expected when all parts are combined.

### Functional Tests

Functional tests are high-level tests that verify the system's functionalities against the requirements. They ensure the software product is functionally complete and works as expected end-to-end.

For each release, we spin a cluster in Databricks with the same version of `dataassetbuilders` to guarantee that the toolkit is fully functional.

## Test Structure

Our tests are organized in a clear and simple structure as per their type and scope. Here's a brief overview of the directory structure:

## Test Structure

Our tests are organized in a clear and simple structure as per their type and scope. Here's a brief overview of the directory structure:

- `__init__.py`: This is an empty file that instructs Python to treat directories as containing packages.

- `functional`: This directory contains all functional test files. Functional tests are high-level tests that verify the system's functionalities against the requirements.

- `integration`: This directory is for all integration test files. It is further divided into two subdirectories:
  - `databricks_cluster`: Contains terraform files (`main.tf`) for setting up the Databricks cluster.
  - `databricks_workspace`: Contains terraform files (`main.tf`) for setting up the Databricks workspace.

- `unit`: This directory contains all unit test files. Unit tests ensure that individual components of the system work as expected in isolation.

## Code Style

### PEP 484 - Type Hints

Our project adheres to the Python type hints style guide, [PEP 484](https://peps.python.org/pep-0484/),
as a standard to improve the readability and maintainability of our codebase. PEP 484 provides a set of rules for
using type hints, which are a mechanism for statically indicating the type of a value within your Python code.
This makes the code easier to read, understand and debug.

### Code Quality

### Flake8
We use Flake8 as a Python tool for enforcing our code style. It checks our code against the style guides and reports any discrepancies.
To add Flake8 to your Poetry-managed project, To check the code style of your project with Flake8, use:
:

```bash
poetry run flake8 
```

### Mypy
Mypy is an optional static type checker for Python. By following the typing discipline, we aim to make our code more readable and robust.

To add Mypy to your Poetry-managed project, use:

```bash
poetry add --dev mypy
```

To run Mypy , use:

```bash
poetry run mypy observability.py dataops --explicit-package-bases
```

