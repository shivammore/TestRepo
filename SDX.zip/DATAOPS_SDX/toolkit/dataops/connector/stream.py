import os
import re
from kafka import KafkaProducer
from typing import Optional, Union, Tuple


class KafkaConnector:
    __producer: KafkaProducer
    __topic: str

    def __init__(
        self,
        event_hub_connection_string: Optional[str] = None,
        event_hub_name: Optional[str] = None,
    ):
        """
        Initializes an instance of KafkaConnector.
        :param event_hub_connection_string: The connection string for the Event Hub (optional).
        :param event_hub_name: The event hub name AKA topic (optional).
        """

        if event_hub_connection_string is None:
            event_hub_connection_string = os.getenv("EVENT_HUB_CONNECTION_STRING", None)
            if event_hub_connection_string is None:
                raise ValueError(
                    "Event Hub connection string is not provided and not found in environment variables."
                )

        if event_hub_name is None:
            event_hub_name = os.getenv("EVENT_HUB_NAME", None)
            if event_hub_name is None:
                raise ValueError(
                    "Event Hub FQDN is not provided and not found in environment variables."
                )

        fqdn, sasl_plain_username, sasl_plain_password = self.parse_connection_string(
            connection_str=event_hub_connection_string
        )

        self.__producer = KafkaProducer(
            bootstrap_servers=fqdn,
            security_protocol="SASL_SSL",
            sasl_mechanism="PLAIN",
            sasl_plain_username=sasl_plain_username,
            sasl_plain_password=sasl_plain_password,
        )
        self.__topic = event_hub_name

    @classmethod
    def parse_connection_string(cls, connection_str: str) -> Tuple[str, str, str]:
        """
        Parse an Azure Event Hubs connection string and extract the required components for authentication.

        Args:
            connection_str (str): The Event Hubs connection string containing the FQDN, SharedAccessKeyName, and SharedAccessKey.

        Returns:
            tuple: A tuple containing the FQDN (str), sasl_plain_username (str), and sasl_plain_password (str).

        Raises:
            ValueError: If the connection string is malformed or if any of the required components are missing.
        """
        pattern = r"Endpoint=sb://(?P<fqdn>[^/]+)/;SharedAccessKeyName=(?P<keyname>[^;]+);SharedAccessKey=(?P<key>[^;]+)"
        match = re.match(pattern, connection_str)
        if not match:
            raise ValueError("Invalid connection string")

        fqdn = match.group("fqdn")
        if not fqdn:
            raise ValueError("FQDN not found in connection string")

        sasl_plain_username = match.group("keyname")
        if not sasl_plain_username:
            raise ValueError("SharedAccessKeyName not found in connection string")

        sasl_plain_password = match.group("key")
        if not sasl_plain_password:
            raise ValueError("SharedAccessKey not found in connection string")

        return fqdn, sasl_plain_username, sasl_plain_password

    def send(
        self,
        value: str,
        key: Optional[Union[str, bytes]] = None,
        encoding: str = "utf-8",
    ):
        """
        Sends a message to the specified topic using the Kafka producer.

        :param value: The message value (string).
        :param key: The optional message key (string or bytes).
        :param encoding: The string encoding (default is 'utf-8').
        """

        if key is not None and isinstance(key, str):
            key = key.encode(encoding)

        self.__producer.send(self.__topic, value=value.encode(encoding), key=key)
        self.__producer.flush()
