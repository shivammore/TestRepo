import os
from typing import Optional
from azure.eventhub import EventHubProducerClient, EventData


class EventHubConnector:
    __producer: EventHubProducerClient

    def __init__(
        self,
        event_hub_connection_string: Optional[str] = None,
        event_hub_name: Optional[str] = None,
    ):
        """
        Initializes an instance of EventHubConnector.
        :param event_hub_connection_string: The connection string for the Event Hub (optional).
        :param event_hub_name: The event hub name (optional).
        """

        if event_hub_connection_string is None:
            event_hub_connection_string = os.getenv("EVENT_HUB_CONNECTION_STRING", None)
            if event_hub_connection_string is None:
                raise ValueError(
                    "Event Hub connection string is not provided and not found in environment variables."
                )

        if event_hub_name is None:
            event_hub_name = os.getenv("EVENT_HUB_NAME", None)
            if event_hub_name is None:
                raise ValueError(
                    "Event Hub name is not provided and not found in environment variables."
                )

        self.__producer = EventHubProducerClient.from_connection_string(
            conn_str=event_hub_connection_string, eventhub_name=event_hub_name
        )

    def send(self, value: str, encoding: str = "utf-8"):
        """
        Sends a message to the specified event hub using the Event Hub producer client.

        :param value: The message value (string).
        :param encoding: The string encoding (default is 'utf-8').
        """

        with self.__producer as producer:
            event_data_batch = producer.create_batch()
            event_data_batch.add(EventData(value.encode(encoding)))
            producer.send_batch(event_data_batch=event_data_batch)
