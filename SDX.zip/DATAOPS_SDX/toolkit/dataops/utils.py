from pyspark.sql import SparkSession


def get_azure_subscription_id() -> str:
    """
    Retrieve the value of the configuration 'spark.databricks.clusterUsageTags.azureSubscriptionId'.

    :return: Configuration value if found, otherwise 'None'.
    """
    spark = SparkSession.builder.appName("ConfigExtractor").getOrCreate()
    value = spark.conf.get("spark.databricks.clusterUsageTags.azureSubscriptionId")

    return value if value else "None"
