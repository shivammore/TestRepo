import json
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from dataops.utils import get_azure_subscription_id
from datetime import datetime
from typing import Dict, Optional, Union, List
import pytz
from enum import Enum


class ExitCode(int, Enum):
    SUCCESS: int = 0
    ERROR: int = -1
    NO_NEW_DATA: int = 1
    SKIPPED: int = 2


class MetricName(str, Enum):
    PROCESSING_STARTED_DATE: str = "processing_started_date"
    PROCESSING_FINISHED_DATE: str = "processing_finished_date"
    PROCESSING_EXIT_CODE: str = "processing_exit_code"

    ROWS_COUNT: str = "rows_count"
    COLUMNS_COUNT: str = "columns_count"
    REJECTED_RECORDS: str = "rejected_records"

    FRESHNESS_LATEST_UNIX_TIME_STAMP: str = "content_latest_date"
    FRESHNESS_EARLIEST_UNIX_TIME_STAMP: str = "content_oldest_date"
    SITE_PATTERN: str = "SITE_%%%%%%%%"


class EventType(str, Enum):
    PROCESSING_STARTED: str = "processingstarted"
    PROCESSING_FINISHED: str = "processingfinished"


class Zone(str, Enum):
    SILVER: str = "silver"
    BRONZE: str = "bronze"  # deprecated
    GOLD: str = "gold"
    STAGING: str = "staging"
    RAW: str = "raw"  # deprecated
    BRONZE_HISTORY: str = "bronze_history"
    BRONZE_RAW: str = "bronze_raw"
    TRANSIENT: str = "transient"
    LANDING: str = "landing"  # Urbanization rules for SDX (October 2023)
    HISTORY: str = "history"
    STANDARDIZED: str = "standardized"
    SOURCE: str = (
        "source"  # For the ingestion directly from source to landing in SDX (May 2024)
    )


class Kind(str, Enum):
    TABLE: str = "table"


class LogLevel(str, Enum):
    TRACE = "trace"
    DEBUG = "debug"
    INFO = "info"
    WARN = "warn"
    ERROR = "error"


class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):

        if isinstance(obj, Enum):
            return obj.value
        elif type(obj) in [Zone, MetricName, EventType, ExitCode, Kind]:
            return obj.value
        elif isinstance(obj, dict):
            return {k.value if isinstance(k, Enum) else k: v for k, v in obj.items()}

        return super().default(obj)


@dataclass
class Context:
    """
    Context dataclass represents the context of an event

    Attributes:
    ----------
        publisher_name: name of the event publisher
        project_name: name of the project which generates the event
        dataset_name: name of the processed dataset
        landing_zone: zone where data are write
        event_type: type of the event (ProcessingStarted, ProcessingFinished)
        kind: type of processed data (file, column)
        job_id: id of the processing job
        takeoff_zone: zone where data are read
        subscription_id: Azure SubscriptionId

    Methods:
    -------
        to_dict(): Returns a dictionary representation of the Context dataclass.
        __post_init__(): Return the Azure SubscriptionId
        to_json(): Returns a JSON string representation of the Context dataclass.
    """

    publisher_name: str
    project_name: str
    dataset_name: str
    landing_zone: Union[str, Zone]
    event_type: str
    kind: Union[str, Kind]
    job_id: str
    takeoff_zone: Union[str, Zone]
    subscription_id: Optional[str] = None

    def to_dict(self):
        return asdict(self)

    def __post_init__(self):
        self.subscription_id = (
            get_azure_subscription_id()
            if self.subscription_id is None
            else self.subscription_id
        )

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), cls=CustomJSONEncoder)


@dataclass
class MetaData:
    """
    A dataclass for maintaining metadata, specifically a timestamp.

    Attributes
    ----------
    timestamp : Optional[float]
        The timestamp as a float. If no timestamp is given during instantiation,
        it will default to the current time in UTC.

    Methods
    -------
    __post_init__():
        A dataclass specific method that runs after the class is instantiated.
        It sets the timestamp to the current time in UTC if it's not provided during initialization.

    to_dict():
        Converts the MetaData instance to a dictionary.
    """

    timestamp: Optional[float] = None

    def __post_init__(self):
        """
        Post-initialization method for the MetaData dataclass.
        If the timestamp is not provided during instantiation, it sets the timestamp
        to the current time in UTC.

        Returns
        -------
        None
        """
        self.timestamp = (
            self.timestamp
            if self.timestamp is not None
            else datetime.now(tz=pytz.utc).timestamp()
        )

    def to_dict(self):
        """
        Converts the MetaData instance to a dictionary.

        Returns
        -------
        dict
            A dictionary representation of the MetaData instance.
        """

        return asdict(self)


@dataclass
class Log:
    """
    Log dataclass represents a single log entry.

    Attributes:
    ----------
    timestamp: float
        The time at which the log entry was created, represented as a floating-point number.
    message: str
        The content of the log message.
    level: LogLevel
        The severity level of the log, categorized by the LogLevel enumeration (DEBUG, INFO, WARNING, ERROR, CRITICAL).
    max_message_length: int
        The maximum length that the log message can have. If the provided message exceeds this length, it will be truncated.
        Defaults to 500 characters.

    Methods:
    -------
    to_dict():
        Returns a dictionary representation of the Log instance,
        which is useful for serialization or when working with systems that expect data in dictionary format.
    __post_init__():
        A method that runs after the class's initialization.
        It checks if the message length exceeds `max_message_length` and truncates the message if necessary.
    """

    message: str
    level: LogLevel
    timestamp: Optional[float] = None

    def __post_init__(self):
        max_message_length: int = 500
        if len(self.message) > max_message_length:
            self.message = self.message[:max_message_length] + "..."

    def to_dict(self):
        return asdict(self)


@dataclass
class Event:
    """
     Event dataclass represents an event with context, timestamp, and metrics.
    This structure facilitates the comprehensive tracking of event details, metadata, performance metrics, and
    any associated log messages that may indicate the event's status, errors, or warnings.

    Attributes:
        context (Context): An instance of the Context dataclass containing event metadata.
        metadata (MetaData): The event MetaData if None it will auto generated
        metrics (Dict[str, float]): A dictionary containing metric names as keys and their values as floats.
                                     Defaults to an empty dictionary.
        logs (Optional[List[Log]]): An optional instance of the Log dataclass that captures any logging information.
                                     This could include errors, warnings, informational messages, or debug logs.

    Methods:
        to_dict: Returns a dictionary representation of the Event dataclass.
        to_json: Returns a JSON string representation of the Event dataclass.
    """

    context: Context
    metadata: Optional[MetaData] = None  # type: ignore
    metrics: Dict[str, float] = field(default_factory=lambda: defaultdict(float))
    logs: Optional[List[Log]] = None

    def __post_init__(self):
        self.metadata = self.metadata if self.metadata is not None else MetaData()

    def to_dict(self) -> Dict:
        """
        Returns a dictionary representation of the Event dataclass.

        Returns:
            dict: A dictionary containing the metadata, context, and metrics of the event.
        """
        event = {
            "metadata": self.metadata.to_dict(),
            "contexts": self.context.to_dict(),
            "metrics": self.metrics,
        }

        if self.logs:
            event["logs"] = [log.to_dict() for log in self.logs]

        return event

    def add_metric(
        self, metric_name: Union[str, MetricName], metric_value: float
    ) -> None:
        self.metrics = {**self.metrics, **{metric_name: metric_value}}

    def to_json(self):
        """
        Returns a JSON string representation of the Event dataclass.

        Returns:
            str: A JSON string containing the metadata, context, and metrics of the event.
        """
        return json.dumps(self.to_dict(), cls=CustomJSONEncoder)
