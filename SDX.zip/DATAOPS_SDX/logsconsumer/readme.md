# Docker Compose Setup for Loki and Loki Consumer

## Overview

This setup configures two primary services using Docker Compose:
- **Loki**: A log aggregation system by Grafana, useful for collecting and visualizing logs in a central location.
- **Loki Consumer**: A custom Docker container that interacts with Loki, designed specifically to facilitate integration testing with log data.

## Prerequisites

Ensure Docker and Docker Compose are installed on your system. For installation instructions, visit [Docker's official documentation](https://docs.docker.com/get-docker/).

## Configuration

### Environment Variables

Before running the services, configure the required environment variables in a `.env` file at the project root. This file should define the following variables (ensure sensitive information is appropriately secured):

```plaintext
EVENT_HUB_NAME_SPACE=test-loki
EVENT_HUB_CONSUMER_GROUP=$Default
EVENT_HUB_CONNEXION_STR=Endpoint=sb://yournamespace.servicebus.windows.net/;SharedAccessKeyName=KeyName;SharedAccessKey=*******
EVENT_HUB_STORAGE_CONNECTION_STR=DefaultEndpointsProtocol=https;AccountName=youraccountname;AccountKey=*******;EndpointSuffix=core.windows.net
EVENT_HUB_STORAGE_CONTAINER_NAME=your-container-name
LOKI_URL=http://loki:3100/loki/api/v1/push
```



### Running the Application
To start the application in a development environment, use the following command:

```bash docker-compose up --build --force-recreate --no-deps ```


The output should be something like 

```bash
intergation-loki-consumer-1  | 2024-04-22 14:03:51,106 - root - INFO - Partition 0, Received events count: 0
intergation-loki-consumer-1  | 2024-04-22 14:03:56,129 - root - INFO - Partition 0, Received events count: 0
intergation-loki-consumer-1  | 2024-04-22 14:04:01,176 - root - INFO - Partition 0, Received events count: 0
intergation-loki-consumer-1  | 2024-04-22 14:04:06,206 - root - INFO - Partition 0, Received events count: 0
intergation-loki-consumer-1  | 2024-04-22 14:04:11,243 - root - INFO - Partition 0, Received events count: 0
intergation-loki-consumer-1  | 2024-04-22 14:04:16,259 - root - INFO - Partition 0, Received events count: 0
intergation-loki-1           | level=info ts=2024-04-22T14:04:17.515609797Z caller=table_manager.go:136 index-store=boltdb-shipper-2020-10-24 msg="uploading tables"
intergation-loki-1           | level=info ts=2024-04-22T14:04:17.515368256Z caller=table_manager.go:171 index-store=boltdb-shipper-2020-10-24 msg="handing over indexes to shipper"
intergation-loki-consumer-1  | 2024-04-22 14:04:21,282 - root - INFO - Partition 0, Received events count: 0
intergation-loki-consumer-1  | 2024-04-22 14:04:26,297 - root - INFO - Partition 0, Received events count: 0
intergation-loki-consumer-1  | 2024-04-22 14:04:31,308 - root - INFO - Partition 0, Received events count: 0
intergation-loki-consumer-1  | 2024-04-22 14:04:36,322 - root - INFO - Partition 0, Received events count: 0

```


This command builds the Docker images, forces the recreation of containers (regardless of changes), and avoids starting linked services.

### Integration Testing with Azure Event Hubs
Here is an example of a Python unittest class for sending logs to an Azure Event Hub. This test leverages environment variables loaded with the dotenv package for secure configuration management.

```python
from dotenv import load_dotenv
load_dotenv()

import json
import os
import unittest
from datetime import datetime
from azure.eventhub import EventHubProducerClient, EventData
import uuid
import pytz

class TestLokiLogsDispatcher(unittest.TestCase):
    def setUp(self):
        self.timestamp = datetime.now(tz=pytz.utc).timestamp()
        self.job_uuid = str(uuid.uuid4())
        self.primary_connection_string = os.environ['EVENT_HUB_CONNEXION_STR']
        self.event_hub_name = os.environ['EVENT_HUB_NAME_SPACE']
        self.producer = EventHubProducerClient.from_connection_string(conn_str=self.primary_connection_string, eventhub_name=self.event_hub_name)

    def test_send_event(self):
        event = {
            'metadata': {'timestamp': self.timestamp},
            'contexts': {
                'job_id': self.job_uuid,
                'event_type': 'test',
                'project_name': 'project_test',
                'dataset_name': 'dataset_test',
                'publisher_name': 'publisher_test',
                'landing_zone': 'zone_test',
                'takeoff_zone': 'takeoff_zone',
                'kind': 'table'
            },
            'logs': [{'message': 'INFO TEST', 'level': 'WARNING'}]
        }
        with self.producer as producer:
            event_data_batch = producer.create_batch()
            event_data_batch.add(EventData(json.dumps(event).encode('utf-8')))
            producer.send_batch(event_data_batch)

```