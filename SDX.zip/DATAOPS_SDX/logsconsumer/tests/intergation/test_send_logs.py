from dotenv import load_dotenv
load_dotenv()

import json
import os
import unittest
from datetime import datetime
from azure.eventhub import EventHubProducerClient, EventData

import uuid

import pytz


class TestLokiLogsDispatcher(unittest.TestCase):
    timestamp = None
    job_uuid = str(uuid.uuid4())

    primary_connection_string = os.environ['EVENT_HUB_CONNEXION_STR']
    event_hub_name = os.environ['EVENT_HUB_NAME_SPACE']

    producer = EventHubProducerClient.from_connection_string(conn_str=primary_connection_string,
                                                             eventhub_name=event_hub_name)

    def setUp(self):
        self.timestamp = datetime.now(tz=pytz.utc).timestamp()
        self.job_uuid = str(uuid.uuid4())

    def test_send_event(self):
        event = {
            'metadata': {
                'timestamp': self.timestamp
            },
            'contexts': {
                'job_id': self.job_uuid,
                'event_type': 'test',
                'project_name': 'project_test',
                'dataset_name': 'dataset_test',
                'publisher_name': 'publisher_test',
                'landing_zone': 'zone_test',
                'takeoff_zone': 'takeoff_zone',
                'kind': 'table'
            },
            'logs': [
                {
                    'message': 'INFO TEST',
                    'level': 'WARNING'
                }
            ]
        }

        with self.producer as producer:
            event_data_batch = producer.create_batch()
            event_data_batch.add(EventData(json.dumps(event).encode('utf-8')))
            producer.send_batch(event_data_batch=event_data_batch)
