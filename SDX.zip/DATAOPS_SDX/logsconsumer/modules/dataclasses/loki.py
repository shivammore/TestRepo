import re
import dataclasses
import logging

logger = logging.getLogger(__name__)


@dataclasses.dataclass
class LokiDataclass:
    """
    Dataclass to get logs sent in event
    """
    message: str
    level: str = None

    def __post_init__(self):
        self.valid_message()
        if not self.level:  # Only set level if not already provided
            self.level = self.__get_level(self.message)

    def valid_message(self):
        if not isinstance(self.message, str):
            logger.error("Message must be a string.")
            raise TypeError("Message must be a string.")

    @classmethod
    def __get_level(cls, message: str, default: str = "INFO") -> str:
        pattern = r'\b(DEBUG|INFO|WARN|ERROR|FATAL)\b'
        match = re.search(pattern, message, re.IGNORECASE)
        if match:
            return match.group().upper()  # Normalize the log level to uppercase
        return default
