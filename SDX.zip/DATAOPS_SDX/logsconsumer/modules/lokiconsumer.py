import logging
from typing import List
from cerberus import Validator
from modules.abstract.asynceventhubconsumer import AsyncEventhubConsumer, EventMetaDataTuple
from modules.dataclasses.loki import LokiDataclass
from modules.lokilogger import AsyncLokiHttpDispatcher
from modules.utils.verbose import verbose
from azure.eventhub.extensions.checkpointstoreblobaio import BlobCheckpointStore
from azure.eventhub.aio import EventHubConsumerClient

logger = logging.getLogger(__name__)


class InvalidSchema(Exception):
    pass


async def async_generator(events):
    # normal loop
    for event in events:
        # yield the result
        yield event


class LogsToLokiConsumer(AsyncEventhubConsumer):
    """
    Consumer class to consume event in eventhub and send in mssql
    Heritage attributes:
    :attribute connection_string: The connection string to use for connecting to the Event Hub instance
    :attribute consumer_group: The name of the consumer group from which you want to process events
    :attribute eventhub_name: Gets the name of the EventHub
    :attribute storage_connection_str: The connection string to use for connecting to the checkpoint
    of Event Hub instance
    :attribute blob_container_name: The blob container name to use for the checkpoint
    :attribute retry_total: Configures the retry policy for all the operations on the client
    :attribute retry_backoff_factor: Configures the retry policy for all the operations on the client
    :attribute retry_mode: Configures the retry policy for all the operations on the client
    :attribute max_batch_size: Configures the way events are received
    :attribute max_wait_time: Configures the way events are received
    Self attributes:
    :attribute SCHEMA: Schema to follow to validate an event
    :attribute ALLOW_UNKNOWN: With true, it is enable to have other fields
    :attribute _schema_validator: A validator to valid input data schema
    """

    SCHEMA = {
        'metadata': {
            'type': 'dict',
            'schema': {
                'timestamp': {'type': ['number', 'string'], 'required': True}
            },
            'required': True
        },
        'contexts': {
            'type': 'dict',
            'schema': {
                'job_id': {'type': ['number', 'string'], 'required': True},
                'event_type': {'type': 'string', 'required': True},
                'project_name': {'type': 'string', 'required': True},
                'dataset_name': {'type': 'string', 'required': True},
                'publisher_name': {'type': 'string', 'required': True},
                'landing_zone': {'type': 'string', 'required': True},
                'takeoff_zone': {'type': 'string', 'required': True},
                'kind': {'type': 'string', 'required': True, 'allowed': ['file', 'column', 'table']}
            },
            'required': True
        },
        "logs": {
            'type': 'list',
            'schema': {
                'type': 'dict',
                'schema': {
                    'message': {'type': 'string', 'required': True},
                    'level': {'type': 'string', 'required': False},
                },
                'empty': False
            },
            'required': True,
            'empty': False
        }
    }

    ALLOW_UNKNOWN = True

    def __init__(self, loki_connection_string, connection_string: str, consumer_group: str, eventhub_name: str,
                 storage_connection_str: str,
                 blob_container_name: str, retry_total: int = 5, retry_backoff_factor: int = 1,
                 retry_mode: str = "exponential", max_batch_size: int = 100, max_wait_time: int = 5) -> None:

        self._schema_validator = Validator(schema=self.SCHEMA, allow_unknown=self.ALLOW_UNKNOWN)
        self.loki_connection_string = loki_connection_string

        super().__init__(connection_string=connection_string, consumer_group=consumer_group,
                         eventhub_name=eventhub_name,
                         storage_connection_str=storage_connection_str, blob_container_name=blob_container_name,
                         retry_total=retry_total, retry_backoff_factor=retry_backoff_factor, retry_mode=retry_mode,
                         max_batch_size=max_batch_size, max_wait_time=max_wait_time)

    @verbose(logger=logger, tags={'class_name': 'LogsToLokiConsumer'})
    async def listen(self) -> None:
        """

        """
        blob_logger = logging.getLogger('azure.core.pipeline.policies.http_logging_policy')
        blob_logger.setLevel(logging.WARNING)
        checkpoint_store = BlobCheckpointStore.from_connection_string(self.storage_connection_str,
                                                                      self.blob_container_name, logging=blob_logger)
        client = EventHubConsumerClient.from_connection_string(
            conn_str=self._connection_string,
            consumer_group=self._consumer_group,
            eventhub_name=self._eventhub_name,
            checkpoint_store=checkpoint_store,
            retry_total=self._retry_total,
            retry_backoff_factor=self._retry_backoff_factor,
        )

        async with client:
            await self.receive_batch(client)

    @verbose(logger=logger, tags={'ClassName': 'LogsToLokiConsumer'})
    async def on_event_batch_processing(self, events_metadatalist: List[EventMetaDataTuple]):
        """
        Event structure in eventhub: body, properties, offset, sequence_number, enqueued_time
        EventMetaDataTuple structure: [body, properties+offset+sequence_number+enqueued_time]
        """

        async for event in async_generator(events_metadatalist):
            logger.info("Parse event: {}".format(event.Event))
            try:
                # validate macro schema
                body_json = event.Event
                if not self._schema_validator(body_json):
                    logger.warning(
                        "Event skipped due to schema validation errors: {}".format(self._schema_validator.errors))
                    continue  # Skip to the next event

                tags, logs = body_json['contexts'], body_json['logs']
                timestamp = body_json['metadata']['timestamp']
                loki_dispatcher = AsyncLokiHttpDispatcher(loki_url=self.loki_connection_string, tags=tags)
                loki_logs = [LokiDataclass(message=log.get('message'), level=log.get('level', None)) for log in logs]

                await loki_dispatcher.push(logs=loki_logs, timestamp=int(timestamp))

            except InvalidSchema as error:
                logger.error("Parse event: {} hasn't been execute: {}".format(event.Event, error))
            except Exception as error:
                logger.error("Logs: {} hasn't been send: {}".format(event.Event, error))
