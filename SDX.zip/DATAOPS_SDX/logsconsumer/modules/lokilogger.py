import logging
from typing import Dict, Union, List

from modules.dataclasses.loki import LokiDataclass
import itertools
import aiohttp
import json

from modules.utils.catcher import catch
from modules.utils.verbose import verbose

logger = logging.getLogger(__name__)


class AsyncLokiHttpDispatcher:
    _loki_url: str = None
    _tags: Dict[str, Union[str, int, float]] = None

    def __init__(self, loki_url: str, tags: Dict[str, Union[str, int, float]]):
        self._loki_url, self._tags = loki_url, tags

    @verbose(logger=logger, tags={'class_name': 'AsyncLokiHttpDispatcher'})
    @catch(logger, raise_exception=False)
    async def push(self, logs: List[LokiDataclass], timestamp: int):

        sorted_logs = sorted(logs, key=lambda log: log.level)
        grouped_logs = [list(group) for _, group in itertools.groupby(sorted_logs, key=lambda log: log.level)]

        streams = [self.get_stream(logs=group, timestamp=timestamp) for group in grouped_logs]

        streams_payload = {'streams': streams}

        async with aiohttp.ClientSession() as session:
            async with session.post(self._loki_url,
                                    data=json.dumps(streams_payload),
                                    headers={"Content-Type": "application/json"}) as response:
                if response.status != 204:
                    response_text = await response.text()
                    raise AttributeError(f"Failed to send log message. Status code:"
                                         f" {response.status}, Response: {response_text}")

    def get_stream(self, logs: List[LokiDataclass], timestamp: int):
        return {
            "stream": {**self._tags, **{'level': logs[0].level if len(logs) != 0 else None}},
            "values": [
                [str(timestamp * 10 ** 9), log.message] for log in logs
            ]

        }
