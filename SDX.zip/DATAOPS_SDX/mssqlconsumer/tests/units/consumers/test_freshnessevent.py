import pytest
import asyncio
import unittest
from unittest.mock import patch
from modules.consumers.freshnessevent import MetricsToSqlConsumer
from modules.abstract.asynceventhubconsumer import EventMetaDataTuple
from modules.kernel.dbhandler import AzureSQLConnectorManager

tested_module = "modules.consumers.freshnessevent."


@pytest.fixture(scope="class")
def test_blob_container_name():
    return "test"


class TestMetricsToSqlConsumer(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def inject_fixtures(self, caplog):
        self._caplog = caplog

    def setUp(self):
        self.metrics_consumer_from_eventhub_to_mssql = MetricsToSqlConsumer(
            connection_string="Endpoint=sb://test.servicebus.windows.net/",
            consumer_group="test_group",
            eventhub_name="test_eventhub_name",
            retry_total=3,
            retry_mode="exponential",
            retry_backoff_factor=0.1,
            storage_connection_str="test_storage_connection_str",
            blob_container_name="test_blob_container_name",
            table_name="test_table_name",
            mssql_connection_string="test_mssql_connection_string"
        )
        self.count = 0

    def test_mssql_insert(self):
        """
        Test mssql_insert() method
        """
        with patch('pyodbc.connect') as mock_connect:
            with AzureSQLConnectorManager(
                    connection_string=self.metrics_consumer_from_eventhub_to_mssql.mssql_connection_string) as conn:
                mock_connect.assert_called_once_with(
                    self.metrics_consumer_from_eventhub_to_mssql.mssql_connection_string)
                params = ()
                self.metrics_consumer_from_eventhub_to_mssql.mssql_insert(params)

                conn.cursor.assert_called_once()
                conn.cursor().executemany.assert_called_once_with(
                    self.metrics_consumer_from_eventhub_to_mssql.rq_insert, params)
                conn.cursor().close.assert_called_once()

    def test_on_event_batch_processing_good_events(self):
        """
        Test on_event_batch_processing() method with one good Event format but with wrong logs key
        """
        events_metadatalist = [
            EventMetaDataTuple(
                Event={'metadata': {'timestamp': 1674056803.892927, 'timezone': 'epochutc'},
                       'contexts': {'publisher_name': 'publisher1', 'event_type': 'ProcessingFinished',
                                    'project_name': 'project5', 'dataset_name': 'dataset2', 'landing_zone': 'silver',
                                    'takeoff_zone': 'bronze', 'job_id': 'app_1373592073', 'kind': 'table'},
                       'metrics': {'content_latest_date': 1674056803.892927, 'content_oldest_date': 1666280803.892927,
                                   'delta_content_latest_date': 1674056803.8929276,
                                   'delta_content_oldest_date': 1674056803.8929276,
                                   'processing_started_date': 1674055603.892927,
                                   'processing_finished_date': 1674056803.892927, 'rows_count': 1642,
                                   'columns_count': 17, 'processing_exit_code': 0},
                       'log': [{'timestamp': None, 'message': 'Hello world', 'level': 'ERROR'},
                               {'timestamp': None, 'message': 'Hello world', 'level': 'DEBUG'}]},
                MetaData={'_last_enqueued_event_properties': {}, '_sys_properties': None}),
            EventMetaDataTuple(
                Event={'metadata': {'timestamp': 1674056805.028674, 'timezone': 'epochutc'},
                       'contexts': {'publisher_name': 'publisher1', 'event_type': 'ProcessingFinished',
                                    'project_name': 'project1', 'dataset_name': 'dataset2', 'landing_zone': 'silver',
                                    'takeoff_zone': 'bronze', 'job_id': 'app_1373592073', 'kind': 'table'},
                       'metrics': {'content_latest_date': 1674056805.028674, 'content_oldest_date': 1666280805.028674,
                                   'delta_content_latest_date': 1674056805.0286748,
                                   'delta_content_oldest_date': 1674056805.0286748,
                                   'processing_started_date': 1674055605.028674,
                                   'processing_finished_date': 1674056805.028674, 'rows_count': 1383,
                                   'columns_count': 5, 'processing_exit_code': 0},
                       'logs': [{'level': 'DEBUG'},
                                {'timestamp': None, 'message': 'Hello world', 'level': 'INFO'}]},
                MetaData={'_last_enqueued_event_properties': {}, '_sys_properties': None})
        ]

        with patch.object(MetricsToSqlConsumer, 'mssql_insert') as mock_mssql_insert:
            loop = asyncio.new_event_loop()
            task = loop.create_task(
                self.metrics_consumer_from_eventhub_to_mssql.on_event_batch_processing(events_metadatalist))
            loop.run_until_complete(task)
            mock_mssql_insert.assert_called_once_with(
                [
                    [1674056803, 'publisher1', 'project5', 'dataset2', 'silver', 'bronze', 'processingfinished',
                     'app_1373592073', 'table', 'content_latest_date', 1674056803.892927, ''],
                    [1674056803, 'publisher1', 'project5', 'dataset2', 'silver', 'bronze', 'processingfinished',
                     'app_1373592073', 'table', 'content_oldest_date', 1666280803.892927, ''],
                    [1674056803, 'publisher1', 'project5', 'dataset2', 'silver', 'bronze', 'processingfinished',
                     'app_1373592073', 'table', 'delta_content_latest_date', 1674056803.8929276, ''],
                    [1674056803, 'publisher1', 'project5', 'dataset2', 'silver', 'bronze', 'processingfinished',
                     'app_1373592073', 'table', 'delta_content_oldest_date', 1674056803.8929276, ''],
                    [1674056803, 'publisher1', 'project5', 'dataset2', 'silver', 'bronze', 'processingfinished',
                     'app_1373592073', 'table', 'processing_started_date', 1674055603.892927, ''],
                    [1674056803, 'publisher1', 'project5', 'dataset2', 'silver', 'bronze', 'processingfinished',
                     'app_1373592073', 'table', 'processing_finished_date', 1674056803.892927, ''],
                    [1674056803, 'publisher1', 'project5', 'dataset2', 'silver', 'bronze', 'processingfinished',
                     'app_1373592073', 'table', 'rows_count', 1642.0, ''],
                    [1674056803, 'publisher1', 'project5', 'dataset2', 'silver', 'bronze', 'processingfinished',
                     'app_1373592073', 'table', 'columns_count', 17.0, ''],
                    [1674056803, 'publisher1', 'project5', 'dataset2', 'silver', 'bronze', 'processingfinished',
                     'app_1373592073', 'table', 'processing_exit_code', 0.0, ''],
                    [1674056805, 'publisher1', 'project1', 'dataset2', 'silver', 'bronze', 'processingfinished',
                     'app_1373592073', 'table', 'content_latest_date', 1674056805.028674, ''],
                    [1674056805, 'publisher1', 'project1', 'dataset2', 'silver', 'bronze', 'processingfinished',
                     'app_1373592073', 'table', 'content_oldest_date', 1666280805.028674, ''],
                    [1674056805, 'publisher1', 'project1', 'dataset2', 'silver', 'bronze', 'processingfinished',
                     'app_1373592073', 'table', 'delta_content_latest_date', 1674056805.0286748, ''],
                    [1674056805, 'publisher1', 'project1', 'dataset2', 'silver', 'bronze', 'processingfinished',
                     'app_1373592073', 'table', 'delta_content_oldest_date', 1674056805.0286748, ''],
                    [1674056805, 'publisher1', 'project1', 'dataset2', 'silver', 'bronze', 'processingfinished',
                     'app_1373592073', 'table', 'processing_started_date', 1674055605.028674, ''],
                    [1674056805, 'publisher1', 'project1', 'dataset2', 'silver', 'bronze', 'processingfinished',
                     'app_1373592073', 'table', 'processing_finished_date', 1674056805.028674, ''],
                    [1674056805, 'publisher1', 'project1', 'dataset2', 'silver', 'bronze', 'processingfinished',
                     'app_1373592073', 'table', 'rows_count', 1383.0, ''],
                    [1674056805, 'publisher1', 'project1', 'dataset2', 'silver', 'bronze', 'processingfinished',
                     'app_1373592073', 'table', 'columns_count', 5.0, ''],
                    [1674056805, 'publisher1', 'project1', 'dataset2', 'silver', 'bronze', 'processingfinished',
                     'app_1373592073', 'table', 'processing_exit_code', 0.0, '']
                ]
            )

    def test_on_event_batch_processing_with_bad_events(self):
        """
        Test on_event_batch_processing() method with one bad Event format on context key, one bad Event format on metadata key, one bad Event format on metadata.timestamp, one bad Event format on context.publisher_name and with empty metrics
        """
        events_metadatalist = [
            EventMetaDataTuple(
                Event={'metdata': {'timestamp': 1674056803.892927, 'timezone': 'epochutc'},
                       'contexts': {'publisher_name': 'publisher1', 'event_type': 'ProcessingFinished',
                                    'project_name': 'project5', 'dataset_name': 'dataset2', 'landing_zone': 'silver',
                                    'takeoff_zone': 'bronze', 'job_id': 'app_1373592073', 'kind': 'table'},
                       'metrics': {'content_latest_date': 1674056803.892927, 'content_oldest_date': 1666280803.892927,
                                   'delta_content_latest_date': 1674056803.8929276,
                                   'delta_content_oldest_date': 1674056803.8929276,
                                   'processing_started_date': 1674055603.892927,
                                   'processing_finished_date': 1674056803.892927, 'rows_count': 1642,
                                   'columns_count': 17, 'processing_exit_code': 0}
                       },
                MetaData={'_last_enqueued_event_properties': {}, '_sys_properties': None}),
            EventMetaDataTuple(
                Event={'metadata': {'timestamp': 1674056805.028674, 'timezone': 'epochutc'},
                       'contxts': {'publisher_name': 'publisher1', 'event_type': 'ProcessingFinished',
                                   'project_name': 'project1', 'dataset_name': 'dataset2', 'landing_zone': 'silver',
                                   'takeoff_zone': 'bronze', 'job_id': 'app_1373592073', 'kind': 'table'},
                       'metrics': {'content_latest_date': 1674056805.028674, 'content_oldest_date': 1666280805.028674,
                                   'delta_content_latest_date': 1674056805.0286748,
                                   'delta_content_oldest_date': 1674056805.0286748,
                                   'processing_started_date': 1674055605.028674,
                                   'processing_finished_date': 1674056805.028674, 'rows_count': 1383,
                                   'columns_count': 5, 'processing_exit_code': 0},
                       },
                MetaData={'_last_enqueued_event_properties': {}, '_sys_properties': None}),
            EventMetaDataTuple(
                Event={'metadata': {'timestmp': 1674056805.028674, 'timezone': 'epochutc'},
                       'contexts': {'publisher_name': 'publisher1', 'event_type': 'ProcessingFinished',
                                    'project_name': 'project1', 'dataset_name': 'dataset2', 'landing_zone': 'silver',
                                    'takeoff_zone': 'bronze', 'job_id': 'app_1373592073', 'kind': 'table'},
                       'metrics': {'content_latest_date': 1674056805.028674, 'content_oldest_date': 1666280805.028674,
                                   'delta_content_latest_date': 1674056805.0286748,
                                   'delta_content_oldest_date': 1674056805.0286748,
                                   'processing_started_date': 1674055605.028674,
                                   'processing_finished_date': 1674056805.028674, 'rows_count': 1383,
                                   'columns_count': 5, 'processing_exit_code': 0},
                       },
                MetaData={'_last_enqueued_event_properties': {}, '_sys_properties': None}),
            EventMetaDataTuple(
                Event={'metadata': {'timestamp': 1674056805.028674, 'timezone': 'epochutc'},
                       'contexts': {'publisher_name': None, 'event_type': 'ProcessingFinished',
                                    'project_name': 'project1', 'dataset_name': 'dataset2', 'landing_zone': 'silver',
                                    'takeoff_zone': 'bronze', 'job_id': 'app_1373592073', 'kind': 'table'},
                       'metrics': {'content_latest_date': 1674056805.028674, 'content_oldest_date': 1666280805.028674,
                                   'delta_content_latest_date': 1674056805.0286748,
                                   'delta_content_oldest_date': 1674056805.0286748,
                                   'processing_started_date': 1674055605.028674,
                                   'processing_finished_date': 1674056805.028674, 'rows_count': 1383,
                                   'columns_count': 5, 'processing_exit_code': 0},
                       },
                MetaData={'_last_enqueued_event_properties': {}, '_sys_properties': None}),
            EventMetaDataTuple(
                Event={'metadata': {'timestamp': 1674056805.028674, 'timezone': 'epochutc'},
                       'contexts': {'publisher_name': 'publisher1', 'event_type': 'ProcessingFinished',
                                    'project_name': 'project1', 'dataset_name': 'dataset2', 'landing_zone': 'silver',
                                    'takeoff_zone': 'bronze', 'job_id': 'app_1373592073', 'kind': 'table'},
                       'metrics': {},
                       },
                MetaData={'_last_enqueued_event_properties': {}, '_sys_properties': None})
        ]

        with patch.object(MetricsToSqlConsumer, 'mssql_insert') as mock_mssql_insert:
            with patch('modules.consumers.freshnessevent.InvalidSchema') as mock_invalid_schema:
                loop = asyncio.new_event_loop()
                task = loop.create_task(
                    self.metrics_consumer_from_eventhub_to_mssql.on_event_batch_processing(events_metadatalist))
                loop.run_until_complete(task)
                mock_mssql_insert.assert_not_called()
                assert len(mock_invalid_schema.call_args_list) == 5

    def test_on_event_batch_processing_with_informatica_events(self):
        """
        Test on_event_batch_processing() method with one bad Event format on context key, one bad Event format on metadata key, one bad Event format on metadata.timestamp, one bad Event format on context.publisher_name and with empty metrics
        """
        events_metadatalist = [
            EventMetaDataTuple(
                Event={
                    'metadata': {'timestamp': '1674054465'},
                    'contexts': {
                        'publisher_name': 'Informatica_mt_sap_azsql_T007A_data_load_full_Europe',
                        'project_name': 'SAP_Data_Ingestion_Europe',
                        'dataset_name': 'T007A',
                        'landing_zone': 'transient',
                        'takeoff_zone': 'DataSource',
                        'event_type': 'processing_end',
                        'kind': 'table',
                        'job_id': '01181Q0Z000000000077_160_01181QC1000000006EQZ'
                    },
                    'metrics': {
                        'content_latest_date': None,
                        'content_oldest_date': None,
                        'delta_content_latest_date': None,
                        'delta_content_oldest_date': None,
                        'processing_started_date': '1673835472',
                        'processing_finished_date': '1673835479',
                        'processing_exit_code': 0,
                        'rows_count': '1121',
                        'columns_count': None
                    },
                    'columns': {
                        'column_name': '',
                        'column_type': '',
                        'column_min_observed_value': '',
                        'column_max_observed_value': '',
                        'column_lower_threshold': '',
                        'column_upper_threshold': '',
                        'Column_null_records_count': ''
                    }
                },
                MetaData={'_last_enqueued_event_properties': {}, '_sys_properties': None})
        ]

        with patch.object(MetricsToSqlConsumer, 'mssql_insert') as mock_mssql_insert:
            with patch('modules.consumers.freshnessevent.InvalidSchema') as mock_invalid_schema:
                loop = asyncio.new_event_loop()
                task = loop.create_task(
                    self.metrics_consumer_from_eventhub_to_mssql.on_event_batch_processing(events_metadatalist))
                loop.run_until_complete(task)
                mock_mssql_insert.assert_called_once_with(
                    [
                        [1674054465, 'informatica_mt_sap_azsql_t007a_data_load_full_europe',
                         'sap_data_ingestion_europe', 't007a', 'transient', 'datasource', 'processing_end',
                         '01181Q0Z000000000077_160_01181QC1000000006EQZ', 'table', 'processing_started_date',
                         1673835472.0, ''],
                        [1674054465, 'informatica_mt_sap_azsql_t007a_data_load_full_europe',
                         'sap_data_ingestion_europe', 't007a', 'transient', 'datasource', 'processing_end',
                         '01181Q0Z000000000077_160_01181QC1000000006EQZ', 'table', 'processing_finished_date',
                         1673835479.0, ''],
                        [1674054465, 'informatica_mt_sap_azsql_t007a_data_load_full_europe',
                         'sap_data_ingestion_europe', 't007a', 'transient', 'datasource', 'processing_end',
                         '01181Q0Z000000000077_160_01181QC1000000006EQZ', 'table', 'processing_exit_code', 0.0, ''],
                        [1674054465, 'informatica_mt_sap_azsql_t007a_data_load_full_europe',
                         'sap_data_ingestion_europe', 't007a', 'transient', 'datasource', 'processing_end',
                         '01181Q0Z000000000077_160_01181QC1000000006EQZ', 'table', 'rows_count', 1121.0, '']
                    ]
                )
