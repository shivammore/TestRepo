## Introduction 
Data observability is the ability to measure, track, and understand the behavior of data as it flows through systems,
processes, and pipelines. It is essential to detect issues early in the data lifecycle,
such as data quality issues, schema changes, and drifts in data distribution,
to ensure the accuracy, reliability, and consistency of data-driven decisions.
Early detection of issues allows organizations to prevent downstream consequences and maintain trust in their data.

## Grafana

Grafana is a popular data visualization tool that provides a user-friendly interface for monitoring and analyzing data.
By using Grafana, data teams can create custom dashboards that consolidate and display metrics from various sources,
making it easier to observe and understand data behavior. By setting up alerts and notifications in Grafana,
data teams can detect and respond to data issues in real-time, improving data observability.
Grafana also provides historical data analysis and comparison features, allowing data teams to identify patterns and
trends in data behavior over time. In summary, Grafana's intuitive dashboard interface enables data teams to gain better
visibility into their data and respond proactively to issues, thereby enhancing data observability.

## Dashboard as code (DaC)

Dashboard as code (DaC) is a practice of defining dashboards and their configurations as code, which can be stored in
version control systems. This practice brings several benefits to data teams, including versioning, change tracking,
and collaboration. When using DaC, changes to the dashboard are recorded as code, and teams can use version control
systems to track these changes, compare versions, and revert changes if necessary. This approach eliminates the risk of
accidental or unauthorized changes to the dashboard, which can impact data observability.

Furthermore, DaC enables teams to automate the deployment of dashboards to different environments, such as staging,
testing, and production, ensuring consistency across environments. This approach also enables teams to build dashboards
from source artifacts, which ensures the reproducibility of the dashboard and eliminates the risk of differences between
environments.

Finally, using DaC helps teams collaborate on dashboard development and maintenance. By using a common repository for 
the dashboard code, teams can collaborate, review changes, and approve pull requests. This approach ensures that the 
dashboard is developed with best practices, and changes are validated before they are deployed.

## Jsonnet 

Jsonnet is a data templating language that allows you to define JSON data in a concise, readable, and maintainable
format. It provides several features such as object-oriented programming, conditionals, and imports, that make it easier
to define complex JSON data structures.

## Grafonet

Grafonnet is a Jsonnet library that allows you to define Grafana dashboards and panels as code. It provides a set of
high-level functions and classes that map to Grafana dashboard components, such as panels, rows, and grids. With
Grafonnet, you can define your dashboard as a set of composable components, making it easier to reuse and manage
your code.

Both Jsonnet and Grafonnet are linked to Grafana because they enable teams to define Grafana dashboards as code,
which brings several benefits such as version control, reproducibility, and automation. By using Jsonnet and Grafonnet,
teams can define their dashboards as code, store them in version control systems, and deploy them automatically to 
different environments, making it easier to maintain and update dashboards. Moreover, because Grafonnet provides a 
set of high-level functions and classes, it simplifies the process of defining complex Grafana dashboards and panels,
enabling teams to focus on the business logic of their dashboards.

## Structure
    .
    ├── Dockerfile
    ├── README.md
    ├── alerting
    │   └── alertDummy.yaml
    ├── dashboards
    │   └── global
    │       └── dashboard.jsonnet
    └── provisioning
        ├── dashboards
        │   └── running.yml
        └── datasources
            └── mssql.yaml


This is a typical directory structure for a Grafana project that is meant to be built and deployed using Docker.
Here is a brief explanation of each directory and file:

Dockerfile: This file contains the instructions for building a Docker image for the Grafana project.

README.md: This file provides instructions and information about the project.
alerting: This directory contains the YAML files for alerting rules that will be used by Grafana.

dashboards: This directory contains the JSONnet files for defining Grafana dashboards. The global subdirectory contains
dashboards that are meant to be shared across multiple environments.

provisioning: This directory contains configuration files for setting up data sources and dashboards in Grafana.
The dashboards subdirectory contains YAML files for deploying dashboards to Grafana, and the datasources subdirectory
contains YAML files for configuring data sources that will be used by Grafana.

Overall, this directory structure makes it easy to build and deploy a Grafana project using Docker, while also allowing
for easy management of alerting rules, dashboards, and data sources.

Note: In order to group related dashboards together in the same folder, it is recommended that you use the provisioning
directory to link the dashboards together through a YAML file. This allows you to easily manage and organize your
dashboards, especially when working with a large number of them.


## Build and Artifacts : Dockerfile Explained
Build the Docker image containing the Grafana instance, preloaded with dashboards defined in the `dashboards` folder:


The `Dockerfile` contains instructions to build a Docker image for the Grafana instance with custom configurations, users, and dashboards.

1. Use Grafana OSS Ubuntu-based image as the base image:
    ```
    FROM grafana/grafana-oss:latest-ubuntu
    ```

2. Set environment variables:
    ```
    ENV GF_USERS_ALLOW_SIGN_UP=false
    ```

3. Set working directory:
    ```
    WORKDIR /app
    ```

4. Switch to root user for installing packages:
    ```
    USER root
    ```

5. Update package list and install required packages:
    ```
    RUN apt-get update
    RUN apt-get install -y software-properties-common
    RUN add-apt-repository ppa:rmescandon/yq

    RUN apt-get update && \
        apt-get install -y jsonnet yq jq
    ```

6. Add Grafana provisioning configurations:
    ```
    ADD provisioning/datasources /etc/grafana/provisioning/datasources
    ADD provisioning/dashboards /etc/grafana/provisioning/dashboards
    ADD provisioning/notifiers /etc/grafana/provisioning/notifiers
    ```

7. Copy custom entry point and user creation scripts:
    ```
    COPY provisioning/scripts/custom_entrypoint.sh /etc/grafana/provisioning/scripts/
    COPY provisioning/scripts/init_users.sh /etc/grafana/provisioning/scripts/
    ```

8. Copy users configuration file:
    ```
    COPY users.yaml /etc/grafana/provisioning/scripts/
    ```

9. Add dashboards and Grafonnet library:
    ```
    ADD ./dashboards /app/dashboards
    COPY ./grafonnet-lib /app/grafonnet-lib
    ```

10. Convert Jsonnet files to JSON dashboards:
    ```
    RUN find /app/dashboards -type f -name  "*.jsonnet" | \
        xargs -I filePath sh -c 'jsonnet -J grafonnet-lib filePath > filePath".json"'
    ```

11. Set execution permissions and ownership for custom entry point and user creation scripts:
    ```
    RUN chmod a+x /etc/grafana/provisioning/scripts/custom_entrypoint.sh && \
        chown $(id -un):$(id -gn) /etc/grafana/provisioning/scripts/custom_entrypoint.sh && \
        chmod a+x /etc/grafana/provisioning/scripts/init_users.sh && \
        chown $(id -un):$(id -gn) /etc/grafana/provisioning/scripts/init_users.sh
    ```

12. Switch back to Grafana user:
    ```
    USER grafana
    ```

13. Set custom entry point:
    ```
    ENTRYPOINT ["/etc/grafana/provisioning/scripts/custom_entrypoint.sh"]
    ```

These steps create a custom Grafana Docker image that includes Grafana OSS, additional packages,
dashboard configurations, users, and a custom entry point to start Grafana.


Note: In order to authenticate with external services such as data sources, it is recommended that you store any
necessary credentials as environment variables when running the container. This ensures that sensitive information is
not stored in plain text within the project directory.

```bash
docker run -it \
-e MSSQL_HOST='dev-sre-mssqlserver.database.windows.net' \
-e MSSQL_PORT='1433' \
-e MSSQL_DB=dev-sre-mssql-database \
-e MSSQL_USER=admindevsre \
-e MSSQL_PASSWORD='************************'  \
-e GF_SECURITY_ADMIN_USER=admin  \
-e GF_SECURITY_ADMIN_PASSWORD=admin  \
-e "GF_AUTH_ANONYMOUS_ENABLED=true" \
-e "GF_AUTH_ANONYMOUS_ORG_ROLE=Admin" \
-e GF_USERS_DEFAULT_THEME='light'  \
-e GF_SECURITY_VIEWER_PASSWORD=admin \
-p 3000:3000 grafana:latest
```

### Docker run arguments explained

- `-e MSSQL_HOST`: The hostname of your MSSQL server instance.
- `-e MSSQL_PORT`: The port number where your MSSQL server is running (default is 1433).
- `-e MSSQL_DB`: The name of the MSSQL database you want to use with Grafana.
- `-e MSSQL_USER`: The username for the MSSQL server instance.
- `-e MSSQL_PASSWORD`: The password for the MSSQL server instance.
- `-e GF_SECURITY_ADMIN_USER`: The username for the Grafana admin user.
- `-e GF_SECURITY_ADMIN_PASSWORD`: The password for the Grafana admin user.
- `-e GF_AUTH_ANONYMOUS_ENABLED`: Enable/disable anonymous access (boolean value, true/false).
- `-e GF_AUTH_ANONYMOUS_ORG_ROLE`: The role assigned to anonymous users (Viewer, Editor, or Admin).
- `-e GF_USERS_DEFAULT_THEME`: The default theme for Grafana users ('light' or 'dark').
- `-e GF_SECURITY_VIEWER_PASSWORD`: The password for the Grafana viewer user.
- `-p 3000:3000`: Expose Grafana on port 3000 on the local machine.


Note: those run argument are for local dev only as they expose the grafana endpoint with no authentication


## Creating a New Dashboard 

To create a new dashboard , you need to create first a dashboard config which is a collection of dashboards with the same topic, follow these steps:

1. Create a new folder inside the `dashboards` directory with the desired name, for example, `csi`.

2. create a YAML file named `dashboard_folder.yaml`. in `provisioning/dashboards`  This file will contain the configuration for the new dashboard folder.

3. Add the following content to the `dashboard_folder.yaml` file, adjusting the values as needed:

```yaml
- name: 'Dashboard Name'
  org_id: 1
  folder: 'Dashboard Monitoring'
  type: 'file'
  options:
    folder: '/dashboards/DashboardNew'
```
4.  Create a new firstDash.jsonnet, which is just an example adjust the name for prod environment 
5.  Populate the firstDash.jsonnet with the chosen template (dashboards/csi/ingestion.jsonnet)

# Grafana User and Folder Management

This document explains how to create local users and manage folders in Grafana using the pipeline.

## 1. Creating Local Users

### Step 1: Update the `users.yaml` File
To add new users, update the `visualisation/az-pipelines/Permissions/users_envname.yaml` file with the required details:

```yaml
users:
  - name: "Harry Potter"
    email: "Harry.potter@sodexo.com"
    role: "Editor"
    password: "password_secret_name" #The password will be fetched from KeyVault just mention the name of the secret here inside double quotes
  - name: "Ronald Weasley"
    email: "Ronald.Weasley@sodexo.com"
    role: "Viewer"
    password: "password_secret_name_2"
  - name: "Hermione Granger"
    email: "Hermione.Granger@sodexo.com"
    role: "Admin"
    password: "password_secret_name_2"

```

- **name**: The full name of the user.
- **email**: The email address of the user.
- **role**: The user role (Admin, Editor, Viewer).
- **password**: The Key Vault secret name storing the user's password.

### Step 2: Store User Passwords in Azure Key Vault
Ensure the passwords are stored in Azure Key Vault with the specified secret names. #You can find the KV Name in the variable file with name "azureKeyvaultAPP"

```sh
az keyvault secret set --vault-name <KeyVaultName> --name "password_secret_name" --value "UserPassword123"
az keyvault secret set --vault-name <KeyVaultName> --name "password_secret_name_2" --value "AnotherPassword456"
```

### Step 3: Run the Pipeline
Trigger the pipeline to create or update the users in Grafana. The pipeline will:
- Read the `users_envname.yaml` file.
- Fetch passwords from Azure Key Vault.
- Create users in Grafana.
- Assign roles as specified in the file.

## 2. Managing Grafana Folders

### Step 1: Update the `visualisation/az-pipelines/Permissions/grafana_permissions_envname.json` File
To create folders and assign permissions, update the `grafana_permissions.yaml` file:

```yaml
{
    "name": "TestFolder",
    "permissions": [
      {
        "role": "Admin",
        "permission": 4
      },
      {
        "role": "Viewer",
        "permission": 1
      }
    ]
  }
```

- **name**: The name of the folder.
- **permissions**: List of user roles and email addresses assigned to the folder.

### Step 2: Run the Pipeline
Trigger the pipeline to create/update the folders and permissions in Grafana. The pipeline will:
- Read the `grafana_permissions_envname.json` file.
- Create folders if they do not exist.
- Assign permissions based on the file configuration.

## Conclusion
- To create users, update `users_envname.yaml` and store passwords in Azure Key Vault.
- To create folders, update `grafana_permissions_envname.json` and specify roles.
- Run the pipeline to apply the changes.

This ensures an automated and consistent setup for Grafana user management and folder permissions.
