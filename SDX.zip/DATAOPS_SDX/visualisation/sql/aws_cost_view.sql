CREATE VIEW aws_cost_view
AS
  (SELECT a.aws as workspace_name,
          a.project_name AS aws_project_name,
          b.project_name,
          b.cost_type,
          b.year,
          b.month,
	   b.cost
    FROM   project_monthly_cost_view b
    RIGHT OUTER JOIN (SELECT DISTINCT "analytics workspace" AS aws,
                                      trim(Lower(cs.value)) AS project_name
                      FROM   [dremio].[sys_analytics_workspace]
                             CROSS apply STRING_SPLIT (
                                         "project name (data source name)",
                                         ',') cs
                      WHERE  "analytics workspace" <> ''
                             AND cs.value <> '') a
    ON CHARINDEX(a.project_name, b.project_name) != 0
) 