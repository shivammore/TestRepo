CREATE VIEW project_monthly_cost_view AS 
WITH 
            
    INGEST_COST AS (
        -- Query for monthly project ingestion cost
        SELECT REPLACE(project_name, '_', '.') as project_name, 'Ingest' as cost_type, year, month, cost =
            CASE 
                WHEN SUM(total_successful_ingestions) <= 300 THEN SUM(total_successful_ingestions) * 0.60
                WHEN SUM(total_successful_ingestions) > 300 AND SUM(total_successful_ingestions) <= 2000 THEN SUM(total_successful_ingestions) * 0.57
                WHEN SUM(total_successful_ingestions) > 2000 AND SUM(total_successful_ingestions) <= 4500 THEN SUM(total_successful_ingestions) * 0.54
                WHEN SUM(total_successful_ingestions) > 4500 THEN SUM(total_successful_ingestions) * 0.51
                ELSE 0 -- Ensure there's a default case if @IngestionCount is NULL
            END
        FROM [observability].[dab_event_cost] 
        Group by project_name, year, month
    ),

    DATA_COST AS (

        -- Query for Bronze
        SELECT project_name, 'Data' as cost_type,
                storageyear as year,
                storagemonth as month,(SUM(max_sourcesize)/ 1073741824.0) * 1.5 as cost
        FROM (
            SELECT
                project_name,
                storageyear,
                storagemonth,
                MAX(toatlsize) AS max_sourcesize
            FROM (
            SELECT (BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + Source) as project_name, ReportGenerationDate,
                YEAR(ReportGenerationDate) AS storageyear, 
                DATEPART(Month, ReportGenerationDate) AS storagemonth, 
                SUM(SourceSize) AS toatlsize
            FROM [reportdata].[bronzeSourceDetailsSDX]
            GROUP BY (BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + Source), ReportGenerationDate, YEAR(ReportGenerationDate), DATENAME(Month, ReportGenerationDate)
            ) as total_S
            GROUP BY project_name, storageyear, storagemonth
        ) as nexts
        where project_name in (select project_name from INGEST_COST)
        GROUP BY project_name, storageyear, storagemonth

        UNION ALL

        -- Query for Silver
        SELECT project_name, 'Data' as cost_type,
                storageyear as year,
                storagemonth as month,(SUM(max_sourcesize)/ 1073741824.0) * 1.5 as cost
        FROM (
            SELECT
                project_name,
                storageyear,
                storagemonth,
                MAX(toatlsize) AS max_sourcesize
            FROM (
            SELECT (BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + Source) as project_name, ReportGenerationDate,
                YEAR(ReportGenerationDate) AS storageyear, 
                DATEPART(Month, ReportGenerationDate) AS storagemonth, 
                SUM(SourceSize) AS toatlsize
            FROM [reportdata].[silverSourceDetailsSDX]
            GROUP BY (BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + Source), ReportGenerationDate, YEAR(ReportGenerationDate), DATENAME(Month, ReportGenerationDate)
            ) as total_S
            GROUP BY project_name, storageyear, storagemonth
        ) as nexts
        where project_name in (select project_name from INGEST_COST)
        GROUP BY project_name, storageyear, storagemonth

        UNION ALL

        -- Query for Gold
        SELECT project_name, 'Data' as cost_type,
                storageyear as year,
                storagemonth as month,(SUM(max_sourcesize)/ 1073741824.0) * 1.5 as cost
        FROM (
            SELECT
                project_name,
                storageyear,
                storagemonth,
                MAX(toatlsize) AS max_sourcesize
            FROM (
            SELECT (BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + Source) as project_name, ReportGenerationDate,
                YEAR(ReportGenerationDate) AS storageyear, 
                DATEPART(Month, ReportGenerationDate) AS storagemonth, 
                SUM(SourceSize) AS toatlsize
            FROM [reportdata].[goldSourceDetailsSDX]
            GROUP BY (BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + Source), ReportGenerationDate, YEAR(ReportGenerationDate), DATENAME(Month, ReportGenerationDate)
            ) as total_S
            GROUP BY project_name, storageyear, storagemonth
        ) as nexts
        where project_name in (select project_name from INGEST_COST)
        GROUP BY project_name, storageyear, storagemonth
    ),

    DREMIO_COST AS (

        -- Query for monthly project dreamio cost
        SELECT REPLACE(project_name, '_', '.') as project_name, cost_type, year, month, cost FROM (SELECT 
            -- Conditional logic based on dataset_fullname
            CASE 
            -- If dataset_fullname does not start with 'aziest1ctg390', apply the original logic
            WHEN dataset_fullname NOT LIKE 'aziest1ctg390%' 
                AND CHARINDEX('.', REVERSE(dataset_fullname)) > 0 
                AND CHARINDEX('.', REVERSE(LEFT(dataset_fullname, LEN(dataset_fullname) - CHARINDEX('.', REVERSE(dataset_fullname))))) > 0 
            THEN 
                RIGHT(
                        LEFT(dataset_fullname, LEN(dataset_fullname) - CHARINDEX('.', REVERSE(dataset_fullname))),
                        CHARINDEX('.', REVERSE(LEFT(dataset_fullname, LEN(dataset_fullname) - CHARINDEX('.', REVERSE(dataset_fullname))))) - 1
                )
            -- If dataset_fullname contains 'aziest1ctg390', apply the alternative logic
            WHEN dataset_fullname LIKE '%aziest1ctg390%' 
            THEN 
                SUBSTRING(
                dataset_fullname,
                CHARINDEX('corporatedata.', dataset_fullname) + LEN('corporatedata.'),
                CHARINDEX('.' + dataset_name, dataset_fullname) 
                - (CHARINDEX('corporatedata.', dataset_fullname) + LEN('corporatedata.'))
            )
            ELSE NULL
            END AS project_name, 'Dremio' as cost_type, year,
            month, cost
            FROM [dremio].[dremio_jobs_cost] ) a
            WHERE REPLACE(project_name, '_', '.') in (select project_name from INGEST_COST)
    )

    SELECT project_name, cost_type, year, month, cost
    FROM INGEST_COST UNION ALL
    SELECT project_name, cost_type, year, month, cost
    FROM DATA_COST UNION ALL
    SELECT project_name, cost_type, year, month, cost
    FROM DREMIO_COST;