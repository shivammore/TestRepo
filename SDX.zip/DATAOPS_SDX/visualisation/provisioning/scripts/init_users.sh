#!/bin/bash

USERS_YAML_PATH="/etc/grafana/provisioning/scripts/users.yaml"

if [[ -z "${GF_SECURITY_ADMIN_USER}" ]]; then
  echo "GF_SECURITY_ADMIN_USER is not set"
else
  echo "GF_SECURITY_ADMIN_USER is set to '${GF_SECURITY_ADMIN_USER}'"
fi

if [[ -z "${GF_SECURITY_ADMIN_PASSWORD}" ]]; then
  echo "GF_SECURITY_ADMIN_PASSWORD is not set"
else
  echo "GF_SECURITY_ADMIN_PASSWORD is set"
fi

encoded_password=$(printf '%s' "$GF_SECURITY_ADMIN_PASSWORD" | jq -sRr @uri)

# Read users from the users.yaml file
# Loop through users and create them using Grafana API
user_count=$(yq e '.users | length'  $USERS_YAML_PATH)


for ((i = 0; i < user_count; i++)); do
  name=$(yq e ".users[$i].name" $USERS_YAML_PATH)
  email=$(yq e ".users[$i].email" $USERS_YAML_PATH)
  password=$(yq e ".users[$i].password" $USERS_YAML_PATH)
  role=$(yq e ".users[$i].role" $USERS_YAML_PATH)
  folders_count=$(yq e ".users[$i].folders | length" $USERS_YAML_PATH)


  # Create user using Grafana API
  # Check for environment variable pattern and validate if it exists
  if [[ "${password}" =~ (\$\{([A-Za-z_][A-Za-z0-9_]*)\}) ]]; then

    env_var_pattern="${BASH_REMATCH[1]}"
    env_var_name="${BASH_REMATCH[2]}"

    if [[ -z "${!env_var_name}" ]]; then
      echo "Environment variable '${env_var_name}' is not set"
    else
      echo "Environment variable '${env_var_name}' is set to '${!env_var_name}'"
      password="${password//${env_var_pattern}/${!env_var_name}}"
    fi
  else
    echo "User password does not contain an environment variable pattern"
  fi

  response=$(curl -s -XPOST -H "Content-Type: application/json" --data-binary "{
      \"name\": \"${name}\",
      \"email\": \"${email}\",
      \"login\": \"${name}\",
      \"password\": \"${password}\"
    }" http://"$GF_SECURITY_ADMIN_USER":"$encoded_password"@localhost:3000/api/admin/users)

  user_id=$(echo "$response" | jq '.id')  # This attempts to capture the user ID from the response.

  if [[ "$user_id" != "" ]]; then
    echo "Created user: ${name} with ID: ${user_id}"
    # Update the user's role in the organization
    curl -X PATCH "http://localhost:3000/api/org/users/${user_id}" \
      -H "Content-Type: application/json" \
      -H "Authorization: Basic $(echo -n "$GF_SECURITY_ADMIN_USER:$GF_SECURITY_ADMIN_PASSWORD" | base64)" \
      --data-raw "{\"role\":\"${role}\"}"

    echo "Updated user: ${name} to role: ${role}"
  #    ADD SECTION HERE FOR DASHOBARD
    # Now handle folders permissions if any folders are specified
    if [[ "$folders_count" -gt 0 ]]; then
      for ((j = 0; j < folders_count; j++)); do
        folder_uuid=$(yq e ".users[$i].folders[$j]" $USERS_YAML_PATH)
        # Capture the response for granting view permission for the folder to the user
        folder_response=$(curl -s -X POST "http://localhost:3000/api/folders/$folder_uuid/permissions" \
             -H "Content-Type: application/json" \
             -H "Authorization: Basic $(echo -n "$GF_SECURITY_ADMIN_USER:$GF_SECURITY_ADMIN_PASSWORD" | base64)" \
             --data-raw '{"items": [{"role": "Editor","permission": 2},{"userId": '$user_id',"permission": 1}]}' )  
        

        # Print the response
        echo "Response for granting view permission for folder UUID $folder_uuid to user ID $user_id: $folder_response"
      done
    fi

  else
    echo "Failed to create user: ${name}"
  fi

  echo "Created user: ${name} with role: ${role}"
done