#!/bin/bash

#!/bin/bash

exec /run.sh &
GRAFANA_PID=$!

wait_for_grafana() {
  until curl -s --head --fail http://localhost:3000; do
    echo "Waiting for Grafana to start..."
    sleep 5
  done
  echo "Grafana is up and running!"
}

# Function to pause alerts
pause_alerts() {
  if [ "${GF_PAUSE_ALERTS}" = "true" ]; then
    echo "Attempting to silence all alerts..."

        if [ "$ENV" != "DEV" ] && [ "$ENV" != "UAT" ]; then
	    echo "Environemnt is dev or uat. So silencing alerts"
	    return 0
	  fi

    # Check for required environment variables
    if [[ -z "${GF_SECURITY_ADMIN_USER}" || -z "${GF_SECURITY_ADMIN_PASSWORD}" ]]; then
      echo "Admin username or password not set. Cannot authenticate to pause alerts."
      return 1
    fi

    # Base64 encode the username:password for basic auth
    auth=$(echo -n "$GF_SECURITY_ADMIN_USER:$GF_SECURITY_ADMIN_PASSWORD" | base64)

    # Define silence period
    startSilence=$(date --utc +"%Y-%m-%dT%H:%M:%SZ")
    endSilence=$(date --utc -d "+356 day" +"%Y-%m-%dT%H:%M:%SZ")  # Silence for 1 year

    # Assuming ENV is set in the environment, e.g., export ENV="prod"
    ENV=${ENV:-prod}  # Default to "prod" if ENV is not set

    # API call to create a silence with no specific matchers
    # API call to create a silence for alerts that do not contain the ENV value in their env label
    APIResp=$(curl --location --request POST 'http://localhost:3000/api/alertmanager/grafana/api/v2/silences' \
      --header 'Content-Type: application/json' \
      --header "Authorization: Basic $auth" \
      --data-raw "{
        \"comment\": \"Attempt to silence alerts not applicable for ${ENV}\",
        \"createdBy\": \"admin\",
        \"endsAt\": \"${endSilence}\",
        \"matchers\": [
          {
            \"name\": \"env\",
            \"value\": \".*${ENV}.*\",
            \"isRegex\": true
          }
        ],
        \"startsAt\": \"${startSilence}\"
      }"
    )


    echo "Silence response: $APIResp"
  fi
}

wait_for_grafana
pause_alerts

wait "${GRAFANA_PID}"

