{
  /**
   * Creates an SQL target.
   *
   * @name sql.target
   *
   * @param rawSql The SQL query
   * @param datasource (optional)
   * @param format (default 'time_series')
   * @param alias (optional)
   * @param rawEditor (default true)
   * @param rawQuery (default true)
   * @param queryText (default as rawSql)
   */
  target(
    rawSql,
    datasource=null,
    format='time_series',
    alias=null,
    rawEditor=true,
    rawQuery=true,
    queryText=rawSql
  ):: {
    [if datasource != null then 'datasource']: datasource,
    format: format,
    [if alias != null then 'alias']: alias,
    rawSql: rawSql,
    rawEditor: rawEditor,
    rawQuery: rawQuery,
    queryText: queryText,
  },
}
