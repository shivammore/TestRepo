{
  /**
   * Creates a [bar chart panel](https://grafana.com/docs/grafana/latest/panels/visualizations/bar-chart/) that can be added in a row.
   * It requires the bar chart panel plugin in grafana, which is built-in.
   *
   * @name barchart.new
   *
   * @param title The title of the graph panel.
   * @param description (optional) Description of the panel
   * @param span (optional)  Width of the panel
   * @param height (optional)  Height of the panel
   * @param datasource (optional) Datasource
   * @param min_span (optional)  Min span
   * @param transparent (default: 'false') Whether to display the panel without a background
   * @param links (optional) Array of links for the panel.
   * @return A json that represents a bar chart panel
   * @param unit (default `'none'`) Panel unit field option.
   *
   * @method addTarget(target) Adds a target object
   * @method addTargets(targets) Adds an array of targets
   * @method addLink(link) Adds a link
   */
  new(
    title,
    description=null,
    span=null,
    min_span=null,
    height=null,
    datasource=null,
    repeat=null,
    repeatDirection='h',
    transparent=false,
    time_from=null,
    time_shift=null,
    links=[],
    unit='none',
  ):: {
    type: 'barchart',
    title: title,
    [if span != null then 'span']: span,
    [if min_span != null then 'minSpan']: min_span,
    [if height != null then 'height']: height,
    [if repeat != null then 'repeat']: repeat,
    [if repeat != null then 'repeatDirection']: repeatDirection,
    datasource: datasource,
    targets: [
    ],
    fieldConfig: {
      defaults: {
        unit: unit,
      },
    },
    timeFrom: time_from,
    timeShift: time_shift,
    links: links,
    [if description != null then 'description']: description,
    [if transparent == true then 'transparent']: transparent,
    _nextTarget:: 0,
    addTarget(target):: self {
      local nextTarget = super._nextTarget,
      _nextTarget: nextTarget + 1,
      targets+: [target { refId: std.char(std.codepoint('A') + nextTarget) }],
    },
    addOption(keyName , value):: self {
      options +: { [keyName]: value}
    },
     addOverridesByFieldName(field , properties):: self {
      fieldConfig+: {

              overrides+: [
                {
                  matcher: {
                    id: 'byName', options: field,
                  },
                  properties: properties
                },
              ],
            }},
    addTargets(targets):: std.foldl(function(p, t) p.addTarget(t), targets, self),
    addLink(link):: self {
      links+: [link],
    },
  },
}
