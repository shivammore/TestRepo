{
  /**
   * Creates a Node Graph panel.
   *
   * @name nodeGraph.new
   *
   * @param title The title of the Node Graph panel.
   * @param datasource (optional) The datasource for the panel.
   * @param nodes An array of objects representing nodes to be displayed.
   * @param edges An array of objects representing edges between nodes.
   * @param nodeLabels (optional) An object with properties for customizing node labels.
   * @param edgeLabels (optional) An object with properties for customizing edge labels.
   * @param showLegend (optional) Determines whether or not to display the legend.
   * @param height (optional) The height of the panel.
   * @param width (optional) The width of the panel.
   * @param refresh (optional) The refresh interval of the panel.
   *
   * @method addNodeLabelStyle(style) Adds a style for node labels.
   * @method addEdgeLabelStyle(style) Adds a style for edge labels.
   */
  new(
    title,
    datasource=null,
    nodeLabels={},
    edgeLabels={},
    showLegend=true,
    height=null,
    width=null,
    refresh=null,
  )::
    {
      [if height != null then 'height']: height,
      addArc(name, color):: self {
      options +: {
        nodes +: {
          arcs+: [{ color: color , field: name}]
        }
      }
  },
      title: title,
      type: 'nodeGraph',
      datasource: datasource,
  _nextTarget:: 0,
      addTarget(target):: self {
        local nextTarget = super._nextTarget,
        _nextTarget: nextTarget + 1,
        targets+: [target { refId: std.char(std.codepoint('A') + nextTarget) }],
      },
      addTargets(targets):: std.foldl(function(p, t) p.addTarget(t), targets, self),
//      datasource: datasource,
//      nodes: nodes,
//      edges: edges,
//      nodeLabels: nodeLabels,
//      edgeLabels: edgeLabels,
//      showLegend: showLegend,
//      refresh: refresh,
//      [if width != null then 'width']: width,
//      addNodeLabelStyle(style)::
//        self {
//          nodeLabels: {
//            ...self.nodeLabels,
//            styles: [
//              ...std.object({} in self.nodeLabels.styles),
//              style,
//            ],
//          },
//        },
//      addEdgeLabelStyle(style)::
//        self {
//          edgeLabels: {
//            ...self.edgeLabels,
//            styles: [
//              ...std.object({} in self.edgeLabels.styles),
//              style,
//            ],
//          },
//        },
    },
}
