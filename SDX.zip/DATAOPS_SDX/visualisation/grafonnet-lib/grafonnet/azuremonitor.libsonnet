{
  /**
   * Creates a [Azure Monitor target](https://grafana.com/docs/grafana/latest/datasources/azure-monitor/)
   * to be added to panels.
   *
   * @name azuremonitor.target
   * 
   * @param datasource (optional)
   * @param dashboardTime (default 'false')
   * @param query The KQL query
   * @param queryType (default 'Azure Log Analytics')
   * @param resources The Azure Monitor resources
   * @param resultFormat  (default 'logs')
   *
   * @return A Azure Monitor target to be added to panels.
   */
  target(
    queryType='Azure Log Analytics',
    datasource=null,
    dashboardTime=false,    #queryType: Azure Log Analytics
    query=null,             #queryType: Azure Log Analytics
    resources=null,         #queryType: Azure Log Analytics
    resultFormat='logs',    #queryType: Azure Log Analytics
    aggregation=null,       #queryType: azureMonitor
    metricName=null,        #queryType: azureMonitor
    metricNamespace=null,   #queryType: azureMonitor
    resourceGroup=null,     #queryType: azureMonitor
    resourceName=null,      #queryType: azureMonitor
    subscription=null,      #queryType: azureMonitor
    region="",              #queryType: azureMonitor
    timeGrain='auto',       #queryType: azureMonitor
    dimension=null,         #queryType: azureMonitor
    dimensionFilters=null,  #queryType: azureMonitor
    dimensionOperator=null, #queryType: azureMonitor
    alias=null,             #queryType: azureMonitor
    #resourceUri=null,      #queryType: azureMonitor

  ):: {
    [if datasource != null then 'datasource']: datasource,
    [if queryType == 'Azure Log Analytics' then 'azureLogAnalytics']: {
        dashboardTime: dashboardTime,
        query: query,       
        resources: resources,
        resultFormat: resultFormat,
    },
     [if queryType == 'Azure Monitor' then 'azureMonitor']: {
       aggregation: aggregation,
       alias: alias,
       timeGrain: timeGrain,
       metricNamespace: metricNamespace,
       region: region,
       resources: [
         {
          subscription: subscription,
          metricNamespace: metricNamespace,
          region: region,
          resourceGroup: resourceGroup,
          resourceName: resourceName,
         }
       ],
       metricName: metricName,
       [if dimension != null then 'dimensionFilters']: [
         {
            dimension: dimension,
            filters: [
              dimensionFilters
            ],
            operator: dimensionOperator
          }
       ],
     },
    [if queryType == 'Azure Monitor' then 'subscription']: subscription,
    queryType: queryType
  },
}