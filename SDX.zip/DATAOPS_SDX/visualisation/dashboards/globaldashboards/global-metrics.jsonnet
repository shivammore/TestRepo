local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;

local businessTemplate =   tmpl.new(
    name='Business',
    datasource='Azure SQL Server',
    query='select distinct(BusinessLines) from [reportdata].[bronzeSourceDetailsSDX] union select distinct(BusinessLines) from [reportdata].[silverSourceDetailsSDX] order by BusinessLines',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='BusinessLine'
  );

local regionTemplate = tmpl.new(
    name='Region',
    datasource='Azure SQL Server',
    query='select distinct(regionCode) from [reportdata].[bronzeSourceDetailsSDX] union select distinct(regionCode) from [reportdata].[silverSourceDetailsSDX] order by regionCode',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='RegionCode'
  );

local sourceTemplate = tmpl.new(
    name='Source',
    datasource='Azure SQL Server',
    query='select distinct(source) from [reportdata].[bronzeSourceDetailsSDX] union select distinct(source) from [reportdata].[silverSourceDetailsSDX] order by source',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='SourceName'
  );

local YearTemplate = tmpl.new(
    name='year',
    datasource='Azure SQL Server',
    query="select distinct YEAR(ReportGenerationDate) as 'Year' from [reportdata].[bronzeSourceDetailsSDX] union select distinct YEAR(ReportGenerationDate) as 'Year' from [reportdata].[silverSourceDetailsSDX] order by YEAR(ReportGenerationDate)",
    current='2024',
    includeAll=false,
    multi=false,
    label='Year',
    refresh='load'
  );

local totalBronzeDSForIFM =
  statPanel.new(
    title="IFM Bronze Datasets",
    datasource='IFM Azure SQL Server',
    description="Showcasing monthly statistics of number of datasets in IFM bronze layer",
    colorMode='background',
    unit='none',
  ).addThresholds(
    steps=[
      {
        "color": "purple",
        "value": 0,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT 
        sum(datasetNumber) as TotalBronzeDataSets 
        FROM 
        [reportdata].[bronzeSourceDetailsSDX] 
        where 
        ZoneType not like 'test%' 
        And BusinessLines in ($Business) 
        And RegionCode in ($Region) 
        And Source in ($Source) 
        And Year(ReportGenerationDate) in ($year)
      ",
      format='table'
    )
  );

  local totalBronzeDSForSDX =
  statPanel.new(
    title="SDX Bronze Datasets",
    datasource='Azure SQL Server',
    description="This graph represents monthly statistics of data lake size  for bronze layer",
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
        SELECT 
        sum(datasetNumber) as TotalBronzeDataSets 
        FROM 
        [reportdata].[bronzeSourceDetailsSDX] 
        where 
        ZoneType not like 'test%' 
        And BusinessLines in ($Business) 
        And RegionCode in ($Region) 
        And Source in ($Source) 
        And Year(ReportGenerationDate) in ($year)
        ",
      format='table'
    )
  );
  // local numberOfAnalyticsWorkspace =
  // statPanel.new(
  //   title="Analytics Workspaces",
  //   datasource='Azure SQL Server',
  //   description="This graph represents number of analytics workspaces",
  //   colorMode='background'
  // ).addThresholds(
  //   steps=[
  //     {
  //       value: 0,
  //       color: 'orange',
  //     },
  //   ]
  // ).addTarget(
  //   target=grafana.sql.target(
  //     rawSql="
  //       SELECT 
  //       count(distinct [Analytics workspace]) as numberOfAnalyticsWorkspace 
  //       FROM 
  //       [dremio].[sys_Analytics_workspace];
  //       ",
  //     format='table'
  //   )
  // );

local barChartBronzeDataSize = grafana.barChart.new(
    title="SDX Bronze Layer Data Volume",
    description='This graph represents monthly statistics of data lake size  for SDX bronze layer',
    datasource='Azure SQL Server',
    unit='bytes',
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      with CTE1 as (
        select 
          SUM(SourceSize) as 'TotalSize', 
          datename(Month, ReportGenerationDate) as 'MonthPart', 
          datepart(Month, ReportGenerationDate) as 'MonthNumber'  
        from [reportdata].[bronzeSourceDetailsSDX] 
        where 
          BusinessLines in ($Business) And 
          RegionCode in ($Region) And 
          Source in ($Source) And 
          Year(ReportGenerationDate) in ($year) 
        group by ReportGenerationDate, datename(Month, ReportGenerationDate), datepart(Month, ReportGenerationDate)
      ) 
      select MonthPart, Avg(TotalSize) as 'TotalSize' from CTE1 
      group by MonthPart, MonthNumber 
      order by MonthNumber
      ",
      format='table'
    )
  );

local barChartSilverDataSize = grafana.barChart.new(
    title="SDX Silver Layer Data Volume",
    description='This graph represents  monthly statistics of data lake size  for SDX silver layer',
    datasource='Azure SQL Server',
    unit='bytes',
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
        with CTE1 as (
            select 
                SUM(SourceSize) as 'TotalSize', 
                datename(Month, ReportGenerationDate) as 'MonthPart', 
                datepart(Month, ReportGenerationDate) as 'MonthNumber' 
            from 
                [reportdata].[silverSourceDetailsSDX] 
            where 
                BusinessLines in ($Business) 
                and RegionCode in ($Region) 
                and Source in ($Source) 
                And Year(ReportGenerationDate) in ($year) 
            group by 
                ReportGenerationDate, 
                datename(Month, ReportGenerationDate), 
                datepart(Month, ReportGenerationDate)
            ) 
            select MonthPart, Avg(TotalSize) as 'TotalSize' from CTE1 
            group by MonthPart, MonthNumber 
            order by MonthNumber
      ",
      format='table'
    )
  );

local listDailyQueriesonDremio = grafana.tablePanel.new(
    title="Daily Queries Executed on Dremio",
    datasource='Azure SQL Server',
    description="This graph represents queries executed on dremio per day"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="select CONVERT(NVARCHAR, CAST(submitted_ts AS DATE), 7 ) as 'Execution Date', 
        count(query) as 'Total Queries', 
        sum(duration_in_minutes) as 'Total Execution Time'
      from 
        dremio.dremio_jobs_recent_part
      group by 
        CAST(submitted_ts AS DATE)
      order by 
        CAST(submitted_ts AS DATE) desc
      ",
      format='table'
    )
  ).addOverridesByFieldName(
  field='Execution Date',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
  ).addOverridesByFieldName(
  field='Total Queries',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
  ).addOverridesByFieldName(
  field='Total Execution Time',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
  );

local listTopTenDSQueriedonDremio = grafana.tablePanel.new(
    title="Top Ten Datasets Queried on Dremio",
    datasource='Azure SQL Server',
    description="This graph represents top ten most frequently used datasets"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="select TOP 10 queried_datasets as 'Dataset Name', 
          count(queried_datasets) as 'Access Count'
        from 
          dremio.dremio_jobs_recent_part 
        where 
          queried_datasets <> '' and queried_datasets <> '[INFORMATION_SCHEMA.TABLES]' and queried_datasets <> '[INFORMATION_SCHEMA.SCHEMATA]'
          and  queried_datasets not like '![sys!.%' ESCAPE '!'
          and submitted_ts >= DATEADD( day, -30, GETDATE() ) and submitted_ts <= getdate() 
        group by 
          queried_datasets 
        order by 
          count(queried_datasets) desc
      ",
      format='table'
    )
  ).addOverridesByFieldName(
  field='Dataset Name',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
  ).addOverridesByFieldName(
  field='Access Count',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
  );

local listCDMInDremio = grafana.tablePanel.new(
    title="Core Data Model's Uses Frequency for Last 30 Days",
    datasource='Azure SQL Server',
    description="This graph represents number of Core Data Models used for last 30 days"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="select queried_datasets as 'CDM Dataset Name', count(queried_datasets) as 'Access Count'
        from 
          [dremio].[dremio_jobs_recent_part] 
        where 
          submitted_ts >= DATEADD(day, -30, GETDATE()) 
          And submitted_ts <= getdate() 
          And queried_datasets like N'%live.gold.certified%'
        group by 
          queried_datasets
        order by 
          count(queried_datasets) desc
      ",
      format='table'
    )
  ).addOverridesByFieldName(
  field='CDM Dataset Name',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
  ).addOverridesByFieldName(
  field='Access Count',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
  );

local listActiveUsersDremio = grafana.tablePanel.new(
    title="Active Dremio Users for Last 30 Days",
    datasource='Azure SQL Server',
    description="This graph represents number of active dremio users for last 30 days"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="select user_name as 'User Name', count(user_name) as 'Activity Count'
      from 
        [dremio].[dremio_jobs_recent_part] 
      where 
        submitted_ts >= DATEADD(day,-30,GETDATE()) 
        And submitted_ts <= getdate()
      group by 
        user_name 
      order by 
        count(user_name) desc
      ",
      format='table'
    )
  ).addOverridesByFieldName(
  field='User Name',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
  ).addOverridesByFieldName(
  field='Activity Count',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
  );

// local listAnalyticsWorkspaces = grafana.tablePanel.new(
//     title="Analytics Workspaces",
//     datasource='Azure SQL Server',
//     description="This graph represents details of analytics workspaces"
//   ).addTarget(
//     target=grafana.sql.target(
//       rawSql="select distinct ([Analytics workspace]), [Project name (Data source name)] 
//       from
// 	      [dremio].[sys_Analytics_workspace]
//       where 
//         [Analytics workspace] IS NOT NULL;
//       ",
//       format='table'
//     )
//   ).addOverridesByFieldName(
//   field='Analytics workspace',
//   properties=[
//     { id: 'custom.filterable', value: 'true' },
//   ]
//   ).addOverridesByFieldName(
//   field='Project name (Data source name)',
//   properties=[
//     { id: 'custom.filterable', value: 'true' },
//   ]
//   );

grafana.dashboard.new(
  title='Global Metrics Dashboard',
  editable='false',
  schemaVersion=39,
  uid='21EiXdsfccn17Y',
  tags=['monitoring', 'observability', 'SDX'])

.addTemplate(businessTemplate)
.addTemplate(regionTemplate)
.addTemplate(sourceTemplate)
.addTemplate(YearTemplate)

.addPanel(panel = totalBronzeDSForIFM, gridPos={h:6,w:5,x:0,y:0})
.addPanel(panel = totalBronzeDSForSDX, gridPos={h:6,w:5,x:5,y: 0})
// .addPanel(panel = numberOfAnalyticsWorkspace, gridPos={h:6,w:5,x:10,y: 0})

.addPanel(
    grafana.row.new(
    title="Bronze Layer Data Volume - GraphView",
    showTitle=true,
    collapse=true,
  ).addPanel(panel = barChartBronzeDataSize, gridPos={h:12,w:23,x:0,y:6}),
    gridPos={h:12,w:23,x:0,y:6}
)
.addPanel(
    grafana.row.new(
    title="Silver Layer Data Volume - GraphView",
    showTitle=true,
    collapse=true,
  ).addPanel(panel = barChartSilverDataSize, gridPos={h:12,w:23,x:0,y:18}),
    {h:12,w:23,x:0,y:18}
)
.addPanel(
    grafana.row.new(
    title="Daily Queries Executed on Dremio - Table",
    showTitle=true,
    collapse=true,
  ).addPanel(panel = listDailyQueriesonDremio, gridPos={h:12,w:23,x:0,y:30}),
    {h:12,w:23,x:0,y:30}
)
.addPanel(
    grafana.row.new(
    title="Top Ten Datasets Queried on Dremio - Table",
    showTitle=true,
    collapse=true,
  ).addPanel(panel = listTopTenDSQueriedonDremio, gridPos={h:12,w:23,x:0,y:42}),
    {h:12,w:23,x:0,y:42}
)
.addPanel(
    grafana.row.new(
    title="Core Data Model's Uses Frequency for Last 30 Days - Table",
    showTitle=true,
    collapse=true,
  ).addPanel(panel = listCDMInDremio, gridPos={h:12,w:23,x:0,y:54}),
    {h:12,w:23,x:0,y:54}
)
.addPanel(
    grafana.row.new(
    title="Active Dremio Users for Last 30 Days - Table",
    showTitle=true,
    collapse=true,
  ).addPanel(panel = listActiveUsersDremio, gridPos={h:12,w:23,x:0,y:66}),
    {h:12,w:23,x:0,y:66}
)
// .addPanel(
//     grafana.row.new(
//     title="Analytics Workspaces - Table",
//     showTitle=true,
//     collapse=true,
//   ).addPanel(panel = listAnalyticsWorkspaces, gridPos={h:12,w:23,x:0,y:78}),
//     {h:12,w:23,x:0,y:78}
// )
+ {
"timepicker": {
    "hidden": true
  }
}

