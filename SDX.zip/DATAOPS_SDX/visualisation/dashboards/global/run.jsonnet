local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;


local template = grafana.template;

local TemplateProject =   template.new(
    name='project',
    datasource='IFM Azure SQL Server',
    query="select distinct project_name from [observability].[event] where project_name is not null and project_name <> '' ",
    refresh='load',
    includeAll=true,
    multi=true,
    label='Application Source'
  );

local TemplateRegion =  template.new(
    name='region',
    datasource='IFM Azure SQL Server',
    query="select Distinct upper(parseName([project_name],3)) AS Region FROM [observability].[event] where upper(parseName([project_name],3)) is NOT NULL order by upper(parseName([project_name],3))",
    refresh='load',
    includeAll=true,
    multi=true,
    label='Region'
);


local TemplateStatus =  template.custom(
    name='status',
    current='all',
    query='Succeeded,Failed,No New Data,Skipped',
    includeAll=true,
    multi=true,
    label='Ingestion Status'
  );

local TemplateStage = tmpl.custom(
    name='stage',
    query="silver,bronze,transient",
    current='all',
    includeAll=true,
    multi=false,
    label='Stage'
  );


local TemplatePublisher = template.new(
    name='publisher',
    datasource='IFM Azure SQL Server',
    query='select distinct publisher_name from [observability].[event]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Publisher Name'
  );

local TemplateDataset = template.new(
    name='dataset',
    datasource='IFM Azure SQL Server',
    query='select distinct dataset_name from [observability].[event]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Dataset Name'
  );

local TemplateTextSearch = template.text(
    name='text_search',
	  label='Search Log'
  );

local ContextTmplHided = tmpl.new(
  name='context',
  datasource='IFM Azure SQL Server',
  query="

    SELECT distinct(context_id)
     FROM [observability].[references]
    WHERE metric_name = 'consumer_csi' AND metric_value = 1
      AND context_id IN (
        SELECT context_id
         FROM [observability].[references]
         WHERE metric_name = 'ttl' AND metric_value IS NOT NULL
      )
    and project_name in ($project)
    and dataset_name in ($dataset)
    and upper(parseName([project_name],3)) IN ($region)
    and landing_zone in ($stage)
    ",
  current='all',
  refresh='load',
  hide = 'true',
  includeAll=true,
  multi=false,
  label='Context'
);

local TotalApplicationSource =
  statPanel.new(
    title='Total Application Source',
    datasource='IFM Azure SQL Server',
    description="This metric represents the number of sources that are monitored over a time slot",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'white',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT  COUNT(DISTINCT project_name) FROM [observability].[event]
      where metric_name= 'processing_exit_code'
      AND event_type =  'processingfinished'
      AND project_name in ($project)
      AND upper(parseName([project_name],3)) IN ($region)
      AND landing_zone in ($stage)
      AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
      ",
      format='table'
    )
  );


local TotalDataSets =
  statPanel.new(
    title='Total Datasets',
    datasource='IFM Azure SQL Server',
    description="this metric represents the number of datasets per source that are monitored over a time slot",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'white',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT  COUNT(DISTINCT dataset_name) FROM [observability].[event]
      where metric_name= 'processing_exit_code'
      AND event_type =  'processingfinished'
      AND project_name in ($project)
      AND upper(parseName([project_name],3)) IN ($region)
      AND landing_zone in ($stage)
      AND dataset_name in ($dataset)
      AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
      ",
      format='table'
    )
  );


local TotalIngestionRun =
  statPanel.new(
    title="Total Ingestion's",
    datasource='IFM Azure SQL Server',
    description="this metric represents the total number of ingestions calculated over a time slot",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'white',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT  COUNT(*) FROM [observability].[event]
      where metric_name= 'processing_exit_code'
      AND event_type =  'processingfinished'
      AND project_name in ($project)
      AND upper(parseName([project_name],3)) IN ($region)
      AND landing_zone in ($stage)
      AND dataset_name in ($dataset)
      AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
      ",
      format='table'
    )
  );


local SuccessRun =
  statPanel.new(
    title="New Data Ingestion's",
    datasource='IFM Azure SQL Server',
    description="This metric represents new ingests in success over a time slot",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT  COUNT(*) FROM [observability].[event]
      where metric_name= 'processing_exit_code'
      AND event_type =  'processingfinished'
      AND metric_value =  0
      AND project_name in ($project)
      AND upper(parseName([project_name],3)) IN ($region)
      AND landing_zone in ($stage)
      AND dataset_name in ($dataset)
      AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
      ",

      format='table'
    )
  );

local ShallowRun =
  statPanel.new(
    title="No New Data Ingestion's",
    datasource='IFM Azure SQL Server',
    description="this metric represents old data ingestion updated over a time slot",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'yellow',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT  COUNT(*) FROM [observability].[event]
      where metric_name= 'processing_exit_code'
      AND event_type =  'processingfinished'
      AND metric_value =  1
      AND project_name in ($project)
      AND upper(parseName([project_name],3)) IN ($region)
      AND landing_zone in ($stage)
      AND dataset_name in ($dataset)
      AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
      ",

      format='table'
    )
  );

local FailedRun =
  statPanel.new(
    title="Failed Ingestion's",
    datasource='IFM Azure SQL Server',
    description="this metric represents the total number of ingests that are failed over a time slot",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'red',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT  COUNT(*) FROM [observability].[event]
      where metric_name= 'processing_exit_code'
      AND event_type =  'processingfinished'
      AND metric_value =  -1
      AND project_name in ($project)
      AND upper(parseName([project_name],3)) IN ($region)
      AND landing_zone in ($stage)
      AND dataset_name in ($dataset)
      AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
      ",

      format='table'
    )
  );


local gaugeRatio = grafana.gaugePanel.new(title="Ingestion Success Ratio", description='The success ratio metric measures the percentage of successful requests over the entire request period. A successful request is one that returns the expected response code or status, while an unsuccessful request is one that returns an error response code or status. Monitoring the success rate helps us identify failed ingestion.'
, thresholdsMode='percentage', datasource='IFM Azure SQL Server').addTarget(
    target=grafana.sql.target(
      rawSql="

      SELECT 
        CASE WHEN COUNT(*) = 0 THEN 100
          ELSE COUNT(CASE WHEN metric_value != -1 THEN 1 ELSE NULL END) * 100.0 / COUNT(*) 
        END AS ratio 
      FROM [observability].[event]
      where metric_name= 'processing_exit_code'
      AND event_type =  'processingfinished'
      AND project_name in ($project)
      AND upper(parseName([project_name],3)) IN ($region)
      AND landing_zone in ($stage)
      AND dataset_name in ($dataset)
      AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()

      ",
      format='table'
    )
  ).addThresholds(
    steps=[
      {
        value: 50,
        color: 'red',
        text: 'Warning',
      },
      {
        value: 70,
        color: 'yellow',
        text: 'Warning',
      },
      {
        value: 90,
        color: 'green',
        text: 'Warning',
      },
    ]
  );
local DataSetStatistics = grafana.tablePanel.new(
  title='Dataset Statistics',
  datasource='IFM Azure SQL Server',
  description="Dataset statistics metric provides an overview of key statistical metrics for a specific dataset, including application source, dataset, region, area, landing, freshness , row count, average, diff % and SLO.
  These statistics help us identify trends and patterns in the data, as well as highlight outliers or anomalies, about data Freshness and Volume."
).addTarget(
  target=sql_target(
    rawSql="

WITH aggregated_rows AS (
    SELECT
        m.context_id,
        MAX(CASE WHEN rn = 1 THEN m.metric_value END) AS 'rows',
        CAST(AVG(m.metric_value) AS FLOAT) AS 'total-avg'
    FROM
        (
            SELECT
                context_id,
                metric_name,
                metric_value,
                timestamp,
                ROW_NUMBER() OVER(PARTITION BY context_id ORDER BY timestamp DESC) AS rn
            FROM
                [observability].[event]
            WHERE
                metric_name = 'rows_count'
                AND dataset_name IN ($dataset)
                AND project_name IN ($project)
                AND upper(parseName([project_name],3)) IN ($region)
                AND landing_zone IN ($stage)
                AND metric_value IS NOT NULL
        ) AS m
    GROUP BY
        m.metric_name, context_id
),
headers AS (
    SELECT DISTINCT context_id, project_name, dataset_name, landing_zone
    FROM [observability].[event]
    WHERE
        dataset_name IN ($dataset)
        AND project_name IN ($project)
        AND upper(parseName([project_name],3)) IN ($region)
        AND landing_zone IN ($stage)
),
ttl AS (
SELECT context_id, metric_value from [observability].[references] where metric_name = 'ttl'
),
last_ingestion AS (
    SELECT context_id,
        MAX(CASE WHEN metric_name = 'processing_exit_code' THEN metric_value END) AS processing_exit_code,
        MAX(CASE WHEN metric_name = 'content_latest_date' THEN metric_value END) AS content_latest_date,
        MAX(CASE WHEN metric_name = 'processing_exit_code' THEN timestamp END) AS timestamp
    FROM (
        SELECT
            context_id,
            metric_name,
            metric_value,
            timestamp,
            ROW_NUMBER() OVER(PARTITION BY context_id, metric_name ORDER BY timestamp DESC) AS rn
        FROM [observability].[event]
        WHERE
            metric_name IN ('processing_exit_code', 'content_latest_date')
            AND dataset_name IN ($dataset)
            AND project_name IN ($project)
            AND upper(parseName([project_name],3)) IN ($region)
            AND landing_zone IN ($stage)
    ) t
    WHERE rn = 1
    GROUP BY context_id
)

SELECT
    h.project_name AS 'Application Source',
    h.dataset_name AS 'Dataset',
    Upper(parseName([project_name],3)) AS 'Region',
    h.landing_zone AS 'Zone',

    DATEDIFF(s, '19700101', GETUTCDATE()) - b.timestamp AS 'Landed',
    DATEDIFF(s, '19700101', GETUTCDATE()) - b.content_latest_date AS 'Freshness',
    a.rows AS 'Rows',
    a.[total-avg] AS 'Avg',
    CASE
        WHEN a.[total-avg] = 0 THEN 'N/A'
        ELSE CAST(ROUND((a.rows - a.[total-avg]) / NULLIF(a.[total-avg], 0) * 100, 2) AS VARCHAR) + '%'
    END AS 'Diff %' ,
    c.metric_value as 'SLO'
FROM
    headers AS h
    LEFT JOIN aggregated_rows AS a ON a.context_id = h.context_id
    LEFT JOIN last_ingestion AS b ON b.context_id = h.context_id
    LEFT JOIN ttl AS c ON c.context_id = h.context_id
    ORDER BY CASE
    WHEN b.content_latest_date IS NULL THEN 1
        ELSE 0
    END, b.content_latest_date
",
    format='table'
  )
).addOverridesByFieldName(
  field='Status',
  properties=[
    { id: 'custom.displayMode', value: 'color-text' },
    {
      id: 'thresholds',
      value: {
        mode: 'absolute',
        steps: [{ color: 'text', value: null }],
      },
    },
    {
      id: 'mappings',
      value: [
        {
          type: 'value',
          options: {
            Succeeded: { color: 'green', index: 0 },
            'No New Data': { color: 'yellow', index: 1 },
          },
        }
      ],
    }
  ]
).addOverridesByFieldName(
  field='Diff %',
  properties=[
    { id: 'custom.displayMode', value: 'color-text' },
    {
      id: 'thresholds',
      value: {
        mode: 'absolute',
        steps: [{ color: 'text', value: null }],
      },
    },
    {
      id: 'mappings',
      value: [
        {
          type: 'regex',
          options: {
            pattern: '^\\d+(?:\\.\\d+)?%$',
            result: { color: 'green', index: 0 }
          }
        },
        {
                    options: {
                      "0%": {
                        color: 'text',
                        index: 2,
                      },
                    },
                    type: 'value'
                  },
        {
          type: 'regex',
          options: {
            pattern: '^-\\d+(?:\\.\\d+)?%$',
            result: { color: 'red', index: 1 }
          }
        }
      ]
    }
  ]
)
.addOverridesByFieldName(
  field='Landed',
  properties=[
    {id: 'unit',value: 's'}
  ]
)
.addOverridesByFieldName(
  field='Freshness',
  properties=[
    {id: 'unit',value: 's'}
  ]
).addOverridesByFieldName(
  field='TTL',
  properties=[
    {id: 'unit',value: 's'}
  ]
);

local PanelIngestionHistory = grafana.tablePanel.new(
    title='Ingestion History',
    datasource='IFM Azure SQL Server',
    description="The ingestion history metric tracks the amount of data ingested into a specific system or application over a defined period of time.
                 This metric helps us monitor the overall health of our data ingestion pipeline, as well as identify potential issues or bottlenecks that could impact performance.
                 By analyzing ingestion history, informed decisions can be made regarding resource allocation, capacity planning, and system optimization to ensure optimal data processing and storage."
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
                        WITH FilteredEvents AS (
                SELECT
                    job_id,
                    context_id,
                    project_name,
                    dataset_name,
                    landing_zone,
                    takeoff_zone,
                    timestamp,
                    metric_name,
                    metric_value
                FROM
                    [observability].[event]
                WHERE
                    dataset_name IN ($dataset)
                    AND project_name IN ($project)
                    AND upper(parseName([project_name],3)) IN ($region)
                    AND landing_zone IN ($stage)
                    AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                    AND metric_name IN ('processing_started_date', 'processing_finished_date', 'processing_exit_code', 'rows_count', 'content_latest_date')
            ),
            MergedEvents AS (
                SELECT
                    job_id,
                    context_id,
                    timestamp,
                    project_name,
                    dataset_name,
                    landing_zone,
                    takeoff_zone,
                    [processing_started_date] AS processing_started_date_value,
                    [processing_finished_date] AS processing_finished_date_value,
                    [processing_exit_code] AS processing_exit_code_value,
                    [content_latest_date] AS content_latest_date,
                    [rows_count] AS rows_count_value
                FROM
                    FilteredEvents
                PIVOT (
                    MAX(metric_value)
                    FOR metric_name IN ([processing_started_date], [processing_finished_date], [processing_exit_code], [rows_count], [content_latest_date])
                ) AS PivotTable
            ),
            FinalResult AS (
            SELECT
                MAX(project_name) AS 'Application Source',
                MAX(dataset_name) AS 'Dataset',
                MAX(Upper(parseName([project_name],3))) AS 'Region',
                MAX(landing_zone) AS 'Zone',
                MAX(takeoff_zone) + ' to ' + MAX(landing_zone) AS 'Activity',
                CASE
                    WHEN MAX(processing_exit_code_value) = 0 THEN 'Succeeded'
                    WHEN MAX(processing_exit_code_value) = 1 THEN 'No New Data'
                    WHEN MAX(processing_exit_code_value) = 2 THEN 'Skipped'
                    WHEN MAX(processing_exit_code_value) IS NULL THEN 'Running'
                    ELSE 'Failed'
                END AS 'Status',
                DATEADD(SECOND, MAX([timestamp]), '1970-01-01') AS 'Landed at',
                DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([timestamp]) AS 'Landed Since',
                DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([content_latest_date]) AS 'Freshness',
                CAST(MAX(processing_finished_date_value) - MAX(processing_started_date_value) AS BIGINT) AS 'Duration',
                ISNULL(CAST(CAST(MAX(rows_count_value) AS BIGINT) AS VARCHAR), 'N/A') AS 'Rows'
            FROM MergedEvents
            GROUP BY job_id, context_id
            )
            select * from FinalResult WHERE ('ALL' IN ($status) OR [Status] IN ($status))
            ORDER BY 'Landed at' DESC;

      ",
      format='table'
    )
  ).addOverridesByFieldName(field='Rows', properties=[
  {
    id: 'thresholds',
    value: {
      mode: 'absolute',
      steps: [
        {
          color: 'text',
          value: null,
        }
      ],
    },
  },
  {
    id: 'custom.displayMode',
    value: 'color-text',
  },
  {
    id: 'mappings',
    value: [
      {
        options: {
          'N/A': {
            color: 'red',
            index: 1,
          }

        },
        type: 'value',
      }
    ],
  }
]).addOverridesByFieldName(field='Status', properties=[
                          { id: 'custom.displayMode', value: 'color-text' },
                          {
                            id: 'thresholds',
                            value: {
                              mode: 'absolute',
                              steps: [{ color: 'text', value: null }],
                            },
                          },
                          {
                            id: 'mappings',
                            value: [
                              {
                                type: 'value',
                                options: {
                                  Succeeded: { color: 'green', index: 0 },
                                  Failed: { color: 'red', index: 1 },
                                },
                              }
                            ],
                          }
]).addOverridesByFieldName(
  field='Duration',
  properties=[
    {id: 'unit',value: 's'}
  ]
).addOverridesByFieldName(field='Freshness', properties=[{id: 'unit',value: 's'}])
    .addOverridesByFieldName(field='Landed Since', properties=[{id: 'unit',value: 's'}]);

local FailedIngestionLogsPanel = grafana.tablePanel.new(
		title='Ingestion Error messages',
		datasource='Loki Container',
		description="Failed Ingestion Logs metric provides an overview of failure reason for failed ingestions for selected Application Source, Dataset,Landing Zone. It also provides an ability to search for specific failed ingestion over this table view by using text search box. These view helps us see error messages displaying on Grafana dashboards regarding failed ingestions in order to be able know quickly what are the ingestion issues."
  )
	.addTarget(
		target=grafana.loki.target(
			expr="{level=\"error\", landing_zone=~\"$stage\", project_name=~\"$project\"} |~\"$text_search\""
		)
	)
	.addTransformations([
		grafana.transformation.new('extractFields', options={
			source: 'labels'
		  }),
		grafana.transformation.new('filterFieldsByName', options={
			include: {
              names: [
                'Time',
                'Line',
                'dataset_name',
                'landing_zone',
                'project_name'
              ]
            }
		  }),
		grafana.transformation.new('organize', options={
			indexByName: {
              'Line': 4,
              'Time': 3,
              'dataset_name': 1,
              'landing_zone': 2,
              'project_name': 0
            },
            renameByName: {
              'Line': 'Error Message',
              'Time': 'Landed At',
              'dataset_name': 'Dataset',
              'landing_zone': 'Zone',
              'project_name': 'Application Source'
            }
      })
  ])
  .addOverridesByFieldName(
    field='Application Source',
    properties=[
      { id: 'custom.filterable', value: 'true' },
    ]
  )
  .addOverridesByFieldName(
    field='Dataset',
    properties=[
      { id: 'custom.filterable', value: 'true' },
    ]
  )
  .addOverridesByFieldName(
    field='Zone',
    properties=[
      { id: 'custom.filterable', value: 'true' },
    ]
  )
  .addOverridesByFieldName(
    field='Landed At',
    properties=[
      { id: 'custom.filterable', value: 'true' },
    ]
  )
  .addOverridesByFieldName(
    field='Error Message',
    properties=[
      { id: 'custom.filterable', value: 'true' },
    ]
  )
;

local DatasetsStatusRow = row.new(
  title="Dataset's Status",
  showTitle = 'true'
);


local Test =
  statPanel.new(
    title="context $context",
    datasource='IFM Azure SQL Server',
    description="The freshness is how long the event has been received and which mentions that the ingestion was well done -
The TTL is the threshold defined by the business for a data set to expire.",
    colorMode='background',
    repeat="context"

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'white',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT TOP 1 DATEDIFF(s, '19700101', GETUTCDATE()) - timestamp AS 'freshness' FROM [observability].[event]
      WHERE
      context_id = $context
      AND metric_name = 'processing_exit_code' AND metric_value = 0
      ORDER BY [timestamp] DESC
      ",
      format='table'
    )
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT metric_value as 'TTL' from [observability].[references] where context_id = $context
      AND metric_name = 'ttl'
      ",
      format='table'
    )
  ).addOverridesByFieldName(
  field='freshness',
  properties=[
    {id: 'unit',value: 's'},
    {
                id: 'thresholds',
      value: {
                  mode: 'absolute',
                  steps: [
                    {
                      color: 'green',
                      value: null,
                    }
                  ],
                },
              }
  ]
).addOverridesByFieldName(
  field='TTL',
  properties=[
    {id: 'unit',value: 's'}
  ]
);


local StatusPanelRow = row.new(
    title="Dataset Ingestion Monitoring",
    showTitle="false",
    collapse="true"
).addPanel(
    panel=Test,
    gridPos={h: 4, w: 10, x: 0, y: 20}
);

local IngestionsHistoryRow = row.new(title="Ingestion's History", collapse=true).addPanel(
  panel=PanelIngestionHistory,gridPos={h: 20, w: 24, x: 0, y: 30}
);

local FailedIngestionLogsRow = row.new(title="Failed Ingestion Logs - TableView", showTitle=true, collapse=true).addPanel(
  panel=FailedIngestionLogsPanel,gridPos={h: 15, w: 24, x: 0, y: 20}
);


local nodeGraph = grafana.nodeGraph.new(title="Project dependencies").addTarget(target=grafana.sql.target(
      rawSql="
      SELECT context_id as 'id' FROM  [observability].[lineageNodes]
      ",
      format='table'
    )) ;

local DataSetStatisticsRow = row.new(title="Dataset Statistics ", collapse=true).addPanel(
  panel=DataSetStatistics,gridPos={h: 10, w: 24, x: 0, y: 30}
);
grafana.dashboard.new(
  title='Tracking Last Ingestion #observability',
  refresh='5m',
  time_from='now-24h',
  editable='false',
  schemaVersion=37,
  uid='21EiXw14k',
  tags=['monitoring', 'run_team', 'observability', ])
.addTemplate(TemplateProject)
.addTemplate(TemplateDataset)
.addTemplate(TemplateRegion)
.addTemplate(TemplateStage)
.addTemplate(TemplateStatus)
.addTemplate(TemplateTextSearch)
.addTemplate(ContextTmplHided)
.addPanel(panel = gaugeRatio, gridPos={h:3,w:3,x:0,y: 0})
.addPanel(panel = TotalApplicationSource, gridPos={h:3,w:3,x:3,y: 0})
.addPanel(panel = TotalDataSets, gridPos={h:3,w:3,x:6,y: 0})
.addPanel(panel = TotalIngestionRun, gridPos={h:3,w:3,x:9,y: 0})
.addPanel(panel = SuccessRun, gridPos={h:3,w:3,x:15,y: 0})
.addPanel(panel = ShallowRun, gridPos={h:3,w:3,x:18,y: 0})
.addPanel(panel = FailedRun, gridPos={h:3,w:3,x:21,y: 0})
.addPanel(panel=DataSetStatisticsRow, gridPos={h: 20, w: 24, x: 0, y: 10})
.addPanel(panel=IngestionsHistoryRow, gridPos={h: 8, w: 24, x: 0, y: 20})
.addPanel(panel=FailedIngestionLogsRow, gridPos={h: 8, w: 24, x: 0, y: 20})
//.addPanel(panel=StatusPanelRow, gridPos={h: 8, w: 24, x: 0, y: 30})
