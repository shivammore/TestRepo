local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;

local adgroupTemplate =   tmpl.new(
    name='adgroup',
    datasource='Azure SQL Server',
    query="SELECT DISTINCT r.role_name FROM [dremio].[sys_roles] r
              where Upper(r.role_name) like '%DYNAMIFY%'",
    refresh='load',
    includeAll=true,
    multi=true,
    label='Ad Group'
  );

local dataassetTemplate = tmpl.custom(
    name='dataset',
    query="DYNAMIFY",
    current='DYNAMIFY',
    includeAll=false,
    multi=false,
    label='Data Asset'
  );

local datasetnameTemplate =   tmpl.new(
    name='datasetname',
    datasource='Azure SQL Server',
    query="select view_name from [dremio].[sys_views]
            WHERE Upper(SUBSTRING(REPLACE(REPLACE(REPLACE(path, '[', ''), ']', ''), ',', '.'), CHARINDEX('.', REPLACE(REPLACE(REPLACE(path, '[', ''), ']', ''), ',', '.')) + 1, LEN(REPLACE(REPLACE(REPLACE(path, '[', ''), ']', ''), ',', '.')))) LIKE '%DYNAMIFY%'",
    refresh='load',
    includeAll=true,
    multi=true,
    label='Dataset Name'
  );


local PrivilegePanelStatistics = grafana.tablePanel.new(
    title="User Privilege Details",
    datasource='Azure SQL Server',
    description="This table lists all the User prvilige details on AD Group"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
            SELECT DISTINCT r.role_name as 'AD Group', p.object_id as 'Folder Access',
                p.privilege as 'Privilege'
            FROM [dremio].[sys_roles] r
            JOIN [dremio].[sys_privileges] p ON r.role_name = p.grantee_id
           where r.role_name in ($adgroup) and Upper(r.role_name) like '%' || '$dataset' || '%'
      ",
      format='table'
    )
).addOverridesByFieldName(
  field='AD Group',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='Folder Access',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='Privilege',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
);

local AccessPanelStatistics = grafana.tablePanel.new(
    title="User Access Details",
    datasource='Azure SQL Server',
    description="This table lists all the User access details on AD Group"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
            select SUBSTRING(REPLACE(REPLACE(REPLACE(path, '[', ''), ']', ''), ',', '.'), CHARINDEX('.', REPLACE(REPLACE(REPLACE(path, '[', ''), ']', ''), ',', '.')) + 1, LEN(REPLACE(REPLACE(REPLACE(path, '[', ''), ']', ''), ',', '.'))) as 'Folder',
		--SUBSTRING(SUBSTRING(REPLACE(REPLACE(REPLACE(path, '[', ''), ']', ''), ',', '.'), CHARINDEX('.', REPLACE(REPLACE(REPLACE(path, '[', ''), ']', ''), ',', '.')) + 1, LEN(REPLACE(REPLACE(REPLACE(path, '[', ''), ']', ''), ',', '.'))), 1, CHARINDEX('.', SUBSTRING(REPLACE(REPLACE(REPLACE(path, '[', ''), ']', ''), ',', '.'), CHARINDEX('.', REPLACE(REPLACE(REPLACE(path, '[', ''), ']', ''), ',', '.')) + 1, LEN(REPLACE(REPLACE(REPLACE(path, '[', ''), ']', ''), ',', '.')))) - 1) as 'Zone',
	            type as 'DatasetType', view_name as 'Filtered Dataset', masking_policies as 'Masked Column', row_access_policies as 'Row Access Policy'
            from [dremio].[sys_views]
           WHERE view_name in ($datasetname) and Upper(SUBSTRING(REPLACE(REPLACE(REPLACE(path, '[', ''), ']', ''), ',', '.'), CHARINDEX('.', REPLACE(REPLACE(REPLACE(path, '[', ''), ']', ''), ',', '.')) + 1, LEN(REPLACE(REPLACE(REPLACE(path, '[', ''), ']', ''), ',', '.')))) LIKE '%' || '$dataset' || '%'   
      ",
      format='table'
    )
  ).addOverridesByFieldName(
  field='Folder',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='DatasetType',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='Filtered Dataset',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='Masked Column',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='Row Access Policy',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
);

local PanelHistogramtotalqueries = grafana.barChart.new(
    title="Queries executed by month",
    description='This graph represents the total Queries executed by timestamp',
    datasource='Azure SQL Server',
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
            SELECT 
                Sum(queries_count) AS 'Queries Executed',
                DATENAME(Month, DATEADD(Month, [dremio].[dremio_jobs_cost].month - 1, '1900-01-01')) AS Month
            FROM 
                [dremio].[dremio_jobs_cost]
            where 
               (upper(dataset_fullname) like '%' || '$dataset' || '%')
                    AND DATEDIFF(SECOND, '1970-01-01', create_ts) >= ${__from:date:seconds}
                    AND DATEDIFF(SECOND, '1970-01-01', create_ts) < ${__to:date:seconds}
            
            GROUP BY 
                [dremio].[dremio_jobs_cost].month
            ORDER BY 
                [dremio].[dremio_jobs_cost].month;
        ",
      format='table'
    )
  );

    local PanelHistogramqueriesbytype = grafana.barChart.new(
    title="Queries executed by Type",
    description='This graph represents the Queries executed by type',
    datasource='Azure SQL Server',
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
            SELECT 
                query_type as 'Query Type',SUM(queries_count) AS 'Queries Executed'
            FROM 
                [dremio].[dremio_jobs_cost]
            where 
                (upper(dataset_fullname) like '%' || '$dataset' || '%')   
            AND DATEDIFF(SECOND, '1970-01-01', create_ts) >= ${__from:date:seconds}
            AND DATEDIFF(SECOND, '1970-01-01', create_ts) < ${__to:date:seconds}
            GROUP BY 
                query_type
            ORDER BY 
                query_type;
        ",
      format='table'
    )
  ).addOption('orientation','horizontal')
  ;

    local PanelHistogramqueriesbydataset = grafana.barChart.new(
    title="Queries executed by Dataset",
    description='This graph represents the Queries executed by Dataset',
    datasource='Azure SQL Server',
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
            SELECT 
                dataset_name as 'Dataset',SUM(queries_count) AS 'Queries Executed'
            FROM 
                [dremio].[dremio_jobs_cost]
            where 
                (upper(dataset_fullname) like '%' || '$dataset' || '%')   
            AND DATEDIFF(SECOND, '1970-01-01', create_ts) >= ${__from:date:seconds}
            AND DATEDIFF(SECOND, '1970-01-01', create_ts) < ${__to:date:seconds}
            GROUP BY 
                dataset_name
            ORDER BY 
                dataset_name;
        ",
      format='table'
    )
  ).addOption('orientation','horizontal')
  ;

   local AdminePanelStatistics = grafana.tablePanel.new(
    title="Admin Access Details",
    datasource='Azure SQL Server',
    description="This table lists all the users having admin access"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
            select member_name, role_name from [dremio].[sys_membership] where role_name = 'ADMIN' and member_name like '%@sodexo%'
      ",
      format='table'
    )
  );

  local DataAccessStatisticsRow = row.new(title="Data Access View", collapse=true).addPanel(
  PrivilegePanelStatistics,gridPos={h: 15, w: 12, x: 0, y: 1})
  .addPanel(
  AccessPanelStatistics,gridPos={h: 15, w: 12, x: 12, y: 1});

  local DataUsageStatisticsRow = row.new(title="Data Usage View", collapse=true).addPanel(
  panel=PanelHistogramtotalqueries,gridPos={h: 8, w: 24, x: 0, y: 2})
  .addPanel(
  panel=PanelHistogramqueriesbytype,gridPos={h: 9, w: 12, x: 0, y: 10})
  .addPanel(
  panel=PanelHistogramqueriesbydataset,gridPos={h: 9, w: 12, x: 12, y: 10});

  local AdminAccessStatisticsRow = row.new(title="Admin Access View", collapse=true).addPanel(
  panel=AdminePanelStatistics,gridPos={h: 12, w: 24, x: 0, y: 3}
);

grafana.dashboard.new(
  title='Consumer Data Access Dashboard',
  editable='false',
  schemaVersion=37,
  uid='23RuLd20mc',
  tags=['monitoring', 'observability', 'SDX'])

.addTemplate(adgroupTemplate)
.addTemplate(dataassetTemplate)
.addTemplate(datasetnameTemplate)

.addPanel(panel=DataAccessStatisticsRow, gridPos={h: 1, w: 24, x: 0, y: 0})
.addPanel(panel=DataUsageStatisticsRow, gridPos={h: 1, w: 24, x: 0, y: 1})
.addPanel(panel=AdminAccessStatisticsRow, gridPos={h: 1, w: 24, x: 0, y: 29})