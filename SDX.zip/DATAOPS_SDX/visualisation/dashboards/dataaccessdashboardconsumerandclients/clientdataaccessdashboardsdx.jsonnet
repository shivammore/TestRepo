local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;

local adgroupTemplate =  tmpl.new(
    name='role',
    datasource='Azure SQL Server',
    query="select distinct role_name from [dremio].[user_access]
		        where role_name like '%INMOMENT%' or 
			            role_name like '%CLIENT%' or 
			            role_name like '%SOFORCE%' or
			            role_name like '%MARKET%'",
    refresh='load',
    current='all',
    includeAll=true,
    multi=true,
    label='Role Assigned'
  );

local userTemplate =   tmpl.new(
    name='user',
    datasource='Azure SQL Server',
    query="SELECT distinct name FROM [dremio].[user_access] where role_name like '%INMOMENT%' or role_name like '%CLIENT%' or role_name like '%SOFORCE%' or role_name like '%MARKET%'",
    refresh='load',
    includeAll=true,
    multi=true,
    label='User'
  );

local zoneTemplate = tmpl.custom(
    name='zone',
    query="gold,live",
    current='gold',
    includeAll=false,
    multi=false,
    label='Zone'
  );

local folderTemplate = tmpl.new(
    name='folder',
    datasource='Azure SQL Server',
    query="select 'product' as folder where '$zone' = 'gold'
          union
          select 'certified' as folder where '$zone' = 'gold'
          union
          select 'bronze' as folder where '$zone' = 'live'
          union
          select 'silver' as folder where '$zone' = 'live'",
    refresh='load',
    current='product',
    includeAll=false,
    multi=false,
    label='Folder'
  );

local datasetnameTemplate =   tmpl.new(
    name='dataset',
    datasource='Azure SQL Server',
    query="select 'OSS_GLB_MARKET_DATA' as dataset where '$folder' = 'certified'
            union
            select '4SITE' as dataset where '$folder' = 'product'
            union
            select 'BRAND-PERFORMANCE' as dataset where '$folder' = 'product'
            union
            select 'INMOMENT' as dataset where '$folder' = 'product'
            union
            select 'MDM_SITE' as dataset where '$folder' = 'product'
            union
            select 'SOFORCE' as dataset where '$folder' = 'product'
            union
            select 'OSS_GLB_GLB_DIYBULK' where '$folder' = 'bronze'
            union
            select 'OSS_GLB_GLB_DIYSURVEYS' where '$folder' = 'bronze'
            union
            select 'OSS_GLB_GLB_DYNAMIFY' where '$folder' = 'bronze'
            union
            select 'OSS_GLB_GLB_GLOBALCCX' where '$folder' = 'bronze'
            union
            select 'OSS_GLB_GLB_SOFORCE' where '$folder' = 'bronze'
            union
            select 'OSS_GLB_GLB_DIYBULK' where '$folder' = 'silver'
            union
            select 'STEP' where '$folder' = 'silver'",
    refresh='load',
    current='INMOMENT',
    includeAll=false,
    multi=false,
    label='Data Asset'
  );


local mergedAccessPanelStatistics = grafana.tablePanel.new(
    title="User Access Details",
    datasource='Azure SQL Server',
    description="This table lists all the role definition details"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
              SELECT 
              ua.name as 'UserName', 
              ua.role_name as 'Role Assigned', 
              ua.object_id as  'Access',
          		case 
                      when charindex('/', ua.object_id) > 0 and (charindex('.', ua.object_id) = 0 or charindex('/', ua.object_id) < Charindex('.', ua.object_id))
                      then Substring(ua.object_id,1, charindex('/', ua.object_id) -1) 
                      when charindex('.', ua.object_id) > 0
                      then substring(ua.object_id, 1 , charindex('.', ua.object_id) -1)
                      else ua.object_id
                      END as 'Zone',  
              ua.object_type as 'Access Type', 
              ua.active as 'User Active Status ', 
              ua.grantee_id as 'Grantee', 
              ua.privilege as 'Privilege' 
          FROM [dremio].[user_access] ua
		      where
		  	  case 
                      when charindex('/', ua.object_id) > 0 and (charindex('.', ua.object_id) = 0 or charindex('/', ua.object_id) < Charindex('.', ua.object_id))
                      then Substring(ua.object_id,1, charindex('/', ua.object_id) -1) 
                      when charindex('.', ua.object_id) > 0
                      then substring(ua.object_id, 1 , charindex('.', ua.object_id) -1)
                      else ua.object_id
                      END = '$zone' 
			    AND  ua.object_type != 'SCRIPT'
			    AND upper(ua.object_id) like '%' || '$folder' || '%'
			    AND upper(ua.object_id) like '%' || '$dataset' || '%'
			    and ua.name in ($user) and upper(ua.role_name) in ($role)
      ",
      format='table'
    )
  ).addOverridesByFieldName(
  field='UserName',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='Role Assigned',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='Access',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='Zone',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='Access Type',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='User Active Status',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='Grantee',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='Privilege',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
);

local PanelHistogramtotalqueries = grafana.barChart.new(
    title="Queries executed by month",
    description='This graph represents the total Queries executed by timestamp',
    datasource='Azure SQL Server',
  ).addTarget(
    target=grafana.sql.target(
      rawSql=" 
            with CTE1 as (
            SELECT 
                count(job_id) as 'QueriesExecuted',
                format(submitted_ts, 'MMMM') AS 'MonthName',
                month(submitted_ts) as 'MonthNumber'
            FROM 
                [dremio].[dremio_jobs_recent_part]
            where  
                     query != 'NA' 
                    and query_type != 'METADATA_REFRESH'
                    and (upper(queried_datasets) like '%' || '$dataset' || '%') and [dremio].[dremio_jobs_recent_part].user_name in ($user) 
                    AND DATEDIFF(SECOND, '1970-01-01', submitted_ts) >= ${__from:date:seconds}
                    AND DATEDIFF(SECOND, '1970-01-01', submitted_ts) < ${__to:date:seconds}
            GROUP BY 
                format(submitted_ts, 'MMMM'),
                Month(submitted_ts)
            )
            select QueriesExecuted, MonthName as 'Month' from CTE1
            ORDER BY MonthNumber;
        ",
      format='table'
    )
  );

  local PanelHistogramqueriesbytype = grafana.barChart.new(
    title="Queries executed by Type",
    description='This graph represents the Queries executed by type',
    datasource='Azure SQL Server',
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
			      SELECT 
                query_type as 'Query Type',count(job_id) AS 'Queries Executed'
            FROM 
                [dremio].[dremio_jobs_recent_part]
            where  
                     query != 'NA' 
                    and query_type != 'METADATA_REFRESH'
                    and (upper(queried_datasets) like '%' || '$dataset' || '%') and [dremio].[dremio_jobs_recent_part].user_name in ($user) 
                    AND DATEDIFF(SECOND, '1970-01-01', submitted_ts) >= ${__from:date:seconds}
                    AND DATEDIFF(SECOND, '1970-01-01', submitted_ts) < ${__to:date:seconds}
            GROUP BY 
                query_type
            ORDER BY 
                query_type;
        ",
      format='table'
    )
  ).addOption('orientation','horizontal')
  ;


  local PanelHistogramqueriesbydataset = grafana.barChart.new(
    title="Queries executed by Dataset",
    description='This graph represents the Queries executed by Dataset',
    datasource='Azure SQL Server',
  ).addTarget(
    target=grafana.sql.target(
      rawSql=" 
            SELECT 
                  upper(reverse(substring(reverse(replace(replace(queried_datasets, '[', ''), ']', '')), 1 , 
                  case
                      when charindex('.', reverse(replace(replace(queried_datasets, '[', ''), ']', ''))) > 0
                      then charindex('.', reverse(replace(replace(queried_datasets, '[', ''), ']', ''))) - 1
                  end
                  )
              )) as 'Dataset',count(job_id) AS 'Queries Executed'
            FROM 
                [dremio].[dremio_jobs_recent_part]
            where  
                     query != 'NA' 
                    and query_type != 'METADATA_REFRESH'
                    and (upper(queried_datasets) like '%' || '$dataset' || '%') and [dremio].[dremio_jobs_recent_part].user_name in ($user) 
                    AND DATEDIFF(SECOND, '1970-01-01', submitted_ts) >= ${__from:date:seconds}
                    AND DATEDIFF(SECOND, '1970-01-01', submitted_ts) < ${__to:date:seconds}
            GROUP BY 
                reverse(substring(reverse(replace(replace(queried_datasets, '[', ''), ']', '')), 1 , 
                case
	                when charindex('.', reverse(replace(replace(queried_datasets, '[', ''), ']', ''))) > 0
	                then charindex('.', reverse(replace(replace(queried_datasets, '[', ''), ']', ''))) - 1
	                end
	                )
	            )
            ORDER BY 
                reverse(substring(reverse(replace(replace(queried_datasets, '[', ''), ']', '')), 1 , 
                case
	                when charindex('.', reverse(replace(replace(queried_datasets, '[', ''), ']', ''))) > 0
	                then charindex('.', reverse(replace(replace(queried_datasets, '[', ''), ']', ''))) - 1
	              end
	          ));
        ",
      format='table'
    )
  ).addOption('orientation','horizontal')
  ;

local querydetailsPanelStatistics = grafana.tablePanel.new(
    title="Query Details",
    datasource='Azure SQL Server',
    description="This table lists all the query details of respective users"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
            SELECT user_name as 'UserName', query_type as 'QueryType', queried_datasets as 'Folder', 
                    status as 'Status', 
                    upper(reverse(substring(reverse(replace(replace(queried_datasets, '[', ''), ']', '')), 1 , 
            case
	              when charindex('.', reverse(replace(replace(queried_datasets, '[', ''), ']', ''))) > 0
	              then charindex('.', reverse(replace(replace(queried_datasets, '[', ''), ']', ''))) - 1
	          end
	          )
	      )) as 'Dataset', error_msg as 'FailedError',
                    submitted_epoch_millis as 'TimeStamp',
                    submitted_ts as 'QueriedDate' from [dremio].[dremio_jobs_recent_part]
                where [dremio].[dremio_jobs_recent_part].user_name in ($user)
                 and (upper(queried_datasets) like '%' || '$dataset' || '%')
                 and query != 'NA' 
                 and query_type != 'METADATA_REFRESH'
                            AND DATEDIFF(SECOND, '1970-01-01', submitted_ts) >= ${__from:date:seconds}
            AND DATEDIFF(SECOND, '1970-01-01', submitted_ts) < ${__to:date:seconds}
            order by submitted_ts desc
      ",
      format='table'
    )
).addOverridesByFieldName(
  field='UserName',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='QueryType',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='Folder',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='Dataset',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='QueriedDate',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='Status',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='FailedError',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
);

 local AdminePanelStatistics = grafana.tablePanel.new(
    title="Admin Access Details",
    datasource='Azure SQL Server',
    description="This table lists all the users having admin access"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
            select name as 'Admin user', active as 'User Active', role_name as 'Role Assigned' from [dremio].[user_access] where role_name like '%ADMIN%'
      ",
      format='table'
    )
  );

  local DataAccessStatisticsRow = row.new(title="Data Access View", collapse=true).addPanel(
  mergedAccessPanelStatistics,gridPos={h: 15, w: 24, x: 0, y: 1});

  local DataUsageStatisticsRow = row.new(title="Data Usage View", collapse=true).addPanel(
  panel=PanelHistogramtotalqueries,gridPos={h: 8, w: 24, x: 0, y: 2})
  .addPanel(
  panel=PanelHistogramqueriesbytype,gridPos={h: 8, w: 24, x: 0, y: 10})
  .addPanel(
  panel=PanelHistogramqueriesbydataset,gridPos={h: 8, w: 24, x: 0, y: 18})
  .addPanel(
  panel=querydetailsPanelStatistics,gridPos={h: 9, w: 24, x: 0, y: 19});

  local AdminAccessStatisticsRow = row.new(title="Admin Access View", collapse=true).addPanel(
  panel=AdminePanelStatistics,gridPos={h: 12, w: 24, x: 0, y: 3}
);

grafana.dashboard.new(
  title='Client Data Access Dashboard',
  editable='false',
  schemaVersion=37,
  uid='47RuLd19bc',
  tags=['monitoring', 'observability', 'SDX'])

.addTemplate(userTemplate)
.addTemplate(adgroupTemplate)
.addTemplate(zoneTemplate)
.addTemplate(folderTemplate)
.addTemplate(datasetnameTemplate)


.addPanel(panel=DataAccessStatisticsRow, gridPos={h: 1, w: 24, x: 0, y: 0})
.addPanel(panel=DataUsageStatisticsRow, gridPos={h: 1, w: 24, x: 0, y: 1})
.addPanel(panel=AdminAccessStatisticsRow, gridPos={h: 1, w: 24, x: 0, y: 29})