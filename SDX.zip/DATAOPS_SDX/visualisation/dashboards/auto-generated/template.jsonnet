local grafana = import 'grafonnet/grafana.libsonnet';

local generateContextIds(s) = std.set(['%s_%s_%s' % [x.project_name, x.dataset_name, x.landing_zone] for x in s]);
local get(d, key, defaultVal) = if std.objectHas(d, key) then d[key] else defaultVal;

local uniqueList(attribute, sources) = std.set([x[attribute] for x in sources]);

local generateStatPanelWithSourceCount(sources) =
  grafana.statPanel.new(title='Total Sources', datasource='Azure SQL Server')
  .addTarget(target=grafana.sql.target(rawSql=std.format("SELECT %d AS 'total_sources'", std.length(sources)), format='table'))
  ;


local filterSourcesWithDashboardView(sources) = [
  source for source in sources
  if !std.objectHas(source, 'disable_dashboard_view') || (std.objectHas(source, 'disable_dashboard_view') && source.disable_dashboard_view == false)

];

local ensureFieldsAndDeduplicate(sources) = [
    // First, construct a temporary object that includes a unique identifier
    s + {
        unique_id: s.project_name + '_' + s.dataset_name + '_' + s.landing_zone,
        publisher_name: std.get(s, 'publisher_name'),
        project_name: std.get(s, 'project_name'),
        dataset_name: std.get(s, 'dataset_name'),
        landing_zone: std.get(s, 'landing_zone'),
        ttl: std.get(s, 'ttl', null),
    }
    for s in sources
];

// De-duplicate based on the unique_id
local deduplicateSources(tempSources) = [
    // Using an object to enforce uniqueness
    tempSources[i]
    for i in std.range(0, std.length(tempSources) - 1)
    if std.count([
        tempSources[j].unique_id
        for j in std.range(0, i - 1)
    ], tempSources[i].unique_id) == 0
];

local flattenAndDeduplicate(objs) = deduplicateSources([
    // Flattening and preparing for deduplication
    {
        publisher_name: if std.type(obj.publisher_name) == "string" then obj.publisher_name else p,
        project_name: if std.type(obj.project_name) == "string" then obj.project_name else pr,
        dataset_name: if std.type(obj.dataset_name) == "string" then obj.dataset_name else d,
        ttl: std.get(obj, 'ttl', 'NULL'),
        landing_zone: if std.type(obj.landing_zone) == "string" then obj.landing_zone else l,
        // Add unique_id for deduplication
        unique_id: pr + '_' + d + '_' + l,
    }
    for obj in objs
    for p in if std.type(obj.publisher_name) == "array" then obj.publisher_name else [obj.publisher_name]
    for pr in if std.type(obj.project_name) == "array" then obj.project_name else [obj.project_name]
    for d in if std.type(obj.dataset_name) == "array" then obj.dataset_name else [obj.dataset_name]
    for l in if std.type(obj.landing_zone) == "array" then obj.landing_zone else [obj.landing_zone]
]);

// Remove the temporary unique_id field after deduplication
local removeUniqueIdField(sources) = [
    {
        publisher_name: s.publisher_name,
        project_name: s.project_name,
        dataset_name: s.dataset_name,
        landing_zone: s.landing_zone,
        ttl: s.ttl,
    }
    for s in sources
];

local GenerateTemple(name, label, attribute,description, sources) =
  local uniqueValues = uniqueList(attribute, sources);
  grafana.template.custom(
    name=name,
    current='all',
    query=std.join(',', uniqueValues),
    includeAll=true,
    multi=true,
    label=label
  )+ {
"description": description
}
;

local genereateTmplHidedContext =
grafana.template.new(
  name='context',
  datasource='Azure SQL Server',
  query="

    SELECT distinct(context_id)
    FROM [observability].[event]
    WHERE
  dataset_name IN ($dataset_name)
  AND landing_zone IN ($landing_zone)
  AND project_name IN ($project_name)
    ",
  current='all',
  refresh='load',
  hide = true,
  includeAll=true,
  multi=false,
  label='context'
);
local generateStatPanelWithSlo(slo) =
  grafana.statPanel.new(
  title='SLO',
   datasource='Azure SQL Server',
   description="This is a benchmark defined by the proprietors or stakeholders of a data ingestion pipeline.
    It signifies the anticipated and aspired level of efficiency, reliability, and quality for data ingestion processes.
     Such a goal provides a tangible metric against which the actual performance of the data ingestion can be evaluated,
      ensuring that the pipeline operates in alignment with stakeholder expectations and requirements.")
  .addTarget(target=grafana.sql.target(rawSql=std.format("SELECT %d AS 'slo'", slo), format='table')).addOverridesByFieldName(
    field='slo',
    properties=[
      {id: 'unit', value: 'percent'}]);


local generateIngestionPipelinesByCondition(sources, title, color, code) =
  local contexts = [
    s + { context_id: '%s_%s_%s' % [s.project_name, s.dataset_name, s.landing_zone] }
    for s in sources
  ];
  local context_ids = std.join("', '", [c.context_id for c in contexts]);
  local sqlQuery = std.format(
    "
        SELECT COUNT(*)
        FROM (
            SELECT distinct job_id, context_id
            FROM [observability].[event]
            WHERE metric_name='processing_exit_code'
            AND event_type='processingfinished'
            AND metric_value=%d
            AND context_id in ('%s')
            AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
           AND dataset_name IN ($dataset_name)
          AND landing_zone IN ($landing_zone)
          AND project_name IN ($project_name)
        ) AS SubQuery
    ", [code, context_ids]
  );

  grafana.statPanel.new(title, datasource='Azure SQL Server', colorMode='background')
  .addThresholds([{ value: 0, color: color }])
  .addTarget(target=grafana.sql.target(rawSql=sqlQuery, format='table'));

local generateStatPanelWithDynamicTTL(sources, slo) =
  local validSources = [s + { context_id: '%s_%s_%s' % [s.project_name, s.dataset_name, s.landing_zone] } for s in sources];
  local ttlMappingSubquery = std.join(', ', ["('%s', %d)" % [source.context_id, source.ttl] for source in validSources]);

  grafana.statPanel.new(title='Data Performance Indicator',
   datasource='Azure SQL Server',
   description="An Data Performance Indicator is a measurable metric closely monitored by stakeholders to
    evaluate the operational performance and efficiency of a data ingestion pipeline. ")
  .addTarget(
    target=grafana.sql.target(
      rawSql=std.format("
        WITH CTE AS (
    SELECT
        context_id,
        [timestamp],
        COALESCE(LAG([timestamp]) OVER (PARTITION BY context_id ORDER BY [timestamp] ASC), DATEDIFF(second, '1970-01-01', GETUTCDATE())) AS PrevTimestamp
    FROM
        [observability].[event]
    WHERE
        metric_name = 'processing_exit_code'
        AND metric_value = 0
        AND timestamp >= $__unixEpochFrom()
        AND timestamp < $__unixEpochTo()
        AND context_id IN ('%s')
),
TTLMapping AS (
    SELECT
        context_id,
        TTL
    FROM
        (VALUES %s) AS T(context_id, TTL)
),
Filtered AS (
    SELECT
        c.[timestamp] - c.PrevTimestamp - t.TTL as 'DelayInSeconds'
    FROM
        CTE c
    INNER JOIN
        TTLMapping t
    ON
        c.context_id = t.context_id
    WHERE
        c.[timestamp] - c.PrevTimestamp - t.TTL > 0
)
SELECT
    100 -  (ISNULL(SUM(DelayInSeconds), 0))*100 / ($__unixEpochTo() - $__unixEpochFrom()) as 'Percentage'
FROM
    Filtered;
      ", [std.join("', '", [source.context_id for source in validSources]), ttlMappingSubquery]), format='table'
    )
  )
  .addOverridesByFieldName(
    field='Percentage',
    properties=[
      {id: 'unit', value: 'percent'},
      {
        "id": "thresholds",
        "value": {
          "mode": "absolute",
          "steps": [
            { "color": "light-gray", "value": null },
            { "color": "light-red", "value": 0 },
            { "color": "light-yellow", "value": slo*0.9 },
            { "color": "light-green", "value": slo }
          ]
        }
      }
    ]
  );


local GenerateProjectMinSli(sources, slo) =
 local contexts = [
        s + { context_id: '%s_%s_%s' % [s.project_name, s.dataset_name, s.landing_zone] }
        for s in sources
    ];

    local context_ids = std.join("', '", [context.context_id for context in contexts]);
    local contextTTLMapping = { [item.project_name + '_' + item.dataset_name + '_' + item.landing_zone]: item.ttl for item in sources if 'ttl' in item };


    local ValuesClauseNodes = std.join(", ", [
        "('"
        + item.project_name + "', '"
        + item.dataset_name + "', '"
        + item.landing_zone + "', '"
        + item.context_id + "', "
        + std.toString(std.get(contextTTLMapping, item.context_id, 'NULL')) + ")"
        for item in contexts
    ]);



   local sqlQuery = std.format("
WITH
    CombinedValues AS (
        SELECT *
        FROM (VALUES %s) AS t (project_name, dataset_name, landing_zone, context_id, ttl)
        WHERE context_id IN (${context:sqlstring}+'')
    ),
    RawEvents AS (
        SELECT
            [timestamp],
            context_id,
            job_id,
            metric_value
        FROM
            [observability].[event]
        WHERE
            metric_name = 'processing_exit_code'
            AND event_type = 'processingfinished'
            AND context_id IN (${context:sqlstring}+'')
            AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
    ),
    DistinctJobs AS (
        SELECT DISTINCT
            context_id,
            job_id,
            metric_value
        FROM
            RawEvents
    ),
    IngestionSum AS (
        SELECT
            context_id,
            SUM(CASE WHEN metric_value = 0 THEN 1 ELSE 0 END) AS Succeeded,
            SUM(CASE WHEN metric_value = 1 THEN 1 ELSE 0 END) AS No_Data,
            SUM(CASE WHEN metric_value = -1 THEN 1 ELSE 0 END) AS Failed
        FROM
            DistinctJobs
        GROUP BY
            context_id
    ),
    FilteredAndAdded AS (
            SELECT
                timestamp,
                context_id,
                metric_value
            FROM (
                SELECT
                    timestamp,
                    context_id,
                    metric_value
                FROM
                    RawEvents
                WHERE
                    metric_value = 0
 
                UNION ALL
 
                SELECT
                    $__unixEpochTo() AS timestamp,  -- Current UTC timestamp as Unix time
                    context_id,
                    0 AS metric_value
                FROM
                    (SELECT DISTINCT context_id FROM RawEvents WHERE metric_value = 0) AS UniqueContexts
 
                UNION ALL
 
                SELECT
                    $__unixEpochFrom() AS timestamp,  -- Current UTC timestamp as Unix time
                    context_id,
                    0 AS metric_value
                FROM
                    (SELECT DISTINCT context_id FROM RawEvents WHERE metric_value = 0) AS UniqueContexts
                ) AS CombinedFilteredResults
    ),
    EventDifferences AS (
        SELECT
            context_id,
            timestamp,
            metric_value,
            LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
            CASE
                WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                    timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                ELSE NULL
            END AS time_difference
        FROM
            FilteredAndAdded
        WHERE
            metric_value = 0
    ),
    Slis AS (
        SELECT
            cv.project_name AS 'Application Source',
            cv.dataset_name AS 'Dataset Name',
            cv.landing_zone AS 'Zone',
            cv.ttl AS 'TTL',
            COALESCE(iso.Succeeded, 0) AS 'Succeeded',
            COALESCE(iso.No_Data, 0) AS 'No New Data',
            COALESCE(iso.Failed, 0) AS 'Failed',
            COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
            CASE
                WHEN COALESCE(iso.Succeeded, 0) = 0 THEN NULL
                WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
                ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / ($__unixEpochTo() - $__unixEpochFrom()))
            END AS SLI
        FROM
            CombinedValues AS cv
        LEFT JOIN
            IngestionSum AS iso
        ON
            cv.context_id = iso.context_id
        LEFT JOIN
            EventDifferences AS ed
        ON
            cv.context_id = ed.context_id
            AND ed.time_difference > cv.ttl
        GROUP BY
            cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed
    )

SELECT
    CASE
        WHEN COUNT(*) != COUNT(SLI) THEN 0  -- If any SLI is NULL, return 0
        WHEN MIN(SLI) < 0 then 0
        ELSE AVG(SLI)
    END AS 'Percentage'
FROM
    Slis;
", [ValuesClauseNodes]);

  grafana.statPanel.new(
  title='SLI',
  datasource='Azure SQL Server',
  description= "SLI (Service Level Indicator) measures the freshness and accuracy of data ingestion pipelines based on SLO (Service Level Objective) benchmarks set
by DAOs and Data Governors. Stakeholders define the SLOs for datasets in a standardized Excel template.  
 SLI: Selected time range (in hours) - Downtime (in hours)/Selected time range (in hours) * 100  
 Example 1: For a dataset with a 2-day time range and 1-day downtime: SLI: 48-24/48 * 100 = 50%                                                                                                                                                                                                                                
 Example 2: For a dataset with a 7-day time range and half-day downtime: SLI: 168-12/168 * 100 = 92.8%.")
  .addTarget(
    target=grafana.sql.target(
      rawSql=sqlQuery, format='table'
    )
  )
  .addOverridesByFieldName(
    field='Percentage',
    properties=[
      {id: 'unit', value: 'percent'},
      {
        "id": "thresholds",
        "value": {
          "mode": "absolute",
          "steps": [
            { "color": "light-gray", "value": null },
            { "color": "light-red", "value": 0 },
            { "color": "light-yellow", "value": slo },
            { "color": "light-green", "value": slo*1.1 }
          ]
        }
      }
    ]
  );

local Generatesucceded(sources) =
grafana.text.new(mode='markdown',
                content='Succeeded: Count of Ingestion Pipelines Run Successfully during the selected period for the selected dataset(s).',transparent= true);

local GenerateNoNewData(sources) =
grafana.text.new(mode='markdown',
                content='No New Data: Count of Ingestion Pipelines triggered but no data pushed from Integration during the selected period for the selected dataset(s).',transparent= true);

local GenerateFailed(sources) =
grafana.text.new(mode='markdown',
                content='Failed: Count of Ingestion Pipelines Failed during the selected period for the selected dataset(s).',transparent= true);

local GenerateRatio(sources) =
grafana.text.new(mode='markdown',
                content='Success ratio: It is calculated as ((Success+ No New Data)/ (success + No New Data + Failed)) * 100.',transparent= true);

local GenerateSuccessRatio(sources, slo) =
  local validSources = [s + { context_id: '%s_%s_%s' % [s.project_name, s.dataset_name, s.landing_zone] } for s in sources];

  grafana.statPanel.new(
    title='Success Ratio Indicator',
    datasource='Azure SQL Server',
    description= "The Pipeline Success Ratio Indicator provides a clear metric to gauge the effectiveness of
    a data ingestion pipeline by comparing successful operations against failures and no new data. "
  )
  .addTarget(
    target=grafana.sql.target(
      rawSql=std.format("SELECT
            CASE WHEN COUNT(*) = 0 THEN 100 
            ELSE COUNT(CASE WHEN metric_value != -1 THEN 1 ELSE NULL END) * 100.0 / COUNT(*) 
            END AS ratio
        FROM ( select distinct job_id, context_id, metric_value from[observability].[event]
                  WHERE metric_name= 'processing_exit_code'
                  AND event_type =  'processingfinished'
                  AND context_id IN ('%s')
                  AND context_id IN (${context:sqlstring}+'')
                  AND timestamp >= $__unixEpochFrom()
                  AND timestamp < $__unixEpochTo()
              ) As distinct_records",[
        std.join("', '", [source.context_id for source in validSources])
        ]),
      format='table'
    )
  ).addOverridesByFieldName(
    field='ratio',
    properties=[
      {id: 'unit', value: 'percent'}])
;


local generateSourcesStatistiques(sources) =

    local contexts = [
        s + { context_id: '%s_%s_%s' % [s.project_name, s.dataset_name, s.landing_zone] }
        for s in sources
    ];

    local context_ids = std.join("', '", [context.context_id for context in contexts]);
    grafana.tablePanel.new(
    title='Dataset Statistics Overview - TableView',
    datasource='Azure SQL Server',
    description="The Dataset Statistics Overview - TableView provides a structured and tabulated presentation of
    each dataset within the scope, showcasing the most recent statistics pertinent to each set."
  )
  .addTarget(target=grafana.sql.target(rawSql=std.format(
                "
            WITH last_ingestion AS (
            SELECT context_id,
                MAX(CASE WHEN metric_name = 'processing_exit_code' THEN metric_value END) AS processing_exit_code,
                MAX(CASE WHEN metric_name = 'content_latest_date' THEN metric_value END) AS content_latest_date,
                MAX(CASE WHEN metric_name = 'processing_exit_code' THEN timestamp END) AS timestamp
            FROM (
                SELECT
                    context_id,
                    metric_name,
                    metric_value,
                    timestamp,
                    ROW_NUMBER() OVER(PARTITION BY context_id, metric_name ORDER BY timestamp DESC) AS rn
                FROM [observability].[event]
                WHERE
                    metric_name IN ('processing_exit_code', 'content_latest_date')
                    AND context_id in ('%s')
            ) t
            WHERE rn = 1
            GROUP BY context_id
        )

        select * from last_ingestion ;",
        [context_ids]),format='table'))


  .addOverridesByFieldName(
    field='Status',
    properties=[
      { id: 'custom.displayMode', value: 'color-text' },
      { id: 'thresholds', value: { mode: 'absolute', steps: [{ color: 'text', value: null }] }},
      { id: 'mappings', value: [{ type: 'value', options: { Succeeded: { color: 'green' }, 'No New Data': { color: 'yellow' }}}] }
    ]
  )
  .addOverridesByFieldName(
    field='Diff %',
    properties=[
      { id: 'custom.displayMode', value: 'color-text' },
      { id: 'thresholds', value: { mode: 'absolute', steps: [{ color: 'text', value: null }] }},
      { id: 'mappings', value: [{ type: 'regex', options: { pattern: '^\\d+(?:\\.\\d+)?%$', result: { color: 'green' }}}, { type: 'regex', options: { pattern: '^-\\d+(?:\\.\\d+)?%$', result: { color: 'red' }}}] }
    ]
  )
  .addOverridesByFieldName(field='Landed Since', properties=[{id: 'unit',value: 's'}])
  .addOverridesByFieldName(field='Freshness', properties=[{id: 'unit',value: 's'}])
  .addOverridesByFieldName(field='TTL', properties=[{id: 'unit',value: 's'}]);

local generate_sli_per_source(source, position, slo) =
  local context_id = '%s_%s_%s' % [source.project_name, source.dataset_name, source.landing_zone];

  grafana.statPanel.new(
    title = source.project_name + " " + source.dataset_name + " " + source.landing_zone,
    datasource = 'Azure SQL Server',
    description = 'SLI stands for Service Level Indicator',
    colorMode = 'background'
  )
  .addTarget(
    target = grafana.sql.target(
      rawSql = std.format(
        "
        WITH CTE AS (
          SELECT context_id, [timestamp], LAG([timestamp]) OVER (PARTITION BY context_id ORDER BY [timestamp] ASC) AS PrevTimestamp FROM [observability].[event]
          WHERE metric_name = 'processing_exit_code' AND metric_value != -1 AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo() AND context_id IN ('%s')
        ),
        RawEvents AS (
            SELECT
                CASE
                WHEN PrevTimestamp IS NULL THEN DATEDIFF(SECOND, '19700101', GETUTCDATE()) - MAX([timestamp]) OVER() - %d
                ELSE timestamp - PrevTimestamp -  %d
                END AS DelayInSeconds
            FROM
                CTE
        ),
        FilteredEvents AS (
        select * from RawEvents where DelayInSeconds > 0
        )
        SELECT
        CASE
            WHEN SUM(DelayInSeconds) is NULL THEN 0
            ELSE 100 - (ISNULL(SUM(DelayInSeconds), 100)) * 100 / ($__unixEpochTo() - $__unixEpochFrom())
            END AS 'Percentage'

        FROM
            FilteredEvents;

        ",
        [context_id, source.ttl, source.ttl]
      ),
      format = 'table'
    )
  )
  .addOverridesByFieldName(
    field = 'Percentage',
    properties = [
      {id: 'unit', value: 'percent'},
      {
        "id": "thresholds",
        "value": {
          "mode": "absolute",
          "steps": [
            {"color": "light-gray", "value": null},
            {"color": "light-red", "value": 0},
            {"color": "light-yellow", "value": slo},
            {"color": "light-green", "value": slo*1.1}
          ]
        }
      }
    ]
  )
  {
    gridPos: {
      h: 4,
      w: 4,
      x: (position % 6) * 4,  // 6 is chosen based on the assumption of maximum panels in one row.
      y: (position / 6) * 4
    }
  };

local generateLastIngestionPanelPerContext =

  grafana.statPanel.new(
    title = "$context",
    repeat = "context",
    datasource = 'Azure SQL Server',
    description = "@todo",
    colorMode = 'background'
  )
  .addTarget(
    target = grafana.sql.target(
      rawSql = "
        SELECT DATEDIFF(SECOND, '19700101', GETUTCDATE()) - max([timestamp]) as 'Freshness'
        FROM [observability].[event]
        WHERE context_id = $context AND metric_name = 'processing_exit_code' AND metric_value = 0
      ",
      format = 'table'
    )
  )
//  .addTarget(
//    target = grafana.sql.target(
//      rawSql = "
//        SELECT %s as 'TTL'
//      " % [source.ttl],
//      format = 'table'
//    )
//  )
//  .addOverridesByFieldName(
//    field = 'Freshness',
//    properties = [
//      {id: 'unit', value: 's'},
//      {
//        "id": "thresholds",
//        "value": {
//          "mode": "absolute",
//          "steps": [
//          {
//                  "color": "dark-orange",
//                  "value": null
//                },
//                {
//                  "value": 0,
//                  "color": "super-light-yellow"
//                },
//    {"color": "light-green", "value": null},
//    {
//        "color": if source.ttl == null then "#8AB8FF" else "light-yellow",
//        "value": if source.ttl == null then null else source.ttl * 75 / 100
//    },
//    {
//        "color": if source.ttl == null then "#8AB8FF" else "light-red",
//        "value": source.ttl
//    }
//]
//
//        }
//      }
//    ]
//  )
.addOverridesByFieldName(
    field = 'Freshness',
    properties = [
      {id: 'unit', value: 's'},
      {
        "id": "thresholds",
        "value": {
          "mode": "absolute",
          "steps": [{"color": "#ffffff", "value": null}]
        }
      }
    ]
  )
  .addOverridesByFieldName(
    field = 'TTL',
    properties = [
      {id: 'unit', value: 's'},
      {
        "id": "thresholds",
        "value": {
          "mode": "absolute",
          "steps": [{"color": "#ffffff", "value": null}]
        }
      }
    ]
  ) ;



local generatePanelsRow(sources, slo, title, target_function) =
  grafana.row.new(
    title=title,
    showTitle="true",
    collapse="true",
  ).addPanels(
    [target_function(sources[i], i, slo) for i in std.range(0, std.length(sources) - 1)]
  );


local generatePanelsRowPerSource(sources, title, target_function) =
  grafana.row.new(
    title=title,
    showTitle="true",
    collapse="true",
  ).addPanels(
    [target_function(sources[i], i) for i in std.range(0, std.length(sources) - 1)]
  );

local GenerateIngestionHistoryRow(sources) =
    // Extracting context IDs from sources
    local contexts = [
        s + { context_id: '%s_%s_%s' % [s.project_name, s.dataset_name, s.landing_zone] }
        for s in sources
    ];
    local context_ids = std.join("', '", [context.context_id for context in contexts]);

    // SQL query definition
    local sqlQuery = std.format(
    |||
        WITH FilteredEvents AS (
            SELECT
                job_id,
                context_id,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                timestamp,
                metric_name,
                metric_value
            FROM
                [observability].[event]
            WHERE
                context_id IN ('%s')
                AND dataset_name IN ($dataset_name)
                AND landing_zone IN ($landing_zone)
                AND project_name IN ($project_name)
                AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                AND metric_name IN ('processing_started_date', 'processing_finished_date', 'processing_exit_code', 'rows_count', 'content_latest_date')
        ),
        MergedEvents AS (
            SELECT
                job_id,
                context_id,
                timestamp,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                [processing_started_date] AS processing_started_date_value,
                [processing_finished_date] AS processing_finished_date_value,
                [processing_exit_code] AS processing_exit_code_value,
                [content_latest_date] AS content_latest_date,
                [rows_count] AS rows_count_value
            FROM
                FilteredEvents
            PIVOT (
                MAX(metric_value)
                FOR metric_name IN ([processing_started_date], [processing_finished_date], [processing_exit_code], [rows_count], [content_latest_date])
            ) AS PivotTable
        ),
        Finalevents as
        (
        SELECT
            MAX(project_name) AS 'Application Source',
            MAX(dataset_name) AS 'Dataset',
            MAX(landing_zone) AS 'Zone',
            MAX(
                CASE subscription_id
                    WHEN '6b4a5b3f-1015-42da-a46a-2890a5abed30' THEN 'IFM CORE PROD'
                    WHEN '2698ca5b-bf81-43fb-8fe2-f0e21bf068e5' THEN 'IFM CORE UAT/TEST'
                    WHEN '746ac5b9-70eb-4c76-bdf4-0664bfdff2ea' THEN 'IFM CORE DEV'
                    WHEN 'cf25f2a1-4d40-45af-bb81-87ec46112b3e' THEN 'SDX STA/PRD'
                    WHEN 'c0978b9d-b809-45f4-aa76-391ceb2cfdba' THEN 'SDX DEV/TEST'
                    WHEN '8eaa3d95-3cd2-49d8-b44a-7ea47a6fb58b' THEN 'SDX SILVER'
                    WHEN 'daf86ec1-725c-493f-bf09-a1f129b8588a' THEN 'SDX INT/UAT'
                    WHEN 'fea1e9f0-0e20-426f-906e-bc76e5a566ad' THEN 'SDX Sandbox'
                    WHEN '6e3fc63f-851b-4fc7-8499-48f6a9c28a65' THEN 'SDX Global Shared Services'
                    ELSE 'Undefined'
            END
            ) AS 'Subscription',
            MAX(takeoff_zone) + ' to ' + MAX(landing_zone) AS 'Activity',
            CASE
                WHEN MAX(processing_exit_code_value) = 0 THEN 'Succeeded'
                WHEN MAX(processing_exit_code_value) = 1 THEN 'No New Data'
                WHEN MAX(processing_exit_code_value) = 2 THEN 'Skipped'
                WHEN MAX(processing_exit_code_value) IS NULL THEN 'Running'
                ELSE 'Failed'
            END AS 'Status',
            DATEADD(SECOND, MAX([timestamp]), '1970-01-01') AS 'Landed at',
            DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([timestamp]) AS 'Landed Since',
            DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([content_latest_date]) AS 'Freshness',
            CAST(MAX(processing_finished_date_value) - MAX(processing_started_date_value) AS BIGINT) AS 'Duration',
            ISNULL(CAST(CAST(MAX(rows_count_value) AS BIGINT) AS VARCHAR), 'N/A') AS 'Rows'
        FROM MergedEvents
        GROUP BY job_id, context_id
        )
        Select "Application Source", Dataset,Zone, Subscription, Activity, Status, "Landed at", "Landed Since", "Freshness", Duration,"Rows" from Finalevents
        where Status in ($status)
        ORDER BY "Landed at" DESC
    |||, context_ids);

    // Grafana table panel configuration
    local tablePanel = grafana.tablePanel.new(
        title='Dataset Ingestion History - TableView',
        datasource='Azure SQL Server'
    )
    .addTarget(
        target=grafana.sql.target(
            rawSql=sqlQuery,
            format='table'
        )
    )
    .addOverridesByFieldName(field='Landed Since', properties=[{id: 'unit',value: 's'}])
    .addOverridesByFieldName(field='Freshness', properties=[{id: 'unit',value: 's'}])
    .addOverridesByFieldName(field='Duration', properties=[{id: 'unit',value: 's'}])
    .addOverridesByFieldName(field='Rows', properties=[
    { id: 'custom.displayMode', value: 'color-text' },
            {
                id: 'thresholds',
                value: {
                    mode: 'absolute',
                    steps: [{ color: 'text', value: null }],
                },
            },
    {
        id: 'mappings',
        value: [
            {
                options: {
                    'N/A': {
                        color: 'red',
                        index: 0,
                    }
                },
                type: 'value',
            }
        ],
    }])
    .addOverridesByFieldName(
        field='Status',
        properties=[
            { id: 'custom.displayMode', value: 'color-text' },
            {
                id: 'thresholds',
                value: {
                    mode: 'absolute',
                    steps: [{ color: 'text', value: null }],
                },
            },
            {
                id: 'mappings',
                value: [
                    {
                        type: 'value',
                        options: {
                            'Succeeded': { color: 'green', index: 0 },
                            'No New Data': { color: 'yellow', index: 1 },
                            'Running': { color: 'gray', index: 2},
                            'Failed': { color: 'red', index: 3 },
                        },
                    }
                ],
            }
        ]
    );
        // Final Grafana row with the table panel
    grafana.row.new(
        title="Dataset Ingestion History Overview - TableView",
        showTitle=true,
        collapse=true
    ).addPanel(
        tablePanel,
        gridPos={h: 10, w: 24, x: 0, y: 12}
    );
local GenerateStatistiquesPanel (sources) =
    local contexts = [
        s + { context_id: '%s_%s_%s' % [s.project_name, s.dataset_name, s.landing_zone] }
        for s in sources
    ];

    local context_ids = std.join("', '", [context.context_id for context in contexts]);
    local contextTTLMapping = { [item.project_name + '_' + item.dataset_name + '_' + item.landing_zone]: item.ttl for item in sources if 'ttl' in item };


    local ValuesClauseNodes = std.join(", ", [
        "('"
        + item.project_name + "', '"
        + item.dataset_name + "', '"
        + item.landing_zone + "', '"
        + item.context_id + "', "
        + std.toString(std.get(contextTTLMapping, item.context_id, 'NULL')) + ")"
        for item in contexts
    ]);



   local sqlQuery = std.format("
WITH
    CombinedValues AS (
        SELECT *
        FROM (VALUES %s ) AS t (project_name, dataset_name, landing_zone, context_id, ttl)
        where  dataset_name IN ($dataset_name)
                AND landing_zone IN ($landing_zone)
                AND project_name IN ($project_name)
    ),
LastIngestionId AS (
    SELECT
        job_id,
        context_id,
        subscription_id,
        timestamp
    FROM (
        SELECT
            job_id,
            context_id,
            timestamp,
            subscription_id,
            ROW_NUMBER() OVER(PARTITION BY context_id ORDER BY timestamp DESC) AS rn
        FROM
            [observability].[event]
        WHERE
            context_id IN ('%s')
            AND metric_name = 'processing_exit_code'
            AND metric_value = '0'
            AND dataset_name IN ($dataset_name)
            AND landing_zone IN ($landing_zone)
            AND project_name IN ($project_name)
    ) AS RankedEvents
    WHERE
        rn = 1
),

Metrics AS (
    SELECT
        e.context_id,
        e.metric_name,
        e.metric_value,
        e.timestamp,
        e.subscription_id
    FROM
        [observability].[event] e
    JOIN
        LastIngestionId lii ON e.job_id = lii.job_id  AND e.context_id = lii.context_id

    WHERE
        e.metric_name IN ('processing_exit_code', 'content_latest_date', 'rows_count', 'columns_count')
),

LastIngestion AS (
    SELECT
        m.context_id,
        MAX(timestamp) AS timestamp,
        MAX(CASE WHEN m.metric_name = 'processing_exit_code' THEN m.metric_value END) AS processing_exit_code,
        MAX(CASE WHEN m.metric_name = 'content_latest_date' THEN m.metric_value END) AS content_latest_date,
        MAX(CASE WHEN m.metric_name = 'rows_count' THEN m.metric_value END) AS rows_count,
        MAX(CASE WHEN m.metric_name = 'columns_count' THEN m.metric_value END) AS columns_count,
         MAX(
                CASE subscription_id
                    WHEN '6b4a5b3f-1015-42da-a46a-2890a5abed30' THEN 'IFM CORE PROD'
                    WHEN '2698ca5b-bf81-43fb-8fe2-f0e21bf068e5' THEN 'IFM CORE UAT/TEST'
                    WHEN '746ac5b9-70eb-4c76-bdf4-0664bfdff2ea' THEN 'IFM CORE DEV'
                    WHEN 'cf25f2a1-4d40-45af-bb81-87ec46112b3e' THEN 'SDX STA/PRD'
                    WHEN 'c0978b9d-b809-45f4-aa76-391ceb2cfdba' THEN 'SDX DEV/TEST'
                    WHEN '8eaa3d95-3cd2-49d8-b44a-7ea47a6fb58b' THEN 'SDX SILVER'
                    WHEN 'daf86ec1-725c-493f-bf09-a1f129b8588a' THEN 'SDX INT/UAT'
                    WHEN 'fea1e9f0-0e20-426f-906e-bc76e5a566ad' THEN 'SDX Sandbox'
                    WHEN '6e3fc63f-851b-4fc7-8499-48f6a9c28a65' THEN 'SDX Global Shared Services'
                    ELSE 'Undefined'
            END
            ) AS 'subscription'
    FROM
        Metrics m
    GROUP BY
        m.context_id
)
SELECT
    h.project_name AS 'Application Source',
    h.dataset_name AS 'Dataset',
    h.landing_zone AS 'Zone',
    b.subscription AS 'Subscription',
    ISNULL(CONVERT(VARCHAR, h.ttl), 'Not Specified') as 'SLO',

    DATEDIFF(s, '19700101', GETUTCDATE()) - b.timestamp AS 'Landed Since',
    ISNULL(CONVERT(VARCHAR, DATEDIFF(s, '19700101', GETUTCDATE()) - b.content_latest_date), 'Not Specified') AS 'Freshness',
    ISNULL(CONVERT(VARCHAR, b.rows_count), 'N/A') AS 'Rows/Files',
    ISNULL(CONVERT(VARCHAR, b.columns_count), 'N/A') AS 'Columns',

    (
                CASE
                    WHEN h.ttl is NULL then 'Not tracked'
                    WHEN DATEDIFF(s, '19700101', GETUTCDATE()) - b.timestamp - h.ttl < 0 THEN 'On-time'
                    ELSE 'Delayed'
                END
            ) AS 'Delivery Status'


FROM
    CombinedValues AS h
    LEFT JOIN LastIngestion AS b ON b.context_id = h.context_id

", [ValuesClauseNodes, context_ids]);



    grafana.tablePanel.new(
    title='Dataset Statistics Overview - TableView',
    datasource='Azure SQL Server',
    description="Dataset statistics metric provides an overview of key statistical metrics for a specific dataset, including application source, dataset, area, landing, freshness , row count, average, diff % and SLO.
  These statistics help us identify trends and patterns in the data, as well as highlight outliers or anomalies, about data Freshness and Volume. The row number is before the merge with the actual Dataset ."
    ).addTarget(target=grafana.sql.target(rawSql=sqlQuery,format='table')).addOverridesByFieldName(
        field='Ingestion Status',
        properties=[
            { id: 'custom.displayMode', value: 'color-text' },
            {
                id: 'thresholds',
                value: {
                    mode: 'absolute',
                    steps: [{ color: 'text', value: null }],
                },
            },
            {
                id: 'mappings',
                value: [
                    {
                        type: 'value',
                        options: {
                            'Succeeded': { color: 'green', index: 0 },
                            'No New Data': { color: 'yellow', index: 1 },
                            'Failed': { color: 'red', index: 2 },
                        },
                    }
                ],
            }
        ]
    ).addOverridesByFieldName(
        field='Delivery Status',
        properties=[
            { id: 'custom.displayMode', value: 'color-text' },
            {
                id: 'thresholds',
                value: {
                    mode: 'absolute',
                    steps: [{ color: 'text', value: null }],
                },
            },
            {
                id: 'mappings',
                value: [
                    {
                        type: 'value',
                        options: {
                            'Delayed': { color: 'red', index: 0 },
                            'On-time': { color: 'green', index: 1 },
                            'Not tracked': { color: 'gray', index: 2 }

                        },
                    }
                ],
            }
        ]
    ).addOverridesByFieldName(
        field='Columns',
        properties=[
            { id: 'custom.displayMode', value: 'color-text' },
            {
                id: 'thresholds',
                value: {
                    mode: 'absolute',
                    steps: [{ color: 'text', value: null }],
                },
            },
            {
                id: 'mappings',
                value: [
                    {
                        type: 'value',
                        options: {

                            'N/A': { color: 'red', index: 0 },
                        },
                    }
                ],
            }
        ]
    ).addOverridesByFieldName(
  field='Landed Since',
  properties=[
  { id: 'custom.displayMode', value: 'color-text' },
            {
                id: 'thresholds',
                value: {
                    mode: 'absolute',
                    steps: [{ color: 'text', value: null }],
                },
            },
            {
                id: 'mappings',
                value: [
                    {
                        type: 'value',
                        options: {

                            'N/S': { color: 'orange', index: 0 },
                        },
                    }
                ],
            },
    {id: 'unit',value: 's'}
  ]
)
.addOverridesByFieldName(
  field='Freshness',
  properties=[
   { id: 'custom.displayMode', value: 'color-text' },
            {
                id: 'thresholds',
                value: {
                    mode: 'absolute',
                    steps: [{ color: 'text', value: null }],
                },
            },
            {
                id: 'mappings',
                value: [
                    {
                        type: 'value',
                        options: {

                            'Not Specified': { color: 'yellow', index: 0 },
                        },
                    }
                ],
            },
    {id: 'unit',value: 's'}
  ]
).addOverridesByFieldName(
  field='SLO',
  properties=[
    {id: 'unit',value: 's'},
    { id: 'custom.displayMode', value: 'color-text' },
            {
                id: 'thresholds',
                value: {
                    mode: 'absolute',
                    steps: [{ color: 'text', value: null }],
                },
            },
            {
                id: 'mappings',
                value: [
                    {
                        type: 'value',
                        options: {

                            'Not Specified': { color: 'yellow', index: 0 },
                        },
                    }
                ],
            }
  ]
)
.addOverridesByFieldName(
  field='Rows/Files',
  properties=[
    {id: 'unit',value: 'short'},
    { id: 'custom.displayMode', value: 'color-text' },
            {
                id: 'thresholds',
                value: {
                    mode: 'absolute',
                    steps: [{ color: 'text', value: null }],
                },
            },
            {
                id: 'mappings',
                value: [
                    {
                        type: 'value',
                        options: {

                            'Not Specified': { color: 'yellow', index: 0 },
                        },
                    }
                ],
            }
  ]
);


local GenerateKpisPanel (sources, slo) =
    local contexts = [
        s + { context_id: '%s_%s_%s' % [s.project_name, s.dataset_name, s.landing_zone] }
        for s in sources
    ];

    local context_ids = std.join("', '", [context.context_id for context in contexts]);
    local contextTTLMapping = { [item.project_name + '_' + item.dataset_name + '_' + item.landing_zone]: item.ttl for item in sources if 'ttl' in item };


    local ValuesClauseNodes = std.join(", ", [
        "('"
        + item.project_name + "', '"
        + item.dataset_name + "', '"
        + item.landing_zone + "', '"
        + item.context_id + "', "
        + std.toString(std.get(contextTTLMapping, item.context_id, 'NULL')) + ")"
        for item in contexts
    ]);



   local sqlQuery = std.format("
WITH
    CombinedValues AS (
        SELECT *
        FROM (VALUES %s ) AS t (project_name, dataset_name, landing_zone, context_id, ttl)
        where context_id IN (${context:sqlstring}+'')

    ),
    RawEvents AS (
        SELECT distinct
            [timestamp],
            context_id,
            job_id,
            metric_value
        FROM
            [observability].[event]
        WHERE
            metric_name = 'processing_exit_code'
            AND event_type = 'processingfinished'
            AND context_id IN (${context:sqlstring}+'')
            AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
    ),

    DistinctJobs AS (
        SELECT distinct
            context_id,
            job_id,
            metric_value
        FROM
            RawEvents
    ),

    IngestionSum AS (
        SELECT
            context_id,
            SUM(CASE WHEN metric_value = 0 THEN 1 ELSE 0 END) AS Succeeded,
            SUM(CASE WHEN metric_value = 1 THEN 1 ELSE 0 END) AS No_Data,
            SUM(CASE WHEN metric_value = -1 THEN 1 ELSE 0 END) AS Failed
        FROM
            DistinctJobs
        GROUP BY
            context_id
    ),


       FilteredAndAdded AS (
        SELECT
            timestamp,
            context_id,
            metric_value
        FROM
        (
            SELECT
                timestamp,
                context_id,
                metric_value
            FROM
                RawEvents
            WHERE
                metric_value = 0

            UNION ALL

            SELECT
                $__unixEpochTo() AS timestamp,  -- Current UTC timestamp as Unix time
                context_id,
                0 AS metric_value
            FROM
                (SELECT DISTINCT context_id FROM RawEvents WHERE metric_value = 0) AS UniqueContexts

            UNION ALL

            SELECT
                $__unixEpochFrom() AS timestamp,  -- Current UTC timestamp as Unix time
                context_id,
                0 AS metric_value
            FROM
                (SELECT DISTINCT context_id FROM RawEvents WHERE metric_value = 0) AS UniqueContexts
            ) AS CombinedFilteredResults
        ),

    EventDifferences AS (
        SELECT
            context_id,
            timestamp,
            metric_value,
            LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
            CASE
                WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                    timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                ELSE NULL
            END AS time_difference
        FROM
            FilteredAndAdded
        WHERE
            metric_value = 0
    )

    SELECT
        cv.project_name AS 'Application Source',
        cv.dataset_name AS 'Dataset Name',
        cv.landing_zone AS 'Zone',
        cv.ttl AS 'SLO',
        COALESCE(iso.Succeeded, 0) AS 'Succeeded',
        COALESCE(iso.No_Data, 0) AS 'No New Data',
        COALESCE(iso.Failed, 0) AS 'Failed',
        COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
        CASE
        WHEN COALESCE(iso.Succeeded, 0) = 0 THEN NULL
        WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
        ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / ($__unixEpochTo() - $__unixEpochFrom()))
        END AS SLI
    FROM
        CombinedValues AS cv
    LEFT JOIN
        IngestionSum AS iso
    ON
        cv.context_id = iso.context_id
    LEFT JOIN
        EventDifferences AS ed
    ON
        cv.context_id = ed.context_id
        AND ed.time_difference > cv.ttl
    GROUP BY
        cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed
    ORDER BY
        cv.project_name, cv.dataset_name;


", [ValuesClauseNodes]);



    grafana.tablePanel.new(
    title='Dataset Ingestions KPI - TableView',
    datasource='Azure SQL Server',
    description="Dataset Ingestions KPIs"
    ).addTarget(target=grafana.sql.target(rawSql=sqlQuery,format='table')).addOverridesByFieldName(
  field='SLO',
  properties=[
    {id: 'unit',value: 's'},
    { id: 'custom.displayMode', value: 'color-text' },
            {
                id: 'thresholds',
                value: {
                    mode: 'absolute',
                    steps: [{ color: 'text', value: null }],
                },
            },
            {
                id: 'mappings',
                value: [
                    {
                        type: 'value',
                        options: {

                            'Not Specified': { color: 'yellow', index: 0 },
                        },
                    }
                ],
            }
  ]
).addOverridesByFieldName(
  field='DownTime',
  properties=[
    {id: 'unit',value: 's'},
    { id: 'custom.displayMode', value: 'color-text' },
            {
                id: 'thresholds',
                value: {
                    mode: 'absolute',
                    steps: [{ color: 'text', value: null }],
                },
            },
            {
                id: 'mappings',
                value: [
                    {
                        type: 'value',
                        options: {

                            'Not Specified': { color: 'yellow', index: 0 },
                        },
                    }
                ],
            }
  ]
).addOverridesByFieldName(
    field='SLI',
    properties=[
      {id: 'unit', value: 'percent'},
      { id: 'custom.displayMode', value: 'color-text' },
      {
            "id": "noValue",
            "value": "N/A"
       },
       {
        id: 'mappings',
        value: [
            {
                options: {
                    'N/A': {
                        color: 'orange',
                        index: 0,
                    }
                },
                type: 'value',
            }
        ],
    },
      {
        "id": "thresholds",
        "value": {
          "mode": "absolute",
          "steps": [
            { "color": "light-gray", "value": null },
            { "color": "light-red", "value": 0 },
            { "color": "light-yellow", "value": slo*0.9 },
            { "color": "light-green", "value": slo }
          ]
        }
      }
    ]
  );



local GenerateGraphPanel (sources) =

    local generateSteps(ZONES) =
    [
        {
            start: ZONES[i],
            finish: ZONES[i+1]
        }
        for i in std.range(0, std.length(ZONES) - 2)
    ];

    local ZONES = ['transient', 'bronze', 'silver'];
    local uniqueProjects = uniqueList('project_name', sources);
    local uniqueDatasets = uniqueList('dataset_name', sources);
    local contextTTLMapping = { [item.project_name + '_' + item.dataset_name + '_' + item.landing_zone]: item.ttl for item in sources if 'ttl' in item };


    local expandedEdges = [
            {
                id: project + '_' + dataset + '_' + step.start + ':' + step.finish,
                source: project + '_' + dataset + '_' + step.start ,
                target: project + '_' + dataset + '_' + step.finish ,
            }
            for project in uniqueProjects
            for dataset in uniqueDatasets
            for step in generateSteps(ZONES)
        ];
     local expandedSources = [
            {
                project_name: project,
                dataset_name: dataset,
                landing_zone: zone,
                context_id: project + '_' + dataset + '_' + zone
            }
            for project in uniqueProjects
            for dataset in uniqueDatasets
            for zone in ZONES
        ];
        local ValuesClauseEdges = std.join(", ", [
        "('" + edge.id + "', '" + edge.source + "', '" + edge.target + "')"
        for edge in expandedEdges
    ]);

    local MSSQLQueryEdges = "
        WITH CombinedValues AS (
            SELECT *
            FROM (VALUES " + ValuesClauseEdges + " ) AS t (id, source, target)
        )
        SELECT
            id,
            source,
            target
        FROM CombinedValues;
    ";

       local ValuesClauseNodes = std.join(", ", [
    "('" + item.project_name + "', '" + item.dataset_name + "', '" + item.landing_zone + "', '" +
    item.context_id + "', " +
    std.toString(get(contextTTLMapping, item.project_name + '_' + item.dataset_name + '_' + item.landing_zone, 'NULL')) + ")"
    for item in expandedSources
]);


        local context_ids = std.join("', '", [c.context_id for c in expandedSources]);

        local MSSQLQueryNodes = std.format("
            WITH CombinedValues AS (
                SELECT *
                FROM (VALUES " + ValuesClauseNodes + " ) AS t (project_name, dataset_name, landing_zone, context_id, ttl)
            ),
            Freshness AS (
            SELECT DATEDIFF(SECOND, '19700101', GETUTCDATE()) - max([timestamp]) as 'Freshness', context_id
            FROM [observability].[event]
            WHERE context_id in ('%s') AND metric_name = 'processing_exit_code' AND metric_value = 0
            group by context_id
            )
            -- Your main query continues here, for example:
            SELECT
            cv.project_name as 'subtitle',
            cv.dataset_name as 'title',
            cv.landing_zone as 'mainstat',
            cv.context_id as id,
            dbo.ConvertSecondsToReadable(f.Freshness)+ ' ago' as 'secondarystat',
            CASE
                WHEN ttl - freshness < 0 THEN 0
                ELSE CAST((ttl - freshness) AS FLOAT) / ttl
                END AS arc__green,
                -- Calculation for arc__red
                CASE
                    WHEN ttl - freshness < 0 THEN 1
                    ELSE 0
                END AS arc__red,
                CASE
                    WHEN freshness IS NOT NULL AND ttl IS NULL THEN 1
                    ELSE 0
                END AS arc__static,
                -- Calculation for arc__yellow
                CASE

                    WHEN ttl IS NOT NULL THEN 1 - (CASE
                                                     WHEN ttl - freshness < 0 THEN 0
                                                     ELSE CAST((ttl - freshness) AS FLOAT) / ttl
                                                  END)
                    ELSE 0
                END AS arc__yellow,
                -- Calculation for arc__unhandled
                CASE
                    WHEN ttl IS NULL THEN 1
                    ELSE 0
                END AS arc__unhandled
        FROM CombinedValues cv
        LEFT JOIN Freshness f ON cv.context_id = f.context_id;
        ", [context_ids]);
        grafana.nodeGraph.new(title="Dataset Lifecycle Visualization",
      datasource="Azure SQL Server", showLegend=false).addTarget(target=grafana.sql.target(
          rawSql=MSSQLQueryNodes,
          format='table'
        ))
        .addTarget(target=grafana.sql.target(
          rawSql=MSSQLQueryEdges,
          format='table'
        ))
    .addArc(name = 'arc__green', color='green')
    .addArc(name = 'arc__yellow', color='yellow')
    .addArc(name = 'arc__red', color='red')
    .addArc(name = 'arc__unhandled', color='gray')
    .addArc(name = 'arc__static', color='#8AB8FF');

local GenerateRowsCountPerContext =
grafana.barChart.new(
    title="$context",
    description='Number of ingestion row volume',
    datasource='Azure SQL Server',
   repeat="context"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
          WITH calendar AS (
              SELECT CAST(DATEADD(SECOND, $__unixEpochFrom(), '19700101') AS DATE) AS date
              UNION ALL
              SELECT DATEADD(DAY, 1, date)
              FROM calendar
              WHERE DATEADD(DAY, 1, date) <= DATEADD(SECOND, $__unixEpochTo(), '19700101')
          ),
          converted_dates AS (
              SELECT
              CAST(DATEADD(SECOND, timestamp, '19700101') AS date) as 'date' ,
              metric_value
              FROM [observability].[event]
              WHERE metric_name = 'rows_count'
              AND context_id in (${context:sqlstring}+'')
              AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
          )
          SELECT
              c.date, ad.metric_value as 'rows'
          FROM
              calendar c
          FULL JOIN
              converted_dates ad ON c.date = ad.date
          ORDER BY
              c.date
              option (maxrecursion 0) ;
      ",
      format='table'
    )
  ).addOption('xTickLabelSpacing',100)
;


local GenerateColumnsCountPerContext =

 grafana.barChart.new(
    title="$context",
    description='volume of column count ingested',
    datasource='Azure SQL Server',
    repeat="context"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
          WITH calendar AS (
              SELECT CAST(DATEADD(SECOND, $__unixEpochFrom(), '19700101') AS DATE) AS date
              UNION ALL
              SELECT DATEADD(DAY, 1, date)
              FROM calendar
              WHERE DATEADD(DAY, 1, date) <= DATEADD(SECOND, $__unixEpochTo(), '19700101')
          ),
          converted_dates AS (
              SELECT
              CAST(DATEADD(SECOND, timestamp, '19700101') AS date) as 'date' ,
              metric_value
              FROM [observability].[event]
              WHERE metric_name = 'columns_count'
              AND context_id in (${context:sqlstring}+'')
              AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()

          )
          SELECT
              c.date, ad.metric_value as 'columns_count'
          FROM
              calendar c
          FULL  JOIN
              converted_dates ad ON c.date = ad.date
          ORDER BY
              c.date
              option (maxrecursion 0) ;
      ",
      format='table'
    )
  ).addOption('xTickLabelSpacing',100)
;


local GenerateIngestionHistoryByContext =

 grafana.barChart.new(
    title="$context",
    description='todo',
    datasource='Azure SQL Server',
    repeat="context"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
                  WITH calendar AS (
            SELECT CAST(DATEADD(SECOND, $__unixEpochFrom(), '19700101') AS DATE) AS date
            UNION ALL
            SELECT DATEADD(DAY, 1, date)
            FROM calendar
            WHERE DATEADD(DAY, 1, date) <= DATEADD(SECOND, $__unixEpochTo(), '19700101')
        ),
        converted_dates AS (
            SELECT
            CAST(DATEADD(SECOND, timestamp, '19700101') AS date) as 'date' ,
            metric_value
            FROM [observability].[event]
            WHERE metric_name = 'processing_exit_code'
            AND context_id in (${context:sqlstring}+'')
            AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
        )
        SELECT
            c.date,
            SUM(CASE WHEN metric_value = 0 THEN 1 ELSE 0 END) AS Succeeded,
            SUM(CASE WHEN metric_value = 1 THEN 1 ELSE 0 END) AS no_new_data,
            SUM(CASE WHEN metric_value = -1 THEN 1 ELSE 0 END) AS error
        FROM
            calendar c
        FULL JOIN
            converted_dates ad ON c.date = ad.date
        GROUP BY c.date
        ORDER BY c.date
        option (maxrecursion 0) ;

      ",
      format='table'
    )
  ).addOption('xTickLabelSpacing', 100)
   .addOverridesByFieldName(
    field='Succeeded',
    properties=[
          {
            "id": "color",
            "value": {
              "mode": "fixed",
              "fixedColor": "green"
            }
          }])
    .addOverridesByFieldName(
    field='no_new_data',
    properties=[
          {
            "id": "color",
            "value": {
              "mode": "fixed",
              "fixedColor": "yellow"
            }
          }])
   .addOverridesByFieldName(
    field='error',
    properties=[
          {
            "id": "color",
            "value": {
              "mode": "fixed",
              "fixedColor": "red"
            }
          }])

;

local FailedIngestionLogsPanel = grafana.tablePanel.new(
		title='Ingestion Error messages',
		datasource='Loki Container',
		description="Failed Ingestion Logs metric provides an overview of failure reason for failed ingestions for selected Application Source, Dataset,Landing Zone. It also provides an ability to search for specific failed ingestion over this table view by using text search box. These view helps us see error messages displaying on Grafana dashboards regarding failed ingestions in order to be able know quickly what are the ingestion issues."
    )
	.addTarget(
		target=grafana.loki.target(
			expr="{level=\"error\", landing_zone=~\"$landing_zone\", project_name=~\"$project_name\", dataset_name=~\"$dataset_name\"} |~\"$text_search\""
		)
	)
	.addTransformations([
		grafana.transformation.new('extractFields', options={
			source: 'labels'
		}),
		grafana.transformation.new('filterFieldsByName', options={
			include: {
              names: [
                'Time',
                'Line',
                'dataset_name',
                'landing_zone',
                'project_name'
              ]
            }
		}),
		grafana.transformation.new('organize', options={
			indexByName: {
              'Line': 4,
              'Time': 3,
              'dataset_name': 1,
              'landing_zone': 2,
              'project_name': 0
            },
            renameByName: {
              'Line': 'Error Message',
              'Time': 'Landed At',
              'dataset_name': 'Dataset',
              'landing_zone': 'Zone',
              'project_name': 'Application Source'
            }
      })
	])
;


//local GenerateRowsCountPerDataSet(source, position, slo) =
//  local context_id = '%s_%s_%s' % [source.project_name, source.dataset_name, source.landing_zone];
//
// grafana.barChart.new(
//    title=context_id,
//    description='todo',
//    datasource='Azure SQL Server',
//   repeat="context"
//  ).addTarget(
//    target=grafana.sql.target(
//      rawSql=std.format("
//          WITH calendar AS (
//              SELECT CAST(DATEADD(SECOND, $__unixEpochFrom(), '19700101') AS DATE) AS date
//              UNION ALL
//              SELECT DATEADD(DAY, 1, date)
//              FROM calendar
//              WHERE DATEADD(DAY, 1, date) <= DATEADD(SECOND, $__unixEpochTo(), '19700101')
//          ),
//          converted_dates AS (
//              SELECT
//              CAST(DATEADD(SECOND, timestamp, '19700101') AS date) as 'date' ,
//              metric_value
//              FROM [observability].[event]
//              WHERE metric_name = 'rows_count'
//              AND context_id = '%s'
//              AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
//          )
//          SELECT
//              c.date, ad.metric_value as 'rows'
//          FROM
//              calendar c
//          FULL JOIN
//              converted_dates ad ON c.date = ad.date
//          ORDER BY
//              c.date
//              option (maxrecursion 0) ;
//      ", [context_id]),
//      format='table'
//    )
//  ).addOption('xTickLabelSpacing',100)+ {
//    gridPos: {
//      h: 6,
//      w: 12,
//      x: (position*12 % 24),
//      y: (position*12 / 24)
//    }
//  }
//;

//local GenerateColumnsCountPerDataSet(source, position, slo) =
//  local context_id = '%s_%s_%s' % [source.project_name, source.dataset_name, source.landing_zone];
//
// grafana.barChart.new(
//    title=context_id,
//    description='todo',
//    datasource='Azure SQL Server',
//    repeat="context"
//  ).addTarget(
//    target=grafana.sql.target(
//      rawSql=std.format("
//          WITH calendar AS (
//              SELECT CAST(DATEADD(SECOND, $__unixEpochFrom(), '19700101') AS DATE) AS date
//              UNION ALL
//              SELECT DATEADD(DAY, 1, date)
//              FROM calendar
//              WHERE DATEADD(DAY, 1, date) <= DATEADD(SECOND, $__unixEpochTo(), '19700101')
//          ),
//          converted_dates AS (
//              SELECT
//              CAST(DATEADD(SECOND, timestamp, '19700101') AS date) as 'date' ,
//              metric_value
//              FROM [observability].[event]
//              WHERE metric_name = 'columns_count'
//              AND context_id = '%s'
//              AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
//
//          )
//          SELECT
//              c.date, ad.metric_value as 'columns_count'
//          FROM
//              calendar c
//          FULL  JOIN
//              converted_dates ad ON c.date = ad.date
//          ORDER BY
//              c.date
//              option (maxrecursion 0) ;
//      ", [context_id]),
//      format='table'
//    )
//  ).addOption('xTickLabelSpacing',100)+ {
//    gridPos: {
//      h: 6,
//      w: 12,
//      x: (position*12 % 24),
//      y: (position*12 / 24)
//    }
//  }
//;


//local GenerateIngestionHistoryByState(source, position) =
//    //Slo is the metric value
//  local context_id = '%s_%s_%s' % [source.project_name, source.dataset_name, source.landing_zone];
//
//
// grafana.barChart.new(
//    title=context_id,
//    description='todo',
//    datasource='Azure SQL Server',
//    repeat="context"
//  ).addTarget(
//    target=grafana.sql.target(
//      rawSql=std.format("
//                  WITH calendar AS (
//            SELECT CAST(DATEADD(SECOND, $__unixEpochFrom(), '19700101') AS DATE) AS date
//            UNION ALL
//            SELECT DATEADD(DAY, 1, date)
//            FROM calendar
//            WHERE DATEADD(DAY, 1, date) <= DATEADD(SECOND, $__unixEpochTo(), '19700101')
//        ),
//        converted_dates AS (
//            SELECT
//            CAST(DATEADD(SECOND, timestamp, '19700101') AS date) as 'date' ,
//            metric_value
//            FROM [observability].[event]
//            WHERE metric_name = 'processing_exit_code'
//            AND context_id = '%s'
//            AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
//        )
//        SELECT
//            c.date,
//            SUM(CASE WHEN metric_value = 0 THEN 1 ELSE 0 END) AS Succeeded,
//            SUM(CASE WHEN metric_value = 1 THEN 1 ELSE 0 END) AS no_new_data,
//            SUM(CASE WHEN metric_value = -1 THEN 1 ELSE 0 END) AS error
//        FROM
//            calendar c
//        FULL JOIN
//            converted_dates ad ON c.date = ad.date
//        GROUP BY c.date
//        ORDER BY c.date
//        option (maxrecursion 0) ;
//
//      ", [context_id]),
//      format='table'
//    )
//  ).addOption('xTickLabelSpacing', 100)
//   .addOverridesByFieldName(
//    field='Succeeded',
//    properties=[
//          {
//            "id": "color",
//            "value": {
//              "mode": "fixed",
//              "fixedColor": "green"
//            }
//          }])
//    .addOverridesByFieldName(
//    field='no_new_data',
//    properties=[
//          {
//            "id": "color",
//            "value": {
//              "mode": "fixed",
//              "fixedColor": "yellow"
//            }
//          }])
//   .addOverridesByFieldName(
//    field='error',
//    properties=[
//          {
//            "id": "color",
//            "value": {
//              "mode": "fixed",
//              "fixedColor": "red"
//            }
//          }])
//    + {
//    gridPos+: {
//      h: 6,
//      w: 12,
//      x: (position * 12 % 24),
//      y: (position * 12 / 24)
//    },
//
//}
//;

local GenerateDocumentation(sources) =
local content = std.format(
    |||
        # Introduction %s
        In data observability, our main focus is on tracking the flow of data as it moves through different stages in our system. Each team involved in this process sends out updates or 'events' at every stage. This helps us keep a close eye on how the data is being handled and transformed at each step. Our goal is to make sure that the quality of the data remains high throughout this journey. By monitoring these events closely, we can quickly spot and fix any issues, ensuring that the data we use and rely on across our platform is accurate and reliable.

        # Dashboard Components
        This document outlines the key components of our dashboard and the lifecycle stages of data from Transient to Bronze to Silver. Each dashboard component plays a vital role in visualizing and monitoring the flow and quality of data as it progresses through these stages. Understanding these components is crucial for effectively managing and interpreting the data pipeline.


        **Application Source**
        The Application Source component represents a unique identifier assigned to each data source across all layers of the system. It's constructed as a concatenation of `{business_lines}.{region_code}.{country_code}.{source_name}`, providing a structured and standardized way to identify and track the origin of data. This identifier is crucial for organizing and analyzing data based on business line, geographical region, and specific data sources.

        **Dataset Name**
        The Dataset Name is the specific name given to the data within the source. It could refer to a database table, a file, or any other structured form of data, depending on how the dataset is constructed.

        **Zone**
        The Zone component signifies the current stage of data ingestion within the system. It categorizes the data into different stages or levels of processing and refinement. Currently, we support three main zones:
        - *Transient*: This is the initial stage where data is temporarily held before further processing.
        - *Bronze*: At this stage, the data undergoes initial cleaning and structuring, preparing it for more advanced analysis.
        - *Silver*: Here, the data is further refined and enriched, making it ready for in-depth analysis and reporting.

        **Owner-Set Performance Goal**
        The Owner-Set Performance Goal is a key metric for data owners, functioning like a Service Level Objective (SLO) for data ingestion. It represents a percentage that defines an agreed-upon threshold for the ingestion lag. This goal ensures that the time taken to ingest data does not exceed a certain limit over a specified period. By setting and monitoring this performance goal, data owners can maintain high standards for data processing efficiency and reliability, thereby ensuring that the system operates within the optimal parameters and meets the expectations for data timeliness.

        **Data Performance Indicator**
        The Data Performance Indicator acts like a Service Level Indicator (SLI), providing real-time monitoring of the data ingestion process. It is a crucial tool that measures whether the current data ingestion rates are in line with the time frames set by the data owners. This indicator helps in immediately identifying any deviations from the expected performance, allowing for quick corrective actions to ensure that the data ingestion process stays within the defined limits. It's an essential component for maintaining the overall health and efficiency of the data ingestion pipeline, ensuring that the system consistently meets the performance goals set by data owners.

        **Success Ratio Indicator**
        The Success Ratio Indicator is a key metric represented as a percentage, reflecting the proportion of successful data ingestions relative to the total ingestions over a defined time period. This indicator provides a clear and quantifiable measure of the effectiveness and reliability of the data ingestion process. By tracking this ratio, teams can quickly assess the health and performance of their data pipeline, identify areas for improvement, and ensure that the majority of ingestion attempts are successful. This metric is crucial for maintaining high data quality and operational efficiency, giving a direct insight into the robustness of the data ingestion system.

        **TTL (Time-To-Live)**
        TTL, or Time-To-Live, is a critical threshold defined by data owners that governs the lifespan of a dataset's ingestion in a specific zone. This threshold specifies the maximum allowable time period within which data ingestion should occur or be re-attempted in case of failure. If there is no successful ingestion or if repeated ingestions fail within this time frame, the dataset is flagged as expired. This expiration triggers an alert, prompting immediate attention to address and resolve the issue. The TTL mechanism ensures proactive monitoring and maintenance of data flow, safeguarding against prolonged data gaps or persistent ingestion problems, and thereby maintaining the health and reliability of the overall data pipeline.

        **Ingestion Status**
        The Ingestion Status component tracks the current state of data ingestion processes, categorizing them into three distinct statuses:

        - *Succeeded*: Count of ingestion pipelines run successfully during the selected period for the selected datasets.

        - *No-New-Data*: Count of ingestion pipelines triggered but no data pushed from integration during the selected period for the selected datasets.

        - *Failed*: Count of ingestion pipelines failed during the selected period for the selected datasets.

        Each of these statuses provides vital information about the health and performance of the data ingestion pipeline, facilitating effective monitoring and management of data flow across the system.


        # Graph Panel: Data Lifecycle Visualization

        The Graph Panel dynamically illustrates the progression of data through its lifecycle stages: Transient, Bronze, and Silver. Generated via a Jsonnet script, this panel visualizes each unique project and dataset combination as it moves through these zones. It's a powerful tool for observing the real-time status and transitions of data, allowing teams to monitor the flow and identify any bottlenecks or delays in the process.

        ## Graph View Color Legend

        The colors in the graph view provide quick visual cues regarding the status of data freshness and the TTL (Time-To-Live) thresholds:

        - **Green**: Data freshness is within acceptable limits. This indicates that the data is current and up-to-date.
        - **Yellow**: Remaining time until TTL threshold. This signals that the data is approaching the limit of its freshness period.
        - **Red**: Data has exceeded the TTL and isn't fresh. This signifies that the data is outdated and requires immediate attention.
        - **Gray**: Data source is not yet handled. This shows that the data source has not been processed yet.
        - **Blue**: Freshness data is available, but no TTL is set. This indicates that while data freshness is being tracked, no specific TTL has been defined for it.

        [More details on Event Naming Rules](https://sdxcloud.visualstudio.com/IST.GLB.GLB.GDS_DATAPLATFORM/_wiki/wikis/IST.GLB.GLB.GDS_DATAPLATFORM.wiki/7839/Event-Naming-rules)
    |||, [""] );
grafana.text.new(mode='markdown',content=content,title="Dashboard runbook Documentation",description="todo");

local graphDocumentation() =
        grafana.text.new(
        mode='html',
        content='
    <div style="display: flex; justify-content: space-between;">
        <div style="">
            <span style="width: 12px; height: 12px; display: inline-block; border-radius: 50%; background-color: green; vertical-align: middle; margin-right: 4px;"></span>
             Data freshness within acceptable limits.
        </div>
        <div style="">
            <span style="width: 12px; height: 12px; display: inline-block; border-radius: 50%; background-color: yellow; vertical-align: middle; margin-right: 4px;"></span>
             Remaining time until TTL threshold.
        </div>
        <div style="">
            <span style="width: 12px; height: 12px; display: inline-block; border-radius: 50%; background-color: red; vertical-align: middle; margin-right: 4px;"></span>
            Data exceeded TTL and isnt fresh.
        </div>
        <div style="">
            <span style="width: 12px; height: 12px; display: inline-block; border-radius: 50%; background-color: gray; vertical-align: middle; margin-right: 4px;"></span>
             Data source is not yet handled.
        </div>
        <div style="">
            <span style="width: 12px; height: 12px; display: inline-block; border-radius: 50%; background-color: #8AB8FF; vertical-align: middle; margin: 4px;"></span>
            Freshness data is available, but no TTL is set.
        </div>
    </div>
</div>
',
        title="Graph View colors legend",
        description="todo"
        );

local getDashboardAlertsPanel(id) =
grafana.alertlist.new(
title = std.format("Dashboard Alerts %s", id),
onlyAlertsOnDashboard = true,
limit=null,

)

+ {
'options' :
    {
    "dashboardAlerts": true ,
    "sortOrder" : 4,
    "maxItems": -1,
    "stateFilter": {
          "firing": true,
          "pending": true,
          "noData": true,
          "normal": true,
          "error": true
        }
    }
}

+ {
"limit": null,
"sortOrder": 1,


};

local generatePanelCount(sources) =
  grafana.statPanel.new(
    title='Total Datasets',
    datasource='Azure SQL Server',
    description="The total dataset we have in database within the source. It could refer to a database table, a file, or any other structured form of data, depending on how the dataset is constructed."
  )
  // Use the length of the sources list as the value to display
  .addTarget(
    target=grafana.sql.target(
      rawSql="with cte as (select '${dataset_name:csv}' as val)
	              select (LEN(val) - LEN(REPLACE(val, ',', ''))) + 1 from cte;",
      format='table'
    )
  );

local ensureFields(sources) = [
    {
        publisher_name: std.get(s, 'publisher_name'),
        project_name: std.get(s, 'project_name'),
        dataset_name: std.get(s, 'dataset_name'),
        landing_zone: std.get(s, 'landing_zone'),
        ttl: std.get(s, 'ttl', null),
    }
    for s in sources
];
local flattenStrings(objs) = [
  {
    publisher_name: if std.type(obj.publisher_name) == "string" then obj.publisher_name else p,
    project_name: if std.type(obj.project_name) == "string" then obj.project_name else pr,
    dataset_name: if std.type(obj.dataset_name) == "string" then obj.dataset_name else d,
    ttl: std.get(obj, 'ttl', 'NULL'),
    landing_zone: if std.type(obj.landing_zone) == "string" then obj.landing_zone else l,
    disable_dashboard_view: std.get(obj, 'disable_dashboard_view', true) ,

  }
  for obj in objs
  for p in if std.type(obj.publisher_name) == "array" then obj.publisher_name else [obj.publisher_name]
  for pr in if std.type(obj.project_name) == "array" then obj.project_name else [obj.project_name]
  for d in if std.type(obj.dataset_name) == "array" then obj.dataset_name else [obj.dataset_name]
  for l in if std.type(obj.landing_zone) == "array" then obj.landing_zone else [obj.landing_zone]
];


local input_json = std.parseYaml(std.extVar("input"));
local flat_sources_all = flattenStrings(input_json.sources);
local flat_sources = flat_sources_all;#filterSourcesWithDashboardView(flat_sources_all);

local tempSources = ensureFieldsAndDeduplicate(flat_sources);
local deduplicatedTempSources = deduplicateSources(tempSources);
local flatAndDeduplicatedSources = flattenAndDeduplicate(deduplicatedTempSources);
local finalSources = removeUniqueIdField(flatAndDeduplicatedSources);
local sources = ensureFields(finalSources);



grafana.dashboard.new(
  title=input_json.title,
  refresh='5m',
  time_from='now-7d',
  editable=true,
  timezone='utc',
  schemaVersion=37,
  uid=std.md5(input_json.title),
  tags=input_json.tags,
)
.addTemplate(
  GenerateTemple(
    name="project_name",
    label="Application Source",
    attribute="project_name",
    description='{business_lines}.{region_code}.{country_code}.{source_name}',
    sources=sources
  )
)
.addTemplate(
  GenerateTemple(
    name="dataset_name",
    label="Dataset Name",
    attribute="dataset_name",
    description='The Table Name',
    sources=sources
  )
)
.addTemplate(
  GenerateTemple(
    name="landing_zone",
    label="Zone",
    attribute="landing_zone",
    description='The Zone name',
    sources=sources
  )
).addTemplate(grafana.template.custom(
    name='status',
    current='all',
    query='Succeeded,Failed,No New Data,Running,Skipped',
    includeAll=true,
    multi=true,
    label='Ingestion Status'
  )
)
// .addTemplate(grafana.template.text(
//     name='text_search',
// 	label='Search Log'
//   )
// )

.addTemplate(
 genereateTmplHidedContext
)
.addPanel(
  generatePanelCount(sources),
  gridPos={h: 3, w: 8, x: 0, y: 0}
)
.addPanel(
  generateStatPanelWithSlo(input_json.slo),
  gridPos={h: 3, w: 8, x: 8, y: 0}
)
.addPanel(
  GenerateProjectMinSli(sources, input_json.slo),
  gridPos={h: 3, w: 8, x: 16, y: 0}
)

.addPanel(
  generateIngestionPipelinesByCondition(sources, 'Succeeded', 'green', 0),
  gridPos={h: 3, w: 6, x: 0, y: 3}
)
.addPanel(
  generateIngestionPipelinesByCondition(sources, 'No New Data', 'yellow', 1),
  gridPos={h: 3, w: 6, x: 6, y: 3}
)
.addPanel(
  generateIngestionPipelinesByCondition(sources, 'Failed', 'red', -1),
  gridPos={h: 3, w: 6, x: 12, y: 3}
)
.addPanel(
  GenerateSuccessRatio(sources, input_json.slo),
  gridPos={h: 3, w: 6, x: 18, y: 3}
)

//.addPanel(
//  grafana.row.new(
//    title="Datasets Last Successful Ingestion Graph View",
//    showTitle=true,
//    collapse=true,
//  )
//  .addPanel(
//  graphDocumentation(),
//  gridPos={h: 2, w: 24, x: 0, y: 0}
//  )
//  .addPanel(
//  GenerateGraphPanel(sources),
//  gridPos={h: 20, w: 24, x: 0, y: 2}
//  ),
//gridPos={h: 22, w: 24, x: 0, y: 15}
//)
.addPanel(
  grafana.row.new(
    title="Dataset KPIs Overview - TableView",
    showTitle=true,
    collapse=true,
  ).addPanel(
  GenerateKpisPanel(sources, input_json.slo),
  gridPos={h: 10, w: 24, x: 0, y: 10}
  ),
gridPos={h: 1, w: 24, x: 0, y: 9}
)
.addPanel(
  grafana.row.new(
    title="Dataset Statistics Overview - TableView",
    showTitle=true,
    collapse=true,
  ).addPanel(
  GenerateStatistiquesPanel(sources),
  gridPos={h: 10, w: 24, x: 0, y: 11}
  ),
gridPos={h: 1, w: 24, x: 0, y: 10}
)
.addPanel(
  GenerateIngestionHistoryRow(sources),
  gridPos={h: 1, w: 24, x: 0, y: 12}
)
//.addPanel(
//grafana.row.new(
//    title="Recent Success & TTL Overview by Source - PanelView",
//    showTitle=true,
//    collapse=true,
//  )
//  .addPanel(
//  generateLastIngestionPanelPerContext,
//  gridPos={h: 5, w: 5, x: 0, y: 0}
//  ),
//  gridPos={h: 20, w: 24, x: 0, y: 25}
//)

//.addPanel(
//  generatePanelsRow(
//    [s for s in sources if s.ttl != null],
//    input_json.slo,
//    "Data Performance Indicator by Source - PanelView",
//    generate_sli_per_source
//  ),
//  gridPos={h: 20, w: 24, x: 0, y: 20}
//)
.addPanel(
grafana.row.new(
    title="Source-Based Row Volume Histogram",
    showTitle=true,
    collapse=true,
  )
  .addPanel(
  GenerateRowsCountPerContext,
  gridPos={h: 5, w: 6, x: 0, y: 13}
  ),
  gridPos={h: 1, w: 24, x: 0, y: 13}
)
.addPanel(
grafana.row.new(
    title="Source-Based Column Count Histogram",
    showTitle=true,
    collapse=true,
  )
  .addPanel(
  GenerateColumnsCountPerContext,
  gridPos={h: 5, w: 6, x: 0, y: 14}
  ),
  gridPos={h: 1, w: 24, x: 0, y: 14}
)
//.addPanel(
//grafana.row.new(
//    title="Source-Based Cumulative Ingestions Histogram",
//    showTitle=true,
//    collapse=true,
//  )
//  .addPanel(
//  GenerateIngestionHistoryByContext,
//  gridPos={h: 5, w: 5, x: 0, y: 0}
//  ),
//  gridPos={h: 20, w: 24, x: 0, y: 35}
//)
//.addPanel(
//grafana.row.new(
//    title="Failed Ingestion Logs - TableView",
//    showTitle=true,
//    collapse=true
//  )
//  .addPanel(
//  FailedIngestionLogsPanel,
//  gridPos={h: 15, w: 24, x: 0, y: 20}
//  ),
//  gridPos={h: 15, w: 24, x: 0, y: 20}
//)

.addPanel(
  grafana.row.new(
    title="Dashboard Alerts",
    showTitle=true,
    collapse=true,
  ).addPanel(
  getDashboardAlertsPanel(input_json.title),
  gridPos={h: 12, w: 24, x: 0, y: 15}
  ),
gridPos={h: 1, w: 24, x: 0, y: 15}
)
.addPanel(
  Generatesucceded(sources),
  gridPos={h: 3, w: 6, x: 0, y: 6}
  )
.addPanel(
  GenerateNoNewData(sources),
  gridPos={h: 3, w: 6, x: 6, y: 6}
  )
  .addPanel(
  GenerateFailed(sources),
  gridPos={h: 3, w: 6, x: 12, y: 6}
  )
  .addPanel(
  GenerateRatio(sources),
  gridPos={h: 3, w: 6, x: 18, y: 6}
  )


.addPanel(
  grafana.row.new(
    title="Dashboard runbook Documentation",
    showTitle=true,
    collapse=true,
  ).addPanel(
  GenerateDocumentation(sources),
  gridPos={h: 12, w: 24, x: 0, y: 16}
  ),
gridPos={h: 1, w: 24, x: 0, y: 16}

)