local grafana = import 'grafonnet/grafana.libsonnet';

local filterSourceWithAlerting(sources) = [
  source for source in sources if std.objectHas(source, 'alerting') && source.alerting != null
];


local filterVolumeAlertRows(sources) = [
  source for source in sources
  if std.objectHas(source, 'alerting') &&  // Check if 'alerting' field exists
     source.alerting.type == 'volume' &&
     std.objectHas(source.alerting, 'rows_min_threshold')
];

local secondsToReadableFormat(seconds) =
  local secPerMinute = 60;
  local secPerHour = secPerMinute * 60;
  local secPerDay = secPerHour * 24;
  local secPerWeek = secPerDay * 7;
  local secPerMonth = secPerDay * 30; // Approximation
  local secPerYear = secPerDay * 365; // Approximation

  // Calculate each time component
  local years = (seconds / secPerYear);
  local months = (seconds % secPerYear) / secPerMonth;
  local weeks = (seconds % secPerMonth) / secPerWeek;
  local days = (seconds % secPerWeek) / secPerDay;
  local hours = (seconds % secPerDay) / secPerHour;
  local minutes = (seconds % secPerHour) / secPerMinute;
  local secs = seconds % secPerMinute;

  // Format the output string
  local result = [
    if years >= 1 then std.floor(years) + "y " else "",
    if months >= 1 && years < 1 then std.floor(months) + "mo " else "",
    if weeks >= 1 && months < 1 then std.floor(weeks) + "w " else "",
    if days >= 1 && weeks < 1 then std.floor(days) + "d " else "",
    if hours >= 1 && days < 1 then std.floor(hours) + "h " else "",
    if minutes >= 1 && hours < 1 then std.floor(minutes) + "m " else "",
    if secs >= 1 && minutes < 1 then secs + "s" else "",
  ];

  std.join(" ", result);

local ensureFields(sources) = [
    {
        publisher_name: std.get(s, 'publisher_name'),
        project_name: std.get(s, 'project_name'),
        dataset_name: std.get(s, 'dataset_name'),
        landing_zone: std.get(s, 'landing_zone'),
        alerting: std.get(s, 'alerting'),
    }
    for s in sources
];

local flatSources(objs) = [
  {
    publisher_name: if std.type(obj.publisher_name) == "string" then obj.publisher_name else p,
    project_name: if std.type(obj.project_name) == "string" then obj.project_name else pr,
    dataset_name: if std.type(obj.dataset_name) == "string" then obj.dataset_name else d,
    landing_zone: if std.type(obj.landing_zone) == "string" then obj.landing_zone else l,
    ttl: if std.type(obj.ttl) == "string" then obj.ttl else t,
    alerting: if std.type(obj.alerting) == "string" then obj.alerting else alerting,
  }
  for obj in objs
  for p in if std.type(obj.publisher_name) == "array" then obj.publisher_name else [obj.publisher_name]
  for pr in if std.type(obj.project_name) == "array" then obj.project_name else [obj.project_name]
  for d in if std.type(obj.dataset_name) == "array" then obj.dataset_name else [obj.dataset_name]
  for l in if std.type(obj.landing_zone) == "array" then obj.landing_zone else [obj.landing_zone]
  for t in if std.type(obj.ttl) == "array" then obj.ttl else [obj.ttl]
  for alerting in if std.type(obj.alerting) == "array" then obj.alerting else [obj.alerting]
];



local convertToGrafanaAlertVolumeRows(source, title) =
local context_id = std.format('%s_%s_%s', [source.project_name, source.dataset_name, source.landing_zone]);
local disable_during_weekend = if std.objectHas(source.alerting, 'disable_during_weekend') then source.alerting.disable_during_weekend else false;
local disable_during_work_days = if std.objectHas(source.alerting, 'disable_during_work_days') then source.alerting.disable_during_work_days else false;

// Convert boolean values to integers for SQL Server compatibility
local disable_during_weekend_int = if disable_during_weekend then 1 else 0;
local disable_during_work_days_int = if disable_during_work_days then 1 else 0;

local rows_min_threshold = source.alerting.rows_min_threshold;

local rawSql = std.format(
    "

    SELECT TOP 1
    CASE
            WHEN (DATEPART(dw, DATEADD(SECOND, TIMESTAMP, '1970-01-01 00:00:00')) IN (1, 7) AND (%d = 1)) OR
                 (DATEPART(dw, DATEADD(SECOND, TIMESTAMP, '1970-01-01 00:00:00')) NOT IN (1, 7) AND (%d = 1) )
            THEN %d

            ELSE metric_value
   END AS LastIngestionRows


    FROM observability.event
    WHERE metric_name = 'rows_count' and context_id = '%s'
    ORDER BY TIMESTAMP DESC
    ",
    [
      disable_during_weekend_int,
      disable_during_work_days_int,
      rows_min_threshold,
      context_id
    ]
  );


local severity = source.alerting.severity;
local channels = source.alerting.channels;

local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
local silence_labels = std.join("::", envs);

{
  "uid": std.md5(std.format("volume::rows::%s%s", [context_id, rows_min_threshold])),
  "title": std.format("Volume(Rows): %s ────  %s ────️  %s  (%d)", [source.project_name, source.dataset_name, source.landing_zone, rows_min_threshold]),
  "condition": "B",  // Set "B" as the alert condition
  "data": [
    {
      "refId": "A",
      "datasourceUid": "AzureSQLServer",
      "relativeTimeRange": { "from": 1800, "to": 0 },
      "model": {
        "format": "table",
        "hide": false,
        "intervalMs": 1000,
        "maxDataPoints": 43200,
        "rawQuery": true,
        "rawSql": rawSql,
      }
    },
    {
      refId: "B",
      datasourceUid: "__expr__",  // Use the "__expr__" datasource for Grafana expressions
      model: {
        type: "classic_conditions",  // Use classic conditions for threshold evaluation
        conditions: [
          {
            evaluator: { params: [rows_min_threshold], type: "lt" },  // Adjust `threshold` as needed
            operator: { type: "and" },
            query: { params: ["A", "5m", "now"] },  // Reference "A" over a time range
            reducer: { type: "last" },  // Use the last value for evaluation, adjust as needed
          }
        ],
        refId: "B",
      }
    }
  ],
  "noDataState": "Alerting",
  "for": "60s",
  "annotations": {
    "__dashboardUid__": std.md5(title),
    "__panelId__": 23,
  },
  "labels": {
    "project_name": source.project_name,
    "dataset_name": source.dataset_name,
    "landing_zone": source.landing_zone,
    "alert_type": "Volume(Rows)",
    "severity": severity,
    "sla" : secondsToReadableFormat(source.ttl),
    "rows_min_threshold": rows_min_threshold,
    "env": silence_labels,
    "dashboard_title": title,
    "disable_during_weekend": disable_during_weekend,
    "disable_during_work_days": disable_during_work_days,
    "channels": std.join("::", channels),
  }
};


local input_json = std.parseYaml(std.extVar("input"));
local dashboard_title = input_json.title;
local filtred_sources = filterSourceWithAlerting(input_json.sources);
local flat_sources = flatSources(filtred_sources);
local volume_alerts_rows = filterVolumeAlertRows(flat_sources);
local volume_alerts_grafana = [convertToGrafanaAlertVolumeRows(source, dashboard_title) for source in volume_alerts_rows];

local generatePolicies(sources, defaultReceiver='') =
  // Extract all channels from all sources
  local allChannels = [channel for source in sources for channel in source.alerting.channels];
  // Remove duplicates to get unique channels
  local uniqueChannels = std.set(allChannels);

  // Check if there are any unique channels
  if std.length(uniqueChannels) == 0 then
    []
  else
    // Construct the routes array for all unique channels
    local routes = [
      {
        receiver: if std.length(channel) > 0 then channel else defaultReceiver,
        object_matchers: [['channels', '=~', '.*' + channel + '.*']],
      }
      for channel in uniqueChannels
    ];
    // Create a single policy with all routes
    [
      {
        orgId: 1,
        receiver: uniqueChannels[0], // Use the specified default receiver
        routes: routes,
      }
    ];


{
  "apiVersion": 1,
  "groups": [
    {
      "orgId": 1,
      "name": "Volume "+ input_json.title,
      "folder": "Observability Monitoring",
      "interval": "1h",
        rules: volume_alerts_grafana,
    }
  ],
//  "policies": generatePolicies(volume_alerts)
}
