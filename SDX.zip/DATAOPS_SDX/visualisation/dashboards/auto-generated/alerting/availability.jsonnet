local grafana = import 'grafonnet/grafana.libsonnet';

local filterSourceWithAlerting(sources) = [
  source for source in sources if std.objectHas(source, 'alerting') && source.alerting != null
];



local filterAvailabilityAlertTTL(sources) = [
  source for source in sources
  if std.objectHas(source, 'alerting') &&  // Check if 'alerting' field exists
     source.alerting.type == 'availability' &&
     std.objectHas(source.alerting, 'time_to_live') &&  // Check if 'time_to_live' field exists within 'alerting'
     source.alerting.time_to_live != null
];

local filterAvailabilityAlertSchedule(sources) = [
  source for source in sources
  if std.objectHas(source, 'alerting') &&  // Check if 'alerting' field exists
     source.alerting.type == 'availability' &&
     std.objectHas(source.alerting, 'ingestion_schedule_utc') &&  // Check if 'ingestion_schedule_utc' field exists within 'alerting'
     source.alerting.ingestion_schedule_utc != null
];


  // Helper function to convert time string to float
local timeToFloat(timeStr) =
    local timeComponents = std.split(timeStr, ':');
    local hour = std.parseInt(timeComponents[0]);
    local minute = if std.length(timeComponents) > 1 then std.parseInt(timeComponents[1]) else 0;
    hour + minute / 60.0; // Convert to float format


local parseAndConvertSchedule(input) =

  local parts = std.split(input, ' ');
  local dayOfMonth = parts[0];
  local dayOfWeek = parts[1];
  local timePart = parts[2];


   // todo add verification for the correct snytax
   {
      // Process dayOfMonth: Convert to null if '*', else pass as integer
      monthday: if dayOfMonth == '*' then null else std.parseInt(dayOfMonth),
      // Process dayOfWeek: Convert to null if '*', else pass as integer
      weekday: if dayOfWeek == '*' then null else std.parseInt(dayOfWeek),
      // Convert time part to float
      datetimePart: timePart, # timeToFloat(timePart),
    };


local secondsToReadableFormat(seconds) =
  local secPerMinute = 60;
  local secPerHour = secPerMinute * 60;
  local secPerDay = secPerHour * 24;
  local secPerWeek = secPerDay * 7;
  local secPerMonth = secPerDay * 30; // Approximation
  local secPerYear = secPerDay * 365; // Approximation

  // Calculate each time component
  local years = (seconds / secPerYear);
  local months = (seconds % secPerYear) / secPerMonth;
  local weeks = (seconds % secPerMonth) / secPerWeek;
  local days = (seconds % secPerWeek) / secPerDay;
  local hours = (seconds % secPerDay) / secPerHour;
  local minutes = (seconds % secPerHour) / secPerMinute;
  local secs = seconds % secPerMinute;

  // Format the output string
  local result = [
    if years >= 1 then std.floor(years) + "y " else "",
    if months >= 1 && years < 1 then std.floor(months) + "mo " else "",
    if weeks >= 1 && months < 1 then std.floor(weeks) + "w " else "",
    if days >= 1 && weeks < 1 then std.floor(days) + "d " else "",
    if hours >= 1 && days < 1 then std.floor(hours) + "h " else "",
    if minutes >= 1 && hours < 1 then std.floor(minutes) + "m " else "",
    if secs >= 1 && minutes < 1 then secs + "s" else "",
  ];

  std.join(" ", result);


local ensureFields(sources) = [
    {
        publisher_name: std.get(s, 'publisher_name'),
        project_name: std.get(s, 'project_name'),
        dataset_name: std.get(s, 'dataset_name'),
        landing_zone: std.get(s, 'landing_zone'),
        alerting: std.get(s, 'alerting'),
    }
    for s in sources
];




local flatSources(objs) = [
  {
    publisher_name: if std.type(obj.publisher_name) == "string" then obj.publisher_name else p,
    project_name: if std.type(obj.project_name) == "string" then obj.project_name else pr,
    dataset_name: if std.type(obj.dataset_name) == "string" then obj.dataset_name else d,
    landing_zone: if std.type(obj.landing_zone) == "string" then obj.landing_zone else l,
    ttl: if std.type(obj.ttl) == "string" then obj.ttl else t,
    alerting: if std.type(obj.alerting) == "string" then obj.alerting else alerting,
  }
  for obj in objs
  for p in if std.type(obj.publisher_name) == "array" then obj.publisher_name else [obj.publisher_name]
  for pr in if std.type(obj.project_name) == "array" then obj.project_name else [obj.project_name]
  for d in if std.type(obj.dataset_name) == "array" then obj.dataset_name else [obj.dataset_name]
  for l in if std.type(obj.landing_zone) == "array" then obj.landing_zone else [obj.landing_zone]
  for t in if std.type(obj.ttl) == "array" then obj.ttl else [obj.ttl]
  for alerting in if std.type(obj.alerting) == "array" then obj.alerting else [obj.alerting]
];

local convertToGrafanaAlertSchedule(source, title) =
local context_id = std.format('%s_%s_%s', [source.project_name, source.dataset_name, source.landing_zone]);

local ingestion_schedule_utc = source.alerting.ingestion_schedule_utc;
local ingestion_schedule_allowed_delta = 345600; #if std.objectHas(source.alerting, 'ingestion_schedule_allowed_delta') then source.alerting.ingestion_schedule_allowed_delta else 14400;


local disable_during_weekend = if std.objectHas(source.alerting, 'disable_during_weekend') then source.alerting.disable_during_weekend else false;
local disable_during_work_days = if std.objectHas(source.alerting, 'disable_during_work_days') then source.alerting.disable_during_work_days else false;

// Convert boolean values to integers for SQL Server compatibility
local disable_during_weekend_int = if disable_during_weekend then 1 else 0;
local disable_during_work_days_int = if disable_during_work_days then 1 else 0;


local parsedCroneExpression = parseAndConvertSchedule(ingestion_schedule_utc); // Format the output string


local rawSql = if parsedCroneExpression.monthday == null && parsedCroneExpression.weekday == null then
  std.format(
    "
    DECLARE @NextScheduleCroneJob INT = dbo.GetNextCronRunTimeDailyTimeStamp('%s');
    DECLARE @PrevScheduleCroneJob INT = @NextScheduleCroneJob - 86400;
    DECLARE @AllowDelta INT = %d;

    SELECT TOP 1
    CASE
            WHEN (DATEPART(dw, GETUTCDATE()) IN (1, 7) AND (%d = 1)) OR
                   (DATEPART(dw, GETUTCDATE()) NOT IN (1, 7) AND (%d = 1) )
            THEN 0
            WHEN TIMESTAMP + @AllowDelta > @PrevScheduleCroneJob THEN 0
            ELSE @PrevScheduleCroneJob - TIMESTAMP -- Trigger The Alert and return the delta
    END AS AlertTrigger

    FROM observability.event
    WHERE metric_name = 'processing_exit_code' and metric_value = 0 and context_id = '%s'
    ORDER BY TIMESTAMP DESC
    ",
    [
      parsedCroneExpression.datetimePart,
      14400,
      disable_during_weekend_int,
      disable_during_work_days_int,
      context_id
    ]
  )
else if parsedCroneExpression.monthday == null && parsedCroneExpression.weekday != null  && parsedCroneExpression.datetimePart != null then
  std.format(
    "
    DECLARE @NextScheduleCroneJob INT = dbo.GetNextCronRunTimeWeeklyTimeStamp(%d,'%s');
    DECLARE @PrevScheduleCroneJob INT = @NextScheduleCroneJob - 604800;
    DECLARE @AllowDelta INT = %d;

    SELECT TOP 1
    CASE
            WHEN (DATEPART(dw, GETUTCDATE()) IN (1, 7) AND (%d = 1)) OR
                   (DATEPART(dw, GETUTCDATE()) NOT IN (1, 7) AND (%d = 1) )
            THEN 0
            WHEN TIMESTAMP + @AllowDelta > @PrevScheduleCroneJob THEN 0
            ELSE @PrevScheduleCroneJob - TIMESTAMP -- Trigger The Alert and return the delta
    END AS AlertTrigger

    FROM observability.event
    WHERE metric_name = 'processing_exit_code' and metric_value = 0 and context_id = '%s'
    ORDER BY TIMESTAMP DESC
    ",
    [
      parsedCroneExpression.weekday,
      parsedCroneExpression.datetimePart,
      ingestion_schedule_allowed_delta,
      disable_during_weekend_int,
      disable_during_work_days_int,
      context_id
    ]
  )
else if parsedCroneExpression.weekday == null && parsedCroneExpression.monthday != null  && parsedCroneExpression.datetimePart != null then
  std.format(
    "
    DECLARE @NextScheduleCroneJob INT = dbo.GetNextCronRunTimeMonthlyTimeStamp(%d,'%s');
    DECLARE @PrevScheduleCroneJob INT = @NextScheduleCroneJob - 2592000;
    DECLARE @AllowDelta INT = %d;

    SELECT TOP 1
    CASE
            WHEN (DATEPART(dw, GETUTCDATE()) IN (1, 7) AND (%d = 1)) OR
                   (DATEPART(dw, GETUTCDATE()) NOT IN (1, 7) AND (%d = 1) )
            THEN 0
            WHEN TIMESTAMP + @AllowDelta > @PrevScheduleCroneJob THEN 0
            ELSE @PrevScheduleCroneJob - TIMESTAMP -- Trigger The Alert and return the delta
    END AS AlertTrigger

    FROM observability.event
    WHERE metric_name = 'processing_exit_code' and metric_value = 0 and context_id = '%s'
    ORDER BY TIMESTAMP DESC
    ",
    [
      parsedCroneExpression.monthday,
      parsedCroneExpression.datetimePart,
      2592000,
      disable_during_weekend_int,
      disable_during_work_days_int,
      context_id
    ]
  )
else
  error ('@todo u must provide either monthday or weekday not both');




local channels = source.alerting.channels;
local severity = source.alerting.severity;


local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
local silence_labels = std.join("::", envs);

{
  "uid": std.md5(std.format("availability:Schedule:%s%s", [context_id, ingestion_schedule_utc])),
  "title": std.format("Availability(Schedule): %s ────  %s ────️  %s (%s)", [source.project_name, source.dataset_name, source.landing_zone, ingestion_schedule_utc]),
  "condition": "B",  // Set "B" as the alert condition
  "data": [
    {
      "refId": "A",
      "datasourceUid": "AzureSQLServer",
      "relativeTimeRange": { "from": 1800, "to": 0 },
      "model": {
        "format": "table",
        "hide": false,
        "intervalMs": 1000,
        "maxDataPoints": 43200,
        "rawQuery": true,
        "rawSql": rawSql,
      }
    },
    {
      refId: "B",
      datasourceUid: "__expr__",  // Use the "__expr__" datasource for Grafana expressions
      model: {
        type: "classic_conditions",  // Use classic conditions for threshold evaluation
        conditions: [
          {
            evaluator: { params: [0], type: "gt" },  // Adjust `threshold` as needed
            operator: { type: "and" },
            query: { params: ["A", "5m", "now"] },  // Reference "A" over a time range
            reducer: { type: "last" },  // Use the last value for evaluation, adjust as needed
          }
        ],
        refId: "B",
      }
    }
  ],
  "noDataState": "Alerting",
  "for": "60s",
  "annotations": {
    "__dashboardUid__": std.md5(title),
    "__panelId__": 23,
  },
  "labels": {
    "project_name": source.project_name,
    "dataset_name": source.dataset_name,
    "landing_zone": source.landing_zone,
    "alert_type": "Availability(Schedule)",
    "severity": severity,
    "sla" : secondsToReadableFormat(source.ttl),
    "ingestion_schedule_utc": ingestion_schedule_utc,
    "ingestion_schedule_allowed_delta": secondsToReadableFormat(ingestion_schedule_allowed_delta),
    "disable_during_weekend": disable_during_weekend,
    "disable_during_work_days": disable_during_work_days,
    "env": silence_labels,
    "dashboard_title": title,
    "channels": std.join("::", channels),
  }
};


local convertToGrafanaAlertTTL(source, title) =
local context_id = std.format('%s_%s_%s', [source.project_name, source.dataset_name, source.landing_zone]);
local time_to_live = source.alerting.time_to_live;


local disable_during_weekend = if std.objectHas(source.alerting, 'disable_during_weekend') then source.alerting.disable_during_weekend else false;
local disable_during_work_days = if std.objectHas(source.alerting, 'disable_during_work_days') then source.alerting.disable_during_work_days else false;

// Convert boolean values to integers for SQL Server compatibility
local disable_during_weekend_bool = if disable_during_weekend then 1 else 0;
local disable_during_work_days_bool = if disable_during_work_days then 1 else 0;

local rawSql = std.format("
      SELECT TOP 1
          CASE
              WHEN (DATEPART(dw, GETUTCDATE()) IN (1, 7) AND (%d = 1)) OR
                   (DATEPART(dw, GETUTCDATE()) NOT IN (1, 7) AND (%d = 1) )
              THEN 0
              ELSE DATEDIFF(SECOND, '19700101', GETUTCDATE()) - TIMESTAMP
          END AS result
      FROM observability.event
      WHERE context_id = '%s' AND metric_name = 'processing_exit_code' AND metric_value = 0
      ORDER BY TIMESTAMP DESC
  ", [disable_during_weekend_bool, disable_during_work_days_bool, context_id]);

local channels = source.alerting.channels;
local severity = source.alerting.severity;


local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
local silence_labels = std.join("::", envs);

{
  "uid": std.md5(std.format("availability::%s%s", [context_id, time_to_live])),
  "title": std.format("Availability(TTL): %s ────  %s ────️  %s ( %s)", [source.project_name, source.dataset_name, source.landing_zone, secondsToReadableFormat(time_to_live)]),
  "condition": "B",  // Set "B" as the alert condition
  "data": [
    {
      "refId": "A",
      "datasourceUid": "AzureSQLServer",
      "relativeTimeRange": { "from": 1800, "to": 0 },
      "model": {
        "format": "table",
        "hide": false,
        "intervalMs": 1000,
        "maxDataPoints": 43200,
        "rawQuery": true,
        "rawSql": rawSql,
      }
    },
    {
      refId: "B",
      datasourceUid: "__expr__",  // Use the "__expr__" datasource for Grafana expressions
      model: {
        type: "classic_conditions",  // Use classic conditions for threshold evaluation
        conditions: [
          {
            evaluator: { params: [time_to_live], type: "gt" },  // Adjust `threshold` as needed
            operator: { type: "and" },
            query: { params: ["A", "5m", "now"] },  // Reference "A" over a time range
            reducer: { type: "last" },  // Use the last value for evaluation, adjust as needed
          }
        ],
        refId: "B",
      }
    }
  ],
  "noDataState": "Alerting",
  "for": "60s",
  "annotations": {
    "__dashboardUid__": std.md5(title),
    "__panelId__": 23,
  },
  "labels": {
    "project_name": source.project_name,
    "dataset_name": source.dataset_name,
    "landing_zone": source.landing_zone,
    "disable_during_weekend": disable_during_weekend,
    "disable_during_work_days": disable_during_work_days,
    "alert_type": "Availability(TTL)",
    "severity": severity,
    "time_to_live": secondsToReadableFormat(time_to_live),
    "env": silence_labels,
    "dashboard_title": title,
    "channels": std.join("::", channels),
  }
};


local input_json = std.parseYaml(std.extVar("input"));

local dashboard_title = input_json.title;
local filtred_sources = filterSourceWithAlerting(input_json.sources);
local flat_sources = flatSources(filtred_sources);

local availability_alerts_ttl = filterAvailabilityAlertTTL(flat_sources);
local availability_alerts_ttl_json = [convertToGrafanaAlertTTL(source, dashboard_title) for source in availability_alerts_ttl];


local availability_alerts_schedule = filterAvailabilityAlertSchedule(flat_sources);
local availability_alerts_schedule_json = [convertToGrafanaAlertSchedule(source, dashboard_title) for source in availability_alerts_schedule];


local generatePolicies(sources, defaultReceiver='') =
  // Extract all channels from all sources
  local allChannels = [channel for source in sources for channel in source.alerting.channels];
  // Remove duplicates to get unique channels
  local uniqueChannels = std.set(allChannels);

  // Check if there are any unique channels
  if std.length(uniqueChannels) == 0 then
    []
  else
    // Construct the routes array for all unique channels
    local routes = [
      {
        receiver: if std.length(channel) > 0 then channel else defaultReceiver,
        object_matchers: [['channels', '=~', '.*' + channel + '.*']],
      }
      for channel in uniqueChannels
    ];
    // Create a single policy with all routes
    [
      {
        orgId: 1,
        receiver: uniqueChannels[0], // Use the specified default receiver
        routes: routes,
      }
    ];



{
  "apiVersion": 1,
  "groups": [
    {
      "orgId": 1,
      "name": "Availability "+ input_json.title,
      "folder": "Observability Monitoring",
      "interval": "1h",
        rules: availability_alerts_ttl_json + availability_alerts_schedule_json,
    }
  ],
//  "policies": generatePolicies(availability_alerts)
}
