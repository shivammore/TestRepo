local grafana = import 'grafonnet/grafana.libsonnet';

local filterSourceWithAlerting(sources) = [
  source for source in sources if std.objectHas(source, 'alerting')
   && source.alerting != null
];



local filterFreshnessAlert(sources) = [
  source for source in sources if source.alerting != null
  && source.alerting.type == 'freshness'
  && std.objectHas(source.alerting, 'acceptable_freshness_delay')
];


local secondsToReadableFormat(seconds) =
  local secPerMinute = 60;
  local secPerHour = secPerMinute * 60;
  local secPerDay = secPerHour * 24;
  local secPerWeek = secPerDay * 7;
  local secPerMonth = secPerDay * 30; // Approximation
  local secPerYear = secPerDay * 365; // Approximation

  // Calculate each time component
  local years = (seconds / secPerYear);
  local months = (seconds % secPerYear) / secPerMonth;
  local weeks = (seconds % secPerMonth) / secPerWeek;
  local days = (seconds % secPerWeek) / secPerDay;
  local hours = (seconds % secPerDay) / secPerHour;
  local minutes = (seconds % secPerHour) / secPerMinute;
  local secs = seconds % secPerMinute;

  // Format the output string
  local result = [
    if years >= 1 then std.floor(years) + "y " else "",
    if months >= 1 && years < 1 then std.floor(months) + "mo " else "",
    if weeks >= 1 && months < 1 then std.floor(weeks) + "w " else "",
    if days >= 1 && weeks < 1 then std.floor(days) + "d " else "",
    if hours >= 1 && days < 1 then std.floor(hours) + "h " else "",
    if minutes >= 1 && hours < 1 then std.floor(minutes) + "m " else "",
    if secs >= 1 && minutes < 1 then secs + "s" else "",
  ];

  std.join("", result);


local ensureFields(sources) = [
    {
        publisher_name: std.get(s, 'publisher_name'),
        project_name: std.get(s, 'project_name'),
        dataset_name: std.get(s, 'dataset_name'),
        landing_zone: std.get(s, 'landing_zone'),
        alerting: std.get(s, 'alerting'),
    }
    for s in sources
];

local flatSources(objs) = [
  {
    publisher_name: if std.type(obj.publisher_name) == "string" then obj.publisher_name else p,
    project_name: if std.type(obj.project_name) == "string" then obj.project_name else pr,
    dataset_name: if std.type(obj.dataset_name) == "string" then obj.dataset_name else d,
    landing_zone: if std.type(obj.landing_zone) == "string" then obj.landing_zone else l,
    ttl: if std.type(obj.ttl) == "string" then obj.ttl else t,
    alerting: if std.type(obj.alerting) == "string" then obj.alerting else alerting,
  }
  for obj in objs
  for p in if std.type(obj.publisher_name) == "array" then obj.publisher_name else [obj.publisher_name]
  for pr in if std.type(obj.project_name) == "array" then obj.project_name else [obj.project_name]
  for d in if std.type(obj.dataset_name) == "array" then obj.dataset_name else [obj.dataset_name]
  for l in if std.type(obj.landing_zone) == "array" then obj.landing_zone else [obj.landing_zone]
  for t in if std.type(obj.ttl) == "array" then obj.ttl else [obj.ttl]
  for alerting in if std.type(obj.alerting) == "array" then obj.alerting else [obj.alerting]
];



local convertToGrafanaAlertFreshness(source, title) =
local context_id = std.format('%s_%s_%s', [source.project_name, source.dataset_name, source.landing_zone]);
local acceptable_freshness_delay = source.alerting.acceptable_freshness_delay;
local severity = source.alerting.severity;
local channels = source.alerting.channels;

local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
local silence_labels = std.join("::", envs);

{
  "uid": std.md5(std.format("freshness::%s%s", [context_id, acceptable_freshness_delay])),
  "title": std.format("Freshness: %s ────  %s ────️  %s (%s)", [source.project_name, source.dataset_name, source.landing_zone, secondsToReadableFormat(acceptable_freshness_delay)]),
  "condition": "B",  // Set "B" as the alert condition
  "data": [
    {
      "refId": "A",
      "datasourceUid": "AzureSQLServer",
      "relativeTimeRange": { "from": 1800, "to": 0 },
      "model": {
        "format": "table",
        "hide": false,
        "intervalMs": 1000,
        "maxDataPoints": 43200,
        "rawQuery": true,
        "rawSql": std.format("
                SELECT TOP  1 timestamp - metric_value from observability.event
                WHERE context_id = '%s'  AND metric_name = 'content_latest_date'
                ORDER BY TIMESTAMP DESC;\n", [context_id ]),
      }
    },
    {
      refId: "B",
      datasourceUid: "__expr__",  // Use the "__expr__" datasource for Grafana expressions
      model: {
        type: "classic_conditions",  // Use classic conditions for threshold evaluation
        conditions: [
          {
            evaluator: { params: [acceptable_freshness_delay], type: "gt" },  // Adjust `threshold` as needed
            operator: { type: "and" },
            query: { params: ["A", "5m", "now"] },  // Reference "A" over a time range
            reducer: { type: "last" },  // Use the last value for evaluation, adjust as needed
          }
        ],
        refId: "B",
      }
    }
  ],
  "noDataState": "Alerting",
  "for": "60s",
  "annotations": {
    "__dashboardUid__": std.md5(title),
    "__panelId__": 23,
  },
  "labels": {
    "project_name": source.project_name,
    "dataset_name": source.dataset_name,
    "landing_zone": source.landing_zone,
    "severity": severity,
    "sla" : secondsToReadableFormat(source.ttl),
    "alert_type": "Freshness",
    "acceptable_freshness_delay": secondsToReadableFormat(acceptable_freshness_delay),
    "env": silence_labels,
    "dashboard_title": title,
    "channels": std.join("::", channels),
  }
};


local input_json = std.parseYaml(std.extVar("input"));
local dashboard_title = input_json.title;
local filtred_sources = filterSourceWithAlerting(input_json.sources);
local flat_sources = flatSources(filtred_sources);
local freshness_alerts = filterFreshnessAlert(flat_sources);
local freshness_alerts_grafana = [convertToGrafanaAlertFreshness(source, dashboard_title) for source in freshness_alerts];

local generatePolicies(sources) =
  // Extract all channels from all sources
  local allChannels = [channel for source in sources for channel in source.alerting.channels];
  // Remove duplicates to get unique channels
  local uniqueChannels = std.set(allChannels);
  // Generate a policy for each unique channel
  [
    {
      orgId: 1,
      receiver: channel,
      routes: [
        {
          receiver: channel,
          // Adjust object matchers as needed; this example uses regex for flexible matching
          object_matchers: [['channels', '=~', '.*' + channel + '.*']],
        },
      ],
    }
    for channel in uniqueChannels
  ];


{
  "apiVersion": 1,
  "groups": [
    {
      "orgId": 1,
      "name": "Freshness "+ input_json.title,
      "folder": "Observability Monitoring",
      "interval": "1h",
        rules: freshness_alerts_grafana,
    }
  ],
//  "policies": generatePolicies(availability_alerts)
}
