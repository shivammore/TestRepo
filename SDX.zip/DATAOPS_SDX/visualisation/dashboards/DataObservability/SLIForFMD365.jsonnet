local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local stat = grafana.statPanel;
local table = grafana.tablePanel;
local slo = 80;

//global filters
local projectTemplate =  tmpl.custom(
    name='project_name',
    current='all',
    query='oss.apac.glb.d365,oss.coe.glb.d365,oss.noram.glb.d365',
    includeAll=true,
    multi=true,
    label="Application Source"
);

local datasetTemplate = tmpl.custom(
    name='dataset_name',
    query= 'account,activitypointer,adx_portalcomment,annotation,bookableresource,bookableresourcebooking,bookableresourcecategory,contact,contract,entitlement,ifm_assettype,ifm_contract,ifm_country,ifm_feedback,ifm_log,ifm_masterservicecategory,ifm_servicecategory,ifm_workordernote,incident,incidentresolution,msdyn_agreement,msdyn_customerasset,msdyn_expense,msdyn_priority,msdyn_project,msdyn_projectapproval,msdyn_projecttask,msdyn_resourcerequirement,msdyn_survey,msdyn_timeentry,msdyn_workorder,msdyn_workordertype,pricelevel,queue,quote,role,sdxmob_facility,sla,slaitem,slakpiinstance,systemuser,timezonedefinition,timezonerule,transactioncurrency',
    current='all',
    includeAll=true,
    multi=true,
    label='Dataset Name'
);

local stageTemplate =  tmpl.custom(
    name='landing_zone',
    current='all',
    query='Bronze,Silver',
    includeAll=true,
    multi=true,
    label="Zone"
);

local statusTemplate =  tmpl.custom(
    name='status',
    current='all',
    query='Succeeded,Failed,No New Data,Running,Skipped',
    includeAll=true,
    multi=true,
    label="Ingestion Status"
);

local HidedContext =
    grafana.template.new(
    name='context',
    datasource='IFM Azure SQL Server',
    query="
        SELECT distinct(context_id)
        FROM [observability].[event]
        WHERE
    dataset_name IN ($dataset_name)
    AND landing_zone IN ($landing_zone)
    AND project_name IN ($project_name)
        ",
    current='all',
    refresh='load',
    hide = true,
    includeAll=true,
    multi=false,
    label='context'
);

//panels
local generatePanelCount =
  stat.new(
    title='Total Datasets',
    datasource='IFM Azure SQL Server',
    description="Total Datasets Name"
  )
  // Use the length of the sources list as the value to display
  .addTarget(
    target=grafana.sql.target(
      rawSql="with cte as (select '${dataset_name:csv}' as val)
	              select (LEN(val) - LEN(REPLACE(val, ',', ''))) + 1 from cte;",
      format='table'
    )
);

local SLOPanel = stat.new(
    title='SLO',
    datasource='IFM Azure SQL Server',
    description="This is a benchmark defined by the proprietors or stakeholders of a data ingestion pipeline.
    It signifies the anticipated and aspired level of efficiency, reliability, and quality for data ingestion processes.
    Such a goal provides a tangible metric against which the actual performance of the data ingestion can be evaluated,ensuring that the pipeline operates in alignment with stakeholder expectations and requirements.")
    .addTarget(target=grafana.sql.target(rawSql= "SELECT 80 AS SLO", format='table'))
    .addOverridesByFieldName(field='SLO',properties=[{id: 'unit', value: 'percent'}]
);

local generateSLIPanel =
    local SLISqlQuery = "         
                 
        WITH
            CombinedValues AS (
                SELECT *
                FROM (VALUES ('oss.apac.glb.d365', 'account', 'silver', 'oss.apac.glb.d365_account_silver', 86400),
                ('oss.apac.glb.d365', 'account', 'bronze', 'oss.apac.glb.d365_account_bronze', 86400),
                ('oss.apac.glb.d365', 'activitypointer', 'silver', 'oss.apac.glb.d365_activitypointer_silver', 86400),
                ('oss.apac.glb.d365', 'activitypointer', 'bronze', 'oss.apac.glb.d365_activitypointer_bronze', 86400),
                ('oss.apac.glb.d365', 'adx_portalcomment', 'silver', 'oss.apac.glb.d365_adx_portalcomment_silver', 86400),
                ('oss.apac.glb.d365', 'adx_portalcomment', 'bronze', 'oss.apac.glb.d365_adx_portalcomment_bronze', 86400),
                ('oss.apac.glb.d365', 'annotation', 'silver', 'oss.apac.glb.d365_annotation_silver', 86400), 
                ('oss.apac.glb.d365', 'annotation', 'bronze', 'oss.apac.glb.d365_annotation_bronze', 86400), 
                ('oss.apac.glb.d365', 'bookableresource', 'silver', 'oss.apac.glb.d365_bookableresource_silver', 86400), 
                ('oss.apac.glb.d365', 'bookableresource', 'bronze', 'oss.apac.glb.d365_bookableresource_bronze', 86400), 
                ('oss.apac.glb.d365', 'bookableresourcebooking', 'silver', 'oss.apac.glb.d365_bookableresourcebooking_silver', 86400), 
                ('oss.apac.glb.d365', 'bookableresourcebooking', 'bronze', 'oss.apac.glb.d365_bookableresourcebooking_bronze', 86400), 
                ('oss.apac.glb.d365', 'bookableresourcecategory', 'silver', 'oss.apac.glb.d365_bookableresourcecategory_silver', 86400), 
                ('oss.apac.glb.d365', 'bookableresourcecategory', 'bronze', 'oss.apac.glb.d365_bookableresourcecategory_bronze', 86400), 
                ('oss.apac.glb.d365', 'contact', 'silver', 'oss.apac.glb.d365_contact_silver', 86400), 
                ('oss.apac.glb.d365', 'contact', 'bronze', 'oss.apac.glb.d365_contact_bronze', 86400),
                ('oss.apac.glb.d365', 'contract', 'silver', 'oss.apac.glb.d365_contract_silver', 86400),
                ('oss.apac.glb.d365', 'contract', 'bronze', 'oss.apac.glb.d365_contract_bronze', 86400), 
                ('oss.apac.glb.d365', 'entitlement', 'silver', 'oss.apac.glb.d365_entitlement_silver', 86400), 
                ('oss.apac.glb.d365', 'entitlement', 'bronze', 'oss.apac.glb.d365_entitlement_bronze', 86400),
                ('oss.apac.glb.d365', 'ifm_assettype', 'silver', 'oss.apac.glb.d365_ifm_assettype_silver', 86400), 
                ('oss.apac.glb.d365', 'ifm_assettype', 'bronze', 'oss.apac.glb.d365_ifm_assettype_bronze', 86400), 
                ('oss.apac.glb.d365', 'ifm_contract', 'silver', 'oss.apac.glb.d365_ifm_contract_silver', 86400),
                ('oss.apac.glb.d365', 'ifm_contract', 'bronze', 'oss.apac.glb.d365_ifm_contract_bronze', 86400), 
                ('oss.apac.glb.d365', 'ifm_country', 'silver', 'oss.apac.glb.d365_ifm_country_silver', 86400), 
                ('oss.apac.glb.d365', 'ifm_country', 'bronze', 'oss.apac.glb.d365_ifm_country_bronze', 86400),
                ('oss.apac.glb.d365', 'ifm_feedback', 'silver', 'oss.apac.glb.d365_ifm_feedback_silver', 86400), 
                ('oss.apac.glb.d365', 'ifm_feedback', 'bronze', 'oss.apac.glb.d365_ifm_feedback_bronze', 86400), 
                ('oss.apac.glb.d365', 'ifm_log', 'silver', 'oss.apac.glb.d365_ifm_log_silver', 86400), 
                ('oss.apac.glb.d365', 'ifm_log', 'bronze', 'oss.apac.glb.d365_ifm_log_bronze', 86400), 
                ('oss.apac.glb.d365', 'ifm_masterservicecategory', 'silver', 'oss.apac.glb.d365_ifm_masterservicecategory_silver', 86400), 
                ('oss.apac.glb.d365', 'ifm_masterservicecategory', 'bronze', 'oss.apac.glb.d365_ifm_masterservicecategory_bronze', 86400), 
                ('oss.apac.glb.d365', 'ifm_servicecategory', 'silver', 'oss.apac.glb.d365_ifm_servicecategory_silver', 86400), 
                ('oss.apac.glb.d365', 'ifm_servicecategory', 'bronze', 'oss.apac.glb.d365_ifm_servicecategory_bronze', 86400), 
                ('oss.apac.glb.d365', 'ifm_workordernote', 'silver', 'oss.apac.glb.d365_ifm_workordernote_silver', 86400), 
                ('oss.apac.glb.d365', 'ifm_workordernote', 'bronze', 'oss.apac.glb.d365_ifm_workordernote_bronze', 86400), 
                ('oss.apac.glb.d365', 'incident', 'silver', 'oss.apac.glb.d365_incident_silver', 86400), 
                ('oss.apac.glb.d365', 'incident', 'bronze', 'oss.apac.glb.d365_incident_bronze', 86400),
                ('oss.apac.glb.d365', 'incidentresolution', 'silver', 'oss.apac.glb.d365_incidentresolution_silver', 86400), 
                ('oss.apac.glb.d365', 'incidentresolution', 'bronze', 'oss.apac.glb.d365_incidentresolution_bronze', 86400), 
                ('oss.apac.glb.d365', 'msdyn_agreement', 'silver', 'oss.apac.glb.d365_msdyn_agreement_silver', 86400),
                ('oss.apac.glb.d365', 'msdyn_agreement', 'bronze', 'oss.apac.glb.d365_msdyn_agreement_bronze', 86400), 
                ('oss.apac.glb.d365', 'msdyn_customerasset', 'silver', 'oss.apac.glb.d365_msdyn_customerasset_silver', 86400), 
                ('oss.apac.glb.d365', 'msdyn_customerasset', 'bronze', 'oss.apac.glb.d365_msdyn_customerasset_bronze', 86400), 
                ('oss.apac.glb.d365', 'msdyn_expense', 'silver', 'oss.apac.glb.d365_msdyn_expense_silver', 86400),
                ('oss.apac.glb.d365', 'msdyn_expense', 'bronze', 'oss.apac.glb.d365_msdyn_expense_bronze', 86400),
                ('oss.apac.glb.d365', 'msdyn_priority', 'silver', 'oss.apac.glb.d365_msdyn_priority_silver', 86400),
                ('oss.apac.glb.d365', 'msdyn_priority', 'bronze', 'oss.apac.glb.d365_msdyn_priority_bronze', 86400), 
                ('oss.apac.glb.d365', 'msdyn_project', 'silver', 'oss.apac.glb.d365_msdyn_project_silver', 86400),
                ('oss.apac.glb.d365', 'msdyn_project', 'bronze', 'oss.apac.glb.d365_msdyn_project_bronze', 86400), 
                ('oss.apac.glb.d365', 'msdyn_projectapproval', 'silver', 'oss.apac.glb.d365_msdyn_projectapproval_silver', 86400),
                ('oss.apac.glb.d365', 'msdyn_projectapproval', 'bronze', 'oss.apac.glb.d365_msdyn_projectapproval_bronze', 86400), 
                ('oss.apac.glb.d365', 'msdyn_projecttask', 'silver', 'oss.apac.glb.d365_msdyn_projecttask_silver', 86400),
                ('oss.apac.glb.d365', 'msdyn_projecttask', 'bronze', 'oss.apac.glb.d365_msdyn_projecttask_bronze', 86400), 
                ('oss.apac.glb.d365', 'msdyn_resourcerequirement', 'silver', 'oss.apac.glb.d365_msdyn_resourcerequirement_silver', 86400), 
                ('oss.apac.glb.d365', 'msdyn_resourcerequirement', 'bronze', 'oss.apac.glb.d365_msdyn_resourcerequirement_bronze', 86400), 
                ('oss.apac.glb.d365', 'msdyn_survey', 'silver', 'oss.apac.glb.d365_msdyn_survey_silver', 86400), 
                ('oss.apac.glb.d365', 'msdyn_survey', 'bronze', 'oss.apac.glb.d365_msdyn_survey_bronze', 86400), 
                ('oss.apac.glb.d365', 'msdyn_timeentry', 'silver', 'oss.apac.glb.d365_msdyn_timeentry_silver', 86400),
                ('oss.apac.glb.d365', 'msdyn_timeentry', 'bronze', 'oss.apac.glb.d365_msdyn_timeentry_bronze', 86400),
                ('oss.apac.glb.d365', 'msdyn_workorder', 'silver', 'oss.apac.glb.d365_msdyn_workorder_silver', 86400), 
                ('oss.apac.glb.d365', 'msdyn_workorder', 'bronze', 'oss.apac.glb.d365_msdyn_workorder_bronze', 86400), 
                ('oss.apac.glb.d365', 'msdyn_workordertype', 'silver', 'oss.apac.glb.d365_msdyn_workordertype_silver', 86400),
                ('oss.apac.glb.d365', 'msdyn_workordertype', 'bronze', 'oss.apac.glb.d365_msdyn_workordertype_bronze', 86400), 
                ('oss.apac.glb.d365', 'pricelevel', 'silver', 'oss.apac.glb.d365_pricelevel_silver', 86400), 
                ('oss.apac.glb.d365', 'pricelevel', 'bronze', 'oss.apac.glb.d365_pricelevel_bronze', 86400), 
                ('oss.apac.glb.d365', 'queue', 'silver', 'oss.apac.glb.d365_queue_silver', 86400), 
                ('oss.apac.glb.d365', 'queue', 'bronze', 'oss.apac.glb.d365_queue_bronze', 86400), 
                ('oss.apac.glb.d365', 'quote', 'silver', 'oss.apac.glb.d365_quote_silver', 86400), 
                ('oss.apac.glb.d365', 'quote', 'bronze', 'oss.apac.glb.d365_quote_bronze', 86400),
                ('oss.apac.glb.d365', 'role', 'silver', 'oss.apac.glb.d365_role_silver', 86400), 
                ('oss.apac.glb.d365', 'role', 'bronze', 'oss.apac.glb.d365_role_bronze', 86400), 
                ('oss.apac.glb.d365', 'sdxmob_facility', 'silver', 'oss.apac.glb.d365_sdxmob_facility_silver', 86400), 
                ('oss.apac.glb.d365', 'sdxmob_facility', 'bronze', 'oss.apac.glb.d365_sdxmob_facility_bronze', 86400), 
                ('oss.apac.glb.d365', 'sla', 'silver', 'oss.apac.glb.d365_sla_silver', 86400), 
                ('oss.apac.glb.d365', 'sla', 'bronze', 'oss.apac.glb.d365_sla_bronze', 86400), 
                ('oss.apac.glb.d365', 'slaitem', 'silver', 'oss.apac.glb.d365_slaitem_silver', 86400), 
                ('oss.apac.glb.d365', 'slaitem', 'bronze', 'oss.apac.glb.d365_slaitem_bronze', 86400), 
                ('oss.apac.glb.d365', 'slakpiinstance', 'silver', 'oss.apac.glb.d365_slakpiinstance_silver', 86400), 
                ('oss.apac.glb.d365', 'slakpiinstance', 'bronze', 'oss.apac.glb.d365_slakpiinstance_bronze', 86400), 
                ('oss.apac.glb.d365', 'systemuser', 'silver', 'oss.apac.glb.d365_systemuser_silver', 86400), 
                ('oss.apac.glb.d365', 'systemuser', 'bronze', 'oss.apac.glb.d365_systemuser_bronze', 86400), 
                ('oss.apac.glb.d365', 'timezonedefinition', 'silver', 'oss.apac.glb.d365_timezonedefinition_silver', 86400), 
                ('oss.apac.glb.d365', 'timezonedefinition', 'bronze', 'oss.apac.glb.d365_timezonedefinition_bronze', 86400), 
                ('oss.apac.glb.d365', 'timezonerule', 'silver', 'oss.apac.glb.d365_timezonerule_silver', 86400), 
                ('oss.apac.glb.d365', 'timezonerule', 'bronze', 'oss.apac.glb.d365_timezonerule_bronze', 86400), 
                ('oss.apac.glb.d365', 'transactioncurrency', 'silver', 'oss.apac.glb.d365_transactioncurrency_silver', 86400), 
                ('oss.apac.glb.d365', 'transactioncurrency', 'bronze', 'oss.apac.glb.d365_transactioncurrency_bronze', 86400),
                ('oss.coe.glb.d365', 'account', 'silver', 'oss.coe.glb.d365_account_silver', 86400),
                ('oss.coe.glb.d365', 'account', 'bronze', 'oss.coe.glb.d365_account_bronze', 86400),
                ('oss.coe.glb.d365', 'activitypointer', 'silver', 'oss.coe.glb.d365_activitypointer_silver', 86400),
                ('oss.coe.glb.d365', 'activitypointer', 'bronze', 'oss.coe.glb.d365_activitypointer_bronze', 86400),
                ('oss.coe.glb.d365', 'adx_portalcomment', 'silver', 'oss.coe.glb.d365_adx_portalcomment_silver', 86400),
                ('oss.coe.glb.d365', 'adx_portalcomment', 'bronze', 'oss.coe.glb.d365_adx_portalcomment_bronze', 86400),
                ('oss.coe.glb.d365', 'annotation', 'silver', 'oss.coe.glb.d365_annotation_silver', 86400), 
                ('oss.coe.glb.d365', 'annotation', 'bronze', 'oss.coe.glb.d365_annotation_bronze', 86400), 
                ('oss.coe.glb.d365', 'bookableresource', 'silver', 'oss.coe.glb.d365_bookableresource_silver', 86400), 
                ('oss.coe.glb.d365', 'bookableresource', 'bronze', 'oss.coe.glb.d365_bookableresource_bronze', 86400), 
                ('oss.coe.glb.d365', 'bookableresourcebooking', 'silver', 'oss.coe.glb.d365_bookableresourcebooking_silver', 86400), 
                ('oss.coe.glb.d365', 'bookableresourcebooking', 'bronze', 'oss.coe.glb.d365_bookableresourcebooking_bronze', 86400), 
                ('oss.coe.glb.d365', 'bookableresourcecategory', 'silver', 'oss.coe.glb.d365_bookableresourcecategory_silver', 86400), 
                ('oss.coe.glb.d365', 'bookableresourcecategory', 'bronze', 'oss.coe.glb.d365_bookableresourcecategory_bronze', 86400), 
                ('oss.coe.glb.d365', 'contact', 'silver', 'oss.coe.glb.d365_contact_silver', 86400), 
                ('oss.coe.glb.d365', 'contact', 'bronze', 'oss.coe.glb.d365_contact_bronze', 86400),
                ('oss.coe.glb.d365', 'contract', 'silver', 'oss.coe.glb.d365_contract_silver', 86400),
                ('oss.coe.glb.d365', 'contract', 'bronze', 'oss.coe.glb.d365_contract_bronze', 86400), 
                ('oss.coe.glb.d365', 'entitlement', 'silver', 'oss.coe.glb.d365_entitlement_silver', 86400), 
                ('oss.coe.glb.d365', 'entitlement', 'bronze', 'oss.coe.glb.d365_entitlement_bronze', 86400),
                ('oss.coe.glb.d365', 'ifm_assettype', 'silver', 'oss.coe.glb.d365_ifm_assettype_silver', 86400), 
                ('oss.coe.glb.d365', 'ifm_assettype', 'bronze', 'oss.coe.glb.d365_ifm_assettype_bronze', 86400), 
                ('oss.coe.glb.d365', 'ifm_contract', 'silver', 'oss.coe.glb.d365_ifm_contract_silver', 86400),
                ('oss.coe.glb.d365', 'ifm_contract', 'bronze', 'oss.coe.glb.d365_ifm_contract_bronze', 86400), 
                ('oss.coe.glb.d365', 'ifm_country', 'silver', 'oss.coe.glb.d365_ifm_country_silver', 86400), 
                ('oss.coe.glb.d365', 'ifm_country', 'bronze', 'oss.coe.glb.d365_ifm_country_bronze', 86400),
                ('oss.coe.glb.d365', 'ifm_feedback', 'silver', 'oss.coe.glb.d365_ifm_feedback_silver', 86400), 
                ('oss.coe.glb.d365', 'ifm_feedback', 'bronze', 'oss.coe.glb.d365_ifm_feedback_bronze', 86400), 
                ('oss.coe.glb.d365', 'ifm_log', 'silver', 'oss.coe.glb.d365_ifm_log_silver', 86400), 
                ('oss.coe.glb.d365', 'ifm_log', 'bronze', 'oss.coe.glb.d365_ifm_log_bronze', 86400), 
                ('oss.coe.glb.d365', 'ifm_masterservicecategory', 'silver', 'oss.coe.glb.d365_ifm_masterservicecategory_silver', 86400), 
                ('oss.coe.glb.d365', 'ifm_masterservicecategory', 'bronze', 'oss.coe.glb.d365_ifm_masterservicecategory_bronze', 86400), 
                ('oss.coe.glb.d365', 'ifm_servicecategory', 'silver', 'oss.coe.glb.d365_ifm_servicecategory_silver', 86400), 
                ('oss.coe.glb.d365', 'ifm_servicecategory', 'bronze', 'oss.coe.glb.d365_ifm_servicecategory_bronze', 86400), 
                ('oss.coe.glb.d365', 'ifm_workordernote', 'silver', 'oss.coe.glb.d365_ifm_workordernote_silver', 86400), 
                ('oss.coe.glb.d365', 'ifm_workordernote', 'bronze', 'oss.coe.glb.d365_ifm_workordernote_bronze', 86400), 
                ('oss.coe.glb.d365', 'incident', 'silver', 'oss.coe.glb.d365_incident_silver', 86400), 
                ('oss.coe.glb.d365', 'incident', 'bronze', 'oss.coe.glb.d365_incident_bronze', 86400),
                ('oss.coe.glb.d365', 'incidentresolution', 'silver', 'oss.coe.glb.d365_incidentresolution_silver', 86400), 
                ('oss.coe.glb.d365', 'incidentresolution', 'bronze', 'oss.coe.glb.d365_incidentresolution_bronze', 86400), 
                ('oss.coe.glb.d365', 'msdyn_agreement', 'silver', 'oss.coe.glb.d365_msdyn_agreement_silver', 86400),
                ('oss.coe.glb.d365', 'msdyn_agreement', 'bronze', 'oss.coe.glb.d365_msdyn_agreement_bronze', 86400), 
                ('oss.coe.glb.d365', 'msdyn_customerasset', 'silver', 'oss.coe.glb.d365_msdyn_customerasset_silver', 86400), 
                ('oss.coe.glb.d365', 'msdyn_customerasset', 'bronze', 'oss.coe.glb.d365_msdyn_customerasset_bronze', 86400), 
                ('oss.coe.glb.d365', 'msdyn_expense', 'silver', 'oss.coe.glb.d365_msdyn_expense_silver', 86400),
                ('oss.coe.glb.d365', 'msdyn_expense', 'bronze', 'oss.coe.glb.d365_msdyn_expense_bronze', 86400),
                ('oss.coe.glb.d365', 'msdyn_priority', 'silver', 'oss.coe.glb.d365_msdyn_priority_silver', 86400),
                ('oss.coe.glb.d365', 'msdyn_priority', 'bronze', 'oss.coe.glb.d365_msdyn_priority_bronze', 86400), 
                ('oss.coe.glb.d365', 'msdyn_project', 'silver', 'oss.coe.glb.d365_msdyn_project_silver', 86400),
                ('oss.coe.glb.d365', 'msdyn_project', 'bronze', 'oss.coe.glb.d365_msdyn_project_bronze', 86400), 
                ('oss.coe.glb.d365', 'msdyn_projectapproval', 'silver', 'oss.coe.glb.d365_msdyn_projectapproval_silver', 86400),
                ('oss.coe.glb.d365', 'msdyn_projectapproval', 'bronze', 'oss.coe.glb.d365_msdyn_projectapproval_bronze', 86400), 
                ('oss.coe.glb.d365', 'msdyn_projecttask', 'silver', 'oss.coe.glb.d365_msdyn_projecttask_silver', 86400),
                ('oss.coe.glb.d365', 'msdyn_projecttask', 'bronze', 'oss.coe.glb.d365_msdyn_projecttask_bronze', 86400), 
                ('oss.coe.glb.d365', 'msdyn_resourcerequirement', 'silver', 'oss.coe.glb.d365_msdyn_resourcerequirement_silver', 86400), 
                ('oss.coe.glb.d365', 'msdyn_resourcerequirement', 'bronze', 'oss.coe.glb.d365_msdyn_resourcerequirement_bronze', 86400), 
                ('oss.coe.glb.d365', 'msdyn_survey', 'silver', 'oss.coe.glb.d365_msdyn_survey_silver', 86400), 
                ('oss.coe.glb.d365', 'msdyn_survey', 'bronze', 'oss.coe.glb.d365_msdyn_survey_bronze', 86400), 
                ('oss.coe.glb.d365', 'msdyn_timeentry', 'silver', 'oss.coe.glb.d365_msdyn_timeentry_silver', 86400),
                ('oss.coe.glb.d365', 'msdyn_timeentry', 'bronze', 'oss.coe.glb.d365_msdyn_timeentry_bronze', 86400),
                ('oss.coe.glb.d365', 'msdyn_workorder', 'silver', 'oss.coe.glb.d365_msdyn_workorder_silver', 86400), 
                ('oss.coe.glb.d365', 'msdyn_workorder', 'bronze', 'oss.coe.glb.d365_msdyn_workorder_bronze', 86400), 
                ('oss.coe.glb.d365', 'msdyn_workordertype', 'silver', 'oss.coe.glb.d365_msdyn_workordertype_silver', 86400),
                ('oss.coe.glb.d365', 'msdyn_workordertype', 'bronze', 'oss.coe.glb.d365_msdyn_workordertype_bronze', 86400), 
                ('oss.coe.glb.d365', 'pricelevel', 'silver', 'oss.coe.glb.d365_pricelevel_silver', 86400), 
                ('oss.coe.glb.d365', 'pricelevel', 'bronze', 'oss.coe.glb.d365_pricelevel_bronze', 86400), 
                ('oss.coe.glb.d365', 'queue', 'silver', 'oss.coe.glb.d365_queue_silver', 86400), 
                ('oss.coe.glb.d365', 'queue', 'bronze', 'oss.coe.glb.d365_queue_bronze', 86400), 
                ('oss.coe.glb.d365', 'quote', 'silver', 'oss.coe.glb.d365_quote_silver', 86400), 
                ('oss.coe.glb.d365', 'quote', 'bronze', 'oss.coe.glb.d365_quote_bronze', 86400),
                ('oss.coe.glb.d365', 'role', 'silver', 'oss.coe.glb.d365_role_silver', 86400), 
                ('oss.coe.glb.d365', 'role', 'bronze', 'oss.coe.glb.d365_role_bronze', 86400), 
                ('oss.coe.glb.d365', 'sdxmob_facility', 'silver', 'oss.coe.glb.d365_sdxmob_facility_silver', 86400), 
                ('oss.coe.glb.d365', 'sdxmob_facility', 'bronze', 'oss.coe.glb.d365_sdxmob_facility_bronze', 86400), 
                ('oss.coe.glb.d365', 'sla', 'silver', 'oss.coe.glb.d365_sla_silver', 86400), 
                ('oss.coe.glb.d365', 'sla', 'bronze', 'oss.coe.glb.d365_sla_bronze', 86400), 
                ('oss.coe.glb.d365', 'slaitem', 'silver', 'oss.coe.glb.d365_slaitem_silver', 86400), 
                ('oss.coe.glb.d365', 'slaitem', 'bronze', 'oss.coe.glb.d365_slaitem_bronze', 86400), 
                ('oss.coe.glb.d365', 'slakpiinstance', 'silver', 'oss.coe.glb.d365_slakpiinstance_silver', 86400), 
                ('oss.coe.glb.d365', 'slakpiinstance', 'bronze', 'oss.coe.glb.d365_slakpiinstance_bronze', 86400), 
                ('oss.coe.glb.d365', 'systemuser', 'silver', 'oss.coe.glb.d365_systemuser_silver', 86400), 
                ('oss.coe.glb.d365', 'systemuser', 'bronze', 'oss.coe.glb.d365_systemuser_bronze', 86400), 
                ('oss.coe.glb.d365', 'timezonedefinition', 'silver', 'oss.coe.glb.d365_timezonedefinition_silver', 86400), 
                ('oss.coe.glb.d365', 'timezonedefinition', 'bronze', 'oss.coe.glb.d365_timezonedefinition_bronze', 86400), 
                ('oss.coe.glb.d365', 'timezonerule', 'silver', 'oss.coe.glb.d365_timezonerule_silver', 86400), 
                ('oss.coe.glb.d365', 'timezonerule', 'bronze', 'oss.coe.glb.d365_timezonerule_bronze', 86400), 
                ('oss.coe.glb.d365', 'transactioncurrency', 'silver', 'oss.coe.glb.d365_transactioncurrency_silver', 86400), 
                ('oss.coe.glb.d365', 'transactioncurrency', 'bronze', 'oss.coe.glb.d365_transactioncurrency_bronze', 86400),
                ('oss.noram.glb.d365', 'account', 'silver', 'oss.noram.glb.d365_account_silver', 86400),
                ('oss.noram.glb.d365', 'account', 'bronze', 'oss.noram.glb.d365_account_bronze', 86400),
                ('oss.noram.glb.d365', 'activitypointer', 'silver', 'oss.noram.glb.d365_activitypointer_silver', 86400),
                ('oss.noram.glb.d365', 'activitypointer', 'bronze', 'oss.noram.glb.d365_activitypointer_bronze', 86400),
                ('oss.noram.glb.d365', 'adx_portalcomment', 'silver', 'oss.noram.glb.d365_adx_portalcomment_silver', 86400),
                ('oss.noram.glb.d365', 'adx_portalcomment', 'bronze', 'oss.noram.glb.d365_adx_portalcomment_bronze', 86400),
                ('oss.noram.glb.d365', 'annotation', 'silver', 'oss.noram.glb.d365_annotation_silver', 86400), 
                ('oss.noram.glb.d365', 'annotation', 'bronze', 'oss.noram.glb.d365_annotation_bronze', 86400), 
                ('oss.noram.glb.d365', 'bookableresource', 'silver', 'oss.noram.glb.d365_bookableresource_silver', 86400), 
                ('oss.noram.glb.d365', 'bookableresource', 'bronze', 'oss.noram.glb.d365_bookableresource_bronze', 86400), 
                ('oss.noram.glb.d365', 'bookableresourcebooking', 'silver', 'oss.noram.glb.d365_bookableresourcebooking_silver', 86400), 
                ('oss.noram.glb.d365', 'bookableresourcebooking', 'bronze', 'oss.noram.glb.d365_bookableresourcebooking_bronze', 86400), 
                ('oss.noram.glb.d365', 'bookableresourcecategory', 'silver', 'oss.noram.glb.d365_bookableresourcecategory_silver', 86400), 
                ('oss.noram.glb.d365', 'bookableresourcecategory', 'bronze', 'oss.noram.glb.d365_bookableresourcecategory_bronze', 86400), 
                ('oss.noram.glb.d365', 'contact', 'silver', 'oss.noram.glb.d365_contact_silver', 86400), 
                ('oss.noram.glb.d365', 'contact', 'bronze', 'oss.noram.glb.d365_contact_bronze', 86400),
                ('oss.noram.glb.d365', 'contract', 'silver', 'oss.noram.glb.d365_contract_silver', 86400),
                ('oss.noram.glb.d365', 'contract', 'bronze', 'oss.noram.glb.d365_contract_bronze', 86400), 
                ('oss.noram.glb.d365', 'entitlement', 'silver', 'oss.noram.glb.d365_entitlement_silver', 86400), 
                ('oss.noram.glb.d365', 'entitlement', 'bronze', 'oss.noram.glb.d365_entitlement_bronze', 86400),
                ('oss.noram.glb.d365', 'ifm_assettype', 'silver', 'oss.noram.glb.d365_ifm_assettype_silver', 86400), 
                ('oss.noram.glb.d365', 'ifm_assettype', 'bronze', 'oss.noram.glb.d365_ifm_assettype_bronze', 86400), 
                ('oss.noram.glb.d365', 'ifm_contract', 'silver', 'oss.noram.glb.d365_ifm_contract_silver', 86400),
                ('oss.noram.glb.d365', 'ifm_contract', 'bronze', 'oss.noram.glb.d365_ifm_contract_bronze', 86400), 
                ('oss.noram.glb.d365', 'ifm_country', 'silver', 'oss.noram.glb.d365_ifm_country_silver', 86400), 
                ('oss.noram.glb.d365', 'ifm_country', 'bronze', 'oss.noram.glb.d365_ifm_country_bronze', 86400),
                ('oss.noram.glb.d365', 'ifm_feedback', 'silver', 'oss.noram.glb.d365_ifm_feedback_silver', 86400), 
                ('oss.noram.glb.d365', 'ifm_feedback', 'bronze', 'oss.noram.glb.d365_ifm_feedback_bronze', 86400), 
                ('oss.noram.glb.d365', 'ifm_log', 'silver', 'oss.noram.glb.d365_ifm_log_silver', 86400), 
                ('oss.noram.glb.d365', 'ifm_log', 'bronze', 'oss.noram.glb.d365_ifm_log_bronze', 86400), 
                ('oss.noram.glb.d365', 'ifm_masterservicecategory', 'silver', 'oss.noram.glb.d365_ifm_masterservicecategory_silver', 86400), 
                ('oss.noram.glb.d365', 'ifm_masterservicecategory', 'bronze', 'oss.noram.glb.d365_ifm_masterservicecategory_bronze', 86400), 
                ('oss.noram.glb.d365', 'ifm_servicecategory', 'silver', 'oss.noram.glb.d365_ifm_servicecategory_silver', 86400), 
                ('oss.noram.glb.d365', 'ifm_servicecategory', 'bronze', 'oss.noram.glb.d365_ifm_servicecategory_bronze', 86400), 
                ('oss.noram.glb.d365', 'ifm_workordernote', 'silver', 'oss.noram.glb.d365_ifm_workordernote_silver', 86400), 
                ('oss.noram.glb.d365', 'ifm_workordernote', 'bronze', 'oss.noram.glb.d365_ifm_workordernote_bronze', 86400), 
                ('oss.noram.glb.d365', 'incident', 'silver', 'oss.noram.glb.d365_incident_silver', 86400), 
                ('oss.noram.glb.d365', 'incident', 'bronze', 'oss.noram.glb.d365_incident_bronze', 86400),
                ('oss.noram.glb.d365', 'incidentresolution', 'silver', 'oss.noram.glb.d365_incidentresolution_silver', 86400), 
                ('oss.noram.glb.d365', 'incidentresolution', 'bronze', 'oss.noram.glb.d365_incidentresolution_bronze', 86400), 
                ('oss.noram.glb.d365', 'msdyn_agreement', 'silver', 'oss.noram.glb.d365_msdyn_agreement_silver', 86400),
                ('oss.noram.glb.d365', 'msdyn_agreement', 'bronze', 'oss.noram.glb.d365_msdyn_agreement_bronze', 86400), 
                ('oss.noram.glb.d365', 'msdyn_customerasset', 'silver', 'oss.noram.glb.d365_msdyn_customerasset_silver', 86400), 
                ('oss.noram.glb.d365', 'msdyn_customerasset', 'bronze', 'oss.noram.glb.d365_msdyn_customerasset_bronze', 86400), 
                ('oss.noram.glb.d365', 'msdyn_expense', 'silver', 'oss.noram.glb.d365_msdyn_expense_silver', 86400),
                ('oss.noram.glb.d365', 'msdyn_expense', 'bronze', 'oss.noram.glb.d365_msdyn_expense_bronze', 86400),
                ('oss.noram.glb.d365', 'msdyn_priority', 'silver', 'oss.noram.glb.d365_msdyn_priority_silver', 86400),
                ('oss.noram.glb.d365', 'msdyn_priority', 'bronze', 'oss.noram.glb.d365_msdyn_priority_bronze', 86400), 
                ('oss.noram.glb.d365', 'msdyn_project', 'silver', 'oss.noram.glb.d365_msdyn_project_silver', 86400),
                ('oss.noram.glb.d365', 'msdyn_project', 'bronze', 'oss.noram.glb.d365_msdyn_project_bronze', 86400), 
                ('oss.noram.glb.d365', 'msdyn_projectapproval', 'silver', 'oss.noram.glb.d365_msdyn_projectapproval_silver', 86400),
                ('oss.noram.glb.d365', 'msdyn_projectapproval', 'bronze', 'oss.noram.glb.d365_msdyn_projectapproval_bronze', 86400), 
                ('oss.noram.glb.d365', 'msdyn_projecttask', 'silver', 'oss.noram.glb.d365_msdyn_projecttask_silver', 86400),
                ('oss.noram.glb.d365', 'msdyn_projecttask', 'bronze', 'oss.noram.glb.d365_msdyn_projecttask_bronze', 86400), 
                ('oss.noram.glb.d365', 'msdyn_resourcerequirement', 'silver', 'oss.noram.glb.d365_msdyn_resourcerequirement_silver', 86400), 
                ('oss.noram.glb.d365', 'msdyn_resourcerequirement', 'bronze', 'oss.noram.glb.d365_msdyn_resourcerequirement_bronze', 86400), 
                ('oss.noram.glb.d365', 'msdyn_survey', 'silver', 'oss.noram.glb.d365_msdyn_survey_silver', 86400), 
                ('oss.noram.glb.d365', 'msdyn_survey', 'bronze', 'oss.noram.glb.d365_msdyn_survey_bronze', 86400), 
                ('oss.noram.glb.d365', 'msdyn_timeentry', 'silver', 'oss.noram.glb.d365_msdyn_timeentry_silver', 86400),
                ('oss.noram.glb.d365', 'msdyn_timeentry', 'bronze', 'oss.noram.glb.d365_msdyn_timeentry_bronze', 86400),
                ('oss.noram.glb.d365', 'msdyn_workorder', 'silver', 'oss.noram.glb.d365_msdyn_workorder_silver', 86400), 
                ('oss.noram.glb.d365', 'msdyn_workorder', 'bronze', 'oss.noram.glb.d365_msdyn_workorder_bronze', 86400), 
                ('oss.noram.glb.d365', 'msdyn_workordertype', 'silver', 'oss.noram.glb.d365_msdyn_workordertype_silver', 86400),
                ('oss.noram.glb.d365', 'msdyn_workordertype', 'bronze', 'oss.noram.glb.d365_msdyn_workordertype_bronze', 86400), 
                ('oss.noram.glb.d365', 'pricelevel', 'silver', 'oss.noram.glb.d365_pricelevel_silver', 86400), 
                ('oss.noram.glb.d365', 'pricelevel', 'bronze', 'oss.noram.glb.d365_pricelevel_bronze', 86400), 
                ('oss.noram.glb.d365', 'queue', 'silver', 'oss.noram.glb.d365_queue_silver', 86400), 
                ('oss.noram.glb.d365', 'queue', 'bronze', 'oss.noram.glb.d365_queue_bronze', 86400), 
                ('oss.noram.glb.d365', 'quote', 'silver', 'oss.noram.glb.d365_quote_silver', 86400), 
                ('oss.noram.glb.d365', 'quote', 'bronze', 'oss.noram.glb.d365_quote_bronze', 86400),
                ('oss.noram.glb.d365', 'role', 'silver', 'oss.noram.glb.d365_role_silver', 86400), 
                ('oss.noram.glb.d365', 'role', 'bronze', 'oss.noram.glb.d365_role_bronze', 86400), 
                ('oss.noram.glb.d365', 'sdxmob_facility', 'silver', 'oss.noram.glb.d365_sdxmob_facility_silver', 86400), 
                ('oss.noram.glb.d365', 'sdxmob_facility', 'bronze', 'oss.noram.glb.d365_sdxmob_facility_bronze', 86400), 
                ('oss.noram.glb.d365', 'sla', 'silver', 'oss.noram.glb.d365_sla_silver', 86400), 
                ('oss.noram.glb.d365', 'sla', 'bronze', 'oss.noram.glb.d365_sla_bronze', 86400), 
                ('oss.noram.glb.d365', 'slaitem', 'silver', 'oss.noram.glb.d365_slaitem_silver', 86400), 
                ('oss.noram.glb.d365', 'slaitem', 'bronze', 'oss.noram.glb.d365_slaitem_bronze', 86400), 
                ('oss.noram.glb.d365', 'slakpiinstance', 'silver', 'oss.noram.glb.d365_slakpiinstance_silver', 86400), 
                ('oss.noram.glb.d365', 'slakpiinstance', 'bronze', 'oss.noram.glb.d365_slakpiinstance_bronze', 86400), 
                ('oss.noram.glb.d365', 'systemuser', 'silver', 'oss.noram.glb.d365_systemuser_silver', 86400), 
                ('oss.noram.glb.d365', 'systemuser', 'bronze', 'oss.noram.glb.d365_systemuser_bronze', 86400), 
                ('oss.noram.glb.d365', 'timezonedefinition', 'silver', 'oss.noram.glb.d365_timezonedefinition_silver', 86400), 
                ('oss.noram.glb.d365', 'timezonedefinition', 'bronze', 'oss.noram.glb.d365_timezonedefinition_bronze', 86400), 
                ('oss.noram.glb.d365', 'timezonerule', 'silver', 'oss.noram.glb.d365_timezonerule_silver', 86400), 
                ('oss.noram.glb.d365', 'timezonerule', 'bronze', 'oss.noram.glb.d365_timezonerule_bronze', 86400), 
                ('oss.noram.glb.d365', 'transactioncurrency', 'silver', 'oss.noram.glb.d365_transactioncurrency_silver', 86400), 
                ('oss.noram.glb.d365', 'transactioncurrency', 'bronze', 'oss.noram.glb.d365_transactioncurrency_bronze', 86400)) AS t (project_name, dataset_name, landing_zone, context_id, ttl)
                WHERE context_id IN (${context:sqlstring}+'')
            ),
            RawEvents AS (
                SELECT
                    [timestamp],
                    context_id,
                    job_id,
                    metric_value
                FROM
                    [observability].[event]
                WHERE
                    metric_name = 'processing_exit_code'
                    AND event_type = 'processingfinished'
                    AND context_id IN (${context:sqlstring}+'')
                    AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
            ),
            DistinctJobs AS (
                SELECT DISTINCT
                    context_id,
                    job_id,
                    metric_value
                FROM
                    RawEvents
            ),
            IngestionSum AS (
                SELECT
                    context_id,
                    SUM(CASE WHEN metric_value = 0 THEN 1 ELSE 0 END) AS Succeeded,
                    SUM(CASE WHEN metric_value = 1 THEN 1 ELSE 0 END) AS No_Data,
                    SUM(CASE WHEN metric_value = -1 THEN 1 ELSE 0 END) AS Failed
                FROM
                    DistinctJobs
                GROUP BY
                    context_id
            ),
            FilteredAndAdded AS (
            SELECT
                timestamp,
                context_id,
                metric_value
            FROM (
                SELECT
                    timestamp,
                    context_id,
                    metric_value
                FROM
                    RawEvents
                WHERE
                    metric_value = 0
 
                UNION ALL
 
                SELECT
                    $__unixEpochTo() AS timestamp,  -- Current UTC timestamp as Unix time
                    context_id,
                    0 AS metric_value
                FROM
                    (SELECT DISTINCT context_id FROM RawEvents WHERE metric_value = 0) AS UniqueContexts
 
                UNION ALL
 
                SELECT
                    $__unixEpochFrom() AS timestamp,  -- Current UTC timestamp as Unix time
                    context_id,
                    0 AS metric_value
                FROM
                    (SELECT DISTINCT context_id FROM RawEvents WHERE metric_value = 0) AS UniqueContexts
                ) AS CombinedFilteredResults
        	),
            EventDifferences AS (
                SELECT
                    context_id,
                    timestamp,
                    metric_value,
                    LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
                    CASE
                        WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                            timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                        ELSE NULL
                    END AS time_difference
                FROM
                    FilteredAndAdded
                WHERE
                    metric_value = 0
            ),
            Slis AS (
                SELECT
                    cv.project_name AS 'Application Source',
                    cv.dataset_name AS 'DatasetName',
                    cv.landing_zone AS 'Zone',
                    cv.ttl AS 'TTL',
                    COALESCE(iso.Succeeded, 0) AS 'Succeeded',
                    COALESCE(iso.No_Data, 0) AS 'No New Data',
                    COALESCE(iso.Failed, 0) AS 'Failed',
                    COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
                    CASE
                        WHEN COALESCE(iso.Succeeded, 0) = 0 THEN 0
                        WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
                        ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / ($__unixEpochTo() - $__unixEpochFrom()))
                    END AS SLI
                FROM
                    CombinedValues AS cv
                LEFT JOIN
                    IngestionSum AS iso
                ON
                    cv.context_id = iso.context_id
                LEFT JOIN
                    EventDifferences AS ed
                ON
                    cv.context_id = ed.context_id
                    AND ed.time_difference > cv.ttl
                GROUP BY
                    cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed
            )
            select AVG(SLI) as 'SLI Percentage'  from Slis
    ";

    stat.new(
        title='SLI',
        datasource='IFM Azure SQL Server',
        description= "The SLI(Service Level Indicator) is a measurable metric closely monitored by stakeholders to
        evaluate the operational performance and efficiency of a data ingestion pipeline. It is calculated here as a 
        percentage of up-to-date ingestions, by calculating the percentage of ingestionDelay for ingestions against 
        the specific timeframe(by application source, dataset name, zone). An ingestion is up to date if the difference 
        between two ingestions is lower than the ttl. For Example, If there is no IngestionDelay for ingestions over 
        specific timeframe then SLI is 100.")
        .addTarget(target=grafana.sql.target(rawSql=SLISqlQuery, format='table'))
        .addOverridesByFieldName(
        field='SLI Percentage',
        properties=[{id: 'unit', value: 'percent'},
        {
            "id": "thresholds",
            "value": {
            "mode": "absolute",
            "steps": [
                { "color": "light-gray", "value": null },
                { "color": "light-red", "value": 0 },
                { "color": "light-yellow", "value": 80 },
                { "color": "light-green", "value": 80*1.1 }
            ]
            }
        }
        ]
);

local generateIngestionPipelinesByCondition(title, color, code) =
   local sqlQuery = std.format("
        SELECT COUNT(*)
        FROM (
            SELECT distinct job_id, context_id
            FROM [observability].[event]
            WHERE metric_name='processing_exit_code'
            AND event_type='processingfinished'
            AND metric_value=%d
            AND context_id in ('oss.apac.glb.d365_account_silver', 'oss.apac.glb.d365_account_bronze', 'oss.apac.glb.d365_activitypointer_silver', 'oss.apac.glb.d365_activitypointer_bronze', 'oss.apac.glb.d365_adx_portalcomment_silver', 'oss.apac.glb.d365_adx_portalcomment_bronze', 'oss.apac.glb.d365_annotation_silver', 'oss.apac.glb.d365_annotation_bronze', 'oss.apac.glb.d365_bookableresource_silver', 'oss.apac.glb.d365_bookableresource_bronze', 'oss.apac.glb.d365_bookableresourcebooking_silver', 'oss.apac.glb.d365_bookableresourcebooking_bronze', 'oss.apac.glb.d365_bookableresourcecategory_silver', 'oss.apac.glb.d365_bookableresourcecategory_bronze', 'oss.apac.glb.d365_contact_silver', 'oss.apac.glb.d365_contact_bronze', 'oss.apac.glb.d365_contract_silver', 'oss.apac.glb.d365_contract_bronze', 'oss.apac.glb.d365_entitlement_silver', 'oss.apac.glb.d365_entitlement_bronze', 'oss.apac.glb.d365_ifm_assettype_silver', 'oss.apac.glb.d365_ifm_assettype_bronze', 'oss.apac.glb.d365_ifm_contract_silver', 'oss.apac.glb.d365_ifm_contract_bronze', 'oss.apac.glb.d365_ifm_country_silver', 'oss.apac.glb.d365_ifm_country_bronze', 'oss.apac.glb.d365_ifm_feedback_silver', 'oss.apac.glb.d365_ifm_feedback_bronze', 'oss.apac.glb.d365_ifm_log_silver', 'oss.apac.glb.d365_ifm_log_bronze', 'oss.apac.glb.d365_ifm_masterservicecategory_silver', 'oss.apac.glb.d365_ifm_masterservicecategory_bronze', 'oss.apac.glb.d365_ifm_servicecategory_silver', 'oss.apac.glb.d365_ifm_servicecategory_bronze', 'oss.apac.glb.d365_ifm_workordernote_silver', 'oss.apac.glb.d365_ifm_workordernote_bronze', 'oss.apac.glb.d365_incident_silver', 'oss.apac.glb.d365_incident_bronze', 'oss.apac.glb.d365_incidentresolution_silver', 'oss.apac.glb.d365_incidentresolution_bronze', 'oss.apac.glb.d365_msdyn_agreement_silver', 'oss.apac.glb.d365_msdyn_agreement_bronze', 'oss.apac.glb.d365_msdyn_customerasset_silver', 'oss.apac.glb.d365_msdyn_customerasset_bronze', 'oss.apac.glb.d365_msdyn_expense_silver', 'oss.apac.glb.d365_msdyn_expense_bronze', 'oss.apac.glb.d365_msdyn_priority_silver', 'oss.apac.glb.d365_msdyn_priority_bronze', 'oss.apac.glb.d365_msdyn_project_silver', 'oss.apac.glb.d365_msdyn_project_bronze', 'oss.apac.glb.d365_msdyn_projectapproval_silver', 'oss.apac.glb.d365_msdyn_projectapproval_bronze', 'oss.apac.glb.d365_msdyn_projecttask_silver', 'oss.apac.glb.d365_msdyn_projecttask_bronze', 'oss.apac.glb.d365_msdyn_resourcerequirement_silver', 'oss.apac.glb.d365_msdyn_resourcerequirement_bronze', 'oss.apac.glb.d365_msdyn_survey_silver', 'oss.apac.glb.d365_msdyn_survey_bronze', 'oss.apac.glb.d365_msdyn_timeentry_silver', 'oss.apac.glb.d365_msdyn_timeentry_bronze', 'oss.apac.glb.d365_msdyn_workorder_silver', 'oss.apac.glb.d365_msdyn_workorder_bronze', 'oss.apac.glb.d365_msdyn_workordertype_silver', 'oss.apac.glb.d365_msdyn_workordertype_bronze', 'oss.apac.glb.d365_pricelevel_silver', 'oss.apac.glb.d365_pricelevel_bronze', 'oss.apac.glb.d365_queue_silver', 'oss.apac.glb.d365_queue_bronze', 'oss.apac.glb.d365_quote_silver', 'oss.apac.glb.d365_quote_bronze', 'oss.apac.glb.d365_role_silver', 'oss.apac.glb.d365_role_bronze', 'oss.apac.glb.d365_sdxmob_facility_silver', 'oss.apac.glb.d365_sdxmob_facility_bronze', 'oss.apac.glb.d365_sla_silver', 'oss.apac.glb.d365_sla_bronze', 'oss.apac.glb.d365_slaitem_silver', 'oss.apac.glb.d365_slaitem_bronze', 'oss.apac.glb.d365_slakpiinstance_silver', 'oss.apac.glb.d365_slakpiinstance_bronze', 'oss.apac.glb.d365_systemuser_silver', 'oss.apac.glb.d365_systemuser_bronze', 'oss.apac.glb.d365_timezonedefinition_silver', 'oss.apac.glb.d365_timezonedefinition_bronze', 'oss.apac.glb.d365_timezonerule_silver', 'oss.apac.glb.d365_timezonerule_bronze', 'oss.apac.glb.d365_transactioncurrency_silver', 'oss.apac.glb.d365_transactioncurrency_bronze', 'oss.coe.glb.d365_account_silver', 'oss.coe.glb.d365_account_bronze', 'oss.coe.glb.d365_activitypointer_silver', 'oss.coe.glb.d365_activitypointer_bronze', 'oss.coe.glb.d365_adx_portalcomment_silver', 'oss.coe.glb.d365_adx_portalcomment_bronze', 'oss.coe.glb.d365_annotation_silver', 'oss.coe.glb.d365_annotation_bronze', 'oss.coe.glb.d365_bookableresource_silver', 'oss.coe.glb.d365_bookableresource_bronze', 'oss.coe.glb.d365_bookableresourcebooking_silver', 'oss.coe.glb.d365_bookableresourcebooking_bronze', 'oss.coe.glb.d365_bookableresourcecategory_silver', 'oss.coe.glb.d365_bookableresourcecategory_bronze', 'oss.coe.glb.d365_contact_silver', 'oss.coe.glb.d365_contact_bronze', 'oss.coe.glb.d365_contract_silver', 'oss.coe.glb.d365_contract_bronze', 'oss.coe.glb.d365_entitlement_silver', 'oss.coe.glb.d365_entitlement_bronze', 'oss.coe.glb.d365_ifm_assettype_silver', 'oss.coe.glb.d365_ifm_assettype_bronze', 'oss.coe.glb.d365_ifm_contract_silver', 'oss.coe.glb.d365_ifm_contract_bronze', 'oss.coe.glb.d365_ifm_country_silver', 'oss.coe.glb.d365_ifm_country_bronze', 'oss.coe.glb.d365_ifm_feedback_silver', 'oss.coe.glb.d365_ifm_feedback_bronze', 'oss.coe.glb.d365_ifm_log_silver', 'oss.coe.glb.d365_ifm_log_bronze', 'oss.coe.glb.d365_ifm_masterservicecategory_silver', 'oss.coe.glb.d365_ifm_masterservicecategory_bronze', 'oss.coe.glb.d365_ifm_servicecategory_silver', 'oss.coe.glb.d365_ifm_servicecategory_bronze', 'oss.coe.glb.d365_ifm_workordernote_silver', 'oss.coe.glb.d365_ifm_workordernote_bronze', 'oss.coe.glb.d365_incident_silver', 'oss.coe.glb.d365_incident_bronze', 'oss.coe.glb.d365_incidentresolution_silver', 'oss.coe.glb.d365_incidentresolution_bronze', 'oss.coe.glb.d365_msdyn_agreement_silver', 'oss.coe.glb.d365_msdyn_agreement_bronze', 'oss.coe.glb.d365_msdyn_customerasset_silver', 'oss.coe.glb.d365_msdyn_customerasset_bronze', 'oss.coe.glb.d365_msdyn_expense_silver', 'oss.coe.glb.d365_msdyn_expense_bronze', 'oss.coe.glb.d365_msdyn_priority_silver', 'oss.coe.glb.d365_msdyn_priority_bronze', 'oss.coe.glb.d365_msdyn_project_silver', 'oss.coe.glb.d365_msdyn_project_bronze', 'oss.coe.glb.d365_msdyn_projectapproval_silver', 'oss.coe.glb.d365_msdyn_projectapproval_bronze', 'oss.coe.glb.d365_msdyn_projecttask_silver', 'oss.coe.glb.d365_msdyn_projecttask_bronze', 'oss.coe.glb.d365_msdyn_resourcerequirement_silver', 'oss.coe.glb.d365_msdyn_resourcerequirement_bronze', 'oss.coe.glb.d365_msdyn_survey_silver', 'oss.coe.glb.d365_msdyn_survey_bronze', 'oss.coe.glb.d365_msdyn_timeentry_silver', 'oss.coe.glb.d365_msdyn_timeentry_bronze', 'oss.coe.glb.d365_msdyn_workorder_silver', 'oss.coe.glb.d365_msdyn_workorder_bronze', 'oss.coe.glb.d365_msdyn_workordertype_silver', 'oss.coe.glb.d365_msdyn_workordertype_bronze', 'oss.coe.glb.d365_pricelevel_silver', 'oss.coe.glb.d365_pricelevel_bronze', 'oss.coe.glb.d365_queue_silver', 'oss.coe.glb.d365_queue_bronze', 'oss.coe.glb.d365_quote_silver', 'oss.coe.glb.d365_quote_bronze', 'oss.coe.glb.d365_role_silver', 'oss.coe.glb.d365_role_bronze', 'oss.coe.glb.d365_sdxmob_facility_silver', 'oss.coe.glb.d365_sdxmob_facility_bronze', 'oss.coe.glb.d365_sla_silver', 'oss.coe.glb.d365_sla_bronze', 'oss.coe.glb.d365_slaitem_silver', 'oss.coe.glb.d365_slaitem_bronze', 'oss.coe.glb.d365_slakpiinstance_silver', 'oss.coe.glb.d365_slakpiinstance_bronze', 'oss.coe.glb.d365_systemuser_silver', 'oss.coe.glb.d365_systemuser_bronze', 'oss.coe.glb.d365_timezonedefinition_silver', 'oss.coe.glb.d365_timezonedefinition_bronze', 'oss.coe.glb.d365_timezonerule_silver', 'oss.coe.glb.d365_timezonerule_bronze', 'oss.coe.glb.d365_transactioncurrency_silver', 'oss.coe.glb.d365_transactioncurrency_bronze', 'oss.noram.glb.d365_account_silver', 'oss.noram.glb.d365_account_bronze', 'oss.noram.glb.d365_activitypointer_silver', 'oss.noram.glb.d365_activitypointer_bronze', 'oss.noram.glb.d365_adx_portalcomment_silver', 'oss.noram.glb.d365_adx_portalcomment_bronze', 'oss.noram.glb.d365_annotation_silver', 'oss.noram.glb.d365_annotation_bronze', 'oss.noram.glb.d365_bookableresource_silver', 'oss.noram.glb.d365_bookableresource_bronze', 'oss.noram.glb.d365_bookableresourcebooking_silver', 'oss.noram.glb.d365_bookableresourcebooking_bronze', 'oss.noram.glb.d365_bookableresourcecategory_silver', 'oss.noram.glb.d365_bookableresourcecategory_bronze', 'oss.noram.glb.d365_contact_silver', 'oss.noram.glb.d365_contact_bronze', 'oss.noram.glb.d365_contract_silver', 'oss.noram.glb.d365_contract_bronze', 'oss.noram.glb.d365_entitlement_silver', 'oss.noram.glb.d365_entitlement_bronze', 'oss.noram.glb.d365_ifm_assettype_silver', 'oss.noram.glb.d365_ifm_assettype_bronze', 'oss.noram.glb.d365_ifm_contract_silver', 'oss.noram.glb.d365_ifm_contract_bronze', 'oss.noram.glb.d365_ifm_country_silver', 'oss.noram.glb.d365_ifm_country_bronze', 'oss.noram.glb.d365_ifm_feedback_silver', 'oss.noram.glb.d365_ifm_feedback_bronze', 'oss.noram.glb.d365_ifm_log_silver', 'oss.noram.glb.d365_ifm_log_bronze', 'oss.noram.glb.d365_ifm_masterservicecategory_silver', 'oss.noram.glb.d365_ifm_masterservicecategory_bronze', 'oss.noram.glb.d365_ifm_servicecategory_silver', 'oss.noram.glb.d365_ifm_servicecategory_bronze', 'oss.noram.glb.d365_ifm_workordernote_silver', 'oss.noram.glb.d365_ifm_workordernote_bronze', 'oss.noram.glb.d365_incident_silver', 'oss.noram.glb.d365_incident_bronze', 'oss.noram.glb.d365_incidentresolution_silver', 'oss.noram.glb.d365_incidentresolution_bronze', 'oss.noram.glb.d365_msdyn_agreement_silver', 'oss.noram.glb.d365_msdyn_agreement_bronze', 'oss.noram.glb.d365_msdyn_customerasset_silver', 'oss.noram.glb.d365_msdyn_customerasset_bronze', 'oss.noram.glb.d365_msdyn_expense_silver', 'oss.noram.glb.d365_msdyn_expense_bronze', 'oss.noram.glb.d365_msdyn_priority_silver', 'oss.noram.glb.d365_msdyn_priority_bronze', 'oss.noram.glb.d365_msdyn_project_silver', 'oss.noram.glb.d365_msdyn_project_bronze', 'oss.noram.glb.d365_msdyn_projectapproval_silver', 'oss.noram.glb.d365_msdyn_projectapproval_bronze', 'oss.noram.glb.d365_msdyn_projecttask_silver', 'oss.noram.glb.d365_msdyn_projecttask_bronze', 'oss.noram.glb.d365_msdyn_resourcerequirement_silver', 'oss.noram.glb.d365_msdyn_resourcerequirement_bronze', 'oss.noram.glb.d365_msdyn_survey_silver', 'oss.noram.glb.d365_msdyn_survey_bronze', 'oss.noram.glb.d365_msdyn_timeentry_silver', 'oss.noram.glb.d365_msdyn_timeentry_bronze', 'oss.noram.glb.d365_msdyn_workorder_silver', 'oss.noram.glb.d365_msdyn_workorder_bronze', 'oss.noram.glb.d365_msdyn_workordertype_silver', 'oss.noram.glb.d365_msdyn_workordertype_bronze', 'oss.noram.glb.d365_pricelevel_silver', 'oss.noram.glb.d365_pricelevel_bronze', 'oss.noram.glb.d365_queue_silver', 'oss.noram.glb.d365_queue_bronze', 'oss.noram.glb.d365_quote_silver', 'oss.noram.glb.d365_quote_bronze', 'oss.noram.glb.d365_role_silver', 'oss.noram.glb.d365_role_bronze', 'oss.noram.glb.d365_sdxmob_facility_silver', 'oss.noram.glb.d365_sdxmob_facility_bronze', 'oss.noram.glb.d365_sla_silver', 'oss.noram.glb.d365_sla_bronze', 'oss.noram.glb.d365_slaitem_silver', 'oss.noram.glb.d365_slaitem_bronze', 'oss.noram.glb.d365_slakpiinstance_silver', 'oss.noram.glb.d365_slakpiinstance_bronze', 'oss.noram.glb.d365_systemuser_silver', 'oss.noram.glb.d365_systemuser_bronze', 'oss.noram.glb.d365_timezonedefinition_silver', 'oss.noram.glb.d365_timezonedefinition_bronze', 'oss.noram.glb.d365_timezonerule_silver', 'oss.noram.glb.d365_timezonerule_bronze', 'oss.noram.glb.d365_transactioncurrency_silver', 'oss.noram.glb.d365_transactioncurrency_bronze'+'')
            AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
           AND dataset_name IN ($dataset_name)
          AND landing_zone IN ($landing_zone)
          AND project_name IN ($project_name)
        ) AS SubQuery
        ", [code]
    );

    grafana.statPanel.new(title, datasource='IFM Azure SQL Server', colorMode='background')
    .addThresholds([{ value: 0, color: color }])
    .addTarget(target=grafana.sql.target(rawSql=sqlQuery, format='table')
);

local GenerateSuccessRatio =
    local sqlQuery = "
    SELECT
        CASE WHEN COUNT(*) = 0 THEN 100 
        ELSE COUNT(CASE WHEN metric_value != -1 THEN 1 ELSE NULL END) * 100.0 / COUNT(*) 
        END AS ratio
    FROM ( select distinct job_id, context_id, metric_value from[observability].[event]
                WHERE metric_name= 'processing_exit_code'
                AND event_type =  'processingfinished'
                AND context_id IN ('oss.apac.glb.d365_account_silver', 'oss.apac.glb.d365_account_bronze', 'oss.apac.glb.d365_activitypointer_silver', 'oss.apac.glb.d365_activitypointer_bronze', 'oss.apac.glb.d365_adx_portalcomment_silver', 'oss.apac.glb.d365_adx_portalcomment_bronze', 'oss.apac.glb.d365_annotation_silver', 'oss.apac.glb.d365_annotation_bronze', 'oss.apac.glb.d365_bookableresource_silver', 'oss.apac.glb.d365_bookableresource_bronze', 'oss.apac.glb.d365_bookableresourcebooking_silver', 'oss.apac.glb.d365_bookableresourcebooking_bronze', 'oss.apac.glb.d365_bookableresourcecategory_silver', 'oss.apac.glb.d365_bookableresourcecategory_bronze', 'oss.apac.glb.d365_contact_silver', 'oss.apac.glb.d365_contact_bronze', 'oss.apac.glb.d365_contract_silver', 'oss.apac.glb.d365_contract_bronze', 'oss.apac.glb.d365_entitlement_silver', 'oss.apac.glb.d365_entitlement_bronze', 'oss.apac.glb.d365_ifm_assettype_silver', 'oss.apac.glb.d365_ifm_assettype_bronze', 'oss.apac.glb.d365_ifm_contract_silver', 'oss.apac.glb.d365_ifm_contract_bronze', 'oss.apac.glb.d365_ifm_country_silver', 'oss.apac.glb.d365_ifm_country_bronze', 'oss.apac.glb.d365_ifm_feedback_silver', 'oss.apac.glb.d365_ifm_feedback_bronze', 'oss.apac.glb.d365_ifm_log_silver', 'oss.apac.glb.d365_ifm_log_bronze', 'oss.apac.glb.d365_ifm_masterservicecategory_silver', 'oss.apac.glb.d365_ifm_masterservicecategory_bronze', 'oss.apac.glb.d365_ifm_servicecategory_silver', 'oss.apac.glb.d365_ifm_servicecategory_bronze', 'oss.apac.glb.d365_ifm_workordernote_silver', 'oss.apac.glb.d365_ifm_workordernote_bronze', 'oss.apac.glb.d365_incident_silver', 'oss.apac.glb.d365_incident_bronze', 'oss.apac.glb.d365_incidentresolution_silver', 'oss.apac.glb.d365_incidentresolution_bronze', 'oss.apac.glb.d365_msdyn_agreement_silver', 'oss.apac.glb.d365_msdyn_agreement_bronze', 'oss.apac.glb.d365_msdyn_customerasset_silver', 'oss.apac.glb.d365_msdyn_customerasset_bronze', 'oss.apac.glb.d365_msdyn_expense_silver', 'oss.apac.glb.d365_msdyn_expense_bronze', 'oss.apac.glb.d365_msdyn_priority_silver', 'oss.apac.glb.d365_msdyn_priority_bronze', 'oss.apac.glb.d365_msdyn_project_silver', 'oss.apac.glb.d365_msdyn_project_bronze', 'oss.apac.glb.d365_msdyn_projectapproval_silver', 'oss.apac.glb.d365_msdyn_projectapproval_bronze', 'oss.apac.glb.d365_msdyn_projecttask_silver', 'oss.apac.glb.d365_msdyn_projecttask_bronze', 'oss.apac.glb.d365_msdyn_resourcerequirement_silver', 'oss.apac.glb.d365_msdyn_resourcerequirement_bronze', 'oss.apac.glb.d365_msdyn_survey_silver', 'oss.apac.glb.d365_msdyn_survey_bronze', 'oss.apac.glb.d365_msdyn_timeentry_silver', 'oss.apac.glb.d365_msdyn_timeentry_bronze', 'oss.apac.glb.d365_msdyn_workorder_silver', 'oss.apac.glb.d365_msdyn_workorder_bronze', 'oss.apac.glb.d365_msdyn_workordertype_silver', 'oss.apac.glb.d365_msdyn_workordertype_bronze', 'oss.apac.glb.d365_pricelevel_silver', 'oss.apac.glb.d365_pricelevel_bronze', 'oss.apac.glb.d365_queue_silver', 'oss.apac.glb.d365_queue_bronze', 'oss.apac.glb.d365_quote_silver', 'oss.apac.glb.d365_quote_bronze', 'oss.apac.glb.d365_role_silver', 'oss.apac.glb.d365_role_bronze', 'oss.apac.glb.d365_sdxmob_facility_silver', 'oss.apac.glb.d365_sdxmob_facility_bronze', 'oss.apac.glb.d365_sla_silver', 'oss.apac.glb.d365_sla_bronze', 'oss.apac.glb.d365_slaitem_silver', 'oss.apac.glb.d365_slaitem_bronze', 'oss.apac.glb.d365_slakpiinstance_silver', 'oss.apac.glb.d365_slakpiinstance_bronze', 'oss.apac.glb.d365_systemuser_silver', 'oss.apac.glb.d365_systemuser_bronze', 'oss.apac.glb.d365_timezonedefinition_silver', 'oss.apac.glb.d365_timezonedefinition_bronze', 'oss.apac.glb.d365_timezonerule_silver', 'oss.apac.glb.d365_timezonerule_bronze', 'oss.apac.glb.d365_transactioncurrency_silver', 'oss.apac.glb.d365_transactioncurrency_bronze', 'oss.coe.glb.d365_account_silver', 'oss.coe.glb.d365_account_bronze', 'oss.coe.glb.d365_activitypointer_silver', 'oss.coe.glb.d365_activitypointer_bronze', 'oss.coe.glb.d365_adx_portalcomment_silver', 'oss.coe.glb.d365_adx_portalcomment_bronze', 'oss.coe.glb.d365_annotation_silver', 'oss.coe.glb.d365_annotation_bronze', 'oss.coe.glb.d365_bookableresource_silver', 'oss.coe.glb.d365_bookableresource_bronze', 'oss.coe.glb.d365_bookableresourcebooking_silver', 'oss.coe.glb.d365_bookableresourcebooking_bronze', 'oss.coe.glb.d365_bookableresourcecategory_silver', 'oss.coe.glb.d365_bookableresourcecategory_bronze', 'oss.coe.glb.d365_contact_silver', 'oss.coe.glb.d365_contact_bronze', 'oss.coe.glb.d365_contract_silver', 'oss.coe.glb.d365_contract_bronze', 'oss.coe.glb.d365_entitlement_silver', 'oss.coe.glb.d365_entitlement_bronze', 'oss.coe.glb.d365_ifm_assettype_silver', 'oss.coe.glb.d365_ifm_assettype_bronze', 'oss.coe.glb.d365_ifm_contract_silver', 'oss.coe.glb.d365_ifm_contract_bronze', 'oss.coe.glb.d365_ifm_country_silver', 'oss.coe.glb.d365_ifm_country_bronze', 'oss.coe.glb.d365_ifm_feedback_silver', 'oss.coe.glb.d365_ifm_feedback_bronze', 'oss.coe.glb.d365_ifm_log_silver', 'oss.coe.glb.d365_ifm_log_bronze', 'oss.coe.glb.d365_ifm_masterservicecategory_silver', 'oss.coe.glb.d365_ifm_masterservicecategory_bronze', 'oss.coe.glb.d365_ifm_servicecategory_silver', 'oss.coe.glb.d365_ifm_servicecategory_bronze', 'oss.coe.glb.d365_ifm_workordernote_silver', 'oss.coe.glb.d365_ifm_workordernote_bronze', 'oss.coe.glb.d365_incident_silver', 'oss.coe.glb.d365_incident_bronze', 'oss.coe.glb.d365_incidentresolution_silver', 'oss.coe.glb.d365_incidentresolution_bronze', 'oss.coe.glb.d365_msdyn_agreement_silver', 'oss.coe.glb.d365_msdyn_agreement_bronze', 'oss.coe.glb.d365_msdyn_customerasset_silver', 'oss.coe.glb.d365_msdyn_customerasset_bronze', 'oss.coe.glb.d365_msdyn_expense_silver', 'oss.coe.glb.d365_msdyn_expense_bronze', 'oss.coe.glb.d365_msdyn_priority_silver', 'oss.coe.glb.d365_msdyn_priority_bronze', 'oss.coe.glb.d365_msdyn_project_silver', 'oss.coe.glb.d365_msdyn_project_bronze', 'oss.coe.glb.d365_msdyn_projectapproval_silver', 'oss.coe.glb.d365_msdyn_projectapproval_bronze', 'oss.coe.glb.d365_msdyn_projecttask_silver', 'oss.coe.glb.d365_msdyn_projecttask_bronze', 'oss.coe.glb.d365_msdyn_resourcerequirement_silver', 'oss.coe.glb.d365_msdyn_resourcerequirement_bronze', 'oss.coe.glb.d365_msdyn_survey_silver', 'oss.coe.glb.d365_msdyn_survey_bronze', 'oss.coe.glb.d365_msdyn_timeentry_silver', 'oss.coe.glb.d365_msdyn_timeentry_bronze', 'oss.coe.glb.d365_msdyn_workorder_silver', 'oss.coe.glb.d365_msdyn_workorder_bronze', 'oss.coe.glb.d365_msdyn_workordertype_silver', 'oss.coe.glb.d365_msdyn_workordertype_bronze', 'oss.coe.glb.d365_pricelevel_silver', 'oss.coe.glb.d365_pricelevel_bronze', 'oss.coe.glb.d365_queue_silver', 'oss.coe.glb.d365_queue_bronze', 'oss.coe.glb.d365_quote_silver', 'oss.coe.glb.d365_quote_bronze', 'oss.coe.glb.d365_role_silver', 'oss.coe.glb.d365_role_bronze', 'oss.coe.glb.d365_sdxmob_facility_silver', 'oss.coe.glb.d365_sdxmob_facility_bronze', 'oss.coe.glb.d365_sla_silver', 'oss.coe.glb.d365_sla_bronze', 'oss.coe.glb.d365_slaitem_silver', 'oss.coe.glb.d365_slaitem_bronze', 'oss.coe.glb.d365_slakpiinstance_silver', 'oss.coe.glb.d365_slakpiinstance_bronze', 'oss.coe.glb.d365_systemuser_silver', 'oss.coe.glb.d365_systemuser_bronze', 'oss.coe.glb.d365_timezonedefinition_silver', 'oss.coe.glb.d365_timezonedefinition_bronze', 'oss.coe.glb.d365_timezonerule_silver', 'oss.coe.glb.d365_timezonerule_bronze', 'oss.coe.glb.d365_transactioncurrency_silver', 'oss.coe.glb.d365_transactioncurrency_bronze', 'oss.noram.glb.d365_account_silver', 'oss.noram.glb.d365_account_bronze', 'oss.noram.glb.d365_activitypointer_silver', 'oss.noram.glb.d365_activitypointer_bronze', 'oss.noram.glb.d365_adx_portalcomment_silver', 'oss.noram.glb.d365_adx_portalcomment_bronze', 'oss.noram.glb.d365_annotation_silver', 'oss.noram.glb.d365_annotation_bronze', 'oss.noram.glb.d365_bookableresource_silver', 'oss.noram.glb.d365_bookableresource_bronze', 'oss.noram.glb.d365_bookableresourcebooking_silver', 'oss.noram.glb.d365_bookableresourcebooking_bronze', 'oss.noram.glb.d365_bookableresourcecategory_silver', 'oss.noram.glb.d365_bookableresourcecategory_bronze', 'oss.noram.glb.d365_contact_silver', 'oss.noram.glb.d365_contact_bronze', 'oss.noram.glb.d365_contract_silver', 'oss.noram.glb.d365_contract_bronze', 'oss.noram.glb.d365_entitlement_silver', 'oss.noram.glb.d365_entitlement_bronze', 'oss.noram.glb.d365_ifm_assettype_silver', 'oss.noram.glb.d365_ifm_assettype_bronze', 'oss.noram.glb.d365_ifm_contract_silver', 'oss.noram.glb.d365_ifm_contract_bronze', 'oss.noram.glb.d365_ifm_country_silver', 'oss.noram.glb.d365_ifm_country_bronze', 'oss.noram.glb.d365_ifm_feedback_silver', 'oss.noram.glb.d365_ifm_feedback_bronze', 'oss.noram.glb.d365_ifm_log_silver', 'oss.noram.glb.d365_ifm_log_bronze', 'oss.noram.glb.d365_ifm_masterservicecategory_silver', 'oss.noram.glb.d365_ifm_masterservicecategory_bronze', 'oss.noram.glb.d365_ifm_servicecategory_silver', 'oss.noram.glb.d365_ifm_servicecategory_bronze', 'oss.noram.glb.d365_ifm_workordernote_silver', 'oss.noram.glb.d365_ifm_workordernote_bronze', 'oss.noram.glb.d365_incident_silver', 'oss.noram.glb.d365_incident_bronze', 'oss.noram.glb.d365_incidentresolution_silver', 'oss.noram.glb.d365_incidentresolution_bronze', 'oss.noram.glb.d365_msdyn_agreement_silver', 'oss.noram.glb.d365_msdyn_agreement_bronze', 'oss.noram.glb.d365_msdyn_customerasset_silver', 'oss.noram.glb.d365_msdyn_customerasset_bronze', 'oss.noram.glb.d365_msdyn_expense_silver', 'oss.noram.glb.d365_msdyn_expense_bronze', 'oss.noram.glb.d365_msdyn_priority_silver', 'oss.noram.glb.d365_msdyn_priority_bronze', 'oss.noram.glb.d365_msdyn_project_silver', 'oss.noram.glb.d365_msdyn_project_bronze', 'oss.noram.glb.d365_msdyn_projectapproval_silver', 'oss.noram.glb.d365_msdyn_projectapproval_bronze', 'oss.noram.glb.d365_msdyn_projecttask_silver', 'oss.noram.glb.d365_msdyn_projecttask_bronze', 'oss.noram.glb.d365_msdyn_resourcerequirement_silver', 'oss.noram.glb.d365_msdyn_resourcerequirement_bronze', 'oss.noram.glb.d365_msdyn_survey_silver', 'oss.noram.glb.d365_msdyn_survey_bronze', 'oss.noram.glb.d365_msdyn_timeentry_silver', 'oss.noram.glb.d365_msdyn_timeentry_bronze', 'oss.noram.glb.d365_msdyn_workorder_silver', 'oss.noram.glb.d365_msdyn_workorder_bronze', 'oss.noram.glb.d365_msdyn_workordertype_silver', 'oss.noram.glb.d365_msdyn_workordertype_bronze', 'oss.noram.glb.d365_pricelevel_silver', 'oss.noram.glb.d365_pricelevel_bronze', 'oss.noram.glb.d365_queue_silver', 'oss.noram.glb.d365_queue_bronze', 'oss.noram.glb.d365_quote_silver', 'oss.noram.glb.d365_quote_bronze', 'oss.noram.glb.d365_role_silver', 'oss.noram.glb.d365_role_bronze', 'oss.noram.glb.d365_sdxmob_facility_silver', 'oss.noram.glb.d365_sdxmob_facility_bronze', 'oss.noram.glb.d365_sla_silver', 'oss.noram.glb.d365_sla_bronze', 'oss.noram.glb.d365_slaitem_silver', 'oss.noram.glb.d365_slaitem_bronze', 'oss.noram.glb.d365_slakpiinstance_silver', 'oss.noram.glb.d365_slakpiinstance_bronze', 'oss.noram.glb.d365_systemuser_silver', 'oss.noram.glb.d365_systemuser_bronze', 'oss.noram.glb.d365_timezonedefinition_silver', 'oss.noram.glb.d365_timezonedefinition_bronze', 'oss.noram.glb.d365_timezonerule_silver', 'oss.noram.glb.d365_timezonerule_bronze', 'oss.noram.glb.d365_transactioncurrency_silver', 'oss.noram.glb.d365_transactioncurrency_bronze')
                AND context_id IN (${context:sqlstring}+'')
                AND timestamp >= $__unixEpochFrom()
                AND timestamp < $__unixEpochTo()
            ) As distinct_records
    ";
        
    grafana.statPanel.new(
    title='Success Ratio Indicator',
    datasource='IFM Azure SQL Server',
    description= "The Pipeline Success Ratio Indicator provides a clear metric to gauge the effectiveness of
    a data ingestion pipeline by comparing successful operations against failures and no new data. "
    ).addTarget(target=grafana.sql.target(rawSql=sqlQuery,format='table'))
    .addOverridesByFieldName(field='ratio',properties=[{id: 'unit', value: 'percent'}]
);

local SLID365 = 
    local sqlQuery = " 
        WITH
            CombinedValues AS (
                SELECT *
                FROM (VALUES ('oss.apac.glb.d365', 'account', 'silver', 'oss.apac.glb.d365_account_silver', 86400),
            ('oss.apac.glb.d365', 'account', 'bronze', 'oss.apac.glb.d365_account_bronze', 86400),
            ('oss.apac.glb.d365', 'activitypointer', 'silver', 'oss.apac.glb.d365_activitypointer_silver', 86400),
            ('oss.apac.glb.d365', 'activitypointer', 'bronze', 'oss.apac.glb.d365_activitypointer_bronze', 86400),
            ('oss.apac.glb.d365', 'adx_portalcomment', 'silver', 'oss.apac.glb.d365_adx_portalcomment_silver', 86400),
            ('oss.apac.glb.d365', 'adx_portalcomment', 'bronze', 'oss.apac.glb.d365_adx_portalcomment_bronze', 86400),
            ('oss.apac.glb.d365', 'annotation', 'silver', 'oss.apac.glb.d365_annotation_silver', 86400), 
            ('oss.apac.glb.d365', 'annotation', 'bronze', 'oss.apac.glb.d365_annotation_bronze', 86400), 
            ('oss.apac.glb.d365', 'bookableresource', 'silver', 'oss.apac.glb.d365_bookableresource_silver', 86400), 
            ('oss.apac.glb.d365', 'bookableresource', 'bronze', 'oss.apac.glb.d365_bookableresource_bronze', 86400), 
            ('oss.apac.glb.d365', 'bookableresourcebooking', 'silver', 'oss.apac.glb.d365_bookableresourcebooking_silver', 86400), 
            ('oss.apac.glb.d365', 'bookableresourcebooking', 'bronze', 'oss.apac.glb.d365_bookableresourcebooking_bronze', 86400), 
            ('oss.apac.glb.d365', 'bookableresourcecategory', 'silver', 'oss.apac.glb.d365_bookableresourcecategory_silver', 86400), 
            ('oss.apac.glb.d365', 'bookableresourcecategory', 'bronze', 'oss.apac.glb.d365_bookableresourcecategory_bronze', 86400), 
            ('oss.apac.glb.d365', 'contact', 'silver', 'oss.apac.glb.d365_contact_silver', 86400), 
            ('oss.apac.glb.d365', 'contact', 'bronze', 'oss.apac.glb.d365_contact_bronze', 86400),
            ('oss.apac.glb.d365', 'contract', 'silver', 'oss.apac.glb.d365_contract_silver', 86400),
            ('oss.apac.glb.d365', 'contract', 'bronze', 'oss.apac.glb.d365_contract_bronze', 86400), 
            ('oss.apac.glb.d365', 'entitlement', 'silver', 'oss.apac.glb.d365_entitlement_silver', 86400), 
            ('oss.apac.glb.d365', 'entitlement', 'bronze', 'oss.apac.glb.d365_entitlement_bronze', 86400),
            ('oss.apac.glb.d365', 'ifm_assettype', 'silver', 'oss.apac.glb.d365_ifm_assettype_silver', 86400), 
            ('oss.apac.glb.d365', 'ifm_assettype', 'bronze', 'oss.apac.glb.d365_ifm_assettype_bronze', 86400), 
            ('oss.apac.glb.d365', 'ifm_contract', 'silver', 'oss.apac.glb.d365_ifm_contract_silver', 86400),
            ('oss.apac.glb.d365', 'ifm_contract', 'bronze', 'oss.apac.glb.d365_ifm_contract_bronze', 86400), 
            ('oss.apac.glb.d365', 'ifm_country', 'silver', 'oss.apac.glb.d365_ifm_country_silver', 86400), 
            ('oss.apac.glb.d365', 'ifm_country', 'bronze', 'oss.apac.glb.d365_ifm_country_bronze', 86400),
            ('oss.apac.glb.d365', 'ifm_feedback', 'silver', 'oss.apac.glb.d365_ifm_feedback_silver', 86400), 
            ('oss.apac.glb.d365', 'ifm_feedback', 'bronze', 'oss.apac.glb.d365_ifm_feedback_bronze', 86400), 
            ('oss.apac.glb.d365', 'ifm_log', 'silver', 'oss.apac.glb.d365_ifm_log_silver', 86400), 
            ('oss.apac.glb.d365', 'ifm_log', 'bronze', 'oss.apac.glb.d365_ifm_log_bronze', 86400), 
            ('oss.apac.glb.d365', 'ifm_masterservicecategory', 'silver', 'oss.apac.glb.d365_ifm_masterservicecategory_silver', 86400), 
            ('oss.apac.glb.d365', 'ifm_masterservicecategory', 'bronze', 'oss.apac.glb.d365_ifm_masterservicecategory_bronze', 86400), 
            ('oss.apac.glb.d365', 'ifm_servicecategory', 'silver', 'oss.apac.glb.d365_ifm_servicecategory_silver', 86400), 
            ('oss.apac.glb.d365', 'ifm_servicecategory', 'bronze', 'oss.apac.glb.d365_ifm_servicecategory_bronze', 86400), 
            ('oss.apac.glb.d365', 'ifm_workordernote', 'silver', 'oss.apac.glb.d365_ifm_workordernote_silver', 86400), 
            ('oss.apac.glb.d365', 'ifm_workordernote', 'bronze', 'oss.apac.glb.d365_ifm_workordernote_bronze', 86400), 
            ('oss.apac.glb.d365', 'incident', 'silver', 'oss.apac.glb.d365_incident_silver', 86400), 
            ('oss.apac.glb.d365', 'incident', 'bronze', 'oss.apac.glb.d365_incident_bronze', 86400),
            ('oss.apac.glb.d365', 'incidentresolution', 'silver', 'oss.apac.glb.d365_incidentresolution_silver', 86400), 
            ('oss.apac.glb.d365', 'incidentresolution', 'bronze', 'oss.apac.glb.d365_incidentresolution_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_agreement', 'silver', 'oss.apac.glb.d365_msdyn_agreement_silver', 86400),
            ('oss.apac.glb.d365', 'msdyn_agreement', 'bronze', 'oss.apac.glb.d365_msdyn_agreement_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_customerasset', 'silver', 'oss.apac.glb.d365_msdyn_customerasset_silver', 86400), 
            ('oss.apac.glb.d365', 'msdyn_customerasset', 'bronze', 'oss.apac.glb.d365_msdyn_customerasset_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_expense', 'silver', 'oss.apac.glb.d365_msdyn_expense_silver', 86400),
            ('oss.apac.glb.d365', 'msdyn_expense', 'bronze', 'oss.apac.glb.d365_msdyn_expense_bronze', 86400),
            ('oss.apac.glb.d365', 'msdyn_priority', 'silver', 'oss.apac.glb.d365_msdyn_priority_silver', 86400),
            ('oss.apac.glb.d365', 'msdyn_priority', 'bronze', 'oss.apac.glb.d365_msdyn_priority_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_project', 'silver', 'oss.apac.glb.d365_msdyn_project_silver', 86400),
            ('oss.apac.glb.d365', 'msdyn_project', 'bronze', 'oss.apac.glb.d365_msdyn_project_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_projectapproval', 'silver', 'oss.apac.glb.d365_msdyn_projectapproval_silver', 86400),
            ('oss.apac.glb.d365', 'msdyn_projectapproval', 'bronze', 'oss.apac.glb.d365_msdyn_projectapproval_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_projecttask', 'silver', 'oss.apac.glb.d365_msdyn_projecttask_silver', 86400),
            ('oss.apac.glb.d365', 'msdyn_projecttask', 'bronze', 'oss.apac.glb.d365_msdyn_projecttask_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_resourcerequirement', 'silver', 'oss.apac.glb.d365_msdyn_resourcerequirement_silver', 86400), 
            ('oss.apac.glb.d365', 'msdyn_resourcerequirement', 'bronze', 'oss.apac.glb.d365_msdyn_resourcerequirement_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_survey', 'silver', 'oss.apac.glb.d365_msdyn_survey_silver', 86400), 
            ('oss.apac.glb.d365', 'msdyn_survey', 'bronze', 'oss.apac.glb.d365_msdyn_survey_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_timeentry', 'silver', 'oss.apac.glb.d365_msdyn_timeentry_silver', 86400),
            ('oss.apac.glb.d365', 'msdyn_timeentry', 'bronze', 'oss.apac.glb.d365_msdyn_timeentry_bronze', 86400),
            ('oss.apac.glb.d365', 'msdyn_workorder', 'silver', 'oss.apac.glb.d365_msdyn_workorder_silver', 86400), 
            ('oss.apac.glb.d365', 'msdyn_workorder', 'bronze', 'oss.apac.glb.d365_msdyn_workorder_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_workordertype', 'silver', 'oss.apac.glb.d365_msdyn_workordertype_silver', 86400),
            ('oss.apac.glb.d365', 'msdyn_workordertype', 'bronze', 'oss.apac.glb.d365_msdyn_workordertype_bronze', 86400), 
            ('oss.apac.glb.d365', 'pricelevel', 'silver', 'oss.apac.glb.d365_pricelevel_silver', 86400), 
            ('oss.apac.glb.d365', 'pricelevel', 'bronze', 'oss.apac.glb.d365_pricelevel_bronze', 86400), 
            ('oss.apac.glb.d365', 'queue', 'silver', 'oss.apac.glb.d365_queue_silver', 86400), 
            ('oss.apac.glb.d365', 'queue', 'bronze', 'oss.apac.glb.d365_queue_bronze', 86400), 
            ('oss.apac.glb.d365', 'quote', 'silver', 'oss.apac.glb.d365_quote_silver', 86400), 
            ('oss.apac.glb.d365', 'quote', 'bronze', 'oss.apac.glb.d365_quote_bronze', 86400),
            ('oss.apac.glb.d365', 'role', 'silver', 'oss.apac.glb.d365_role_silver', 86400), 
            ('oss.apac.glb.d365', 'role', 'bronze', 'oss.apac.glb.d365_role_bronze', 86400), 
            ('oss.apac.glb.d365', 'sdxmob_facility', 'silver', 'oss.apac.glb.d365_sdxmob_facility_silver', 86400), 
            ('oss.apac.glb.d365', 'sdxmob_facility', 'bronze', 'oss.apac.glb.d365_sdxmob_facility_bronze', 86400), 
            ('oss.apac.glb.d365', 'sla', 'silver', 'oss.apac.glb.d365_sla_silver', 86400), 
            ('oss.apac.glb.d365', 'sla', 'bronze', 'oss.apac.glb.d365_sla_bronze', 86400), 
            ('oss.apac.glb.d365', 'slaitem', 'silver', 'oss.apac.glb.d365_slaitem_silver', 86400), 
            ('oss.apac.glb.d365', 'slaitem', 'bronze', 'oss.apac.glb.d365_slaitem_bronze', 86400), 
            ('oss.apac.glb.d365', 'slakpiinstance', 'silver', 'oss.apac.glb.d365_slakpiinstance_silver', 86400), 
            ('oss.apac.glb.d365', 'slakpiinstance', 'bronze', 'oss.apac.glb.d365_slakpiinstance_bronze', 86400), 
            ('oss.apac.glb.d365', 'systemuser', 'silver', 'oss.apac.glb.d365_systemuser_silver', 86400), 
            ('oss.apac.glb.d365', 'systemuser', 'bronze', 'oss.apac.glb.d365_systemuser_bronze', 86400), 
            ('oss.apac.glb.d365', 'timezonedefinition', 'silver', 'oss.apac.glb.d365_timezonedefinition_silver', 86400), 
            ('oss.apac.glb.d365', 'timezonedefinition', 'bronze', 'oss.apac.glb.d365_timezonedefinition_bronze', 86400), 
            ('oss.apac.glb.d365', 'timezonerule', 'silver', 'oss.apac.glb.d365_timezonerule_silver', 86400), 
            ('oss.apac.glb.d365', 'timezonerule', 'bronze', 'oss.apac.glb.d365_timezonerule_bronze', 86400), 
            ('oss.apac.glb.d365', 'transactioncurrency', 'silver', 'oss.apac.glb.d365_transactioncurrency_silver', 86400), 
            ('oss.apac.glb.d365', 'transactioncurrency', 'bronze', 'oss.apac.glb.d365_transactioncurrency_bronze', 86400),
            ('oss.coe.glb.d365', 'account', 'silver', 'oss.coe.glb.d365_account_silver', 86400),
            ('oss.coe.glb.d365', 'account', 'bronze', 'oss.coe.glb.d365_account_bronze', 86400),
            ('oss.coe.glb.d365', 'activitypointer', 'silver', 'oss.coe.glb.d365_activitypointer_silver', 86400),
            ('oss.coe.glb.d365', 'activitypointer', 'bronze', 'oss.coe.glb.d365_activitypointer_bronze', 86400),
            ('oss.coe.glb.d365', 'adx_portalcomment', 'silver', 'oss.coe.glb.d365_adx_portalcomment_silver', 86400),
            ('oss.coe.glb.d365', 'adx_portalcomment', 'bronze', 'oss.coe.glb.d365_adx_portalcomment_bronze', 86400),
            ('oss.coe.glb.d365', 'annotation', 'silver', 'oss.coe.glb.d365_annotation_silver', 86400), 
            ('oss.coe.glb.d365', 'annotation', 'bronze', 'oss.coe.glb.d365_annotation_bronze', 86400), 
            ('oss.coe.glb.d365', 'bookableresource', 'silver', 'oss.coe.glb.d365_bookableresource_silver', 86400), 
            ('oss.coe.glb.d365', 'bookableresource', 'bronze', 'oss.coe.glb.d365_bookableresource_bronze', 86400), 
            ('oss.coe.glb.d365', 'bookableresourcebooking', 'silver', 'oss.coe.glb.d365_bookableresourcebooking_silver', 86400), 
            ('oss.coe.glb.d365', 'bookableresourcebooking', 'bronze', 'oss.coe.glb.d365_bookableresourcebooking_bronze', 86400), 
            ('oss.coe.glb.d365', 'bookableresourcecategory', 'silver', 'oss.coe.glb.d365_bookableresourcecategory_silver', 86400), 
            ('oss.coe.glb.d365', 'bookableresourcecategory', 'bronze', 'oss.coe.glb.d365_bookableresourcecategory_bronze', 86400), 
            ('oss.coe.glb.d365', 'contact', 'silver', 'oss.coe.glb.d365_contact_silver', 86400), 
            ('oss.coe.glb.d365', 'contact', 'bronze', 'oss.coe.glb.d365_contact_bronze', 86400),
            ('oss.coe.glb.d365', 'contract', 'silver', 'oss.coe.glb.d365_contract_silver', 86400),
            ('oss.coe.glb.d365', 'contract', 'bronze', 'oss.coe.glb.d365_contract_bronze', 86400), 
            ('oss.coe.glb.d365', 'entitlement', 'silver', 'oss.coe.glb.d365_entitlement_silver', 86400), 
            ('oss.coe.glb.d365', 'entitlement', 'bronze', 'oss.coe.glb.d365_entitlement_bronze', 86400),
            ('oss.coe.glb.d365', 'ifm_assettype', 'silver', 'oss.coe.glb.d365_ifm_assettype_silver', 86400), 
            ('oss.coe.glb.d365', 'ifm_assettype', 'bronze', 'oss.coe.glb.d365_ifm_assettype_bronze', 86400), 
            ('oss.coe.glb.d365', 'ifm_contract', 'silver', 'oss.coe.glb.d365_ifm_contract_silver', 86400),
            ('oss.coe.glb.d365', 'ifm_contract', 'bronze', 'oss.coe.glb.d365_ifm_contract_bronze', 86400), 
            ('oss.coe.glb.d365', 'ifm_country', 'silver', 'oss.coe.glb.d365_ifm_country_silver', 86400), 
            ('oss.coe.glb.d365', 'ifm_country', 'bronze', 'oss.coe.glb.d365_ifm_country_bronze', 86400),
            ('oss.coe.glb.d365', 'ifm_feedback', 'silver', 'oss.coe.glb.d365_ifm_feedback_silver', 86400), 
            ('oss.coe.glb.d365', 'ifm_feedback', 'bronze', 'oss.coe.glb.d365_ifm_feedback_bronze', 86400), 
            ('oss.coe.glb.d365', 'ifm_log', 'silver', 'oss.coe.glb.d365_ifm_log_silver', 86400), 
            ('oss.coe.glb.d365', 'ifm_log', 'bronze', 'oss.coe.glb.d365_ifm_log_bronze', 86400), 
            ('oss.coe.glb.d365', 'ifm_masterservicecategory', 'silver', 'oss.coe.glb.d365_ifm_masterservicecategory_silver', 86400), 
            ('oss.coe.glb.d365', 'ifm_masterservicecategory', 'bronze', 'oss.coe.glb.d365_ifm_masterservicecategory_bronze', 86400), 
            ('oss.coe.glb.d365', 'ifm_servicecategory', 'silver', 'oss.coe.glb.d365_ifm_servicecategory_silver', 86400), 
            ('oss.coe.glb.d365', 'ifm_servicecategory', 'bronze', 'oss.coe.glb.d365_ifm_servicecategory_bronze', 86400), 
            ('oss.coe.glb.d365', 'ifm_workordernote', 'silver', 'oss.coe.glb.d365_ifm_workordernote_silver', 86400), 
            ('oss.coe.glb.d365', 'ifm_workordernote', 'bronze', 'oss.coe.glb.d365_ifm_workordernote_bronze', 86400), 
            ('oss.coe.glb.d365', 'incident', 'silver', 'oss.coe.glb.d365_incident_silver', 86400), 
            ('oss.coe.glb.d365', 'incident', 'bronze', 'oss.coe.glb.d365_incident_bronze', 86400),
            ('oss.coe.glb.d365', 'incidentresolution', 'silver', 'oss.coe.glb.d365_incidentresolution_silver', 86400), 
            ('oss.coe.glb.d365', 'incidentresolution', 'bronze', 'oss.coe.glb.d365_incidentresolution_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_agreement', 'silver', 'oss.coe.glb.d365_msdyn_agreement_silver', 86400),
            ('oss.coe.glb.d365', 'msdyn_agreement', 'bronze', 'oss.coe.glb.d365_msdyn_agreement_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_customerasset', 'silver', 'oss.coe.glb.d365_msdyn_customerasset_silver', 86400), 
            ('oss.coe.glb.d365', 'msdyn_customerasset', 'bronze', 'oss.coe.glb.d365_msdyn_customerasset_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_expense', 'silver', 'oss.coe.glb.d365_msdyn_expense_silver', 86400),
            ('oss.coe.glb.d365', 'msdyn_expense', 'bronze', 'oss.coe.glb.d365_msdyn_expense_bronze', 86400),
            ('oss.coe.glb.d365', 'msdyn_priority', 'silver', 'oss.coe.glb.d365_msdyn_priority_silver', 86400),
            ('oss.coe.glb.d365', 'msdyn_priority', 'bronze', 'oss.coe.glb.d365_msdyn_priority_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_project', 'silver', 'oss.coe.glb.d365_msdyn_project_silver', 86400),
            ('oss.coe.glb.d365', 'msdyn_project', 'bronze', 'oss.coe.glb.d365_msdyn_project_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_projectapproval', 'silver', 'oss.coe.glb.d365_msdyn_projectapproval_silver', 86400),
            ('oss.coe.glb.d365', 'msdyn_projectapproval', 'bronze', 'oss.coe.glb.d365_msdyn_projectapproval_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_projecttask', 'silver', 'oss.coe.glb.d365_msdyn_projecttask_silver', 86400),
            ('oss.coe.glb.d365', 'msdyn_projecttask', 'bronze', 'oss.coe.glb.d365_msdyn_projecttask_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_resourcerequirement', 'silver', 'oss.coe.glb.d365_msdyn_resourcerequirement_silver', 86400), 
            ('oss.coe.glb.d365', 'msdyn_resourcerequirement', 'bronze', 'oss.coe.glb.d365_msdyn_resourcerequirement_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_survey', 'silver', 'oss.coe.glb.d365_msdyn_survey_silver', 86400), 
            ('oss.coe.glb.d365', 'msdyn_survey', 'bronze', 'oss.coe.glb.d365_msdyn_survey_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_timeentry', 'silver', 'oss.coe.glb.d365_msdyn_timeentry_silver', 86400),
            ('oss.coe.glb.d365', 'msdyn_timeentry', 'bronze', 'oss.coe.glb.d365_msdyn_timeentry_bronze', 86400),
            ('oss.coe.glb.d365', 'msdyn_workorder', 'silver', 'oss.coe.glb.d365_msdyn_workorder_silver', 86400), 
            ('oss.coe.glb.d365', 'msdyn_workorder', 'bronze', 'oss.coe.glb.d365_msdyn_workorder_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_workordertype', 'silver', 'oss.coe.glb.d365_msdyn_workordertype_silver', 86400),
            ('oss.coe.glb.d365', 'msdyn_workordertype', 'bronze', 'oss.coe.glb.d365_msdyn_workordertype_bronze', 86400), 
            ('oss.coe.glb.d365', 'pricelevel', 'silver', 'oss.coe.glb.d365_pricelevel_silver', 86400), 
            ('oss.coe.glb.d365', 'pricelevel', 'bronze', 'oss.coe.glb.d365_pricelevel_bronze', 86400), 
            ('oss.coe.glb.d365', 'queue', 'silver', 'oss.coe.glb.d365_queue_silver', 86400), 
            ('oss.coe.glb.d365', 'queue', 'bronze', 'oss.coe.glb.d365_queue_bronze', 86400), 
            ('oss.coe.glb.d365', 'quote', 'silver', 'oss.coe.glb.d365_quote_silver', 86400), 
            ('oss.coe.glb.d365', 'quote', 'bronze', 'oss.coe.glb.d365_quote_bronze', 86400),
            ('oss.coe.glb.d365', 'role', 'silver', 'oss.coe.glb.d365_role_silver', 86400), 
            ('oss.coe.glb.d365', 'role', 'bronze', 'oss.coe.glb.d365_role_bronze', 86400), 
            ('oss.coe.glb.d365', 'sdxmob_facility', 'silver', 'oss.coe.glb.d365_sdxmob_facility_silver', 86400), 
            ('oss.coe.glb.d365', 'sdxmob_facility', 'bronze', 'oss.coe.glb.d365_sdxmob_facility_bronze', 86400), 
            ('oss.coe.glb.d365', 'sla', 'silver', 'oss.coe.glb.d365_sla_silver', 86400), 
            ('oss.coe.glb.d365', 'sla', 'bronze', 'oss.coe.glb.d365_sla_bronze', 86400), 
            ('oss.coe.glb.d365', 'slaitem', 'silver', 'oss.coe.glb.d365_slaitem_silver', 86400), 
            ('oss.coe.glb.d365', 'slaitem', 'bronze', 'oss.coe.glb.d365_slaitem_bronze', 86400), 
            ('oss.coe.glb.d365', 'slakpiinstance', 'silver', 'oss.coe.glb.d365_slakpiinstance_silver', 86400), 
            ('oss.coe.glb.d365', 'slakpiinstance', 'bronze', 'oss.coe.glb.d365_slakpiinstance_bronze', 86400), 
            ('oss.coe.glb.d365', 'systemuser', 'silver', 'oss.coe.glb.d365_systemuser_silver', 86400), 
            ('oss.coe.glb.d365', 'systemuser', 'bronze', 'oss.coe.glb.d365_systemuser_bronze', 86400), 
            ('oss.coe.glb.d365', 'timezonedefinition', 'silver', 'oss.coe.glb.d365_timezonedefinition_silver', 86400), 
            ('oss.coe.glb.d365', 'timezonedefinition', 'bronze', 'oss.coe.glb.d365_timezonedefinition_bronze', 86400), 
            ('oss.coe.glb.d365', 'timezonerule', 'silver', 'oss.coe.glb.d365_timezonerule_silver', 86400), 
            ('oss.coe.glb.d365', 'timezonerule', 'bronze', 'oss.coe.glb.d365_timezonerule_bronze', 86400), 
            ('oss.coe.glb.d365', 'transactioncurrency', 'silver', 'oss.coe.glb.d365_transactioncurrency_silver', 86400), 
            ('oss.coe.glb.d365', 'transactioncurrency', 'bronze', 'oss.coe.glb.d365_transactioncurrency_bronze', 86400),
            ('oss.noram.glb.d365', 'account', 'silver', 'oss.noram.glb.d365_account_silver', 86400),
            ('oss.noram.glb.d365', 'account', 'bronze', 'oss.noram.glb.d365_account_bronze', 86400),
            ('oss.noram.glb.d365', 'activitypointer', 'silver', 'oss.noram.glb.d365_activitypointer_silver', 86400),
            ('oss.noram.glb.d365', 'activitypointer', 'bronze', 'oss.noram.glb.d365_activitypointer_bronze', 86400),
            ('oss.noram.glb.d365', 'adx_portalcomment', 'silver', 'oss.noram.glb.d365_adx_portalcomment_silver', 86400),
            ('oss.noram.glb.d365', 'adx_portalcomment', 'bronze', 'oss.noram.glb.d365_adx_portalcomment_bronze', 86400),
            ('oss.noram.glb.d365', 'annotation', 'silver', 'oss.noram.glb.d365_annotation_silver', 86400), 
            ('oss.noram.glb.d365', 'annotation', 'bronze', 'oss.noram.glb.d365_annotation_bronze', 86400), 
            ('oss.noram.glb.d365', 'bookableresource', 'silver', 'oss.noram.glb.d365_bookableresource_silver', 86400), 
            ('oss.noram.glb.d365', 'bookableresource', 'bronze', 'oss.noram.glb.d365_bookableresource_bronze', 86400), 
            ('oss.noram.glb.d365', 'bookableresourcebooking', 'silver', 'oss.noram.glb.d365_bookableresourcebooking_silver', 86400), 
            ('oss.noram.glb.d365', 'bookableresourcebooking', 'bronze', 'oss.noram.glb.d365_bookableresourcebooking_bronze', 86400), 
            ('oss.noram.glb.d365', 'bookableresourcecategory', 'silver', 'oss.noram.glb.d365_bookableresourcecategory_silver', 86400), 
            ('oss.noram.glb.d365', 'bookableresourcecategory', 'bronze', 'oss.noram.glb.d365_bookableresourcecategory_bronze', 86400), 
            ('oss.noram.glb.d365', 'contact', 'silver', 'oss.noram.glb.d365_contact_silver', 86400), 
            ('oss.noram.glb.d365', 'contact', 'bronze', 'oss.noram.glb.d365_contact_bronze', 86400),
            ('oss.noram.glb.d365', 'contract', 'silver', 'oss.noram.glb.d365_contract_silver', 86400),
            ('oss.noram.glb.d365', 'contract', 'bronze', 'oss.noram.glb.d365_contract_bronze', 86400), 
            ('oss.noram.glb.d365', 'entitlement', 'silver', 'oss.noram.glb.d365_entitlement_silver', 86400), 
            ('oss.noram.glb.d365', 'entitlement', 'bronze', 'oss.noram.glb.d365_entitlement_bronze', 86400),
            ('oss.noram.glb.d365', 'ifm_assettype', 'silver', 'oss.noram.glb.d365_ifm_assettype_silver', 86400), 
            ('oss.noram.glb.d365', 'ifm_assettype', 'bronze', 'oss.noram.glb.d365_ifm_assettype_bronze', 86400), 
            ('oss.noram.glb.d365', 'ifm_contract', 'silver', 'oss.noram.glb.d365_ifm_contract_silver', 86400),
            ('oss.noram.glb.d365', 'ifm_contract', 'bronze', 'oss.noram.glb.d365_ifm_contract_bronze', 86400), 
            ('oss.noram.glb.d365', 'ifm_country', 'silver', 'oss.noram.glb.d365_ifm_country_silver', 86400), 
            ('oss.noram.glb.d365', 'ifm_country', 'bronze', 'oss.noram.glb.d365_ifm_country_bronze', 86400),
            ('oss.noram.glb.d365', 'ifm_feedback', 'silver', 'oss.noram.glb.d365_ifm_feedback_silver', 86400), 
            ('oss.noram.glb.d365', 'ifm_feedback', 'bronze', 'oss.noram.glb.d365_ifm_feedback_bronze', 86400), 
            ('oss.noram.glb.d365', 'ifm_log', 'silver', 'oss.noram.glb.d365_ifm_log_silver', 86400), 
            ('oss.noram.glb.d365', 'ifm_log', 'bronze', 'oss.noram.glb.d365_ifm_log_bronze', 86400), 
            ('oss.noram.glb.d365', 'ifm_masterservicecategory', 'silver', 'oss.noram.glb.d365_ifm_masterservicecategory_silver', 86400), 
            ('oss.noram.glb.d365', 'ifm_masterservicecategory', 'bronze', 'oss.noram.glb.d365_ifm_masterservicecategory_bronze', 86400), 
            ('oss.noram.glb.d365', 'ifm_servicecategory', 'silver', 'oss.noram.glb.d365_ifm_servicecategory_silver', 86400), 
            ('oss.noram.glb.d365', 'ifm_servicecategory', 'bronze', 'oss.noram.glb.d365_ifm_servicecategory_bronze', 86400), 
            ('oss.noram.glb.d365', 'ifm_workordernote', 'silver', 'oss.noram.glb.d365_ifm_workordernote_silver', 86400), 
            ('oss.noram.glb.d365', 'ifm_workordernote', 'bronze', 'oss.noram.glb.d365_ifm_workordernote_bronze', 86400), 
            ('oss.noram.glb.d365', 'incident', 'silver', 'oss.noram.glb.d365_incident_silver', 86400), 
            ('oss.noram.glb.d365', 'incident', 'bronze', 'oss.noram.glb.d365_incident_bronze', 86400),
            ('oss.noram.glb.d365', 'incidentresolution', 'silver', 'oss.noram.glb.d365_incidentresolution_silver', 86400), 
            ('oss.noram.glb.d365', 'incidentresolution', 'bronze', 'oss.noram.glb.d365_incidentresolution_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_agreement', 'silver', 'oss.noram.glb.d365_msdyn_agreement_silver', 86400),
            ('oss.noram.glb.d365', 'msdyn_agreement', 'bronze', 'oss.noram.glb.d365_msdyn_agreement_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_customerasset', 'silver', 'oss.noram.glb.d365_msdyn_customerasset_silver', 86400), 
            ('oss.noram.glb.d365', 'msdyn_customerasset', 'bronze', 'oss.noram.glb.d365_msdyn_customerasset_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_expense', 'silver', 'oss.noram.glb.d365_msdyn_expense_silver', 86400),
            ('oss.noram.glb.d365', 'msdyn_expense', 'bronze', 'oss.noram.glb.d365_msdyn_expense_bronze', 86400),
            ('oss.noram.glb.d365', 'msdyn_priority', 'silver', 'oss.noram.glb.d365_msdyn_priority_silver', 86400),
            ('oss.noram.glb.d365', 'msdyn_priority', 'bronze', 'oss.noram.glb.d365_msdyn_priority_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_project', 'silver', 'oss.noram.glb.d365_msdyn_project_silver', 86400),
            ('oss.noram.glb.d365', 'msdyn_project', 'bronze', 'oss.noram.glb.d365_msdyn_project_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_projectapproval', 'silver', 'oss.noram.glb.d365_msdyn_projectapproval_silver', 86400),
            ('oss.noram.glb.d365', 'msdyn_projectapproval', 'bronze', 'oss.noram.glb.d365_msdyn_projectapproval_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_projecttask', 'silver', 'oss.noram.glb.d365_msdyn_projecttask_silver', 86400),
            ('oss.noram.glb.d365', 'msdyn_projecttask', 'bronze', 'oss.noram.glb.d365_msdyn_projecttask_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_resourcerequirement', 'silver', 'oss.noram.glb.d365_msdyn_resourcerequirement_silver', 86400), 
            ('oss.noram.glb.d365', 'msdyn_resourcerequirement', 'bronze', 'oss.noram.glb.d365_msdyn_resourcerequirement_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_survey', 'silver', 'oss.noram.glb.d365_msdyn_survey_silver', 86400), 
            ('oss.noram.glb.d365', 'msdyn_survey', 'bronze', 'oss.noram.glb.d365_msdyn_survey_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_timeentry', 'silver', 'oss.noram.glb.d365_msdyn_timeentry_silver', 86400),
            ('oss.noram.glb.d365', 'msdyn_timeentry', 'bronze', 'oss.noram.glb.d365_msdyn_timeentry_bronze', 86400),
            ('oss.noram.glb.d365', 'msdyn_workorder', 'silver', 'oss.noram.glb.d365_msdyn_workorder_silver', 86400), 
            ('oss.noram.glb.d365', 'msdyn_workorder', 'bronze', 'oss.noram.glb.d365_msdyn_workorder_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_workordertype', 'silver', 'oss.noram.glb.d365_msdyn_workordertype_silver', 86400),
            ('oss.noram.glb.d365', 'msdyn_workordertype', 'bronze', 'oss.noram.glb.d365_msdyn_workordertype_bronze', 86400), 
            ('oss.noram.glb.d365', 'pricelevel', 'silver', 'oss.noram.glb.d365_pricelevel_silver', 86400), 
            ('oss.noram.glb.d365', 'pricelevel', 'bronze', 'oss.noram.glb.d365_pricelevel_bronze', 86400), 
            ('oss.noram.glb.d365', 'queue', 'silver', 'oss.noram.glb.d365_queue_silver', 86400), 
            ('oss.noram.glb.d365', 'queue', 'bronze', 'oss.noram.glb.d365_queue_bronze', 86400), 
            ('oss.noram.glb.d365', 'quote', 'silver', 'oss.noram.glb.d365_quote_silver', 86400), 
            ('oss.noram.glb.d365', 'quote', 'bronze', 'oss.noram.glb.d365_quote_bronze', 86400),
            ('oss.noram.glb.d365', 'role', 'silver', 'oss.noram.glb.d365_role_silver', 86400), 
            ('oss.noram.glb.d365', 'role', 'bronze', 'oss.noram.glb.d365_role_bronze', 86400), 
            ('oss.noram.glb.d365', 'sdxmob_facility', 'silver', 'oss.noram.glb.d365_sdxmob_facility_silver', 86400), 
            ('oss.noram.glb.d365', 'sdxmob_facility', 'bronze', 'oss.noram.glb.d365_sdxmob_facility_bronze', 86400), 
            ('oss.noram.glb.d365', 'sla', 'silver', 'oss.noram.glb.d365_sla_silver', 86400), 
            ('oss.noram.glb.d365', 'sla', 'bronze', 'oss.noram.glb.d365_sla_bronze', 86400), 
            ('oss.noram.glb.d365', 'slaitem', 'silver', 'oss.noram.glb.d365_slaitem_silver', 86400), 
            ('oss.noram.glb.d365', 'slaitem', 'bronze', 'oss.noram.glb.d365_slaitem_bronze', 86400), 
            ('oss.noram.glb.d365', 'slakpiinstance', 'silver', 'oss.noram.glb.d365_slakpiinstance_silver', 86400), 
            ('oss.noram.glb.d365', 'slakpiinstance', 'bronze', 'oss.noram.glb.d365_slakpiinstance_bronze', 86400), 
            ('oss.noram.glb.d365', 'systemuser', 'silver', 'oss.noram.glb.d365_systemuser_silver', 86400), 
            ('oss.noram.glb.d365', 'systemuser', 'bronze', 'oss.noram.glb.d365_systemuser_bronze', 86400), 
            ('oss.noram.glb.d365', 'timezonedefinition', 'silver', 'oss.noram.glb.d365_timezonedefinition_silver', 86400), 
            ('oss.noram.glb.d365', 'timezonedefinition', 'bronze', 'oss.noram.glb.d365_timezonedefinition_bronze', 86400), 
            ('oss.noram.glb.d365', 'timezonerule', 'silver', 'oss.noram.glb.d365_timezonerule_silver', 86400), 
            ('oss.noram.glb.d365', 'timezonerule', 'bronze', 'oss.noram.glb.d365_timezonerule_bronze', 86400), 
            ('oss.noram.glb.d365', 'transactioncurrency', 'silver', 'oss.noram.glb.d365_transactioncurrency_silver', 86400), 
            ('oss.noram.glb.d365', 'transactioncurrency', 'bronze', 'oss.noram.glb.d365_transactioncurrency_bronze', 86400)) AS t (project_name, dataset_name, landing_zone, context_id, ttl)
                WHERE context_id IN (${context:sqlstring}+'')
            ),
            RawEvents AS (
                SELECT
                    [timestamp],
                    context_id,
                    job_id,
                    metric_value
                FROM
                    [observability].[event]
                WHERE
                    metric_name = 'processing_exit_code'
                    AND event_type = 'processingfinished'
                    AND context_id IN (${context:sqlstring}+'')
                    AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
            ),
            DistinctJobs AS (
                SELECT DISTINCT
                    context_id,
                    job_id,
                    metric_value
                FROM
                    RawEvents
            ),
            IngestionSum AS (
                SELECT
                    context_id,
                    SUM(CASE WHEN metric_value = 0 THEN 1 ELSE 0 END) AS Succeeded,
                    SUM(CASE WHEN metric_value = 1 THEN 1 ELSE 0 END) AS No_Data,
                    SUM(CASE WHEN metric_value = -1 THEN 1 ELSE 0 END) AS Failed
                FROM
                    DistinctJobs
                GROUP BY
                    context_id
            ),
            FilteredAndAdded AS (
                SELECT
                    timestamp,
                    context_id,
                    metric_value
                FROM (
                    SELECT
                        timestamp,
                        context_id,
                        metric_value
                    FROM
                        RawEvents
                    WHERE
                        metric_value = 0
    
                    UNION ALL
    
                    SELECT
                        $__unixEpochTo() AS timestamp,  -- Current UTC timestamp as Unix time
                        context_id,
                        0 AS metric_value
                    FROM
                        (SELECT DISTINCT context_id FROM RawEvents WHERE metric_value = 0) AS UniqueContexts
    
                    UNION ALL
    
                    SELECT
                        $__unixEpochFrom() AS timestamp,  -- Current UTC timestamp as Unix time
                        context_id,
                        0 AS metric_value
                    FROM (SELECT DISTINCT context_id FROM RawEvents WHERE metric_value = 0) AS UniqueContexts
                ) AS CombinedFilteredResults
        	),
            EventDifferences AS (
                SELECT
                    context_id,
                    timestamp,
                    metric_value,
                    LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
                    CASE
                        WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                            timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                        ELSE NULL
                    END AS time_difference
                FROM
                    FilteredAndAdded
                WHERE
                    metric_value = 0
            ),
            Slis AS (
                SELECT
                    cv.project_name AS 'Application Source',
                    cv.dataset_name AS 'DatasetName',
                    cv.landing_zone AS 'Zone',
                    cv.ttl AS 'TTL',
                    COALESCE(iso.Succeeded, 0) AS 'Succeeded',
                    COALESCE(iso.No_Data, 0) AS 'No New Data',
                    COALESCE(iso.Failed, 0) AS 'Failed',
                    COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
                    CASE
                        WHEN COALESCE(iso.Succeeded, 0) = 0 THEN 0
                        WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
                        ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / ($__unixEpochTo() - $__unixEpochFrom()))
                    END AS SLI
                FROM
                    CombinedValues AS cv
                LEFT JOIN
                    IngestionSum AS iso
                ON
                    cv.context_id = iso.context_id
                LEFT JOIN
                    EventDifferences AS ed
                ON
                    cv.context_id = ed.context_id
                    AND ed.time_difference > cv.ttl
                GROUP BY
                    cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed
            )
            select AVG(SLI) as 'SLI Percentage',DatasetName as 'Dataset Name' from Slis
            group by DatasetName";

    grafana.barChart.new(
        title='D365 SLI',
        datasource='IFM Azure SQL Server',
        description= "The SLI(Service Level Indicator) is a measurable metric closely monitored by stakeholders to
        evaluate the operational performance and efficiency of a data ingestion pipeline. It is calculated here as a 
        percentage of up-to-date ingestions, by calculating the percentage of ingestionDelay for ingestions against 
        the specific timeframe(by application source, dataset name, zone). An ingestion is up to date if the difference 
        between two ingestions is lower than the ttl. For Example, If there is no IngestionDelay for ingestions over 
        specific timeframe then SLI is 100.")
        .addTarget(target=grafana.sql.target(rawSql=sqlQuery, format='table')
        ).addOption('xTickLabelRotation',60
        ).addOption('xTickLabelMaxLength', 100
        ).addOption('colorByField', 'SLI Percentage'
        ).addOption('showValue','always'
        ).addOption('barWidth',0.9
        ).addOverridesByFieldName(field='SLI Percentage',properties=[{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'light-red', value: null },{ color: 'light-green', value: 80 }]}},{id:'color',value:{mode : 'thresholds'}},{id: 'custom.axisSoftMax', value: 110},{id: 'custom.text',valueSize: 15}]
);

local SLIForCOED365 =
    local D365SqlQuery = "
    
    WITH
        CombinedValues AS (
            SELECT *
            FROM (VALUES ('oss.coe.glb.d365', 'account', 'silver', 'oss.coe.glb.d365_account_silver', 86400),
            ('oss.coe.glb.d365', 'account', 'bronze', 'oss.coe.glb.d365_account_bronze', 86400),
            ('oss.coe.glb.d365', 'activitypointer', 'silver', 'oss.coe.glb.d365_activitypointer_silver', 86400),
            ('oss.coe.glb.d365', 'activitypointer', 'bronze', 'oss.coe.glb.d365_activitypointer_bronze', 86400),
            ('oss.coe.glb.d365', 'adx_portalcomment', 'silver', 'oss.coe.glb.d365_adx_portalcomment_silver', 86400),
            ('oss.coe.glb.d365', 'adx_portalcomment', 'bronze', 'oss.coe.glb.d365_adx_portalcomment_bronze', 86400),
            ('oss.coe.glb.d365', 'annotation', 'silver', 'oss.coe.glb.d365_annotation_silver', 86400), 
            ('oss.coe.glb.d365', 'annotation', 'bronze', 'oss.coe.glb.d365_annotation_bronze', 86400), 
            ('oss.coe.glb.d365', 'bookableresource', 'silver', 'oss.coe.glb.d365_bookableresource_silver', 86400), 
            ('oss.coe.glb.d365', 'bookableresource', 'bronze', 'oss.coe.glb.d365_bookableresource_bronze', 86400), 
            ('oss.coe.glb.d365', 'bookableresourcebooking', 'silver', 'oss.coe.glb.d365_bookableresourcebooking_silver', 86400), 
            ('oss.coe.glb.d365', 'bookableresourcebooking', 'bronze', 'oss.coe.glb.d365_bookableresourcebooking_bronze', 86400), 
            ('oss.coe.glb.d365', 'bookableresourcecategory', 'silver', 'oss.coe.glb.d365_bookableresourcecategory_silver', 86400), 
            ('oss.coe.glb.d365', 'bookableresourcecategory', 'bronze', 'oss.coe.glb.d365_bookableresourcecategory_bronze', 86400), 
            ('oss.coe.glb.d365', 'contact', 'silver', 'oss.coe.glb.d365_contact_silver', 86400), 
            ('oss.coe.glb.d365', 'contact', 'bronze', 'oss.coe.glb.d365_contact_bronze', 86400),
            ('oss.coe.glb.d365', 'contract', 'silver', 'oss.coe.glb.d365_contract_silver', 86400),
            ('oss.coe.glb.d365', 'contract', 'bronze', 'oss.coe.glb.d365_contract_bronze', 86400), 
            ('oss.coe.glb.d365', 'entitlement', 'silver', 'oss.coe.glb.d365_entitlement_silver', 86400), 
            ('oss.coe.glb.d365', 'entitlement', 'bronze', 'oss.coe.glb.d365_entitlement_bronze', 86400),
            ('oss.coe.glb.d365', 'ifm_assettype', 'silver', 'oss.coe.glb.d365_ifm_assettype_silver', 86400), 
            ('oss.coe.glb.d365', 'ifm_assettype', 'bronze', 'oss.coe.glb.d365_ifm_assettype_bronze', 86400), 
            ('oss.coe.glb.d365', 'ifm_contract', 'silver', 'oss.coe.glb.d365_ifm_contract_silver', 86400),
            ('oss.coe.glb.d365', 'ifm_contract', 'bronze', 'oss.coe.glb.d365_ifm_contract_bronze', 86400), 
            ('oss.coe.glb.d365', 'ifm_country', 'silver', 'oss.coe.glb.d365_ifm_country_silver', 86400), 
            ('oss.coe.glb.d365', 'ifm_country', 'bronze', 'oss.coe.glb.d365_ifm_country_bronze', 86400),
            ('oss.coe.glb.d365', 'ifm_feedback', 'silver', 'oss.coe.glb.d365_ifm_feedback_silver', 86400), 
            ('oss.coe.glb.d365', 'ifm_feedback', 'bronze', 'oss.coe.glb.d365_ifm_feedback_bronze', 86400), 
            ('oss.coe.glb.d365', 'ifm_log', 'silver', 'oss.coe.glb.d365_ifm_log_silver', 86400), 
            ('oss.coe.glb.d365', 'ifm_log', 'bronze', 'oss.coe.glb.d365_ifm_log_bronze', 86400), 
            ('oss.coe.glb.d365', 'ifm_masterservicecategory', 'silver', 'oss.coe.glb.d365_ifm_masterservicecategory_silver', 86400), 
            ('oss.coe.glb.d365', 'ifm_masterservicecategory', 'bronze', 'oss.coe.glb.d365_ifm_masterservicecategory_bronze', 86400), 
            ('oss.coe.glb.d365', 'ifm_servicecategory', 'silver', 'oss.coe.glb.d365_ifm_servicecategory_silver', 86400), 
            ('oss.coe.glb.d365', 'ifm_servicecategory', 'bronze', 'oss.coe.glb.d365_ifm_servicecategory_bronze', 86400), 
            ('oss.coe.glb.d365', 'ifm_workordernote', 'silver', 'oss.coe.glb.d365_ifm_workordernote_silver', 86400), 
            ('oss.coe.glb.d365', 'ifm_workordernote', 'bronze', 'oss.coe.glb.d365_ifm_workordernote_bronze', 86400), 
            ('oss.coe.glb.d365', 'incident', 'silver', 'oss.coe.glb.d365_incident_silver', 86400), 
            ('oss.coe.glb.d365', 'incident', 'bronze', 'oss.coe.glb.d365_incident_bronze', 86400),
            ('oss.coe.glb.d365', 'incidentresolution', 'silver', 'oss.coe.glb.d365_incidentresolution_silver', 86400), 
            ('oss.coe.glb.d365', 'incidentresolution', 'bronze', 'oss.coe.glb.d365_incidentresolution_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_agreement', 'silver', 'oss.coe.glb.d365_msdyn_agreement_silver', 86400),
            ('oss.coe.glb.d365', 'msdyn_agreement', 'bronze', 'oss.coe.glb.d365_msdyn_agreement_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_customerasset', 'silver', 'oss.coe.glb.d365_msdyn_customerasset_silver', 86400), 
            ('oss.coe.glb.d365', 'msdyn_customerasset', 'bronze', 'oss.coe.glb.d365_msdyn_customerasset_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_expense', 'silver', 'oss.coe.glb.d365_msdyn_expense_silver', 86400),
            ('oss.coe.glb.d365', 'msdyn_expense', 'bronze', 'oss.coe.glb.d365_msdyn_expense_bronze', 86400),
            ('oss.coe.glb.d365', 'msdyn_priority', 'silver', 'oss.coe.glb.d365_msdyn_priority_silver', 86400),
            ('oss.coe.glb.d365', 'msdyn_priority', 'bronze', 'oss.coe.glb.d365_msdyn_priority_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_project', 'silver', 'oss.coe.glb.d365_msdyn_project_silver', 86400),
            ('oss.coe.glb.d365', 'msdyn_project', 'bronze', 'oss.coe.glb.d365_msdyn_project_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_projectapproval', 'silver', 'oss.coe.glb.d365_msdyn_projectapproval_silver', 86400),
            ('oss.coe.glb.d365', 'msdyn_projectapproval', 'bronze', 'oss.coe.glb.d365_msdyn_projectapproval_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_projecttask', 'silver', 'oss.coe.glb.d365_msdyn_projecttask_silver', 86400),
            ('oss.coe.glb.d365', 'msdyn_projecttask', 'bronze', 'oss.coe.glb.d365_msdyn_projecttask_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_resourcerequirement', 'silver', 'oss.coe.glb.d365_msdyn_resourcerequirement_silver', 86400), 
            ('oss.coe.glb.d365', 'msdyn_resourcerequirement', 'bronze', 'oss.coe.glb.d365_msdyn_resourcerequirement_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_survey', 'silver', 'oss.coe.glb.d365_msdyn_survey_silver', 86400), 
            ('oss.coe.glb.d365', 'msdyn_survey', 'bronze', 'oss.coe.glb.d365_msdyn_survey_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_timeentry', 'silver', 'oss.coe.glb.d365_msdyn_timeentry_silver', 86400),
            ('oss.coe.glb.d365', 'msdyn_timeentry', 'bronze', 'oss.coe.glb.d365_msdyn_timeentry_bronze', 86400),
            ('oss.coe.glb.d365', 'msdyn_workorder', 'silver', 'oss.coe.glb.d365_msdyn_workorder_silver', 86400), 
            ('oss.coe.glb.d365', 'msdyn_workorder', 'bronze', 'oss.coe.glb.d365_msdyn_workorder_bronze', 86400), 
            ('oss.coe.glb.d365', 'msdyn_workordertype', 'silver', 'oss.coe.glb.d365_msdyn_workordertype_silver', 86400),
            ('oss.coe.glb.d365', 'msdyn_workordertype', 'bronze', 'oss.coe.glb.d365_msdyn_workordertype_bronze', 86400), 
            ('oss.coe.glb.d365', 'pricelevel', 'silver', 'oss.coe.glb.d365_pricelevel_silver', 86400), 
            ('oss.coe.glb.d365', 'pricelevel', 'bronze', 'oss.coe.glb.d365_pricelevel_bronze', 86400), 
            ('oss.coe.glb.d365', 'queue', 'silver', 'oss.coe.glb.d365_queue_silver', 86400), 
            ('oss.coe.glb.d365', 'queue', 'bronze', 'oss.coe.glb.d365_queue_bronze', 86400), 
            ('oss.coe.glb.d365', 'quote', 'silver', 'oss.coe.glb.d365_quote_silver', 86400), 
            ('oss.coe.glb.d365', 'quote', 'bronze', 'oss.coe.glb.d365_quote_bronze', 86400),
            ('oss.coe.glb.d365', 'role', 'silver', 'oss.coe.glb.d365_role_silver', 86400), 
            ('oss.coe.glb.d365', 'role', 'bronze', 'oss.coe.glb.d365_role_bronze', 86400), 
            ('oss.coe.glb.d365', 'sdxmob_facility', 'silver', 'oss.coe.glb.d365_sdxmob_facility_silver', 86400), 
            ('oss.coe.glb.d365', 'sdxmob_facility', 'bronze', 'oss.coe.glb.d365_sdxmob_facility_bronze', 86400), 
            ('oss.coe.glb.d365', 'sla', 'silver', 'oss.coe.glb.d365_sla_silver', 86400), 
            ('oss.coe.glb.d365', 'sla', 'bronze', 'oss.coe.glb.d365_sla_bronze', 86400), 
            ('oss.coe.glb.d365', 'slaitem', 'silver', 'oss.coe.glb.d365_slaitem_silver', 86400), 
            ('oss.coe.glb.d365', 'slaitem', 'bronze', 'oss.coe.glb.d365_slaitem_bronze', 86400), 
            ('oss.coe.glb.d365', 'slakpiinstance', 'silver', 'oss.coe.glb.d365_slakpiinstance_silver', 86400), 
            ('oss.coe.glb.d365', 'slakpiinstance', 'bronze', 'oss.coe.glb.d365_slakpiinstance_bronze', 86400), 
            ('oss.coe.glb.d365', 'systemuser', 'silver', 'oss.coe.glb.d365_systemuser_silver', 86400), 
            ('oss.coe.glb.d365', 'systemuser', 'bronze', 'oss.coe.glb.d365_systemuser_bronze', 86400), 
            ('oss.coe.glb.d365', 'timezonedefinition', 'silver', 'oss.coe.glb.d365_timezonedefinition_silver', 86400), 
            ('oss.coe.glb.d365', 'timezonedefinition', 'bronze', 'oss.coe.glb.d365_timezonedefinition_bronze', 86400), 
            ('oss.coe.glb.d365', 'timezonerule', 'silver', 'oss.coe.glb.d365_timezonerule_silver', 86400), 
            ('oss.coe.glb.d365', 'timezonerule', 'bronze', 'oss.coe.glb.d365_timezonerule_bronze', 86400), 
            ('oss.coe.glb.d365', 'transactioncurrency', 'silver', 'oss.coe.glb.d365_transactioncurrency_silver', 86400), 
            ('oss.coe.glb.d365', 'transactioncurrency', 'bronze', 'oss.coe.glb.d365_transactioncurrency_bronze', 86400)) As T (project_name, dataset_name, landing_zone, context_id, ttl)
    WHERE context_id IN (${context:sqlstring}+'')),
        RawEvents AS (
            SELECT
                [timestamp],
                DateName(mm,DATEADD(SECOND,timestamp,'1970-01-01')) + '-' + cast(datepart(yyyy, dateadd(second, timestamp, '1970-01-01')) as varchar(10)) as Month_Name,
                 context_id,
                 job_id,
                metric_value
            FROM
                [observability].[event]
            WHERE
                metric_name = 'processing_exit_code'
                AND event_type = 'processingfinished'
                 AND context_id IN (${context:sqlstring}+'')
				and cast(dateadd(second, [timestamp], '1970-01-01') as date) >= dateadd(month, -2, getdate())
        ),

        DistinctJobs AS (
            SELECT
                context_id,
                Month_Name,
                job_id,
                metric_value
            FROM
                RawEvents
        ),

        IngestionSum AS (
            SELECT
                context_id,Month_Name,
                SUM(CASE WHEN metric_value = 0 THEN 1 ELSE 0 END) AS Succeeded,
                SUM(CASE WHEN metric_value = 1 THEN 1 ELSE 0 END) AS No_Data,
                SUM(CASE WHEN metric_value = -1 THEN 1 ELSE 0 END) AS Failed
            FROM
                DistinctJobs
            GROUP BY
                context_id,Month_Name
        ),

		FilteredAndAddedM1 AS (
            SELECT
                timestamp,
                context_id,
                Month_Name,
                metric_value
            FROM
            (
                SELECT
                    timestamp,
                    context_id,
                    Month_Name,
                    metric_value
                FROM
                    RawEvents
                WHERE
                    metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-1,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -1, getdate())) as varchar(10))

                UNION ALL

                SELECT
                    DATEDIFF(second,'1970-01-01',DATEADD(SECOND, -1, DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(), -1))))) AS timestamp,  -- Current UTC timestamp as Unix time
                    context_id,Month_Name,
                    0 AS metric_value
                FROM
                    (SELECT DISTINCT context_id,Month_Name FROM RawEvents WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-1,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -1, getdate())) as varchar(10))) AS UniqueContexts

                UNION ALL

                SELECT
                    DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, EOMONTH(GETDATE(), -2))) AS timestamp,  -- Current UTC timestamp as Unix time
                    context_id,Month_Name,
                    0 AS metric_value
                FROM
                    (SELECT DISTINCT context_id,Month_Name FROM RawEvents WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-1,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -1, '1970-01-01')) as varchar(10))) AS UniqueContexts
            ) AS CombinedFilteredResults
        ),
        EventDifferencesM1 AS (
            SELECT
                context_id,
                timestamp,
                Month_Name,
                metric_value,
                LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
                CASE
                    WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                        timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                    ELSE NULL
                END AS time_difference
            FROM
                FilteredAndAddedM1
				),
        SLIM1 AS (
                SELECT
                    cv.project_name AS 'Application Source',
                    cv.dataset_name AS 'Dataset_Name',
                    cv.landing_zone AS 'Zone',
                    cv.ttl AS 'TTL',
                    iso.Month_Name as Month_name,
                    COALESCE(iso.Succeeded, 0) AS 'Succeeded',
                    COALESCE(iso.No_Data, 0) AS 'No New Data',
                    COALESCE(iso.Failed, 0) AS 'Failed',
                    COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
                    CASE
                        WHEN COALESCE(iso.Succeeded, 0) = 0 THEN 0
                        WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
                        ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / (DATEDIFF(second,'1970-01-01',DATEADD(SECOND, -1, DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(), -1)))))-DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, EOMONTH(GETDATE(), -2)))))
                    END AS SLIM1
                    
                FROM
                    CombinedValues AS cv
                LEFT JOIN
                    IngestionSum AS iso
                ON
                    cv.context_id = iso.context_id
                LEFT JOIN
                    EventDifferencesM1 AS ed
                ON
                    cv.context_id = ed.context_id
                    AND ed.time_difference > cv.ttl
                where iso.Month_Name=DateName(mm,DATEADD(month,-1,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -1, getdate())) as varchar(10))
                GROUP BY
                    cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed,iso.Month_Name
        ),

        FilteredAndAddedM2 AS (
            SELECT
                timestamp,
                context_id,
                Month_Name,
                metric_value
            FROM
            (
                SELECT
                    timestamp,
                    context_id,
                    Month_Name,
                    metric_value
                FROM
                    RawEvents
                WHERE
                    metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-2,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -2, getdate())) as varchar(10))

                UNION ALL

                SELECT
                    DATEDIFF(second,'1970-01-01',DATEADD(SECOND, -1, DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(), -2))))) AS timestamp,  -- Current UTC timestamp as Unix time
                    context_id,Month_Name,
                    0 AS metric_value
                FROM
                    (SELECT DISTINCT context_id,Month_Name FROM RawEvents WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-2,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -2, getdate())) as varchar(10))) AS UniqueContexts

                UNION ALL

                SELECT
                    DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, EOMONTH(GETDATE(), -3))) AS timestamp,  -- Current UTC timestamp as Unix time
                    context_id,Month_Name,
                    0 AS metric_value
                FROM
                    (SELECT DISTINCT context_id,Month_Name FROM RawEvents WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-2,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -2, '1970-01-01')) as varchar(10))) AS UniqueContexts
            ) AS CombinedFilteredResults
        ),

        EventDifferencesM2 AS (
            SELECT
                context_id,
                timestamp,
                Month_Name,
                metric_value,
                LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
                CASE
                    WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                        timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                    ELSE NULL
                END AS time_difference
            FROM
                FilteredAndAddedM2   
        ),
        SLIM2 AS (
            SELECT
                cv.project_name AS 'Application Source',
                cv.dataset_name AS 'Dataset_Name',
                cv.landing_zone AS 'Zone',
                cv.ttl AS 'TTL',
                iso.Month_Name as Month_name,
                COALESCE(iso.Succeeded, 0) AS 'Succeeded',
                COALESCE(iso.No_Data, 0) AS 'No New Data',
                COALESCE(iso.Failed, 0) AS 'Failed',
                COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
                CASE
                    WHEN COALESCE(iso.Succeeded, 0) = 0 THEN 0
                    WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
                    ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / (DATEDIFF(second,'1970-01-01',DATEADD(SECOND, -1, DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(), -2)))))-DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, EOMONTH(GETDATE(), -3)))))
                END AS SLIM2
                
            FROM
                CombinedValues AS cv
            LEFT JOIN
                IngestionSum AS iso
            ON
                cv.context_id = iso.context_id
            LEFT JOIN
                EventDifferencesM2 AS ed
            ON
                cv.context_id = ed.context_id
                AND ed.time_difference > cv.ttl
            where iso.Month_Name=DateName(mm,DATEADD(month,-2,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -2, getdate())) as varchar(10))
            GROUP BY
                cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed,iso.Month_Name
        ),
		 FilteredAndAddedM AS (
                SELECT
                    timestamp,
                    context_id,
                    Month_Name,
                    metric_value
                FROM
                (
                    SELECT
                        timestamp,
                        context_id,
                        Month_Name,
                        metric_value
                    FROM
                        RawEvents
                    WHERE
                        metric_value = 0 and  Month_Name=DateName(mm,DATEADD(month,0,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, 0, getdate())) as varchar(10))

                    UNION ALL

                    SELECT
                        DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(),-1)))) AS timestamp,  -- Current UTC timestamp as Unix time
                        context_id,Month_Name,
                        0 AS metric_value
                    FROM
                        (SELECT DISTINCT context_id,Month_Name FROM RawEvents WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,0,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, 0, getdate())) as varchar(10))) AS UniqueContexts

                    UNION ALL

                    SELECT
                        DATEDIFF(second,'1970-01-01',convert(date,GETDATE())) AS timestamp,  -- Current UTC timestamp as Unix time
                        context_id,Month_Name,
                        0 AS metric_value
                    FROM
                        (SELECT DISTINCT context_id,Month_Name FROM RawEvents WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-2,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -2, '1970-01-01')) as varchar(10))) AS UniqueContexts
                ) AS CombinedFilteredResults
            ),

            EventDifferencesM AS (
                SELECT
                    context_id,
                    timestamp,
                    Month_Name,
                    metric_value,
                    LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
                    CASE
                        WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                            timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                        ELSE NULL
                    END AS time_difference
                FROM
                    FilteredAndAddedM
                
            
            ),
            SLIM AS (
                SELECT
                    cv.project_name AS 'Application Source',
                    cv.dataset_name AS 'Dataset_Name',
                    cv.landing_zone AS 'Zone',
                    cv.ttl AS 'TTL',
                    iso.Month_Name as Month_name,
                    COALESCE(iso.Succeeded, 0) AS 'Succeeded',
                    COALESCE(iso.No_Data, 0) AS 'No New Data',
                    COALESCE(iso.Failed, 0) AS 'Failed',
                    COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
                    CASE
                        WHEN COALESCE(iso.Succeeded, 0) = 0 THEN 0
                        WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
                        ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / (DATEDIFF(second,'1970-01-01',convert(date,GETDATE()))-DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(),-1))))))
                    
                    END AS SLIM
                    
                FROM
                    CombinedValues AS cv
                LEFT JOIN
                    IngestionSum AS iso
                ON
                    cv.context_id = iso.context_id
                LEFT JOIN
                    EventDifferencesM AS ed
                ON
                    cv.context_id = ed.context_id
                    AND ed.time_difference > cv.ttl
                where iso.Month_Name=DateName(mm,DATEADD(month,0,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, 0, getdate())) as varchar(10))
                GROUP BY
                    cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed,iso.Month_Name
        ),
		SLITable as (
            SELECT s.[APPLICATION SOURCE] AS 'APPLICATION SOURCES', s.DATASET_NAME AS 'DATASET NAME', s.[ZONE] AS 'ZONE', SLIM, SLIM1, SLIM2
            FROM SLIM AS s
                INNER JOIN SLIM1 AS s1 ON s.[APPLICATION SOURCE]=s1.[APPLICATION SOURCE] AND s.DATASET_NAME=s1.DATASET_NAME AND s.[ZONE]=s1.[ZONE]
                INNER JOIN SLIM2 AS s2 ON s1.[APPLICATION SOURCE]=s2.[APPLICATION SOURCE] AND s1.DATASET_NAME=s2.DATASET_NAME AND s1.[ZONE]=s2.[ZONE]
        ),

        sliValues as (
            SELECT s.DATASET_NAME AS Dataset_Name, '80%' AS SLO, Avg(SLIM) AS SLI_CurrentMonth, Avg(SLIM1) AS SLI_PreviousMonth, Avg(SLIM2) AS SLI_LastBeforeMonth 
            FROM SLIM AS s
                INNER JOIN SLIM1 AS s1 ON s.DATASET_NAME=s1.DATASET_NAME
                INNER JOIN SLIM2 AS s2 ON s.DATASET_NAME=s2.DATASET_NAME
                where s.DATASET_NAME in ($dataset_name) 
            GROUP BY s.DATASET_NAME
        )
        SELECT * from sliValues
    ";  
    grafana.tablePanel.new(
        title='SLI for D365 - COE',
        datasource='IFM Azure SQL Server',
        description="SLI Of all data sets of D365 for last 3 months"
        ).addTarget(target=grafana.sql.target(rawSql = D365SqlQuery ,format='table')
        ).addOverridesByFieldName(field='SLI_CurrentMonth',properties=[{id: 'unit', value: 'percent'},{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'red', value: null },{ color: 'green', value: 80 }]}}]
        ).addOverridesByFieldName(field='SLI_PreviousMonth',properties=[{id: 'unit', value: 'percent'},{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'red', value: null },{ color: 'green', value: 80 }]}}]
        ).addOverridesByFieldName(field='SLI_LastBeforeMonth',properties=[{id: 'unit', value: 'percent'},{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'red', value: null },{ color: 'green', value: 80 }]}}]
);

local SLIForNoramD365 =
    local D365SqlQuery = "
    WITH
        CombinedValues AS (
            SELECT *
            FROM (VALUES ('oss.noram.glb.d365', 'account', 'silver', 'oss.noram.glb.d365_account_silver', 86400),
            ('oss.noram.glb.d365', 'account', 'bronze', 'oss.noram.glb.d365_account_bronze', 86400),
            ('oss.noram.glb.d365', 'activitypointer', 'silver', 'oss.noram.glb.d365_activitypointer_silver', 86400),
            ('oss.noram.glb.d365', 'activitypointer', 'bronze', 'oss.noram.glb.d365_activitypointer_bronze', 86400),
            ('oss.noram.glb.d365', 'adx_portalcomment', 'silver', 'oss.noram.glb.d365_adx_portalcomment_silver', 86400),
            ('oss.noram.glb.d365', 'adx_portalcomment', 'bronze', 'oss.noram.glb.d365_adx_portalcomment_bronze', 86400),
            ('oss.noram.glb.d365', 'annotation', 'silver', 'oss.noram.glb.d365_annotation_silver', 86400), 
            ('oss.noram.glb.d365', 'annotation', 'bronze', 'oss.noram.glb.d365_annotation_bronze', 86400), 
            ('oss.noram.glb.d365', 'bookableresource', 'silver', 'oss.noram.glb.d365_bookableresource_silver', 86400), 
            ('oss.noram.glb.d365', 'bookableresource', 'bronze', 'oss.noram.glb.d365_bookableresource_bronze', 86400), 
            ('oss.noram.glb.d365', 'bookableresourcebooking', 'silver', 'oss.noram.glb.d365_bookableresourcebooking_silver', 86400), 
            ('oss.noram.glb.d365', 'bookableresourcebooking', 'bronze', 'oss.noram.glb.d365_bookableresourcebooking_bronze', 86400), 
            ('oss.noram.glb.d365', 'bookableresourcecategory', 'silver', 'oss.noram.glb.d365_bookableresourcecategory_silver', 86400), 
            ('oss.noram.glb.d365', 'bookableresourcecategory', 'bronze', 'oss.noram.glb.d365_bookableresourcecategory_bronze', 86400), 
            ('oss.noram.glb.d365', 'contact', 'silver', 'oss.noram.glb.d365_contact_silver', 86400), 
            ('oss.noram.glb.d365', 'contact', 'bronze', 'oss.noram.glb.d365_contact_bronze', 86400),
            ('oss.noram.glb.d365', 'contract', 'silver', 'oss.noram.glb.d365_contract_silver', 86400),
            ('oss.noram.glb.d365', 'contract', 'bronze', 'oss.noram.glb.d365_contract_bronze', 86400), 
            ('oss.noram.glb.d365', 'entitlement', 'silver', 'oss.noram.glb.d365_entitlement_silver', 86400), 
            ('oss.noram.glb.d365', 'entitlement', 'bronze', 'oss.noram.glb.d365_entitlement_bronze', 86400),
            ('oss.noram.glb.d365', 'ifm_assettype', 'silver', 'oss.noram.glb.d365_ifm_assettype_silver', 86400), 
            ('oss.noram.glb.d365', 'ifm_assettype', 'bronze', 'oss.noram.glb.d365_ifm_assettype_bronze', 86400), 
            ('oss.noram.glb.d365', 'ifm_contract', 'silver', 'oss.noram.glb.d365_ifm_contract_silver', 86400),
            ('oss.noram.glb.d365', 'ifm_contract', 'bronze', 'oss.noram.glb.d365_ifm_contract_bronze', 86400), 
            ('oss.noram.glb.d365', 'ifm_country', 'silver', 'oss.noram.glb.d365_ifm_country_silver', 86400), 
            ('oss.noram.glb.d365', 'ifm_country', 'bronze', 'oss.noram.glb.d365_ifm_country_bronze', 86400),
            ('oss.noram.glb.d365', 'ifm_feedback', 'silver', 'oss.noram.glb.d365_ifm_feedback_silver', 86400), 
            ('oss.noram.glb.d365', 'ifm_feedback', 'bronze', 'oss.noram.glb.d365_ifm_feedback_bronze', 86400), 
            ('oss.noram.glb.d365', 'ifm_log', 'silver', 'oss.noram.glb.d365_ifm_log_silver', 86400), 
            ('oss.noram.glb.d365', 'ifm_log', 'bronze', 'oss.noram.glb.d365_ifm_log_bronze', 86400), 
            ('oss.noram.glb.d365', 'ifm_masterservicecategory', 'silver', 'oss.noram.glb.d365_ifm_masterservicecategory_silver', 86400), 
            ('oss.noram.glb.d365', 'ifm_masterservicecategory', 'bronze', 'oss.noram.glb.d365_ifm_masterservicecategory_bronze', 86400), 
            ('oss.noram.glb.d365', 'ifm_servicecategory', 'silver', 'oss.noram.glb.d365_ifm_servicecategory_silver', 86400), 
            ('oss.noram.glb.d365', 'ifm_servicecategory', 'bronze', 'oss.noram.glb.d365_ifm_servicecategory_bronze', 86400), 
            ('oss.noram.glb.d365', 'ifm_workordernote', 'silver', 'oss.noram.glb.d365_ifm_workordernote_silver', 86400), 
            ('oss.noram.glb.d365', 'ifm_workordernote', 'bronze', 'oss.noram.glb.d365_ifm_workordernote_bronze', 86400), 
            ('oss.noram.glb.d365', 'incident', 'silver', 'oss.noram.glb.d365_incident_silver', 86400), 
            ('oss.noram.glb.d365', 'incident', 'bronze', 'oss.noram.glb.d365_incident_bronze', 86400),
            ('oss.noram.glb.d365', 'incidentresolution', 'silver', 'oss.noram.glb.d365_incidentresolution_silver', 86400), 
            ('oss.noram.glb.d365', 'incidentresolution', 'bronze', 'oss.noram.glb.d365_incidentresolution_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_agreement', 'silver', 'oss.noram.glb.d365_msdyn_agreement_silver', 86400),
            ('oss.noram.glb.d365', 'msdyn_agreement', 'bronze', 'oss.noram.glb.d365_msdyn_agreement_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_customerasset', 'silver', 'oss.noram.glb.d365_msdyn_customerasset_silver', 86400), 
            ('oss.noram.glb.d365', 'msdyn_customerasset', 'bronze', 'oss.noram.glb.d365_msdyn_customerasset_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_expense', 'silver', 'oss.noram.glb.d365_msdyn_expense_silver', 86400),
            ('oss.noram.glb.d365', 'msdyn_expense', 'bronze', 'oss.noram.glb.d365_msdyn_expense_bronze', 86400),
            ('oss.noram.glb.d365', 'msdyn_priority', 'silver', 'oss.noram.glb.d365_msdyn_priority_silver', 86400),
            ('oss.noram.glb.d365', 'msdyn_priority', 'bronze', 'oss.noram.glb.d365_msdyn_priority_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_project', 'silver', 'oss.noram.glb.d365_msdyn_project_silver', 86400),
            ('oss.noram.glb.d365', 'msdyn_project', 'bronze', 'oss.noram.glb.d365_msdyn_project_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_projectapproval', 'silver', 'oss.noram.glb.d365_msdyn_projectapproval_silver', 86400),
            ('oss.noram.glb.d365', 'msdyn_projectapproval', 'bronze', 'oss.noram.glb.d365_msdyn_projectapproval_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_projecttask', 'silver', 'oss.noram.glb.d365_msdyn_projecttask_silver', 86400),
            ('oss.noram.glb.d365', 'msdyn_projecttask', 'bronze', 'oss.noram.glb.d365_msdyn_projecttask_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_resourcerequirement', 'silver', 'oss.noram.glb.d365_msdyn_resourcerequirement_silver', 86400), 
            ('oss.noram.glb.d365', 'msdyn_resourcerequirement', 'bronze', 'oss.noram.glb.d365_msdyn_resourcerequirement_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_survey', 'silver', 'oss.noram.glb.d365_msdyn_survey_silver', 86400), 
            ('oss.noram.glb.d365', 'msdyn_survey', 'bronze', 'oss.noram.glb.d365_msdyn_survey_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_timeentry', 'silver', 'oss.noram.glb.d365_msdyn_timeentry_silver', 86400),
            ('oss.noram.glb.d365', 'msdyn_timeentry', 'bronze', 'oss.noram.glb.d365_msdyn_timeentry_bronze', 86400),
            ('oss.noram.glb.d365', 'msdyn_workorder', 'silver', 'oss.noram.glb.d365_msdyn_workorder_silver', 86400), 
            ('oss.noram.glb.d365', 'msdyn_workorder', 'bronze', 'oss.noram.glb.d365_msdyn_workorder_bronze', 86400), 
            ('oss.noram.glb.d365', 'msdyn_workordertype', 'silver', 'oss.noram.glb.d365_msdyn_workordertype_silver', 86400),
            ('oss.noram.glb.d365', 'msdyn_workordertype', 'bronze', 'oss.noram.glb.d365_msdyn_workordertype_bronze', 86400), 
            ('oss.noram.glb.d365', 'pricelevel', 'silver', 'oss.noram.glb.d365_pricelevel_silver', 86400), 
            ('oss.noram.glb.d365', 'pricelevel', 'bronze', 'oss.noram.glb.d365_pricelevel_bronze', 86400), 
            ('oss.noram.glb.d365', 'queue', 'silver', 'oss.noram.glb.d365_queue_silver', 86400), 
            ('oss.noram.glb.d365', 'queue', 'bronze', 'oss.noram.glb.d365_queue_bronze', 86400), 
            ('oss.noram.glb.d365', 'quote', 'silver', 'oss.noram.glb.d365_quote_silver', 86400), 
            ('oss.noram.glb.d365', 'quote', 'bronze', 'oss.noram.glb.d365_quote_bronze', 86400),
            ('oss.noram.glb.d365', 'role', 'silver', 'oss.noram.glb.d365_role_silver', 86400), 
            ('oss.noram.glb.d365', 'role', 'bronze', 'oss.noram.glb.d365_role_bronze', 86400), 
            ('oss.noram.glb.d365', 'sdxmob_facility', 'silver', 'oss.noram.glb.d365_sdxmob_facility_silver', 86400), 
            ('oss.noram.glb.d365', 'sdxmob_facility', 'bronze', 'oss.noram.glb.d365_sdxmob_facility_bronze', 86400), 
            ('oss.noram.glb.d365', 'sla', 'silver', 'oss.noram.glb.d365_sla_silver', 86400), 
            ('oss.noram.glb.d365', 'sla', 'bronze', 'oss.noram.glb.d365_sla_bronze', 86400), 
            ('oss.noram.glb.d365', 'slaitem', 'silver', 'oss.noram.glb.d365_slaitem_silver', 86400), 
            ('oss.noram.glb.d365', 'slaitem', 'bronze', 'oss.noram.glb.d365_slaitem_bronze', 86400), 
            ('oss.noram.glb.d365', 'slakpiinstance', 'silver', 'oss.noram.glb.d365_slakpiinstance_silver', 86400), 
            ('oss.noram.glb.d365', 'slakpiinstance', 'bronze', 'oss.noram.glb.d365_slakpiinstance_bronze', 86400), 
            ('oss.noram.glb.d365', 'systemuser', 'silver', 'oss.noram.glb.d365_systemuser_silver', 86400), 
            ('oss.noram.glb.d365', 'systemuser', 'bronze', 'oss.noram.glb.d365_systemuser_bronze', 86400), 
            ('oss.noram.glb.d365', 'timezonedefinition', 'silver', 'oss.noram.glb.d365_timezonedefinition_silver', 86400), 
            ('oss.noram.glb.d365', 'timezonedefinition', 'bronze', 'oss.noram.glb.d365_timezonedefinition_bronze', 86400), 
            ('oss.noram.glb.d365', 'timezonerule', 'silver', 'oss.noram.glb.d365_timezonerule_silver', 86400), 
            ('oss.noram.glb.d365', 'timezonerule', 'bronze', 'oss.noram.glb.d365_timezonerule_bronze', 86400), 
            ('oss.noram.glb.d365', 'transactioncurrency', 'silver', 'oss.noram.glb.d365_transactioncurrency_silver', 86400), 
            ('oss.noram.glb.d365', 'transactioncurrency', 'bronze', 'oss.noram.glb.d365_transactioncurrency_bronze', 86400)) As T (project_name, dataset_name, landing_zone, context_id, ttl)
    WHERE context_id IN (${context:sqlstring}+'')),
        RawEvents AS (
            SELECT
                [timestamp],
                DateName(mm,DATEADD(SECOND,timestamp,'1970-01-01')) + '-' + cast(datepart(yyyy, dateadd(second, timestamp, '1970-01-01')) as varchar(10)) as Month_Name,
                 context_id,
                 job_id,
                metric_value
            FROM
                [observability].[event]
            WHERE
                metric_name = 'processing_exit_code'
                AND event_type = 'processingfinished'
                 AND context_id IN (${context:sqlstring}+'')
				and cast(dateadd(second, [timestamp], '1970-01-01') as date) >= dateadd(month, -2, getdate())
        ),

        DistinctJobs AS (
            SELECT
                context_id,
                Month_Name,
                job_id,
                metric_value
            FROM
                RawEvents
        ),

        IngestionSum AS (
            SELECT
                context_id,Month_Name,
                SUM(CASE WHEN metric_value = 0 THEN 1 ELSE 0 END) AS Succeeded,
                SUM(CASE WHEN metric_value = 1 THEN 1 ELSE 0 END) AS No_Data,
                SUM(CASE WHEN metric_value = -1 THEN 1 ELSE 0 END) AS Failed
            FROM
                DistinctJobs
            GROUP BY
                context_id,Month_Name
        ),

		FilteredAndAddedM1 AS (
            SELECT
                timestamp,
                context_id,
                Month_Name,
                metric_value
            FROM
            (
                SELECT
                    timestamp,
                    context_id,
                    Month_Name,
                    metric_value
                FROM
                    RawEvents
                WHERE
                    metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-1,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -1, getdate())) as varchar(10))

                UNION ALL

                SELECT
                    DATEDIFF(second,'1970-01-01',DATEADD(SECOND, -1, DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(), -1))))) AS timestamp,  -- Current UTC timestamp as Unix time
                    context_id,Month_Name,
                    0 AS metric_value
                FROM
                    (SELECT DISTINCT context_id,Month_Name FROM RawEvents WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-1,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -1, getdate())) as varchar(10))) AS UniqueContexts

                UNION ALL

                SELECT
                    DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, EOMONTH(GETDATE(), -2))) AS timestamp,  -- Current UTC timestamp as Unix time
                    context_id,Month_Name,
                    0 AS metric_value
                FROM
                    (SELECT DISTINCT context_id,Month_Name FROM RawEvents WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-1,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -1, '1970-01-01')) as varchar(10))) AS UniqueContexts
            ) AS CombinedFilteredResults
        ),
        EventDifferencesM1 AS (
            SELECT
                context_id,
                timestamp,
                Month_Name,
                metric_value,
                LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
                CASE
                    WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                        timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                    ELSE NULL
                END AS time_difference
            FROM
                FilteredAndAddedM1
				),
        SLIM1 AS (
                SELECT
                    cv.project_name AS 'Application Source',
                    cv.dataset_name AS 'Dataset_Name',
                    cv.landing_zone AS 'Zone',
                    cv.ttl AS 'TTL',
                    iso.Month_Name as Month_name,
                    COALESCE(iso.Succeeded, 0) AS 'Succeeded',
                    COALESCE(iso.No_Data, 0) AS 'No New Data',
                    COALESCE(iso.Failed, 0) AS 'Failed',
                    COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
                    CASE
                        WHEN COALESCE(iso.Succeeded, 0) = 0 THEN 0
                        WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
                        ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / (DATEDIFF(second,'1970-01-01',DATEADD(SECOND, -1, DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(), -1)))))-DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, EOMONTH(GETDATE(), -2)))))
                    END AS SLIM1
                    
                FROM
                    CombinedValues AS cv
                LEFT JOIN
                    IngestionSum AS iso
                ON
                    cv.context_id = iso.context_id
                LEFT JOIN
                    EventDifferencesM1 AS ed
                ON
                    cv.context_id = ed.context_id
                    AND ed.time_difference > cv.ttl
                where iso.Month_Name=DateName(mm,DATEADD(month,-1,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -1, getdate())) as varchar(10))
                GROUP BY
                    cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed,iso.Month_Name
        ),

        FilteredAndAddedM2 AS (
            SELECT
                timestamp,
                context_id,
                Month_Name,
                metric_value
            FROM
            (
                SELECT
                    timestamp,
                    context_id,
                    Month_Name,
                    metric_value
                FROM
                    RawEvents
                WHERE
                    metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-2,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -2, getdate())) as varchar(10))

                UNION ALL

                SELECT
                    DATEDIFF(second,'1970-01-01',DATEADD(SECOND, -1, DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(), -2))))) AS timestamp,  -- Current UTC timestamp as Unix time
                    context_id,Month_Name,
                    0 AS metric_value
                FROM
                    (SELECT DISTINCT context_id,Month_Name FROM RawEvents WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-2,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -2, getdate())) as varchar(10))) AS UniqueContexts

                UNION ALL

                SELECT
                    DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, EOMONTH(GETDATE(), -3))) AS timestamp,  -- Current UTC timestamp as Unix time
                    context_id,Month_Name,
                    0 AS metric_value
                FROM
                    (SELECT DISTINCT context_id,Month_Name FROM RawEvents WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-2,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -2, '1970-01-01')) as varchar(10))) AS UniqueContexts
            ) AS CombinedFilteredResults
        ),

        EventDifferencesM2 AS (
            SELECT
                context_id,
                timestamp,
                Month_Name,
                metric_value,
                LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
                CASE
                    WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                        timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                    ELSE NULL
                END AS time_difference
            FROM
                FilteredAndAddedM2   
        ),
        SLIM2 AS (
            SELECT
                cv.project_name AS 'Application Source',
                cv.dataset_name AS 'Dataset_Name',
                cv.landing_zone AS 'Zone',
                cv.ttl AS 'TTL',
                iso.Month_Name as Month_name,
                COALESCE(iso.Succeeded, 0) AS 'Succeeded',
                COALESCE(iso.No_Data, 0) AS 'No New Data',
                COALESCE(iso.Failed, 0) AS 'Failed',
                COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
                CASE
                    WHEN COALESCE(iso.Succeeded, 0) = 0 THEN 0
                    WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
                    ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / (DATEDIFF(second,'1970-01-01',DATEADD(SECOND, -1, DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(), -2)))))-DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, EOMONTH(GETDATE(), -3)))))
                END AS SLIM2
                
            FROM
                CombinedValues AS cv
            LEFT JOIN
                IngestionSum AS iso
            ON
                cv.context_id = iso.context_id
            LEFT JOIN
                EventDifferencesM2 AS ed
            ON
                cv.context_id = ed.context_id
                AND ed.time_difference > cv.ttl
            where iso.Month_Name=DateName(mm,DATEADD(month,-2,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -2, getdate())) as varchar(10))
            GROUP BY
                cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed,iso.Month_Name
        ),
		 FilteredAndAddedM AS (
                SELECT
                    timestamp,
                    context_id,
                    Month_Name,
                    metric_value
                FROM
                (
                    SELECT
                        timestamp,
                        context_id,
                        Month_Name,
                        metric_value
                    FROM
                        RawEvents
                    WHERE
                        metric_value = 0 and  Month_Name=DateName(mm,DATEADD(month,0,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, 0, getdate())) as varchar(10))

                    UNION ALL

                    SELECT
                        DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(),-1)))) AS timestamp,  -- Current UTC timestamp as Unix time
                        context_id,Month_Name,
                        0 AS metric_value
                    FROM
                        (SELECT DISTINCT context_id,Month_Name FROM RawEvents WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,0,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, 0, getdate())) as varchar(10))) AS UniqueContexts

                    UNION ALL

                    SELECT
                        DATEDIFF(second,'1970-01-01',convert(date,GETDATE())) AS timestamp,  -- Current UTC timestamp as Unix time
                        context_id,Month_Name,
                        0 AS metric_value
                    FROM
                        (SELECT DISTINCT context_id,Month_Name FROM RawEvents WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-2,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -2, '1970-01-01')) as varchar(10))) AS UniqueContexts
                ) AS CombinedFilteredResults
            ),

            EventDifferencesM AS (
                SELECT
                    context_id,
                    timestamp,
                    Month_Name,
                    metric_value,
                    LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
                    CASE
                        WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                            timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                        ELSE NULL
                    END AS time_difference
                FROM
                    FilteredAndAddedM
                
            
            ),
            SLIM AS (
                SELECT
                    cv.project_name AS 'Application Source',
                    cv.dataset_name AS 'Dataset_Name',
                    cv.landing_zone AS 'Zone',
                    cv.ttl AS 'TTL',
                    iso.Month_Name as Month_name,
                    COALESCE(iso.Succeeded, 0) AS 'Succeeded',
                    COALESCE(iso.No_Data, 0) AS 'No New Data',
                    COALESCE(iso.Failed, 0) AS 'Failed',
                    COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
                    CASE
                        WHEN COALESCE(iso.Succeeded, 0) = 0 THEN 0
                        WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
                        ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / (DATEDIFF(second,'1970-01-01',convert(date,GETDATE()))-DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(),-1))))))
                    
                    END AS SLIM
                    
                FROM
                    CombinedValues AS cv
                LEFT JOIN
                    IngestionSum AS iso
                ON
                    cv.context_id = iso.context_id
                LEFT JOIN
                    EventDifferencesM AS ed
                ON
                    cv.context_id = ed.context_id
                    AND ed.time_difference > cv.ttl
                where iso.Month_Name=DateName(mm,DATEADD(month,0,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, 0, getdate())) as varchar(10))
                GROUP BY
                    cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed,iso.Month_Name
        ),
		SLITable as (
            SELECT s.[APPLICATION SOURCE] AS 'APPLICATION SOURCES', s.DATASET_NAME AS 'DATASET NAME', s.[ZONE] AS 'ZONE', SLIM, SLIM1, SLIM2
            FROM SLIM AS s
                INNER JOIN SLIM1 AS s1 ON s.[APPLICATION SOURCE]=s1.[APPLICATION SOURCE] AND s.DATASET_NAME=s1.DATASET_NAME AND s.[ZONE]=s1.[ZONE]
                INNER JOIN SLIM2 AS s2 ON s1.[APPLICATION SOURCE]=s2.[APPLICATION SOURCE] AND s1.DATASET_NAME=s2.DATASET_NAME AND s1.[ZONE]=s2.[ZONE]
        ),

        sliValues as (
            SELECT s.DATASET_NAME AS Dataset_Name, '80%' AS SLO, Avg(SLIM) AS SLI_CurrentMonth, Avg(SLIM1) AS SLI_PreviousMonth, Avg(SLIM2) AS SLI_LastBeforeMonth 
            FROM SLIM AS s
                INNER JOIN SLIM1 AS s1 ON s.DATASET_NAME=s1.DATASET_NAME
                INNER JOIN SLIM2 AS s2 ON s.DATASET_NAME=s2.DATASET_NAME
                where s.DATASET_NAME in ($dataset_name) 
            GROUP BY s.DATASET_NAME
        )
        SELECT * from sliValues
    ";  
    grafana.tablePanel.new(
        title='SLI for D365 - NORAM',
        datasource='IFM Azure SQL Server',
        description="SLI Of all data sets of D365 for last 3 months"
        ).addTarget(target=grafana.sql.target(rawSql = D365SqlQuery ,format='table')
        ).addOverridesByFieldName(field='SLI_CurrentMonth',properties=[{id: 'unit', value: 'percent'},{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'red', value: null },{ color: 'green', value: 80 }]}}]
        ).addOverridesByFieldName(field='SLI_PreviousMonth',properties=[{id: 'unit', value: 'percent'},{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'red', value: null },{ color: 'green', value: 80 }]}}]
        ).addOverridesByFieldName(field='SLI_LastBeforeMonth',properties=[{id: 'unit', value: 'percent'},{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'red', value: null },{ color: 'green', value: 80 }]}}]
);

local SLIForAPACD365 =
    local D365SqlQuery = "
    
    WITH
        CombinedValues AS (
            SELECT *
            FROM (VALUES ('oss.apac.glb.d365', 'account', 'silver', 'oss.apac.glb.d365_account_silver', 86400),
            ('oss.apac.glb.d365', 'account', 'bronze', 'oss.apac.glb.d365_account_bronze', 86400),
            ('oss.apac.glb.d365', 'activitypointer', 'silver', 'oss.apac.glb.d365_activitypointer_silver', 86400),
            ('oss.apac.glb.d365', 'activitypointer', 'bronze', 'oss.apac.glb.d365_activitypointer_bronze', 86400),
            ('oss.apac.glb.d365', 'adx_portalcomment', 'silver', 'oss.apac.glb.d365_adx_portalcomment_silver', 86400),
            ('oss.apac.glb.d365', 'adx_portalcomment', 'bronze', 'oss.apac.glb.d365_adx_portalcomment_bronze', 86400),
            ('oss.apac.glb.d365', 'annotation', 'silver', 'oss.apac.glb.d365_annotation_silver', 86400), 
            ('oss.apac.glb.d365', 'annotation', 'bronze', 'oss.apac.glb.d365_annotation_bronze', 86400), 
            ('oss.apac.glb.d365', 'bookableresource', 'silver', 'oss.apac.glb.d365_bookableresource_silver', 86400), 
            ('oss.apac.glb.d365', 'bookableresource', 'bronze', 'oss.apac.glb.d365_bookableresource_bronze', 86400), 
            ('oss.apac.glb.d365', 'bookableresourcebooking', 'silver', 'oss.apac.glb.d365_bookableresourcebooking_silver', 86400), 
            ('oss.apac.glb.d365', 'bookableresourcebooking', 'bronze', 'oss.apac.glb.d365_bookableresourcebooking_bronze', 86400), 
            ('oss.apac.glb.d365', 'bookableresourcecategory', 'silver', 'oss.apac.glb.d365_bookableresourcecategory_silver', 86400), 
            ('oss.apac.glb.d365', 'bookableresourcecategory', 'bronze', 'oss.apac.glb.d365_bookableresourcecategory_bronze', 86400), 
            ('oss.apac.glb.d365', 'contact', 'silver', 'oss.apac.glb.d365_contact_silver', 86400), 
            ('oss.apac.glb.d365', 'contact', 'bronze', 'oss.apac.glb.d365_contact_bronze', 86400),
            ('oss.apac.glb.d365', 'contract', 'silver', 'oss.apac.glb.d365_contract_silver', 86400),
            ('oss.apac.glb.d365', 'contract', 'bronze', 'oss.apac.glb.d365_contract_bronze', 86400), 
            ('oss.apac.glb.d365', 'entitlement', 'silver', 'oss.apac.glb.d365_entitlement_silver', 86400), 
            ('oss.apac.glb.d365', 'entitlement', 'bronze', 'oss.apac.glb.d365_entitlement_bronze', 86400),
            ('oss.apac.glb.d365', 'ifm_assettype', 'silver', 'oss.apac.glb.d365_ifm_assettype_silver', 86400), 
            ('oss.apac.glb.d365', 'ifm_assettype', 'bronze', 'oss.apac.glb.d365_ifm_assettype_bronze', 86400), 
            ('oss.apac.glb.d365', 'ifm_contract', 'silver', 'oss.apac.glb.d365_ifm_contract_silver', 86400),
            ('oss.apac.glb.d365', 'ifm_contract', 'bronze', 'oss.apac.glb.d365_ifm_contract_bronze', 86400), 
            ('oss.apac.glb.d365', 'ifm_country', 'silver', 'oss.apac.glb.d365_ifm_country_silver', 86400), 
            ('oss.apac.glb.d365', 'ifm_country', 'bronze', 'oss.apac.glb.d365_ifm_country_bronze', 86400),
            ('oss.apac.glb.d365', 'ifm_feedback', 'silver', 'oss.apac.glb.d365_ifm_feedback_silver', 86400), 
            ('oss.apac.glb.d365', 'ifm_feedback', 'bronze', 'oss.apac.glb.d365_ifm_feedback_bronze', 86400), 
            ('oss.apac.glb.d365', 'ifm_log', 'silver', 'oss.apac.glb.d365_ifm_log_silver', 86400), 
            ('oss.apac.glb.d365', 'ifm_log', 'bronze', 'oss.apac.glb.d365_ifm_log_bronze', 86400), 
            ('oss.apac.glb.d365', 'ifm_masterservicecategory', 'silver', 'oss.apac.glb.d365_ifm_masterservicecategory_silver', 86400), 
            ('oss.apac.glb.d365', 'ifm_masterservicecategory', 'bronze', 'oss.apac.glb.d365_ifm_masterservicecategory_bronze', 86400), 
            ('oss.apac.glb.d365', 'ifm_servicecategory', 'silver', 'oss.apac.glb.d365_ifm_servicecategory_silver', 86400), 
            ('oss.apac.glb.d365', 'ifm_servicecategory', 'bronze', 'oss.apac.glb.d365_ifm_servicecategory_bronze', 86400), 
            ('oss.apac.glb.d365', 'ifm_workordernote', 'silver', 'oss.apac.glb.d365_ifm_workordernote_silver', 86400), 
            ('oss.apac.glb.d365', 'ifm_workordernote', 'bronze', 'oss.apac.glb.d365_ifm_workordernote_bronze', 86400), 
            ('oss.apac.glb.d365', 'incident', 'silver', 'oss.apac.glb.d365_incident_silver', 86400), 
            ('oss.apac.glb.d365', 'incident', 'bronze', 'oss.apac.glb.d365_incident_bronze', 86400),
            ('oss.apac.glb.d365', 'incidentresolution', 'silver', 'oss.apac.glb.d365_incidentresolution_silver', 86400), 
            ('oss.apac.glb.d365', 'incidentresolution', 'bronze', 'oss.apac.glb.d365_incidentresolution_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_agreement', 'silver', 'oss.apac.glb.d365_msdyn_agreement_silver', 86400),
            ('oss.apac.glb.d365', 'msdyn_agreement', 'bronze', 'oss.apac.glb.d365_msdyn_agreement_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_customerasset', 'silver', 'oss.apac.glb.d365_msdyn_customerasset_silver', 86400), 
            ('oss.apac.glb.d365', 'msdyn_customerasset', 'bronze', 'oss.apac.glb.d365_msdyn_customerasset_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_expense', 'silver', 'oss.apac.glb.d365_msdyn_expense_silver', 86400),
            ('oss.apac.glb.d365', 'msdyn_expense', 'bronze', 'oss.apac.glb.d365_msdyn_expense_bronze', 86400),
            ('oss.apac.glb.d365', 'msdyn_priority', 'silver', 'oss.apac.glb.d365_msdyn_priority_silver', 86400),
            ('oss.apac.glb.d365', 'msdyn_priority', 'bronze', 'oss.apac.glb.d365_msdyn_priority_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_project', 'silver', 'oss.apac.glb.d365_msdyn_project_silver', 86400),
            ('oss.apac.glb.d365', 'msdyn_project', 'bronze', 'oss.apac.glb.d365_msdyn_project_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_projectapproval', 'silver', 'oss.apac.glb.d365_msdyn_projectapproval_silver', 86400),
            ('oss.apac.glb.d365', 'msdyn_projectapproval', 'bronze', 'oss.apac.glb.d365_msdyn_projectapproval_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_projecttask', 'silver', 'oss.apac.glb.d365_msdyn_projecttask_silver', 86400),
            ('oss.apac.glb.d365', 'msdyn_projecttask', 'bronze', 'oss.apac.glb.d365_msdyn_projecttask_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_resourcerequirement', 'silver', 'oss.apac.glb.d365_msdyn_resourcerequirement_silver', 86400), 
            ('oss.apac.glb.d365', 'msdyn_resourcerequirement', 'bronze', 'oss.apac.glb.d365_msdyn_resourcerequirement_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_survey', 'silver', 'oss.apac.glb.d365_msdyn_survey_silver', 86400), 
            ('oss.apac.glb.d365', 'msdyn_survey', 'bronze', 'oss.apac.glb.d365_msdyn_survey_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_timeentry', 'silver', 'oss.apac.glb.d365_msdyn_timeentry_silver', 86400),
            ('oss.apac.glb.d365', 'msdyn_timeentry', 'bronze', 'oss.apac.glb.d365_msdyn_timeentry_bronze', 86400),
            ('oss.apac.glb.d365', 'msdyn_workorder', 'silver', 'oss.apac.glb.d365_msdyn_workorder_silver', 86400), 
            ('oss.apac.glb.d365', 'msdyn_workorder', 'bronze', 'oss.apac.glb.d365_msdyn_workorder_bronze', 86400), 
            ('oss.apac.glb.d365', 'msdyn_workordertype', 'silver', 'oss.apac.glb.d365_msdyn_workordertype_silver', 86400),
            ('oss.apac.glb.d365', 'msdyn_workordertype', 'bronze', 'oss.apac.glb.d365_msdyn_workordertype_bronze', 86400), 
            ('oss.apac.glb.d365', 'pricelevel', 'silver', 'oss.apac.glb.d365_pricelevel_silver', 86400), 
            ('oss.apac.glb.d365', 'pricelevel', 'bronze', 'oss.apac.glb.d365_pricelevel_bronze', 86400), 
            ('oss.apac.glb.d365', 'queue', 'silver', 'oss.apac.glb.d365_queue_silver', 86400), 
            ('oss.apac.glb.d365', 'queue', 'bronze', 'oss.apac.glb.d365_queue_bronze', 86400), 
            ('oss.apac.glb.d365', 'quote', 'silver', 'oss.apac.glb.d365_quote_silver', 86400), 
            ('oss.apac.glb.d365', 'quote', 'bronze', 'oss.apac.glb.d365_quote_bronze', 86400),
            ('oss.apac.glb.d365', 'role', 'silver', 'oss.apac.glb.d365_role_silver', 86400), 
            ('oss.apac.glb.d365', 'role', 'bronze', 'oss.apac.glb.d365_role_bronze', 86400), 
            ('oss.apac.glb.d365', 'sdxmob_facility', 'silver', 'oss.apac.glb.d365_sdxmob_facility_silver', 86400), 
            ('oss.apac.glb.d365', 'sdxmob_facility', 'bronze', 'oss.apac.glb.d365_sdxmob_facility_bronze', 86400), 
            ('oss.apac.glb.d365', 'sla', 'silver', 'oss.apac.glb.d365_sla_silver', 86400), 
            ('oss.apac.glb.d365', 'sla', 'bronze', 'oss.apac.glb.d365_sla_bronze', 86400), 
            ('oss.apac.glb.d365', 'slaitem', 'silver', 'oss.apac.glb.d365_slaitem_silver', 86400), 
            ('oss.apac.glb.d365', 'slaitem', 'bronze', 'oss.apac.glb.d365_slaitem_bronze', 86400), 
            ('oss.apac.glb.d365', 'slakpiinstance', 'silver', 'oss.apac.glb.d365_slakpiinstance_silver', 86400), 
            ('oss.apac.glb.d365', 'slakpiinstance', 'bronze', 'oss.apac.glb.d365_slakpiinstance_bronze', 86400), 
            ('oss.apac.glb.d365', 'systemuser', 'silver', 'oss.apac.glb.d365_systemuser_silver', 86400), 
            ('oss.apac.glb.d365', 'systemuser', 'bronze', 'oss.apac.glb.d365_systemuser_bronze', 86400), 
            ('oss.apac.glb.d365', 'timezonedefinition', 'silver', 'oss.apac.glb.d365_timezonedefinition_silver', 86400), 
            ('oss.apac.glb.d365', 'timezonedefinition', 'bronze', 'oss.apac.glb.d365_timezonedefinition_bronze', 86400), 
            ('oss.apac.glb.d365', 'timezonerule', 'silver', 'oss.apac.glb.d365_timezonerule_silver', 86400), 
            ('oss.apac.glb.d365', 'timezonerule', 'bronze', 'oss.apac.glb.d365_timezonerule_bronze', 86400), 
            ('oss.apac.glb.d365', 'transactioncurrency', 'silver', 'oss.apac.glb.d365_transactioncurrency_silver', 86400), 
            ('oss.apac.glb.d365', 'transactioncurrency', 'bronze', 'oss.apac.glb.d365_transactioncurrency_bronze', 86400)) As T (project_name, dataset_name, landing_zone, context_id, ttl)
    WHERE context_id IN (${context:sqlstring}+'')),
        RawEvents AS (
            SELECT
                [timestamp],
                DateName(mm,DATEADD(SECOND,timestamp,'1970-01-01')) + '-' + cast(datepart(yyyy, dateadd(second, timestamp, '1970-01-01')) as varchar(10)) as Month_Name,
                 context_id,
                 job_id,
                metric_value
            FROM
                [observability].[event]
            WHERE
                metric_name = 'processing_exit_code'
                AND event_type = 'processingfinished'
                 AND context_id IN (${context:sqlstring}+'')
				and cast(dateadd(second, [timestamp], '1970-01-01') as date) >= dateadd(month, -2, getdate())
        ),

        DistinctJobs AS (
            SELECT
                context_id,
                Month_Name,
                job_id,
                metric_value
            FROM
                RawEvents
        ),

        IngestionSum AS (
            SELECT
                context_id,Month_Name,
                SUM(CASE WHEN metric_value = 0 THEN 1 ELSE 0 END) AS Succeeded,
                SUM(CASE WHEN metric_value = 1 THEN 1 ELSE 0 END) AS No_Data,
                SUM(CASE WHEN metric_value = -1 THEN 1 ELSE 0 END) AS Failed
            FROM
                DistinctJobs
            GROUP BY
                context_id,Month_Name
        ),

		FilteredAndAddedM1 AS (
            SELECT
                timestamp,
                context_id,
                Month_Name,
                metric_value
            FROM
            (
                SELECT
                    timestamp,
                    context_id,
                    Month_Name,
                    metric_value
                FROM
                    RawEvents
                WHERE
                    metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-1,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -1, getdate())) as varchar(10))

                UNION ALL

                SELECT
                    DATEDIFF(second,'1970-01-01',DATEADD(SECOND, -1, DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(), -1))))) AS timestamp,  -- Current UTC timestamp as Unix time
                    context_id,Month_Name,
                    0 AS metric_value
                FROM
                    (SELECT DISTINCT context_id,Month_Name FROM RawEvents WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-1,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -1, getdate())) as varchar(10))) AS UniqueContexts

                UNION ALL

                SELECT
                    DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, EOMONTH(GETDATE(), -2))) AS timestamp,  -- Current UTC timestamp as Unix time
                    context_id,Month_Name,
                    0 AS metric_value
                FROM
                    (SELECT DISTINCT context_id,Month_Name FROM RawEvents WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-1,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -1, '1970-01-01')) as varchar(10))) AS UniqueContexts
            ) AS CombinedFilteredResults
        ),
        EventDifferencesM1 AS (
            SELECT
                context_id,
                timestamp,
                Month_Name,
                metric_value,
                LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
                CASE
                    WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                        timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                    ELSE NULL
                END AS time_difference
            FROM
                FilteredAndAddedM1
				),
        SLIM1 AS (
                SELECT
                    cv.project_name AS 'Application Source',
                    cv.dataset_name AS 'Dataset_Name',
                    cv.landing_zone AS 'Zone',
                    cv.ttl AS 'TTL',
                    iso.Month_Name as Month_name,
                    COALESCE(iso.Succeeded, 0) AS 'Succeeded',
                    COALESCE(iso.No_Data, 0) AS 'No New Data',
                    COALESCE(iso.Failed, 0) AS 'Failed',
                    COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
                    CASE
                        WHEN COALESCE(iso.Succeeded, 0) = 0 THEN 0
                        WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
                        ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / (DATEDIFF(second,'1970-01-01',DATEADD(SECOND, -1, DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(), -1)))))-DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, EOMONTH(GETDATE(), -2)))))
                    END AS SLIM1
                    
                FROM
                    CombinedValues AS cv
                LEFT JOIN
                    IngestionSum AS iso
                ON
                    cv.context_id = iso.context_id
                LEFT JOIN
                    EventDifferencesM1 AS ed
                ON
                    cv.context_id = ed.context_id
                    AND ed.time_difference > cv.ttl
                where iso.Month_Name=DateName(mm,DATEADD(month,-1,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -1, getdate())) as varchar(10))
                GROUP BY
                    cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed,iso.Month_Name
        ),

        FilteredAndAddedM2 AS (
            SELECT
                timestamp,
                context_id,
                Month_Name,
                metric_value
            FROM
            (
                SELECT
                    timestamp,
                    context_id,
                    Month_Name,
                    metric_value
                FROM
                    RawEvents
                WHERE
                    metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-2,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -2, getdate())) as varchar(10))

                UNION ALL

                SELECT
                    DATEDIFF(second,'1970-01-01',DATEADD(SECOND, -1, DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(), -2))))) AS timestamp,  -- Current UTC timestamp as Unix time
                    context_id,Month_Name,
                    0 AS metric_value
                FROM
                    (SELECT DISTINCT context_id,Month_Name FROM RawEvents WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-2,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -2, getdate())) as varchar(10))) AS UniqueContexts

                UNION ALL

                SELECT
                    DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, EOMONTH(GETDATE(), -3))) AS timestamp,  -- Current UTC timestamp as Unix time
                    context_id,Month_Name,
                    0 AS metric_value
                FROM
                    (SELECT DISTINCT context_id,Month_Name FROM RawEvents WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-2,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -2, '1970-01-01')) as varchar(10))) AS UniqueContexts
            ) AS CombinedFilteredResults
        ),

        EventDifferencesM2 AS (
            SELECT
                context_id,
                timestamp,
                Month_Name,
                metric_value,
                LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
                CASE
                    WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                        timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                    ELSE NULL
                END AS time_difference
            FROM
                FilteredAndAddedM2   
        ),
        SLIM2 AS (
            SELECT
                cv.project_name AS 'Application Source',
                cv.dataset_name AS 'Dataset_Name',
                cv.landing_zone AS 'Zone',
                cv.ttl AS 'TTL',
                iso.Month_Name as Month_name,
                COALESCE(iso.Succeeded, 0) AS 'Succeeded',
                COALESCE(iso.No_Data, 0) AS 'No New Data',
                COALESCE(iso.Failed, 0) AS 'Failed',
                COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
                CASE
                    WHEN COALESCE(iso.Succeeded, 0) = 0 THEN 0
                    WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
                    ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / (DATEDIFF(second,'1970-01-01',DATEADD(SECOND, -1, DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(), -2)))))-DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, EOMONTH(GETDATE(), -3)))))
                END AS SLIM2
                
            FROM
                CombinedValues AS cv
            LEFT JOIN
                IngestionSum AS iso
            ON
                cv.context_id = iso.context_id
            LEFT JOIN
                EventDifferencesM2 AS ed
            ON
                cv.context_id = ed.context_id
                AND ed.time_difference > cv.ttl
            where iso.Month_Name=DateName(mm,DATEADD(month,-2,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -2, getdate())) as varchar(10))
            GROUP BY
                cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed,iso.Month_Name
        ),
		 FilteredAndAddedM AS (
                SELECT
                    timestamp,
                    context_id,
                    Month_Name,
                    metric_value
                FROM
                (
                    SELECT
                        timestamp,
                        context_id,
                        Month_Name,
                        metric_value
                    FROM
                        RawEvents
                    WHERE
                        metric_value = 0 and  Month_Name=DateName(mm,DATEADD(month,0,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, 0, getdate())) as varchar(10))

                    UNION ALL

                    SELECT
                        DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(),-1)))) AS timestamp,  -- Current UTC timestamp as Unix time
                        context_id,Month_Name,
                        0 AS metric_value
                    FROM
                        (SELECT DISTINCT context_id,Month_Name FROM RawEvents WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,0,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, 0, getdate())) as varchar(10))) AS UniqueContexts

                    UNION ALL

                    SELECT
                        DATEDIFF(second,'1970-01-01',convert(date,GETDATE())) AS timestamp,  -- Current UTC timestamp as Unix time
                        context_id,Month_Name,
                        0 AS metric_value
                    FROM
                        (SELECT DISTINCT context_id,Month_Name FROM RawEvents WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(month,-2,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, -2, '1970-01-01')) as varchar(10))) AS UniqueContexts
                ) AS CombinedFilteredResults
            ),

            EventDifferencesM AS (
                SELECT
                    context_id,
                    timestamp,
                    Month_Name,
                    metric_value,
                    LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
                    CASE
                        WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                            timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                        ELSE NULL
                    END AS time_difference
                FROM
                    FilteredAndAddedM
                
            
            ),
            SLIM AS (
                SELECT
                    cv.project_name AS 'Application Source',
                    cv.dataset_name AS 'Dataset_Name',
                    cv.landing_zone AS 'Zone',
                    cv.ttl AS 'TTL',
                    iso.Month_Name as Month_name,
                    COALESCE(iso.Succeeded, 0) AS 'Succeeded',
                    COALESCE(iso.No_Data, 0) AS 'No New Data',
                    COALESCE(iso.Failed, 0) AS 'Failed',
                    COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
                    CASE
                        WHEN COALESCE(iso.Succeeded, 0) = 0 THEN 0
                        WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
                        ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / (DATEDIFF(second,'1970-01-01',convert(date,GETDATE()))-DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(),-1))))))
                    
                    END AS SLIM
                    
                FROM
                    CombinedValues AS cv
                LEFT JOIN
                    IngestionSum AS iso
                ON
                    cv.context_id = iso.context_id
                LEFT JOIN
                    EventDifferencesM AS ed
                ON
                    cv.context_id = ed.context_id
                    AND ed.time_difference > cv.ttl
                where iso.Month_Name=DateName(mm,DATEADD(month,0,getdate())) + '-' + cast(datepart(yyyy, dateadd(month, 0, getdate())) as varchar(10))
                GROUP BY
                    cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed,iso.Month_Name
        ),
		SLITable as (
            SELECT s.[APPLICATION SOURCE] AS 'APPLICATION SOURCES', s.DATASET_NAME AS 'DATASET NAME', s.[ZONE] AS 'ZONE', SLIM, SLIM1, SLIM2
            FROM SLIM AS s
                INNER JOIN SLIM1 AS s1 ON s.[APPLICATION SOURCE]=s1.[APPLICATION SOURCE] AND s.DATASET_NAME=s1.DATASET_NAME AND s.[ZONE]=s1.[ZONE]
                INNER JOIN SLIM2 AS s2 ON s1.[APPLICATION SOURCE]=s2.[APPLICATION SOURCE] AND s1.DATASET_NAME=s2.DATASET_NAME AND s1.[ZONE]=s2.[ZONE]
        ),

        sliValues as (
            SELECT s.DATASET_NAME AS Dataset_Name, '80%' AS SLO, Avg(SLIM) AS SLI_CurrentMonth, Avg(SLIM1) AS SLI_PreviousMonth, Avg(SLIM2) AS SLI_LastBeforeMonth 
            FROM SLIM AS s
                INNER JOIN SLIM1 AS s1 ON s.DATASET_NAME=s1.DATASET_NAME
                INNER JOIN SLIM2 AS s2 ON s.DATASET_NAME=s2.DATASET_NAME
                where s.DATASET_NAME in ($dataset_name) 
            GROUP BY s.DATASET_NAME
        )
        SELECT * from sliValues
    ";  
    grafana.tablePanel.new(
        title='SLI for D365 - APAC',
        datasource='IFM Azure SQL Server',
        description="SLI Of all data sets of D365 for last 3 months"
        ).addTarget(target=grafana.sql.target(rawSql = D365SqlQuery ,format='table')
        ).addOverridesByFieldName(field='SLI_CurrentMonth',properties=[{id: 'unit', value: 'percent'},{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'red', value: null },{ color: 'green', value: 80 }]}}]
        ).addOverridesByFieldName(field='SLI_PreviousMonth',properties=[{id: 'unit', value: 'percent'},{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'red', value: null },{ color: 'green', value: 80 }]}}]
        ).addOverridesByFieldName(field='SLI_LastBeforeMonth',properties=[{id: 'unit', value: 'percent'},{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'red', value: null },{ color: 'green', value: 80 }]}}]
);


local DatasetIngestionHistory = 
    local sqlQuery = "
    WITH 
        FilteredEvents AS (
            SELECT
                job_id,
                context_id,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                timestamp,
                metric_name,
                metric_value
            FROM
                [observability].[event]
            WHERE
                context_id IN (${context:sqlstring}+'')
                AND dataset_name in ($dataset_name)
                AND landing_zone IN ($landing_zone)
                AND project_name in ($project_name)
                AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                AND metric_name IN ('processing_started_date', 'processing_finished_date', 'processing_exit_code', 'rows_count', 'content_latest_date')
        ),
        MergedEvents AS (
            SELECT
                job_id,
                context_id,
                timestamp,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                [processing_started_date] AS processing_started_date_value,
                [processing_finished_date] AS processing_finished_date_value,
                [processing_exit_code] AS processing_exit_code_value,
                [content_latest_date] AS content_latest_date,
                [rows_count] AS rows_count_value
            FROM
                FilteredEvents
            PIVOT (
                MAX(metric_value)
                FOR metric_name IN ([processing_started_date], [processing_finished_date], [processing_exit_code], [rows_count], [content_latest_date])
            ) AS PivotTable
        ),
        Finalevents as(
            SELECT
                MAX(project_name) AS 'Application Source',
                MAX(dataset_name) AS 'Dataset',
                MAX(landing_zone) AS 'Zone',
                MAX(
                    CASE subscription_id
                    WHEN '6b4a5b3f-1015-42da-a46a-2890a5abed30' THEN 'IFM CORE PROD'
                    WHEN '2698ca5b-bf81-43fb-8fe2-f0e21bf068e5' THEN 'IFM CORE UAT/TEST'
                    WHEN '746ac5b9-70eb-4c76-bdf4-0664bfdff2ea' THEN 'IFM CORE DEV'
                    WHEN 'cf25f2a1-4d40-45af-bb81-87ec46112b3e' THEN 'SDX STA/PRD'
                    WHEN 'c0978b9d-b809-45f4-aa76-391ceb2cfdba' THEN 'SDX DEV/TEST'
                    WHEN '8eaa3d95-3cd2-49d8-b44a-7ea47a6fb58b' THEN 'SDX SILVER'
                    WHEN 'daf86ec1-725c-493f-bf09-a1f129b8588a' THEN 'SDX INT/UAT'
                    WHEN 'fea1e9f0-0e20-426f-906e-bc76e5a566ad' THEN 'SDX Sandbox'
                    WHEN '6e3fc63f-851b-4fc7-8499-48f6a9c28a65' THEN 'SDX Global Shared Services'
                    ELSE 'Undefined'
                    END
                ) AS 'Subscription',
                MAX(takeoff_zone) + ' to ' + MAX(landing_zone) AS 'Activity',
                case 
                    when sum(case when processing_exit_code_value not in (0,1,2) then 1 else 0 end) > 0 then 'Failed'
                    when count(case when processing_exit_code_value = 0 then 1 end) > 0 then 'Succeeded'
                    when count(case when processing_exit_code_value = 1 then 1 end) > 0 then 'No New Data'
                    when count(case when processing_exit_code_value = 2 then 1 end) > 0 then 'Skipped'
                End as 'Status',
                DATEADD(SECOND, MAX([timestamp]), '1970-01-01') AS 'Landed at',
                DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([timestamp]) AS 'Landed Since',
                DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([content_latest_date]) AS 'Freshness',
                CAST(MAX(processing_finished_date_value) - MAX(processing_started_date_value) AS BIGINT) AS 'Duration',
                ISNULL(CAST(CAST(MAX(rows_count_value) AS BIGINT) AS VARCHAR), 'N/A') AS 'Rows'
            FROM MergedEvents
            GROUP BY job_id, context_id
        )
        Select[Application Source], Dataset,Zone, Subscription, Activity, Status,[Landed at], Rows from Finalevents
        where Status in ($status)
        ORDER BY[Landed at] DESC
    ";

    table.new(
        title='Dataset Ingestion History - TableView',
        datasource='IFM Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Landed Since',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Freshness',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Duration',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Rows',properties=[{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'N/A': { color: 'red', index: 0 }}}]}]
    ).addOverridesByFieldName(field='Status',properties=[{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'Failed': {color: 'red','index': 3},'No New Data': {color: 'yellow','index': 1},'Running': {color: 'gray','index': 2},'Succeeded': {color: 'green','index': 0}}}]}]
);

local DatasetFreshnessWithinThreshold = 
    local sqlQuery = " 
    WITH 
        FilteredEvents AS (
            SELECT
                job_id,
                context_id,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                timestamp,
                metric_name,
                metric_value
            FROM
                [observability].[event]
            WHERE
                                context_id in ('oss.apac.glb.d365_account_silver', 'oss.apac.glb.d365_account_bronze', 
					'oss.apac.glb.d365_activitypointer_silver', 'oss.apac.glb.d365_activitypointer_bronze', 
					'oss.apac.glb.d365_adx_portalcomment_silver', 'oss.apac.glb.d365_adx_portalcomment_bronze', 
					'oss.apac.glb.d365_annotation_silver', 'oss.apac.glb.d365_annotation_bronze', 
					'oss.apac.glb.d365_bookableresource_silver', 'oss.apac.glb.d365_bookableresource_bronze', 
					'oss.apac.glb.d365_bookableresourcebooking_silver', 'oss.apac.glb.d365_bookableresourcebooking_bronze', 
					'oss.apac.glb.d365_bookableresourcecategory_silver',
					'oss.apac.glb.d365_bookableresourcecategory_bronze', 
					'oss.apac.glb.d365_contact_silver', 'oss.apac.glb.d365_contact_bronze', 
					'oss.apac.glb.d365_contract_silver', 'oss.apac.glb.d365_contract_bronze', 
					'oss.apac.glb.d365_entitlement_silver', 'oss.apac.glb.d365_entitlement_bronze', 
					'oss.apac.glb.d365_ifm_assettype_silver', 'oss.apac.glb.d365_ifm_assettype_bronze',
					'oss.apac.glb.d365_ifm_contract_silver', 'oss.apac.glb.d365_ifm_contract_bronze', 
					'oss.apac.glb.d365_ifm_country_silver', 'oss.apac.glb.d365_ifm_country_bronze', 
					'oss.apac.glb.d365_ifm_feedback_silver', 'oss.apac.glb.d365_ifm_feedback_bronze', 
					'oss.apac.glb.d365_ifm_log_silver', 'oss.apac.glb.d365_ifm_log_bronze',
					'oss.apac.glb.d365_ifm_masterservicecategory_silver', 
					'oss.apac.glb.d365_ifm_masterservicecategory_bronze',
					'oss.apac.glb.d365_ifm_servicecategory_silver',
					'oss.apac.glb.d365_ifm_servicecategory_bronze',
					'oss.apac.glb.d365_ifm_workordernote_silver', 
					'oss.apac.glb.d365_ifm_workordernote_bronze', 
					'oss.apac.glb.d365_incident_silver', 
					'oss.apac.glb.d365_incident_bronze', 
					'oss.apac.glb.d365_incidentresolution_silver', 
					'oss.apac.glb.d365_incidentresolution_bronze',
					'oss.apac.glb.d365_msdyn_agreement_silver',
					'oss.apac.glb.d365_msdyn_agreement_bronze',
					'oss.apac.glb.d365_msdyn_customerasset_silver',
					'oss.apac.glb.d365_msdyn_customerasset_bronze', 
					'oss.apac.glb.d365_msdyn_expense_silver',
					'oss.apac.glb.d365_msdyn_expense_bronze', 
					'oss.apac.glb.d365_msdyn_priority_silver', 
					'oss.apac.glb.d365_msdyn_priority_bronze', 
					'oss.apac.glb.d365_msdyn_project_silver',
					'oss.apac.glb.d365_msdyn_project_bronze', 
					'oss.apac.glb.d365_msdyn_projectapproval_silver',
					'oss.apac.glb.d365_msdyn_projectapproval_bronze', 
					'oss.apac.glb.d365_msdyn_projecttask_silver', 
					'oss.apac.glb.d365_msdyn_projecttask_bronze', 
					'oss.apac.glb.d365_msdyn_resourcerequirement_silver',
					'oss.apac.glb.d365_msdyn_resourcerequirement_bronze', 
					'oss.apac.glb.d365_msdyn_survey_silver', 
					'oss.apac.glb.d365_msdyn_survey_bronze', 'oss.apac.glb.d365_msdyn_timeentry_silver', 
					'oss.apac.glb.d365_msdyn_timeentry_bronze', 'oss.apac.glb.d365_msdyn_workorder_silver', 
					'oss.apac.glb.d365_msdyn_workorder_bronze', 'oss.apac.glb.d365_msdyn_workordertype_silver',
					'oss.apac.glb.d365_msdyn_workordertype_bronze', 
					'oss.apac.glb.d365_pricelevel_silver', 'oss.apac.glb.d365_pricelevel_bronze', 
					'oss.apac.glb.d365_queue_silver', 'oss.apac.glb.d365_queue_bronze',
					'oss.apac.glb.d365_quote_silver', 'oss.apac.glb.d365_quote_bronze',
					'oss.apac.glb.d365_role_silver', 'oss.apac.glb.d365_role_bronze', 
					'oss.apac.glb.d365_sdxmob_facility_silver', 'oss.apac.glb.d365_sdxmob_facility_bronze',
					'oss.apac.glb.d365_sla_silver', 'oss.apac.glb.d365_sla_bronze',
					'oss.apac.glb.d365_slaitem_silver', 'oss.apac.glb.d365_slaitem_bronze',
					'oss.apac.glb.d365_slakpiinstance_silver',
					'oss.apac.glb.d365_slakpiinstance_bronze',
					'oss.apac.glb.d365_systemuser_silver',
					'oss.apac.glb.d365_systemuser_bronze',
					'oss.apac.glb.d365_timezonedefinition_silver',
					'oss.apac.glb.d365_timezonedefinition_bronze',
					'oss.apac.glb.d365_timezonerule_silver',
					'oss.apac.glb.d365_timezonerule_bronze',
					'oss.apac.glb.d365_transactioncurrency_silver',
					'oss.apac.glb.d365_transactioncurrency_bronze',
					'oss.coe.glb.d365_account_silver', 
					'oss.coe.glb.d365_account_bronze', 
					'oss.coe.glb.d365_activitypointer_silver',
					'oss.coe.glb.d365_activitypointer_bronze',
					'oss.coe.glb.d365_adx_portalcomment_silver', 
					'oss.coe.glb.d365_adx_portalcomment_bronze',
					'oss.coe.glb.d365_annotation_silver', 
					'oss.coe.glb.d365_annotation_bronze', 
					'oss.coe.glb.d365_bookableresource_silver',
					'oss.coe.glb.d365_bookableresource_bronze',
					'oss.coe.glb.d365_bookableresourcebooking_silver', 'oss.coe.glb.d365_bookableresourcebooking_bronze',
					'oss.coe.glb.d365_bookableresourcecategory_silver', 
					'oss.coe.glb.d365_bookableresourcecategory_bronze', 
					'oss.coe.glb.d365_contact_silver', 'oss.coe.glb.d365_contact_bronze', 
					'oss.coe.glb.d365_contract_silver', 'oss.coe.glb.d365_contract_bronze',
					'oss.coe.glb.d365_entitlement_silver',
					'oss.coe.glb.d365_entitlement_bronze', 
					'oss.coe.glb.d365_ifm_assettype_silver',
					'oss.coe.glb.d365_ifm_assettype_bronze',
					'oss.coe.glb.d365_ifm_contract_silver', 
					'oss.coe.glb.d365_ifm_contract_bronze',
					'oss.coe.glb.d365_ifm_country_silver',
					'oss.coe.glb.d365_ifm_country_bronze',
					'oss.coe.glb.d365_ifm_feedback_silver', 
					'oss.coe.glb.d365_ifm_feedback_bronze', 
					'oss.coe.glb.d365_ifm_log_silver',
					'oss.coe.glb.d365_ifm_log_bronze',
					'oss.coe.glb.d365_ifm_masterservicecategory_silver',
					'oss.coe.glb.d365_ifm_masterservicecategory_bronze',
					'oss.coe.glb.d365_ifm_servicecategory_silver',
					'oss.coe.glb.d365_ifm_servicecategory_bronze',
					'oss.coe.glb.d365_ifm_workordernote_silver', 
					'oss.coe.glb.d365_ifm_workordernote_bronze',
					'oss.coe.glb.d365_incident_silver', 
					'oss.coe.glb.d365_incident_bronze', 
					'oss.coe.glb.d365_incidentresolution_silver', 
					'oss.coe.glb.d365_incidentresolution_bronze', 
					'oss.coe.glb.d365_msdyn_agreement_silver',
					'oss.coe.glb.d365_msdyn_agreement_bronze',
					'oss.coe.glb.d365_msdyn_customerasset_silver',
					'oss.coe.glb.d365_msdyn_customerasset_bronze',
					'oss.coe.glb.d365_msdyn_expense_silver', 
					'oss.coe.glb.d365_msdyn_expense_bronze',
					'oss.coe.glb.d365_msdyn_priority_silver',
					'oss.coe.glb.d365_msdyn_priority_bronze', 
					'oss.coe.glb.d365_msdyn_project_silver', 
					'oss.coe.glb.d365_msdyn_project_bronze', 
					'oss.coe.glb.d365_msdyn_projectapproval_silver',
					'oss.coe.glb.d365_msdyn_projectapproval_bronze',
					'oss.coe.glb.d365_msdyn_projecttask_silver', 
					'oss.coe.glb.d365_msdyn_projecttask_bronze', 
					'oss.coe.glb.d365_msdyn_resourcerequirement_silver',
					'oss.coe.glb.d365_msdyn_resourcerequirement_bronze', 
					'oss.coe.glb.d365_msdyn_survey_silver', 
					'oss.coe.glb.d365_msdyn_survey_bronze', 'oss.coe.glb.d365_msdyn_timeentry_silver',
					'oss.coe.glb.d365_msdyn_timeentry_bronze', 'oss.coe.glb.d365_msdyn_workorder_silver', 
					'oss.coe.glb.d365_msdyn_workorder_bronze', 'oss.coe.glb.d365_msdyn_workordertype_silver',
					'oss.coe.glb.d365_msdyn_workordertype_bronze', 
					'oss.coe.glb.d365_pricelevel_silver', 'oss.coe.glb.d365_pricelevel_bronze', 
					'oss.coe.glb.d365_queue_silver', 'oss.coe.glb.d365_queue_bronze', 'oss.coe.glb.d365_quote_silver', 
					'oss.coe.glb.d365_quote_bronze', 'oss.coe.glb.d365_role_silver', 'oss.coe.glb.d365_role_bronze',
					'oss.coe.glb.d365_sdxmob_facility_silver', 'oss.coe.glb.d365_sdxmob_facility_bronze', 
					'oss.coe.glb.d365_sla_silver', 'oss.coe.glb.d365_sla_bronze', 'oss.coe.glb.d365_slaitem_silver',
					'oss.coe.glb.d365_slaitem_bronze', 'oss.coe.glb.d365_slakpiinstance_silver',
					'oss.coe.glb.d365_slakpiinstance_bronze', 'oss.coe.glb.d365_systemuser_silver', 
					'oss.coe.glb.d365_systemuser_bronze', 'oss.coe.glb.d365_timezonedefinition_silver',
					'oss.coe.glb.d365_timezonedefinition_bronze', 'oss.coe.glb.d365_timezonerule_silver',
					'oss.coe.glb.d365_timezonerule_bronze', 'oss.coe.glb.d365_transactioncurrency_silver', 
					'oss.coe.glb.d365_transactioncurrency_bronze', 'oss.noram.glb.d365_account_silver', 
					'oss.noram.glb.d365_account_bronze', 'oss.noram.glb.d365_activitypointer_silver',
					'oss.noram.glb.d365_activitypointer_bronze', 'oss.noram.glb.d365_adx_portalcomment_silver', 
					'oss.noram.glb.d365_adx_portalcomment_bronze',
					'oss.noram.glb.d365_annotation_silver',
					'oss.noram.glb.d365_annotation_bronze',
					'oss.noram.glb.d365_bookableresource_silver',
					'oss.noram.glb.d365_bookableresource_bronze',
					'oss.noram.glb.d365_bookableresourcebooking_silver',
					'oss.noram.glb.d365_bookableresourcebooking_bronze', 
					'oss.noram.glb.d365_bookableresourcecategory_silver', 
					'oss.noram.glb.d365_bookableresourcecategory_bronze',
					'oss.noram.glb.d365_contact_silver', 'oss.noram.glb.d365_contact_bronze',
					'oss.noram.glb.d365_contract_silver', 
					'oss.noram.glb.d365_contract_bronze', 
					'oss.noram.glb.d365_entitlement_silver', 
					'oss.noram.glb.d365_entitlement_bronze', 'oss.noram.glb.d365_ifm_assettype_silver',
					'oss.noram.glb.d365_ifm_assettype_bronze', 'oss.noram.glb.d365_ifm_contract_silver',
					'oss.noram.glb.d365_ifm_contract_bronze', 'oss.noram.glb.d365_ifm_country_silver',
					'oss.noram.glb.d365_ifm_country_bronze', 'oss.noram.glb.d365_ifm_feedback_silver',
					'oss.noram.glb.d365_ifm_feedback_bronze', 'oss.noram.glb.d365_ifm_log_silver',
					'oss.noram.glb.d365_ifm_log_bronze', 'oss.noram.glb.d365_ifm_masterservicecategory_silver',
					'oss.noram.glb.d365_ifm_masterservicecategory_bronze', 
					'oss.noram.glb.d365_ifm_servicecategory_silver',
					'oss.noram.glb.d365_ifm_servicecategory_bronze',
					'oss.noram.glb.d365_ifm_workordernote_silver',
					'oss.noram.glb.d365_ifm_workordernote_bronze',
					'oss.noram.glb.d365_incident_silver', 'oss.noram.glb.d365_incident_bronze',
					'oss.noram.glb.d365_incidentresolution_silver', 'oss.noram.glb.d365_incidentresolution_bronze',
					'oss.noram.glb.d365_msdyn_agreement_silver', 'oss.noram.glb.d365_msdyn_agreement_bronze',
					'oss.noram.glb.d365_msdyn_customerasset_silver', 'oss.noram.glb.d365_msdyn_customerasset_bronze', 
					'oss.noram.glb.d365_msdyn_expense_silver', 'oss.noram.glb.d365_msdyn_expense_bronze', 'oss.noram.glb.d365_msdyn_priority_silver',
					'oss.noram.glb.d365_msdyn_priority_bronze', 'oss.noram.glb.d365_msdyn_project_silver', 'oss.noram.glb.d365_msdyn_project_bronze',
					'oss.noram.glb.d365_msdyn_projectapproval_silver', 'oss.noram.glb.d365_msdyn_projectapproval_bronze',
					'oss.noram.glb.d365_msdyn_projecttask_silver', 'oss.noram.glb.d365_msdyn_projecttask_bronze',
					'oss.noram.glb.d365_msdyn_resourcerequirement_silver', 'oss.noram.glb.d365_msdyn_resourcerequirement_bronze', 
					'oss.noram.glb.d365_msdyn_survey_silver', 'oss.noram.glb.d365_msdyn_survey_bronze', 
					'oss.noram.glb.d365_msdyn_timeentry_silver', 'oss.noram.glb.d365_msdyn_timeentry_bronze', 
					'oss.noram.glb.d365_msdyn_workorder_silver', 'oss.noram.glb.d365_msdyn_workorder_bronze', 
					'oss.noram.glb.d365_msdyn_workordertype_silver', 'oss.noram.glb.d365_msdyn_workordertype_bronze', 
					'oss.noram.glb.d365_pricelevel_silver', 'oss.noram.glb.d365_pricelevel_bronze', 'oss.noram.glb.d365_queue_silver', 
					'oss.noram.glb.d365_queue_bronze', 'oss.noram.glb.d365_quote_silver', 'oss.noram.glb.d365_quote_bronze', 
					'oss.noram.glb.d365_role_silver', 'oss.noram.glb.d365_role_bronze', 'oss.noram.glb.d365_sdxmob_facility_silver', 
					'oss.noram.glb.d365_sdxmob_facility_bronze', 'oss.noram.glb.d365_sla_silver', 'oss.noram.glb.d365_sla_bronze', 
					'oss.noram.glb.d365_slaitem_silver', 'oss.noram.glb.d365_slaitem_bronze', 'oss.noram.glb.d365_slakpiinstance_silver', 
					'oss.noram.glb.d365_slakpiinstance_bronze', 'oss.noram.glb.d365_systemuser_silver', 
					'oss.noram.glb.d365_systemuser_bronze', 'oss.noram.glb.d365_timezonedefinition_silver', 
					'oss.noram.glb.d365_timezonedefinition_bronze', 'oss.noram.glb.d365_timezonerule_silver', 
					'oss.noram.glb.d365_timezonerule_bronze', 'oss.noram.glb.d365_transactioncurrency_silver', 
					'oss.noram.glb.d365_transactioncurrency_bronze'+ '')
                AND dataset_name  in ($dataset_name)
                AND project_name  in ($project_name)
                AND metric_name IN ('processing_started_date', 'processing_finished_date', 'processing_exit_code', 'rows_count', 'content_latest_date')
        ),
        MergedEvents AS (
            SELECT
                job_id,
                context_id,
                timestamp,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                [processing_started_date] AS processing_started_date_value,
                [processing_finished_date] AS processing_finished_date_value,
                [processing_exit_code] AS processing_exit_code_value,
                [content_latest_date] AS content_latest_date,
                [rows_count] AS rows_count_value
            FROM
                FilteredEvents
            PIVOT (
                MAX(metric_value)
                FOR metric_name IN ([processing_started_date], [processing_finished_date], [processing_exit_code], [rows_count], [content_latest_date])
            ) AS PivotTable
        ),
        Finalevents as
        (
        SELECT
            MAX(project_name) AS 'Application Source',
            MAX(dataset_name) AS 'Dataset',
            MAX(landing_zone) AS 'Zone',
            MAX(
                CASE subscription_id
                    WHEN '6b4a5b3f-1015-42da-a46a-2890a5abed30' THEN 'IFM CORE PROD'
                    WHEN '2698ca5b-bf81-43fb-8fe2-f0e21bf068e5' THEN 'IFM CORE UAT/TEST'
                    WHEN '746ac5b9-70eb-4c76-bdf4-0664bfdff2ea' THEN 'IFM CORE DEV'
                    WHEN 'cf25f2a1-4d40-45af-bb81-87ec46112b3e' THEN 'SDX STA/PRD'
                    WHEN 'c0978b9d-b809-45f4-aa76-391ceb2cfdba' THEN 'SDX DEV/TEST'
                    WHEN '8eaa3d95-3cd2-49d8-b44a-7ea47a6fb58b' THEN 'SDX SILVER'
                    WHEN 'daf86ec1-725c-493f-bf09-a1f129b8588a' THEN 'SDX INT/UAT'
                    WHEN 'fea1e9f0-0e20-426f-906e-bc76e5a566ad' THEN 'SDX Sandbox'
                    WHEN '6e3fc63f-851b-4fc7-8499-48f6a9c28a65' THEN 'SDX Global Shared Services'
                    ELSE 'Undefined'
            END
            ) AS 'Subscription',
            MAX(takeoff_zone) + ' to ' + MAX(landing_zone) AS 'Activity',
            CASE
                WHEN MAX(processing_exit_code_value) = 0 THEN 'Succeeded'
                WHEN MAX(processing_exit_code_value) = 1 THEN 'No New Data'
                WHEN MAX(processing_exit_code_value) = 2 THEN 'Skipped'
                WHEN MAX(processing_exit_code_value) IS NULL THEN 'Running'
                ELSE 'Failed'
            END AS 'Status',
            DATEADD(SECOND, MAX([timestamp]), '1970-01-01') AS 'Landed at',
            DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([timestamp]) AS 'Landed Since',
            DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([content_latest_date]) AS 'Freshness',
            CAST(MAX(processing_finished_date_value) - MAX(processing_started_date_value) AS BIGINT) AS 'Duration',
            ISNULL(CAST(CAST(MAX(rows_count_value) AS BIGINT) AS VARCHAR), 'N/A') AS 'Rows'
        FROM MergedEvents
        GROUP BY job_id, context_id
        ),
        Eventsdata as(
            Select [Application Source] as ApplicationSource, Dataset,Zone, Subscription, Activity, Status,[Landed at] as LandedAt,[Landed Since] as LandedSince,[Freshness] as Freshness, Duration,[Rows] as IngestedRows from Finalevents
            where Status in ($status)
        ),

        finaldata as (select 
            ApplicationSource , 
            Dataset, 
            case 
                when Applicationsource like '%d365%'
                    and  count(case when Activity = 'staging to bronze' and status = 'succeeded' then 1 end) >= 1
                    and count(case when Activity = 'bronze to silver' and status = 'succeeded' then 1 end) >= 1
                then 'OK'        
                else 'NOT OK'
            end as [Overall Status],
            Subscription as [Datalake Location],
            case 
                when count(case when Activity = 'staging to bronze' and status = 'succeeded' then 1 end) >= 1
                then 'OK'
                else 'NOT OK'
            end as [Bronze History Status],
            case 
                when count(case when Activity = 'bronze to silver' and status = 'succeeded' then 1 end) >= 1 or count(case when Activity = 'staging to silver' and status = 'succeeded' then 1 end) >= 1
                    then 'OK'
                else 'NOT OK'
            end as [Bronze Standardized Status],     
            min(case 
                when Applicationsource like '%d365%' and
                    Activity = 'staging to bronze' then LandedAt 
                end) as [Pipe Line Execution StartTime],
                max(case 
                when Applicationsource like '%d365%' and
                    Activity = 'bronze to silver' then LandedAt 
                end) as [Pipe Line Execution EndTime],
            --max(case when Activity = 'staging to silver' then LandedAt end) as [Pipe Line execution EndTime],
            datediff(second,
            min(case
                when Applicationsource like '%d365%' and
                    Activity = 'staging to bronze' then LandedAt 
                end),current_timestamp
            ) as [Pipe Line Executed Since],
            --max(LandedSince) as [Pipe Line Executed Since],
            max(Freshness) as Freshness,
            datediff(second, 
			min(case when (ApplicationSource like '%d365%') and Activity = 'staging to bronze' then landedAt end),
			max(case when (ApplicationSource like '%d365%') and (Activity = 'staging to silver' or Activity = 'bronze to silver') then landedAt end)
           ) as 'Total Execution Time',
           convert(Date, LandedAt) as executedDate
        From Eventsdata
        group by ApplicationSource,
            Dataset,
            subscription,
            convert(Date, LandedAt)
        ),

        RankedData as
        (select  ApplicationSource,
                    Dataset,
                    [Datalake Location],
                    executedDate,
                    case 
                    when executedDate < getdate()
                    then DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                        else
                        DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Overall Refresh Status in Second],
                    case 
                    when executedDate < getdate()
                    then DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                        else
                        DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Overall Refresh Status],
                    case when executedDate < getdate()
                    then DatedIff(second, max([Pipe Line Execution StartTime]) over (partition by ApplicationSource, Dataset), GetDate())
                        else
                        DatedIff(second, max([Pipe Line Execution StartTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Bronze Refresh Status],
                    case when executedDate < getdate()
                    then DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                        else
                        DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Silver Refresh Status],
                    row_number() over (partition by ApplicationSource, Dataset order by executedDate desc) as rownum,
                    [Pipe Line Execution EndTime],
                    [Pipe Line Execution StartTime],
                    [Pipe Line Executed Since],
                    Freshness,
                    [Total Execution Time],
                    86400 AS [Freshness Threshold]
        from finalData
            where  [Overall Status] = 'OK'
        )
        select ApplicationSource, 
            Dataset,  
			[Freshness Threshold] as 'Threshold',
            [Overall Refresh Status] as 'Availability',
            [Bronze Refresh Status] as 'Bronze Availability Status',
            [Silver Refresh Status] as 'Silver Availability Status', 
            [Pipe Line Execution StartTime],
            [Pipe Line Execution EndTime],
            ([Freshness Threshold] - [Overall Refresh Status in second]) AS Differenceintime,
			CASE
				WHEN ([Freshness Threshold] - [Overall Refresh Status in second]) < 0 THEN 1
				WHEN ([Freshness Threshold] - [Overall Refresh Status in second]) > 0 THEN 2
				ELSE 0
			END AS Colour_Code
        from RankedData
        where  rownum = 1 and ([Freshness Threshold] - [Overall Refresh Status in second] > 0)
        order by executedDate desc
   ";
   table.new(
    title = 'Dataset Pipeline Availability [Within Threshold] - Tabular View',
    datasource = 'IFM Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Pipe Line Execution StartTime',properties=[{id: 'unit', value: 's'},{id: 'custom.width',value: 226}]
    ).addOverridesByFieldName(field='Pipe Line Execution EndTime',properties=[{id: 'unit', value: 's'},{id: 'custom.width',value: 229}]
    ).addOverridesByFieldName(field='ApplicationSource',properties=[{id: 'custom.width',value: 181}]
    ).addOverridesByFieldName(field='Dataset',properties=[{id: 'custom.width',value: 138}]
    ).addOverridesByFieldName(field='Threshold',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Availability',properties=[{id: 'unit',value: "s"}]
    ).addOverridesByFieldName(field='Colour_Code',properties=[{id: 'custom.cellOptions',value: {type: 'color-background', applyToRow: true}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'light-green',value: null},{color: 'light-orange',value: 0},{color: 'light-red',value: 1},{color: 'super-light-green',value: 2}]}},{id: 'custom.hidden', value: true}]
    ).addOverridesByFieldName(field='Differenceintime',properties=[{id: 'custom.hidden',value: true}]
    ).addOverridesByFieldName(field='Bronze Availability Status',properties=[{id: 'unit',value: "s"}]
    ).addOverridesByFieldName(field='Silver Availability Status',properties=[{id: 'unit',value: "s"}]
);

local DatasetFreshnessOutOfThreshold = 
    local sqlQuery = "
    
    WITH 
        FilteredEvents AS (
            SELECT
                job_id,
                context_id,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                timestamp,
                metric_name,
                metric_value
            FROM
                [observability].[event]
            WHERE
                context_id in ('oss.apac.glb.d365_account_silver', 'oss.apac.glb.d365_account_bronze', 
					'oss.apac.glb.d365_activitypointer_silver', 'oss.apac.glb.d365_activitypointer_bronze', 
					'oss.apac.glb.d365_adx_portalcomment_silver', 'oss.apac.glb.d365_adx_portalcomment_bronze', 
					'oss.apac.glb.d365_annotation_silver', 'oss.apac.glb.d365_annotation_bronze', 
					'oss.apac.glb.d365_bookableresource_silver', 'oss.apac.glb.d365_bookableresource_bronze', 
					'oss.apac.glb.d365_bookableresourcebooking_silver', 'oss.apac.glb.d365_bookableresourcebooking_bronze', 
					'oss.apac.glb.d365_bookableresourcecategory_silver',
					'oss.apac.glb.d365_bookableresourcecategory_bronze', 
					'oss.apac.glb.d365_contact_silver', 'oss.apac.glb.d365_contact_bronze', 
					'oss.apac.glb.d365_contract_silver', 'oss.apac.glb.d365_contract_bronze', 
					'oss.apac.glb.d365_entitlement_silver', 'oss.apac.glb.d365_entitlement_bronze', 
					'oss.apac.glb.d365_ifm_assettype_silver', 'oss.apac.glb.d365_ifm_assettype_bronze',
					'oss.apac.glb.d365_ifm_contract_silver', 'oss.apac.glb.d365_ifm_contract_bronze', 
					'oss.apac.glb.d365_ifm_country_silver', 'oss.apac.glb.d365_ifm_country_bronze', 
					'oss.apac.glb.d365_ifm_feedback_silver', 'oss.apac.glb.d365_ifm_feedback_bronze', 
					'oss.apac.glb.d365_ifm_log_silver', 'oss.apac.glb.d365_ifm_log_bronze',
					'oss.apac.glb.d365_ifm_masterservicecategory_silver', 
					'oss.apac.glb.d365_ifm_masterservicecategory_bronze',
					'oss.apac.glb.d365_ifm_servicecategory_silver',
					'oss.apac.glb.d365_ifm_servicecategory_bronze',
					'oss.apac.glb.d365_ifm_workordernote_silver', 
					'oss.apac.glb.d365_ifm_workordernote_bronze', 
					'oss.apac.glb.d365_incident_silver', 
					'oss.apac.glb.d365_incident_bronze', 
					'oss.apac.glb.d365_incidentresolution_silver', 
					'oss.apac.glb.d365_incidentresolution_bronze',
					'oss.apac.glb.d365_msdyn_agreement_silver',
					'oss.apac.glb.d365_msdyn_agreement_bronze',
					'oss.apac.glb.d365_msdyn_customerasset_silver',
					'oss.apac.glb.d365_msdyn_customerasset_bronze', 
					'oss.apac.glb.d365_msdyn_expense_silver',
					'oss.apac.glb.d365_msdyn_expense_bronze', 
					'oss.apac.glb.d365_msdyn_priority_silver', 
					'oss.apac.glb.d365_msdyn_priority_bronze', 
					'oss.apac.glb.d365_msdyn_project_silver',
					'oss.apac.glb.d365_msdyn_project_bronze', 
					'oss.apac.glb.d365_msdyn_projectapproval_silver',
					'oss.apac.glb.d365_msdyn_projectapproval_bronze', 
					'oss.apac.glb.d365_msdyn_projecttask_silver', 
					'oss.apac.glb.d365_msdyn_projecttask_bronze', 
					'oss.apac.glb.d365_msdyn_resourcerequirement_silver',
					'oss.apac.glb.d365_msdyn_resourcerequirement_bronze', 
					'oss.apac.glb.d365_msdyn_survey_silver', 
					'oss.apac.glb.d365_msdyn_survey_bronze', 'oss.apac.glb.d365_msdyn_timeentry_silver', 
					'oss.apac.glb.d365_msdyn_timeentry_bronze', 'oss.apac.glb.d365_msdyn_workorder_silver', 
					'oss.apac.glb.d365_msdyn_workorder_bronze', 'oss.apac.glb.d365_msdyn_workordertype_silver',
					'oss.apac.glb.d365_msdyn_workordertype_bronze', 
					'oss.apac.glb.d365_pricelevel_silver', 'oss.apac.glb.d365_pricelevel_bronze', 
					'oss.apac.glb.d365_queue_silver', 'oss.apac.glb.d365_queue_bronze',
					'oss.apac.glb.d365_quote_silver', 'oss.apac.glb.d365_quote_bronze',
					'oss.apac.glb.d365_role_silver', 'oss.apac.glb.d365_role_bronze', 
					'oss.apac.glb.d365_sdxmob_facility_silver', 'oss.apac.glb.d365_sdxmob_facility_bronze',
					'oss.apac.glb.d365_sla_silver', 'oss.apac.glb.d365_sla_bronze',
					'oss.apac.glb.d365_slaitem_silver', 'oss.apac.glb.d365_slaitem_bronze',
					'oss.apac.glb.d365_slakpiinstance_silver',
					'oss.apac.glb.d365_slakpiinstance_bronze',
					'oss.apac.glb.d365_systemuser_silver',
					'oss.apac.glb.d365_systemuser_bronze',
					'oss.apac.glb.d365_timezonedefinition_silver',
					'oss.apac.glb.d365_timezonedefinition_bronze',
					'oss.apac.glb.d365_timezonerule_silver',
					'oss.apac.glb.d365_timezonerule_bronze',
					'oss.apac.glb.d365_transactioncurrency_silver',
					'oss.apac.glb.d365_transactioncurrency_bronze',
					'oss.coe.glb.d365_account_silver', 
					'oss.coe.glb.d365_account_bronze', 
					'oss.coe.glb.d365_activitypointer_silver',
					'oss.coe.glb.d365_activitypointer_bronze',
					'oss.coe.glb.d365_adx_portalcomment_silver', 
					'oss.coe.glb.d365_adx_portalcomment_bronze',
					'oss.coe.glb.d365_annotation_silver', 
					'oss.coe.glb.d365_annotation_bronze', 
					'oss.coe.glb.d365_bookableresource_silver',
					'oss.coe.glb.d365_bookableresource_bronze',
					'oss.coe.glb.d365_bookableresourcebooking_silver', 'oss.coe.glb.d365_bookableresourcebooking_bronze',
					'oss.coe.glb.d365_bookableresourcecategory_silver', 
					'oss.coe.glb.d365_bookableresourcecategory_bronze', 
					'oss.coe.glb.d365_contact_silver', 'oss.coe.glb.d365_contact_bronze', 
					'oss.coe.glb.d365_contract_silver', 'oss.coe.glb.d365_contract_bronze',
					'oss.coe.glb.d365_entitlement_silver',
					'oss.coe.glb.d365_entitlement_bronze', 
					'oss.coe.glb.d365_ifm_assettype_silver',
					'oss.coe.glb.d365_ifm_assettype_bronze',
					'oss.coe.glb.d365_ifm_contract_silver', 
					'oss.coe.glb.d365_ifm_contract_bronze',
					'oss.coe.glb.d365_ifm_country_silver',
					'oss.coe.glb.d365_ifm_country_bronze',
					'oss.coe.glb.d365_ifm_feedback_silver', 
					'oss.coe.glb.d365_ifm_feedback_bronze', 
					'oss.coe.glb.d365_ifm_log_silver',
					'oss.coe.glb.d365_ifm_log_bronze',
					'oss.coe.glb.d365_ifm_masterservicecategory_silver',
					'oss.coe.glb.d365_ifm_masterservicecategory_bronze',
					'oss.coe.glb.d365_ifm_servicecategory_silver',
					'oss.coe.glb.d365_ifm_servicecategory_bronze',
					'oss.coe.glb.d365_ifm_workordernote_silver', 
					'oss.coe.glb.d365_ifm_workordernote_bronze',
					'oss.coe.glb.d365_incident_silver', 
					'oss.coe.glb.d365_incident_bronze', 
					'oss.coe.glb.d365_incidentresolution_silver', 
					'oss.coe.glb.d365_incidentresolution_bronze', 
					'oss.coe.glb.d365_msdyn_agreement_silver',
					'oss.coe.glb.d365_msdyn_agreement_bronze',
					'oss.coe.glb.d365_msdyn_customerasset_silver',
					'oss.coe.glb.d365_msdyn_customerasset_bronze',
					'oss.coe.glb.d365_msdyn_expense_silver', 
					'oss.coe.glb.d365_msdyn_expense_bronze',
					'oss.coe.glb.d365_msdyn_priority_silver',
					'oss.coe.glb.d365_msdyn_priority_bronze', 
					'oss.coe.glb.d365_msdyn_project_silver', 
					'oss.coe.glb.d365_msdyn_project_bronze', 
					'oss.coe.glb.d365_msdyn_projectapproval_silver',
					'oss.coe.glb.d365_msdyn_projectapproval_bronze',
					'oss.coe.glb.d365_msdyn_projecttask_silver', 
					'oss.coe.glb.d365_msdyn_projecttask_bronze', 
					'oss.coe.glb.d365_msdyn_resourcerequirement_silver',
					'oss.coe.glb.d365_msdyn_resourcerequirement_bronze', 
					'oss.coe.glb.d365_msdyn_survey_silver', 
					'oss.coe.glb.d365_msdyn_survey_bronze', 'oss.coe.glb.d365_msdyn_timeentry_silver',
					'oss.coe.glb.d365_msdyn_timeentry_bronze', 'oss.coe.glb.d365_msdyn_workorder_silver', 
					'oss.coe.glb.d365_msdyn_workorder_bronze', 'oss.coe.glb.d365_msdyn_workordertype_silver',
					'oss.coe.glb.d365_msdyn_workordertype_bronze', 
					'oss.coe.glb.d365_pricelevel_silver', 'oss.coe.glb.d365_pricelevel_bronze', 
					'oss.coe.glb.d365_queue_silver', 'oss.coe.glb.d365_queue_bronze', 'oss.coe.glb.d365_quote_silver', 
					'oss.coe.glb.d365_quote_bronze', 'oss.coe.glb.d365_role_silver', 'oss.coe.glb.d365_role_bronze',
					'oss.coe.glb.d365_sdxmob_facility_silver', 'oss.coe.glb.d365_sdxmob_facility_bronze', 
					'oss.coe.glb.d365_sla_silver', 'oss.coe.glb.d365_sla_bronze', 'oss.coe.glb.d365_slaitem_silver',
					'oss.coe.glb.d365_slaitem_bronze', 'oss.coe.glb.d365_slakpiinstance_silver',
					'oss.coe.glb.d365_slakpiinstance_bronze', 'oss.coe.glb.d365_systemuser_silver', 
					'oss.coe.glb.d365_systemuser_bronze', 'oss.coe.glb.d365_timezonedefinition_silver',
					'oss.coe.glb.d365_timezonedefinition_bronze', 'oss.coe.glb.d365_timezonerule_silver',
					'oss.coe.glb.d365_timezonerule_bronze', 'oss.coe.glb.d365_transactioncurrency_silver', 
					'oss.coe.glb.d365_transactioncurrency_bronze', 'oss.noram.glb.d365_account_silver', 
					'oss.noram.glb.d365_account_bronze', 'oss.noram.glb.d365_activitypointer_silver',
					'oss.noram.glb.d365_activitypointer_bronze', 'oss.noram.glb.d365_adx_portalcomment_silver', 
					'oss.noram.glb.d365_adx_portalcomment_bronze',
					'oss.noram.glb.d365_annotation_silver',
					'oss.noram.glb.d365_annotation_bronze',
					'oss.noram.glb.d365_bookableresource_silver',
					'oss.noram.glb.d365_bookableresource_bronze',
					'oss.noram.glb.d365_bookableresourcebooking_silver',
					'oss.noram.glb.d365_bookableresourcebooking_bronze', 
					'oss.noram.glb.d365_bookableresourcecategory_silver', 
					'oss.noram.glb.d365_bookableresourcecategory_bronze',
					'oss.noram.glb.d365_contact_silver', 'oss.noram.glb.d365_contact_bronze',
					'oss.noram.glb.d365_contract_silver', 
					'oss.noram.glb.d365_contract_bronze', 
					'oss.noram.glb.d365_entitlement_silver', 
					'oss.noram.glb.d365_entitlement_bronze', 'oss.noram.glb.d365_ifm_assettype_silver',
					'oss.noram.glb.d365_ifm_assettype_bronze', 'oss.noram.glb.d365_ifm_contract_silver',
					'oss.noram.glb.d365_ifm_contract_bronze', 'oss.noram.glb.d365_ifm_country_silver',
					'oss.noram.glb.d365_ifm_country_bronze', 'oss.noram.glb.d365_ifm_feedback_silver',
					'oss.noram.glb.d365_ifm_feedback_bronze', 'oss.noram.glb.d365_ifm_log_silver',
					'oss.noram.glb.d365_ifm_log_bronze', 'oss.noram.glb.d365_ifm_masterservicecategory_silver',
					'oss.noram.glb.d365_ifm_masterservicecategory_bronze', 
					'oss.noram.glb.d365_ifm_servicecategory_silver',
					'oss.noram.glb.d365_ifm_servicecategory_bronze',
					'oss.noram.glb.d365_ifm_workordernote_silver',
					'oss.noram.glb.d365_ifm_workordernote_bronze',
					'oss.noram.glb.d365_incident_silver', 'oss.noram.glb.d365_incident_bronze',
					'oss.noram.glb.d365_incidentresolution_silver', 'oss.noram.glb.d365_incidentresolution_bronze',
					'oss.noram.glb.d365_msdyn_agreement_silver', 'oss.noram.glb.d365_msdyn_agreement_bronze',
					'oss.noram.glb.d365_msdyn_customerasset_silver', 'oss.noram.glb.d365_msdyn_customerasset_bronze', 
					'oss.noram.glb.d365_msdyn_expense_silver', 'oss.noram.glb.d365_msdyn_expense_bronze', 'oss.noram.glb.d365_msdyn_priority_silver',
					'oss.noram.glb.d365_msdyn_priority_bronze', 'oss.noram.glb.d365_msdyn_project_silver', 'oss.noram.glb.d365_msdyn_project_bronze',
					'oss.noram.glb.d365_msdyn_projectapproval_silver', 'oss.noram.glb.d365_msdyn_projectapproval_bronze',
					'oss.noram.glb.d365_msdyn_projecttask_silver', 'oss.noram.glb.d365_msdyn_projecttask_bronze',
					'oss.noram.glb.d365_msdyn_resourcerequirement_silver', 'oss.noram.glb.d365_msdyn_resourcerequirement_bronze', 
					'oss.noram.glb.d365_msdyn_survey_silver', 'oss.noram.glb.d365_msdyn_survey_bronze', 
					'oss.noram.glb.d365_msdyn_timeentry_silver', 'oss.noram.glb.d365_msdyn_timeentry_bronze', 
					'oss.noram.glb.d365_msdyn_workorder_silver', 'oss.noram.glb.d365_msdyn_workorder_bronze', 
					'oss.noram.glb.d365_msdyn_workordertype_silver', 'oss.noram.glb.d365_msdyn_workordertype_bronze', 
					'oss.noram.glb.d365_pricelevel_silver', 'oss.noram.glb.d365_pricelevel_bronze', 'oss.noram.glb.d365_queue_silver', 
					'oss.noram.glb.d365_queue_bronze', 'oss.noram.glb.d365_quote_silver', 'oss.noram.glb.d365_quote_bronze', 
					'oss.noram.glb.d365_role_silver', 'oss.noram.glb.d365_role_bronze', 'oss.noram.glb.d365_sdxmob_facility_silver', 
					'oss.noram.glb.d365_sdxmob_facility_bronze', 'oss.noram.glb.d365_sla_silver', 'oss.noram.glb.d365_sla_bronze', 
					'oss.noram.glb.d365_slaitem_silver', 'oss.noram.glb.d365_slaitem_bronze', 'oss.noram.glb.d365_slakpiinstance_silver', 
					'oss.noram.glb.d365_slakpiinstance_bronze', 'oss.noram.glb.d365_systemuser_silver', 
					'oss.noram.glb.d365_systemuser_bronze', 'oss.noram.glb.d365_timezonedefinition_silver', 
					'oss.noram.glb.d365_timezonedefinition_bronze', 'oss.noram.glb.d365_timezonerule_silver', 
					'oss.noram.glb.d365_timezonerule_bronze', 'oss.noram.glb.d365_transactioncurrency_silver', 
					'oss.noram.glb.d365_transactioncurrency_bronze'+ '')
                AND dataset_name  in ($dataset_name)
                AND project_name  in ($project_name)
                AND metric_name IN ('processing_started_date', 'processing_finished_date', 'processing_exit_code', 'rows_count', 'content_latest_date')
        ),
        MergedEvents AS (
            SELECT
                job_id,
                context_id,
                timestamp,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                [processing_started_date] AS processing_started_date_value,
                [processing_finished_date] AS processing_finished_date_value,
                [processing_exit_code] AS processing_exit_code_value,
                [content_latest_date] AS content_latest_date,
                [rows_count] AS rows_count_value
            FROM
                FilteredEvents
            PIVOT (
                MAX(metric_value)
                FOR metric_name IN ([processing_started_date], [processing_finished_date], [processing_exit_code], [rows_count], [content_latest_date])
            ) AS PivotTable
        ),
        Finalevents as
        (
        SELECT
            MAX(project_name) AS 'Application Source',
            MAX(dataset_name) AS 'Dataset',
            MAX(landing_zone) AS 'Zone',
            MAX(
                CASE subscription_id
                    WHEN '6b4a5b3f-1015-42da-a46a-2890a5abed30' THEN 'IFM CORE PROD'
                    WHEN '2698ca5b-bf81-43fb-8fe2-f0e21bf068e5' THEN 'IFM CORE UAT/TEST'
                    WHEN '746ac5b9-70eb-4c76-bdf4-0664bfdff2ea' THEN 'IFM CORE DEV'
                    WHEN 'cf25f2a1-4d40-45af-bb81-87ec46112b3e' THEN 'SDX STA/PRD'
                    WHEN 'c0978b9d-b809-45f4-aa76-391ceb2cfdba' THEN 'SDX DEV/TEST'
                    WHEN '8eaa3d95-3cd2-49d8-b44a-7ea47a6fb58b' THEN 'SDX SILVER'
                    WHEN 'daf86ec1-725c-493f-bf09-a1f129b8588a' THEN 'SDX INT/UAT'
                    WHEN 'fea1e9f0-0e20-426f-906e-bc76e5a566ad' THEN 'SDX Sandbox'
                    WHEN '6e3fc63f-851b-4fc7-8499-48f6a9c28a65' THEN 'SDX Global Shared Services'
                    ELSE 'Undefined'
            END
            ) AS 'Subscription',
            MAX(takeoff_zone) + ' to ' + MAX(landing_zone) AS 'Activity',
            CASE
                WHEN MAX(processing_exit_code_value) = 0 THEN 'Succeeded'
                WHEN MAX(processing_exit_code_value) = 1 THEN 'No New Data'
                WHEN MAX(processing_exit_code_value) = 2 THEN 'Skipped'
                WHEN MAX(processing_exit_code_value) IS NULL THEN 'Running'
                ELSE 'Failed'
            END AS 'Status',
            DATEADD(SECOND, MAX([timestamp]), '1970-01-01') AS 'Landed at',
            DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([timestamp]) AS 'Landed Since',
            DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([content_latest_date]) AS 'Freshness',
            CAST(MAX(processing_finished_date_value) - MAX(processing_started_date_value) AS BIGINT) AS 'Duration',
            ISNULL(CAST(CAST(MAX(rows_count_value) AS BIGINT) AS VARCHAR), 'N/A') AS 'Rows'
        FROM MergedEvents
        GROUP BY job_id, context_id
        ),
        Eventsdata as(
            Select [Application Source] as ApplicationSource, Dataset,Zone, Subscription, Activity, Status,[Landed at] as LandedAt,[Landed Since] as LandedSince,[Freshness] as Freshness, Duration,[Rows] as IngestedRows from Finalevents
            where Status in ($status)
        ),

        finaldata as (select 
            ApplicationSource , 
            Dataset, 
            case 
                when Applicationsource like '%d365%'
                    and  count(case when Activity = 'staging to bronze' and status = 'succeeded' then 1 end) >= 1
                    and count(case when Activity = 'bronze to silver' and status = 'succeeded' then 1 end) >= 1
                then 'OK'        
                else 'NOT OK'
            end as [Overall Status],
            Subscription as [Datalake Location],
            case 
                when count(case when Activity = 'staging to bronze' and status = 'succeeded' then 1 end) >= 1
                then 'OK'
                else 'NOT OK'
            end as [Bronze History Status],
            case 
                when count(case when Activity = 'bronze to silver' and status = 'succeeded' then 1 end) >= 1 or count(case when Activity = 'staging to silver' and status = 'succeeded' then 1 end) >= 1
                    then 'OK'
                else 'NOT OK'
            end as [Bronze Standardized Status],     
            min(case 
                when Applicationsource like '%d365%' and
                    Activity = 'staging to bronze' then LandedAt 
                end) as [Pipe Line Execution StartTime],
                max(case 
                when Applicationsource like '%d365%' and
                    Activity = 'bronze to silver' then LandedAt 
                end) as [Pipe Line Execution EndTime],
            --max(case when Activity = 'staging to silver' then LandedAt end) as [Pipe Line execution EndTime],
            datediff(second,
            min(case
                when Applicationsource like '%d365%' and
                    Activity = 'staging to bronze' then LandedAt 
                end),current_timestamp
            ) as [Pipe Line Executed Since],
            --max(LandedSince) as [Pipe Line Executed Since],
            max(Freshness) as Freshness,
            datediff(second, 
			min(case when (ApplicationSource like '%d365%') and Activity = 'staging to bronze' then landedAt end),
			max(case when (ApplicationSource like '%d365%') and (Activity = 'staging to silver' or Activity = 'bronze to silver') then landedAt end)
           ) as 'Total Execution Time',
           convert(Date, LandedAt) as executedDate
        From Eventsdata
        group by ApplicationSource,
            Dataset,
            subscription,
            convert(Date, LandedAt)
        ),

        RankedData as
        (select  ApplicationSource,
                    Dataset,
                    [Datalake Location],
                    executedDate,
                    case 
                    when executedDate < getdate()
                    then DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                        else
                        DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Overall Refresh Status in Second],
                    case 
                    when executedDate < getdate()
                    then DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                        else
                        DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Overall Refresh Status],
                    case when executedDate < getdate()
                    then DatedIff(second, max([Pipe Line Execution StartTime]) over (partition by ApplicationSource, Dataset), GetDate())
                        else
                        DatedIff(second, max([Pipe Line Execution StartTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Bronze Refresh Status],
                    case when executedDate < getdate()
                    then DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                        else
                        DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Silver Refresh Status],
                    row_number() over (partition by ApplicationSource, Dataset order by executedDate desc) as rownum,
                    [Pipe Line Execution EndTime],
                    [Pipe Line Execution StartTime],
                    [Pipe Line Executed Since],
                    Freshness,
                    [Total Execution Time],
                    86400 AS [Freshness Threshold]
        from finalData
            where  [Overall Status] = 'OK'
        )
        select ApplicationSource, 
            Dataset,  
			[Freshness Threshold] as 'Threshold',
            [Overall Refresh Status] as 'Availability',
            [Bronze Refresh Status] as 'Bronze Availability Status',
            [Silver Refresh Status] as 'Silver Availability Status', 
            [Pipe Line Execution StartTime],
            [Pipe Line Execution EndTime],
            ([Freshness Threshold] - [Overall Refresh Status in second]) AS Differenceintime,
			CASE
				WHEN ([Freshness Threshold] - [Overall Refresh Status in second]) < 0 THEN 1
				WHEN ([Freshness Threshold] - [Overall Refresh Status in second]) > 0 THEN 2
				ELSE 0
			END AS Colour_Code
        from RankedData 
        where  rownum = 1 and ([Freshness Threshold] - [Overall Refresh Status in second] < 0)
        order by executedDate desc
   
   ";
   table.new(
    title = 'Dataset Pipeline Availability [Out Of Threshold] - Tabular View',
    datasource = 'IFM Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Pipe Line Execution StartTime',properties=[{id: 'unit', value: 's'},{id: 'custom.width',value: 226}]
    ).addOverridesByFieldName(field='Pipe Line Execution EndTime',properties=[{id: 'unit', value: 's'},{id: 'custom.width',value: 229}]
    ).addOverridesByFieldName(field='ApplicationSource',properties=[{id: 'custom.width',value: 181}]
    ).addOverridesByFieldName(field='Dataset',properties=[{id: 'custom.width',value: 138}]
    ).addOverridesByFieldName(field='Threshold',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Availability',properties=[{id: 'unit',value: "s"}]
    ).addOverridesByFieldName(field='Colour_Code',properties=[{id: 'custom.cellOptions',value: {type: 'color-background', applyToRow: true}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'green',value: null},{color: 'light-orange',value: 0},{color: 'light-red',value: 1},{color: 'super-light-green',value: 2}]}},{id: 'custom.hidden', value: true}]
    ).addOverridesByFieldName(field='Differenceintime',properties=[{id: 'custom.hidden',value: true}]
    ).addOverridesByFieldName(field='Bronze Availability Status',properties=[{id: 'unit',value: "s"}]
    ).addOverridesByFieldName(field='Silver Availability Status',properties=[{id: 'unit',value: "s"}]
);

local TrackingVolumeFunctionalFreshnessNORAMD365 = 
    local sqlQuery = "
    with rankeddata as ( 
        select project_name , 
				dataset_name, 
				record_date as 'functional_date', 
				record_count, 
				group_by,
                row_number() over (partition by project_name, dataset_name, group_by order by record_date desc) as rn
        FROM [observability].[d365_custom_slo_metrics]
        where project_name = 'oss.noram.glb.d365' and dataset_name in ($dataset_name) and (dataset_name = 'worklog' and group_by = 'modifydate' or group_by = 'modifiedon')
        ),
      cte1 as (
        select coalesce(r.project_name, 'oss.noram.glb.d365') as 'Application Source', 
				d.dataset_name as 'Dataset Name',
                r.group_by as 'Functional Date',
                case when r.dataset_name in ('queue', 'role') then 172800
                     when r.dataset_name in ('msdyn_timeentry') then 345600
                     WHEN r.dataset_name IN ('bookableresource') THEN 604800
                     WHEN r.dataset_name IN ('bookableresourcebooking', 'bookableresourcecategory', 'ifm_masterservicecategory','ifm_servicecategory', 'sla', 'slaitem') THEN 1209600
                     when r.dataset_name in ('sdxmob_facility') then 1814400
                     when r.dataset_name in ('ifm_assettype','ifm_contract', 'ifm_country', 'msdyn_agreement', 'msdyn_priority', 'msdyn_survey', 'msdyn_workordertype', 'quote', 'timezonedefinition', 'timezonerule', 'transactioncurrency') then 2419200
                      ELSE 86400 END AS [Freshness Threshold],
                Coalesce(cast(datediff(hour, r.functional_date, getdate()) as varchar), 'NA') as 'Functional Freshness',
                				Coalesce(datediff(second,r.functional_date, getdate()),0) as 'Functional Freshness Updated',
                coalesce(cast(r.record_count as varchar), 'NA') as 'Transaction Count' 
	    from (
			select distinct dataset_name from [observability].[d365_custom_slo_metrics] where  dataset_name in ($dataset_name)) d
		left join rankeddata r on d.dataset_name = r.dataset_name
        where (r.rn = 1 or r.rn IS NULL) and r.functional_date is not null and r.record_count is not null
       )
       select [Application Source], [Dataset Name], [Functional Date], [Transaction Count], [Freshness Threshold], [Functional Freshness],
         case when [Functional Freshness Updated] < [Freshness Threshold] then 0 else 1 end as [Status] from cte1
       where [Dataset Name] in ($dataset_name) 
       order by [Dataset Name] asc";
    table.new(
        title='Tracking Functional Freshness - Noram D365',
        datasource='Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Functional Freshness',properties=[{id: 'unit', value: 'h'},{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'NA': { color: 'red', index: 0 }}}]}]
    ).addOverridesByFieldName(field='Freshness Threshold',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Functional Date',properties=[{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'NA': { color: 'red', index: 0 }}}]}]
    ).addOverridesByFieldName(field='Transaction Count',properties=[{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'NA': { color: 'red', index: 0 }}}]}]
    ).addOverridesByFieldName(field='Status',properties=[{id: 'custom.cellOptions',value: {type: 'color-background', applyToRow: true}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'light-green',value: 0},{color: 'light-red',value: 1}]}},{id: 'custom.hidden', value: true}]
);

local TrackingVolumeFunctionalFreshnessCOED365 = 
    local sqlQuery = "    
    with rankeddata as ( 
        select project_name , 
                dataset_name, 
                record_date as 'functional_date', 
                record_count, 
                group_by,
                row_number() over (partition by project_name, dataset_name, group_by order by record_date desc) as rn
        FROM observability.d365_custom_slo_metrics
        where project_name = 'oss.coe.glb.d365' and dataset_name in ($dataset_name) and (dataset_name = 'worklog' and group_by = 'modifydate' or group_by = 'modifiedon')
        ),
    cte1 as (
        select coalesce(r.project_name, 'oss.coe.glb.d365') as 'Application Source', 
                d.dataset_name as 'Dataset Name',
                r.group_by as 'Functional Date',
                case when r.dataset_name in ('queue', 'role') then 172800
                    when r.dataset_name in ('msdyn_timeentry') then 345600
                    WHEN r.dataset_name IN ('bookableresource') THEN 604800
                    WHEN r.dataset_name IN ('bookableresourcebooking', 'bookableresourcecategory', 'ifm_masterservicecategory','ifm_servicecategory', 'sla', 'slaitem') THEN 1209600
                    when r.dataset_name in ('sdxmob_facility') then 1814400
                    when r.dataset_name in ('ifm_assettype','ifm_contract', 'ifm_country', 'msdyn_agreement', 'msdyn_priority', 'msdyn_survey', 'msdyn_workordertype', 'quote', 'timezonedefinition', 'timezonerule', 'transactioncurrency') then 2419200
                    ELSE 86400 END AS [Freshness Threshold],
                Coalesce(cast(datediff(hour, r.functional_date, getdate()) as varchar), 'NA') as 'Functional Freshness',
                                Coalesce(datediff(second,r.functional_date, getdate()),0) as 'Functional Freshness Updated',
                coalesce(cast(r.record_count as varchar), 'NA') as 'Transaction Count' 
        from (
            select distinct dataset_name from observability.d365_custom_slo_metrics where  dataset_name in ($dataset_name)) d
        left join rankeddata r on d.dataset_name = r.dataset_name
        where (r.rn = 1 or r.rn IS NULL) and r.functional_date is not null and r.record_count is not null
    )
    select [Application Source], [Dataset Name], [Functional Date], [Transaction Count], [Freshness Threshold], [Functional Freshness],
        case when [Functional Freshness Updated] < [Freshness Threshold] then 0 else 1 end as [Status] from cte1
    where [Dataset Name] in ($dataset_name) 
    order by [Dataset Name] asc";
    table.new(
        title='Tracking Functional Freshness - COE D365',
        datasource='Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Functional Freshness',properties=[{id: 'unit', value: 'h'},{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'NA': { color: 'red', index: 0 }}}]}]
    ).addOverridesByFieldName(field='Freshness Threshold',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Functional Date',properties=[{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'NA': { color: 'red', index: 0 }}}]}]
    ).addOverridesByFieldName(field='Transaction Count',properties=[{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'NA': { color: 'red', index: 0 }}}]}]
    ).addOverridesByFieldName(field='Status',properties=[{id: 'custom.cellOptions',value: {type: 'color-background', applyToRow: true}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'light-green',value: 0},{color: 'light-red',value: 1}]}},{id: 'custom.hidden', value: true}]
);

local TrackingVolumeFunctionalFreshnessAPACD365 = 
    local sqlQuery = "    
    with rankeddata as ( 
        select project_name , 
				dataset_name, 
				record_date as 'functional_date', 
				record_count, 
				group_by,
                row_number() over (partition by project_name, dataset_name, group_by order by record_date desc) as rn
        FROM [observability].[d365_custom_slo_metrics]
        where project_name = 'oss.apac.glb.d365' and dataset_name in ($dataset_name) and (dataset_name = 'worklog' and group_by = 'modifydate' or group_by = 'modifiedon')
        ),
      cte1 as (
        select coalesce(r.project_name, 'oss.apac.glb.d365') as 'Application Source', 
				d.dataset_name as 'Dataset Name',
                r.group_by as 'Functional Date',
                case when r.dataset_name in ('queue', 'role') then 172800
                     when r.dataset_name in ('msdyn_timeentry') then 345600
                     WHEN r.dataset_name IN ('bookableresource') THEN 604800
                     WHEN r.dataset_name IN ('ifm_masterservicecategory','bookableresourcebooking', 'bookableresourcecategory','ifm_servicecategory', 'sla', 'slaitem') THEN 1209600
                     when r.dataset_name in ('sdxmob_facility') then 1814400
                     when r.dataset_name in ('ifm_assettype','ifm_contract', 'ifm_country', 'msdyn_agreement', 'msdyn_priority', 'msdyn_project', 'msdyn_projectapproval', 'msdyn_survey', 'msdyn_workordertype', 'quote', 'timezonedefinition', 'timezonerule', 'transactioncurrency') then 2419200
                      ELSE 86400 END AS [Freshness Threshold],
                Coalesce(cast(datediff(hour, r.functional_date, getdate()) as varchar), 'NA') as 'Functional Freshness',
                				Coalesce(datediff(second,r.functional_date, getdate()),0) as 'Functional Freshness Updated',
                coalesce(cast(r.record_count as varchar), 'NA') as 'Transaction Count' 
	    from (
			select distinct dataset_name from [observability].[d365_custom_slo_metrics] where  dataset_name in ($dataset_name)) d
		left join rankeddata r on d.dataset_name = r.dataset_name
        where (r.rn = 1 or r.rn IS NULL) and r.functional_date is not null and r.record_count is not null
       )
       select [Application Source], [Dataset Name], [Functional Date], [Transaction Count], [Freshness Threshold], [Functional Freshness],
         case when [Functional Freshness Updated] < [Freshness Threshold] then 0 else 1 end as [Status] from cte1
       where [Dataset Name] in ($dataset_name) 
       order by [Dataset Name] asc";
    table.new(
        title='Tracking Functional Freshness - APAC D365',
        datasource='Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Functional Freshness',properties=[{id: 'unit', value: 'h'},{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'NA': { color: 'red', index: 0 }}}]}]
    ).addOverridesByFieldName(field='Freshness Threshold',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Functional Date',properties=[{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'NA': { color: 'red', index: 0 }}}]}]
    ).addOverridesByFieldName(field='Transaction Count',properties=[{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'NA': { color: 'red', index: 0 }}}]}]
    ).addOverridesByFieldName(field='Status',properties=[{id: 'custom.cellOptions',value: {type: 'color-background', applyToRow: true}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'light-green',value: 0},{color: 'light-red',value: 1}]}},{id: 'custom.hidden', value: true}]
);

local TrackingVolumeTechnicalFreshnessCOED365 = 
    local sqlQuery = "
    
    with rankeddata as ( 
	    select project_name , 
				dataset_name, 
				record_date as 'functional_date', 
				record_count,
				group_by,
                   row_number() over (partition by project_name, dataset_name, group_by order by record_date desc) as rn
                    FROM observability.d365_custom_slo_metrics
                where group_by = 'ingestion_date'
                and project_name = 'oss.coe.glb.d365'
                and dataset_name in ($dataset_name)
        ),
		avg_data as 
			( 
				select dataset_name, group_by, avg(record_count) as Average_transaction_count from rankeddata
				where datediff(day, functional_date, getdate()) between 7 and 28
				group by dataset_name, group_by
			),
        cte1 as (
        select r.project_name as 'Application Source', 
				r.dataset_name as 'Dataset Name',
                cast(r.functional_date as varchar) as 'Ingestion Date', 
                case when r.dataset_name in ('queue', 'role') then 172800
                     when r.dataset_name in ('msdyn_timeentry') then 345600
                     WHEN r.dataset_name IN ('ifm_masterservicecategory','ifm_servicecategory', 'sla', 'slaitem') THEN 1209600
                     when r.dataset_name in ('sdxmob_facility') then 1814400
                     when r.dataset_name in ('ifm_assettype','ifm_contract','bookableresource', 'bookableresourcebooking', 'bookableresourcecategory', 'ifm_country', 'msdyn_agreement', 'msdyn_priority', 'msdyn_project', 'msdyn_projectapproval', 'msdyn_projecttask', 'msdyn_survey', 'msdyn_workordertype', 'quote', 'timezonedefinition', 'timezonerule', 'transactioncurrency') then 2419200
                      ELSE 86400 END AS [Freshness Threshold], 
                cast(datediff(hour, r.functional_date, getdate()) as varchar) as 'Technical Freshness',
                datediff(second, r.functional_date, getdate()) as 'Technical Freshness Updated',  
                r.record_count as Transaction_Count,
                a.Average_transaction_count as [Average Transaction Count],
                case when 
					a.Average_transaction_count is NOT NULL 
                        then cast((r.record_count - a.Average_transaction_count)* 4.0 / nullif(a.Average_transaction_count, 0) as decimal(10, 4))
                    else NULL
                end as 'Variance'
        FROM rankeddata r
		left join avg_data a on r.dataset_name = a.dataset_name and r.group_by = a.group_by
        where r.rn = 1 or r.rn IS NULL
    )

    select [Application Source], [Dataset Name], [Ingestion Date], 
        [Freshness Threshold], [Technical Freshness], [Transaction_Count], 
        [Average Transaction Count], [Variance],
         case when [Technical Freshness Updated] < [Freshness Threshold] then 0 else 1 end as [Status] from cte1
           where [Dataset Name] in ($dataset_name) 
        order by [Dataset Name] asc";
    table.new(
        title='Tracking Technical Freshness - COE D365',
        datasource='Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Technical Freshness',properties=[{id: 'unit', value: 'h'},{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'NA': { color: 'red', index: 0 }}}]}]
    ).addOverridesByFieldName(field='Freshness Threshold',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Ingestion Date',properties=[{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'NA': { color: 'red', index: 0 }}}]}]
    ).addOverridesByFieldName(field='Transaction Count',properties=[{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'NA': { color: 'red', index: 0 }}}]}]
    ).addOverridesByFieldName(field='Status',properties=[{id: 'custom.cellOptions',value: {type: 'color-background', applyToRow: true}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'light-green',value: 0},{color: 'light-red',value: 1}]}},{id: 'custom.hidden', value: true}]
);

local TrackingVolumeTechnicalFreshnessNORAMD365 = 
    local sqlQuery = "
    with rankeddata as ( 
	    select project_name , 
				dataset_name, 
				record_date as 'functional_date', 
				record_count,
				group_by,
                   row_number() over (partition by project_name, dataset_name, group_by order by record_date desc) as rn
                    FROM observability.d365_custom_slo_metrics
                where group_by = 'ingestion_date'
                and project_name = 'oss.noram.glb.d365'
                and dataset_name in ($dataset_name)
        ),
		avg_data as 
			( 
				select dataset_name, group_by, avg(record_count) as Average_transaction_count from rankeddata
				where datediff(day, functional_date, getdate()) between 7 and 28
				group by dataset_name, group_by
			),
        cte1 as (
        select r.project_name as 'Application Source', 
				r.dataset_name as 'Dataset Name',
                cast(r.functional_date as varchar) as 'Ingestion Date', 
                case when r.dataset_name in ('queue', 'role') then 172800
                     when r.dataset_name in ('msdyn_timeentry') then 345600
                     WHEN r.dataset_name IN ('bookableresource') THEN 604800
                     WHEN r.dataset_name IN ('bookableresourcebooking', 'bookableresourcecategory', 'ifm_masterservicecategory','ifm_servicecategory', 'sla', 'slaitem') THEN 1209600
                     when r.dataset_name in ('sdxmob_facility') then 1814400
                     when r.dataset_name in ('ifm_assettype','ifm_contract', 'ifm_country', 'msdyn_agreement', 'msdyn_priority', 'msdyn_survey', 'msdyn_workordertype', 'quote', 'timezonedefinition', 'timezonerule', 'transactioncurrency') then 2419200
                      ELSE 86400 END AS [Freshness Threshold], 
                cast(datediff(hour, r.functional_date, getdate()) as varchar) as 'Technical Freshness',
                datediff(second, r.functional_date, getdate()) as 'Technical Freshness Updated',  
                r.record_count as Transaction_Count,
                a.Average_transaction_count as [Average Transaction Count],
                case when 
					a.Average_transaction_count is NOT NULL 
                        then cast((r.record_count - a.Average_transaction_count)* 4.0 / nullif(a.Average_transaction_count, 0) as decimal(10, 4))
                    else NULL
                end as 'Variance'
        FROM rankeddata r
		left join avg_data a on r.dataset_name = a.dataset_name and r.group_by = a.group_by
        where r.rn = 1 or r.rn IS NULL
    )
    select [Application Source], [Dataset Name], [Ingestion Date], 
        [Freshness Threshold], [Technical Freshness], [Transaction_Count], 
        [Average Transaction Count], [Variance],
         case when [Technical Freshness Updated] < [Freshness Threshold] then 0 else 1 end as [Status] from cte1
           where [Dataset Name] in ($dataset_name) 
        order by [Dataset Name] asc";
    table.new(
        title='Tracking Technical Freshness - Noram D365',
        datasource='Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Technical Freshness',properties=[{id: 'unit', value: 'h'},{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'NA': { color: 'red', index: 0 }}}]}]
    ).addOverridesByFieldName(field='Freshness Threshold',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Ingestion Date',properties=[{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'NA': { color: 'red', index: 0 }}}]}]
    ).addOverridesByFieldName(field='Transaction Count',properties=[{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'NA': { color: 'red', index: 0 }}}]}]
    ).addOverridesByFieldName(field='Status',properties=[{id: 'custom.cellOptions',value: {type: 'color-background', applyToRow: true}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'light-green',value: 0},{color: 'light-red',value: 1}]}},{id: 'custom.hidden', value: true}]
);

local TrackingVolumeTechnicalFreshnessAPACD365 = 
    local sqlQuery = "
    with rankeddata as ( 
	    select project_name , 
				dataset_name, 
				record_date as 'functional_date', 
				record_count,
				group_by,
                   row_number() over (partition by project_name, dataset_name, group_by order by record_date desc) as rn
                    FROM observability.d365_custom_slo_metrics
                where group_by = 'ingestion_date'
                and project_name = 'oss.apac.glb.d365'
                and dataset_name in ($dataset_name)
        ),
		avg_data as 
			( 
				select dataset_name, group_by, avg(record_count) as Average_transaction_count from rankeddata
				where datediff(day, functional_date, getdate()) between 7 and 28
				group by dataset_name, group_by
			),
        cte1 as (
        select r.project_name as 'Application Source', 
				r.dataset_name as 'Dataset Name',
                cast(r.functional_date as varchar) as 'Ingestion Date', 
                case when r.dataset_name in ('queue', 'role') then 172800
                     when r.dataset_name in ('msdyn_timeentry') then 345600
                     WHEN r.dataset_name IN ('bookableresource') THEN 604800
                     WHEN r.dataset_name IN ('ifm_masterservicecategory','bookableresourcebooking', 'bookableresourcecategory','ifm_servicecategory', 'sla', 'slaitem') THEN 1209600
                     when r.dataset_name in ('sdxmob_facility') then 1814400
                     when r.dataset_name in ('ifm_assettype','ifm_contract', 'ifm_country', 'msdyn_agreement', 'msdyn_priority', 'msdyn_project', 'msdyn_projectapproval', 'msdyn_survey', 'msdyn_workordertype', 'quote', 'timezonedefinition', 'timezonerule', 'transactioncurrency') then 2419200
                      ELSE 86400 END AS [Freshness Threshold], 
                cast(datediff(hour, r.functional_date, getdate()) as varchar) as 'Technical Freshness',
                datediff(second, r.functional_date, getdate()) as 'Technical Freshness Updated',  
                r.record_count as Transaction_Count,
                a.Average_transaction_count as [Average Transaction Count],
                TRY_CAST(
                    (
                        (CAST(r.record_count AS DECIMAL(19,4)) - a.Average_transaction_count)
                        / NULLIF(a.Average_transaction_count, 0)
                        * CAST(4 AS DECIMAL(10,4))
                    )
                    AS DECIMAL(19,4)
                ) AS [Variance]
        FROM rankeddata r
		left join avg_data a on r.dataset_name = a.dataset_name and r.group_by = a.group_by
        where r.rn = 1 or r.rn IS NULL
    )
    select [Application Source], [Dataset Name], [Ingestion Date], 
        [Freshness Threshold], [Technical Freshness], [Transaction_Count], 
        [Average Transaction Count], [Variance],
         case when [Technical Freshness Updated] < [Freshness Threshold] then 0 else 1 end as [Status] from cte1
           where [Dataset Name] in ($dataset_name) 
        order by [Dataset Name] asc";
    table.new(
        title='Tracking Technical Freshness - APAC D365',
        datasource='Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Technical Freshness',properties=[{id: 'unit', value: 'h'},{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'NA': { color: 'red', index: 0 }}}]}]
    ).addOverridesByFieldName(field='Freshness Threshold',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Ingestion Date',properties=[{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'NA': { color: 'red', index: 0 }}}]}]
    ).addOverridesByFieldName(field='Transaction Count',properties=[{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'NA': { color: 'red', index: 0 }}}]}]
    ).addOverridesByFieldName(field='Status',properties=[{id: 'custom.cellOptions',value: {type: 'color-background', applyToRow: true}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'light-green',value: 0},{color: 'light-red',value: 1}]}},{id: 'custom.hidden', value: true}]
);

local DataAvailability = 
    local sqlQuery = "
    select replace(project_name, '_', '.') as 'Application Source', table_name as 'Dataset Name', 
        case when row_count > 0 then 'Data Available' else 'Data Not Available' end as 'Data Availability Status',
        format(cast(run_date as date), 'yyyy-MM-dd') as 'Latest Refresh Date'
    from observability.d365_volume_data
    where row_count >= 0 and table_name in ($dataset_name) and replace(project_name, '_', '.') in ($project_name)
    order by project_name, table_name";
    table.new(
        title='Data Availability',
        datasource='Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Data Availability Status',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'mappings',value: [{type: 'value',options: {'Data Not Available': {color: 'red','index': 1},'Data Available': {color: 'green','index': 0}}}]}]
);


local getDashboardAlertsPanel(alertName) =
grafana.alertlist.new(
title = std.format("Dashboard Alerts Observability FM D365 %s",alertName),
onlyAlertsOnDashboard = true,

)

+ {
'options' :
    {
    "dashboardAlerts": false,
    "sortOrder" : 4,
    "alertName": alertName,
    "stateFilter": {
          "firing": true,
          "pending": true,
          "noData": true,
          "normal": true,
          "error": true
        }
    }
}

+ {
"sortOrder": 1,

};

//row sections

grafana.dashboard.new(
  title='FM D365',
  refresh='5m',
  time_from='now-7d',
  editable=true,
  timezone='utc',
  schemaVersion=37,
  uid='fmd365dashbaord',
  tags=['APAC', 'Custom Ingestion', 'IFM', 'NORAM', 'Observability'])

//global filters
.addTemplate(projectTemplate)
.addTemplate(datasetTemplate)
.addTemplate(stageTemplate)
.addTemplate(statusTemplate)
.addTemplate(HidedContext)

//panels
.addPanel(panel = generatePanelCount,gridPos={h:3,w:8,x:0,y:0})
.addPanel(panel = SLOPanel,gridPos={h:3,w:8,x:8,y:0})
.addPanel(panel = generateSLIPanel,gridPos={h:3,w:8,x:16,y:0})

.addPanel(generateIngestionPipelinesByCondition('Succeeded', 'green', 0),gridPos={h: 3, w: 6, x: 0, y: 5})
.addPanel(generateIngestionPipelinesByCondition('No New Data', 'yellow', 1),gridPos={h: 3, w: 6, x: 6, y: 5})
.addPanel(generateIngestionPipelinesByCondition('Failed', 'red', -1),gridPos={h: 3, w: 6, x: 12, y: 5})
.addPanel(panel = GenerateSuccessRatio,gridPos={h: 3, w: 6, x: 18, y: 5})

.addPanel(grafana.text.new(mode='markdown',content='Succeeded: Count of Ingestion Pipelines Run Successfully during the selected period for the selected datasets.',transparent= true),gridPos={h: 3, w: 6, x: 0, y: 10})
.addPanel(grafana.text.new(mode='markdown',content='No New Data: Count of Ingestion Pipelines triggered but no data pushed from Integration during the selected period for the selected datasets.',transparent= true),gridPos={h: 3, w: 6, x: 6, y: 10})
.addPanel(grafana.text.new(mode='markdown',content='Failed: Count of Ingestion Pipelines Failed during the selected period for the selected datasets.',transparent= true),gridPos={h: 3, w: 6, x: 12, y: 10})
.addPanel(grafana.text.new(mode='markdown',content='Success ratio: It is calculated as ((Success+ No New Data)/ (success + No New Data + Failed)) * 100.',transparent= true),gridPos={h: 3, w: 6, x: 18, y: 10})

.addPanel(
    row.new(
        title="Tracking Functional Freshness",
        showTitle=true,
        collapse=true
    ).addPanel(panel = TrackingVolumeFunctionalFreshnessCOED365,gridPos={h:11,w:12,x:0,y:12}
    ).addPanel(panel = TrackingVolumeFunctionalFreshnessNORAMD365,gridPos={h:11,w:12,x:12,y:12}
    ).addPanel(panel = TrackingVolumeFunctionalFreshnessAPACD365,gridPos={h:11,w:24,x:0,y:23}),
    gridPos={h:1,w:24,x:0,y:45}
)
.addPanel(
    row.new(
        title="Tracking Technical Freshness",
        showTitle=true,
        collapse=true
    ).addPanel(panel = TrackingVolumeTechnicalFreshnessCOED365,gridPos={h:11,w:12,x:0,y:13}
    ).addPanel(panel = TrackingVolumeTechnicalFreshnessNORAMD365,gridPos={h:11,w:12,x:12,y:13}
    ).addPanel(panel = TrackingVolumeTechnicalFreshnessAPACD365,gridPos={h:11,w:24,x:0,y:23}),
    gridPos={h:1,w:24,x:0,y:60}
)
.addPanel(
    row.new(
        title="SLI Monthly Trend - D365",
        showTitle=true,
        collapse=true
    ).addPanel(panel = SLIForCOED365,gridPos={h:10,w:12,x:0,y:15}
    ).addPanel(panel = SLIForNoramD365,gridPos={h:10,w:12,x:12,y:15}
    ).addPanel(panel = SLIForAPACD365,gridPos={h:9,w:24,x:0,y:24}),
    gridPos={h:1,w:24,x:0,y:110}
)
.addPanel(
    row.new(
        title="SLI Trend Based on Time Range - D365",
        showTitle=true,
        collapse=true
    ).addPanel(panel = SLID365,gridPos={h:12,w:24,x:0,y:16}),
    gridPos={h:1,w:24,x:0,y:135}
)
.addPanel(
    row.new(
        title="Tracking Data Pipeline Activity",
        showTitle=true,
        collapse=true
    ).addPanel(panel = DatasetFreshnessWithinThreshold,gridPos={h:10,w:12,x:0,y:11}
    ).addPanel(panel = DatasetFreshnessOutOfThreshold,gridPos={h:10,w:12,x:12,y:11}),
    gridPos={h:1,w:24,x:0,y:30}
)
.addPanel(
    row.new(
        title="Data Availability",
        showTitle=true,
        collapse=true
    ).addPanel(panel = DataAvailability,gridPos={h:10,w:24,x:0,y:10}),
    gridPos={h:1,w:24,x:0,y:15}
)
.addPanel(
    row.new(
        title="Dataset Ingestion History Overview",
        showTitle=true,
        collapse=true
    ).addPanel(panel = DatasetIngestionHistory,gridPos={h:10,w:24,x:0,y:26}),
    gridPos={h:1,w:24,x:0,y:150}
)
.addPanel(
    row.new(
        title="Dashboard Alerts",
        showTitle=true,
        collapse=true
    ).addPanel(panel = getDashboardAlertsPanel('oss.apac.glb.d365'),gridPos={h:10,w:24,x:0,y:31}
    ).addPanel(panel = getDashboardAlertsPanel('oss.coe.glb.d365'),gridPos={h:10,w:24,x:0,y:40}
    ).addPanel(panel = getDashboardAlertsPanel('oss.noram.glb.d365'),gridPos={h:10,w:24,x:0,y:46}),
    gridPos={h:1,w:24,x:0,y:165}
)