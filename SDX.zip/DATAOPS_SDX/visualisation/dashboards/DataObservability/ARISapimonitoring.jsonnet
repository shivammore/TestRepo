local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;
local tablePanel = grafana.tablePanel;
local logPanel =  grafana.logPanel;

############################ Dashboard Varaibles ############################

local projectName = "Innovorder";

local ProjectAppinsightsSubscription = tmpl.new(
    name='sub_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>AppinsightsSubscription'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Subscription of Application Insight",
    hide=true
);
local ProjectAppinsightsRG =  tmpl.new(
    name='rg_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>AppinsightsRG'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Resource Group of Application Insight",
    hide=true
);
local ProjectAppinsights =  tmpl.new(
    name='appinsights_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>Appinsights'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Application Insights",
    hide=true
);
local ProjectAppInsightsNamespace =  tmpl.custom(
    name='ns_appinsights',
    current='microsoft.insights/components',
    query='microsoft.insights/components',
    includeAll=false,
    multi=false,
    label="Project: AppInsights Namespace",
    hide=true
);

############################ Dashboard filters ############################

local template_API =  tmpl.custom(
    name='apiName',
    current='all',
    query='glb-sys-tddi-arisingestion,glb-prc-tddi-arisapplicationcdm',
    includeAll=true,
    multi=true,
    label='API Name'
);

local template_country =  tmpl.new(
    name='country',
    datasource='AzureMonitor',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Country',
    queryType='Azure Log Analytics',
    query=|||
            requests
            | where isnotempty(customDimensions)
            | extend country = tostring(customDimensions["Request-x-country-of-origin"])
            | where isnotempty(country)
            | distinct country
            | order by country asc
        |||,
    resources=[
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ]
);

local template_region =  tmpl.new(
    name='region',
    datasource='AzureMonitor',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Region',
    queryType='Azure Log Analytics',
    query=|||
            requests
            | where isnotempty(customDimensions)
            | extend region = tostring(customDimensions.["Request-x-region"])
            | where isnotempty(region)
            | distinct region
            | order by region asc
        |||,
    resources=[
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ]
);

local template_source =  tmpl.new(
    name='source',
    datasource='AzureMonitor',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Source App ID',
    queryType='Azure Log Analytics',
    query=|||
            requests
            | where isnotempty(customDimensions)
            | extend source = tostring(customDimensions.["Request-x-source-application-id"])
            | where isnotempty(source)
            | distinct source
            | order by source asc
        |||,
    resources=[
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ]
);

local template_correlationid = tmpl.text(
    name='correlationid',
	label='Correlation Id'
);

local template_functiontype =  tmpl.custom(
    name='functiontype',
    current='all',
    query='aris_cdm_transform',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Function Type'
);

local template_functionApp =  tmpl.new(
    name='functionApp',
    datasource='Azure SQL Server',
    query="SELECT value FROM grafana.APIMetadataInformation WHERE field IN ('ArisFunctionApp1')",
    refresh='load',
    includeAll=true,
    multi=true,
    label="Function App",
);

############################ Summary panels ############################

local TotalRequestsPanels = statPanel.new(
  title="Total Ingested Records",
  datasource='-- Mixed --',
  description="This panel displays the total number of ingested records received across all services, including APIM, Azure Functions, Service Bus, Landing Zone,  History Zone and Standardized Zone, based on the selected timestamp.",
  graphMode='none',
  reducerFunction='sum',
  orientation="vertical",
  justifyMode= "center",
  transparent=true
)
.addThresholds(
  steps=[
    { "color": "red", "value": 0 },
    { "color": "green", "value": 1 },
  ]
)
.addTarget({
  refId: "A",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ],
    query: |||
      let correlationIds = split("$correlationid", ",");
      requests
      | where $__timeFilter(timestamp)
      | where success == "True"
      | where tostring(customDimensions.["Request-x-region"]) in ($region)
      | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
      | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
      | where tostring(customDimensions["API Name"]) has_any ($apiName)
      | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
      | summarize ['API Requests'] = count()
    |||
  }
})
.addTarget({
  refId: "B",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ],
    query: |||
        let correlationIds = split("$correlationid", ",");
        traces
        | where cloud_RoleName in ($functionApp)
        | where operation_Name in ($functiontype)
        | where isnotempty(message)
        | extend msg = parse_json(message)
        | extend correlationId = tostring(coalesce(msg["x_correlation_id"], msg["correlationId"]))
        | where msg has_cs "Success! Found 1020 matching records"
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where isnotempty(correlationId)
        | summarize latest_timestamp = max(timestamp) by correlationId
        | summarize ['Azure Function Requests'] = count()
    |||
  }
})
.addTarget({
  refId: "C",
  datasource: {
    type: "datasource",
    uid: "AzureSQLServer"
  },
  rawMode: true,
  format: "table",
  rawQuery: true,
  rawSql: "SELECT
            SUM(MaxRows) AS [Landing Zone Requests]
            FROM (
                SELECT
                    REPLACE(dataset_name, '_', '') AS dataset,
                    MAX(metric_value) AS MaxRows
                FROM [observability].[event]
                WHERE project_name in ('oss.glb.glb.cdm_tddi_aris')
                    AND publisher_name = 'custom_pipeline'
                    AND landing_zone IN ('landing')
                     AND metric_name = 'rows_count'
                    AND event_type = 'processingfinished'
                    AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                GROUP BY REPLACE(dataset_name, '_', '')
            ) AS sub",
  query: {
    alias: "Landing Requests",
    format: "table",
    rawEditor: true,
    rawQuery: true,
    rawSql: "SELECT
            SUM(MaxRows) AS [Landing Zone Requests]
            FROM (
                SELECT
                    REPLACE(dataset_name, '_', '') AS dataset,
                    MAX(metric_value) AS MaxRows
                FROM [observability].[event]
                WHERE project_name in ('oss.glb.glb.cdm_tddi_aris')
                    AND publisher_name = 'custom_pipeline'
                    AND landing_zone IN ('landing')
                     AND metric_name = 'rows_count'
                    AND event_type = 'processingfinished'
                    AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                GROUP BY REPLACE(dataset_name, '_', '')
            ) AS sub"
  }
})
.addTarget({
  refId: "D",
  datasource: {
    type: "datasource",
    uid: "AzureSQLServer"
  },
  rawMode: true,
  format: "table",
  rawQuery: true,
  rawSql: "SELECT
            SUM(MaxRows) AS [History Zone Requests]
            FROM (
                SELECT
                    REPLACE(dataset_name, '_', '') AS dataset,
                    MAX(metric_value) AS MaxRows
                FROM [observability].[event]
                WHERE project_name in('oss.glb.glb.cdm_tddi_aris', 'glb.glb.glb.aris')
                    AND publisher_name = 'data_asset_builder'
                    AND landing_zone IN ('history')
                    AND metric_name = 'rows_count'
                    AND event_type = 'processingfinished'
                    AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
               GROUP BY REPLACE(dataset_name, '_', '')
            ) AS sub",
  query: {
    alias: "History Requests",
    format: "table",
    rawEditor: true,
    rawQuery: true,
    rawSql: "SELECT
            SUM(MaxRows) AS [History Zone Requests]
            FROM (
                SELECT
                    REPLACE(dataset_name, '_', '') AS dataset,
                    MAX(metric_value) AS MaxRows
                FROM [observability].[event]
                WHERE project_name in('oss.glb.glb.cdm_tddi_aris', 'glb.glb.glb.aris')
                    AND publisher_name = 'data_asset_builder'
                    AND landing_zone IN ('history')
                    AND metric_name = 'rows_count'
                    AND event_type = 'processingfinished'
                    AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
               GROUP BY REPLACE(dataset_name, '_', '')
            ) AS sub"
  }
})
.addTarget({
  refId: "E",
  datasource: {
    type: "datasource",
    uid: "Azure SQL Server"
  },
  rawMode: true,
  format: "table",
  rawQuery: true,
  rawSql: "SELECT
            SUM(MaxRows) AS [Standardized Zone Requests]
            FROM (
                SELECT
                  REPLACE(dataset_name, '_', '') AS dataset,
                    MAX(metric_value) AS MaxRows
                FROM [observability].[event]
                WHERE project_name in('oss.glb.glb.cdm_tddi_aris', 'glb.glb.glb.aris')
                    AND publisher_name = 'data_asset_builder'
                    AND landing_zone IN ('standardized')
                    AND metric_name = 'rows_count'
                    AND event_type = 'processingfinished'
                    AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                  GROUP BY REPLACE(dataset_name, '_', '')
            ) AS sub",
  query: {
    alias: "Standardized Zone Requests",
    format: "table",
    rawEditor: true,
    rawQuery: true,
    rawSql: "SELECT
            SUM(MaxRows) AS [Standardized Zone Requests]
            FROM (
                SELECT
                  REPLACE(dataset_name, '_', '') AS dataset,
                    MAX(metric_value) AS MaxRows
                FROM [observability].[event]
                WHERE project_name in('oss.glb.glb.cdm_tddi_aris', 'glb.glb.glb.aris')
                    AND publisher_name = 'data_asset_builder'
                    AND landing_zone IN ('standardized')
                    AND metric_name = 'rows_count'
                    AND event_type = 'processingfinished'
                    AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                  GROUP BY REPLACE(dataset_name, '_', '')
            ) AS sub"
  }
})
.addTarget({
  refId: "F",
  datasource: {
    type: "datasource",
    uid: "Azure SQL Server"
  },
  rawMode: true,
  format: "table",
  rawQuery: true,
  rawSql: "SELECT
            SUM(MaxRows) AS [CDM Data_Lake Zone Requests]
            FROM (
                SELECT
                     REPLACE(dataset_name, '_', '') AS dataset,
                    MAX(metric_value) AS MaxRows
                FROM [observability].[event]
                WHERE project_name in('glb.glb.glb.aris')
                    AND publisher_name = 'custom_pipeline'
                    AND landing_zone IN ('cdm_data_lake')
                    AND metric_name = 'rows_count'
                    AND event_type = 'processingfinished'
                    AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
               GROUP BY REPLACE(dataset_name, '_', '')
            ) AS sub",
  query: {
    alias: " CDM Data_Lake Zone Requests",
    format: "table",
    rawEditor: true,
    rawQuery: true,
    rawSql: "SELECT
            SUM(MaxRows) AS [CDM Data_Lake Zone Requests]
            FROM (
                SELECT
                     REPLACE(dataset_name, '_', '') AS dataset,
                    MAX(metric_value) AS MaxRows
                FROM [observability].[event]
                WHERE project_name in('glb.glb.glb.aris')
                    AND publisher_name = 'custom_pipeline'
                    AND landing_zone IN ('cdm_data_lake')
                    AND metric_name = 'rows_count'
                    AND event_type = 'processingfinished'
                    AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
               GROUP BY REPLACE(dataset_name, '_', '')
            ) AS sub"
  }
})
;

local TrankingSource = grafana.tablePanel.new(
  title="Tracking APIM to Standardized Zone Difference",
  datasource='-- Mixed --',
  description="This table panel displays the details of tracking APIM to standardized zone difference.",
)
.addTarget({
  refId: "B",
  datasource: {
    type: "datasource",
    uid: "Azure SQL Server"
  },
  rawMode: true,
  format: "table",
  rawQuery: true,
            rawSql: "WITH standardized_events AS (
                SELECT
                    FORMAT(
                        DATEADD(SECOND, timestamp, '1970-01-01'),
                        'yyyy-MM-dd'
                    ) AS TransactionDate,
                    project_name,
                    REPLACE(dataset_name, '_', '') AS dataset,
                    CAST(metric_value AS BIGINT) AS record_count
                FROM observability.event
                WHERE metric_name = 'rows_count'
                AND landing_zone = 'standardized'
                AND project_name in ('oss.glb.glb.cdm_tddi_aris', 'glb.glb.glb.aris')
                AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
            ),
           
            daily_max AS (
                SELECT
                    TransactionDate,
                dataset,
                project_name,
                    MAX(record_count) AS max_record_count
                FROM standardized_events
                GROUP BY TransactionDate, dataset,project_name
            )
           
            SELECT
                TransactionDate,
                project_name AS [Application Source],
                'Source to Target Match' AS [Threshold],
                SUM(max_record_count) AS [Standardized Record Count]
            FROM daily_max
            GROUP BY TransactionDate,project_name
            ORDER BY TransactionDate DESC;
         ",
    query: {
    alias: "Standardized Requests",
    format: "table",
    rawEditor: true,
    rawQuery: true,
    rawSql: "WITH standardized_events AS (
                SELECT
                    FORMAT(
                        DATEADD(SECOND, timestamp, '1970-01-01'),
                        'yyyy-MM-dd'
                    ) AS TransactionDate,
                    project_name,
                    REPLACE(dataset_name, '_', '') AS dataset,
                    CAST(metric_value AS BIGINT) AS record_count
                FROM observability.event
                WHERE metric_name = 'rows_count'
                AND landing_zone = 'standardized'
                AND project_name in ('oss.glb.glb.cdm_tddi_aris', 'glb.glb.glb.aris')
                AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
            ),
           
            daily_max AS (
                SELECT
                    TransactionDate,
                dataset,
                project_name,
                    MAX(record_count) AS max_record_count
                FROM standardized_events
                GROUP BY TransactionDate, dataset,project_name
            )
           
            SELECT
                TransactionDate,
                project_name AS [Application Source],
                'Source to Target Match' AS [Threshold],
                SUM(max_record_count) AS [Standardized Record Count]
            FROM daily_max
            GROUP BY TransactionDate,project_name
            ORDER BY TransactionDate DESC;
          ",
      }
})
.addTarget({
  refId: "B",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ],
    query: |||
      let correlationIds = split("$correlationid", ",");
      requests
      | where $__timeFilter(timestamp)
      | where success == "True"
      | where tostring(customDimensions.["Request-x-region"]) in ($region)
      | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
      | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
      | where tostring(customDimensions["API Name"]) has_any ($apiName)
      | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
      | summarize APIM_Record_Count = count(), stamp = max(timestamp) by bin(timestamp, 1d)
      | project TransactionDate = format_datetime(stamp, "yyyy-MM-dd"), APIM_Record_Count
      | order by TransactionDate desc
    |||
  }
})
.addOverridesByFieldName(field='Difference',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'red',value: ''}]}},{id: 'mappings',value: [{options: {from: 0,result: {color: 'green',index: 1},to: 0}, type: 'range'}]}])
  {
  transformations: [
    {
      id: 'joinByField',
      options: {
        byField: 'TransactionDate',
        mode: 'inner',
      },
    },
    {
      id: 'calculateField',
      options: {
        alias: 'Difference',
        binary: {
          left: 'APIM_Record_Count',
          operator: '-',
          right: 'Standardized Record Count',
        },
        mode: 'binary',
        reduce: {
          reducer: 'sum',
        },
      },
    },
  ],
}
{   
  options: {
    showHeader: true,
    cellHeight: "sm",
    footer: {
    show: false,
    reducer: [
      "sum"
    ],
    countRows: false,
    fields: ""
    }
  }
};

local TrankingSourcetoTarget = grafana.tablePanel.new(
  title="Tracking APIM Source to Target APIs Difference",
  datasource='-- Mixed --',
  description="This table panel displays the details of tracking APIM Source to Target APIs Difference.",
)
.addTarget({
  refId: "A",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ],
    query: |||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where success == "True"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ('glb-sys-tddi-arisingestion')
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | summarize ['Source_Count'] = count(), stamp = max(timestamp) by bin(timestamp, 1d)
        | project TransactionDate = format_datetime(timestamp, "yyyy-MM-dd"), Source_Count
        | order by TransactionDate desc
    |||
  }
})
.addTarget({
  refId: "B",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ],
    query: |||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where success == "True"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ('glb-prc-tddi-arisapplicationcdm')
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | summarize Target_Count = count(), stamp = max(timestamp) by bin(timestamp, 1d)
        | project TransactionDate = format_datetime(timestamp, "yyyy-MM-dd"), Target_Count
        | order by TransactionDate desc
    |||
  }
})
.addOverridesByFieldName(field='Difference',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'red',value: ''}]}},{id: 'mappings',value: [{options: {from: 0,result: {color: 'green',index: 1},to: 0}, type: 'range'}]}])
  {
  transformations: [
    {
      id: 'joinByField',
      options: {
        byField: 'TransactionDate',
        mode: 'inner',
      },
    },
    {
      id: 'calculateField',
      options: {
        alias: 'Difference',
        binary: {
          left: 'Source_Count',
          operator: '-',
          right: 'Target_Count',
        },
        mode: 'binary',
        reduce: {
          reducer: 'sum',
        },
      },
    },
  ],
}
{   
  options: {
    showHeader: true,
    cellHeight: "sm",
    footer: {
    show: false,
    reducer: [
      "sum"
    ],
    countRows: false,
    fields: ""
    }
  }
};

############################ Status ############################

local ApimLastRequest = statPanel.new(
    title="APIM: Last Request",
    datasource='AzureMonitor',
    description="This panel displays the last request time send to APIM",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields="/.*/",
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | summarize tostring(format_datetime(max(timestamp),'yyyy-MM-dd HH:mm:ss'))
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/.*/"
      },
      graphMode: "none",
    }
};
local ApimLastSucessRequest = statPanel.new(
    title="APIM: Number of Successful Requests",
    datasource='AzureMonitor',
    description="This panel displays the number of successful requests in APIM",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where success == "True"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ('arisingestion','arisapplicationcdm')
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | summarize Total_Success = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};
local ApimLastFailedRequest = statPanel.new(
    title="APIM: Number of Failed Requests",
    datasource='AzureMonitor',
    description="This panel displays the number of failed requests in APIM",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": null,
      },
  ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where success != "True"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | summarize Total_Failed = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};

local AzfLastRun = statPanel.new(
    title="Azure Function: Last Run",
    datasource='AzureMonitor',
    description="This panel displays the last run time for Azure Function",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields="/.*/"
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        traces
        | where $__timeFilter(timestamp)
        | where cloud_RoleName in ($functionApp)
        | where operation_Name in ($functiontype)
        | where isnotempty(message)
        | extend msg = parse_json(message)
        | extend correlationId = tostring(coalesce(msg["x_correlation_id"], msg["correlationId"]))
        | where msg has_cs "Success! Found 1020 matching records"
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where isnotempty(correlationId)
        | summarize tostring(format_datetime(max(timestamp),'yyyy-MM-dd HH:mm:ss'))
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/.*/"
      },
      graphMode: "none",
    }
};
local AzfLastSuccessRun = statPanel.new(
    title="Azure Function: Number of Successful Run",
    datasource='AzureMonitor',
    description="This panel displays the number of successful run in Azure Function",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        traces
        | where $__timeFilter(timestamp)
        | where cloud_RoleName in ($functionApp)
        | where operation_Name in ($functiontype)
        | where isnotempty(message)
        | extend msg = parse_json(message)
        | extend correlationId = tostring(coalesce(msg["x_correlation_id"], msg["correlationId"]))
        | where msg has_cs "Success! Found 1020 matching records"
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where isnotempty(correlationId)
        | summarize latest_timestamp = max(timestamp) by correlationId
        | summarize Successcount = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};

local AzfLastFailedRun = statPanel.new(
    title="Azure Function: Number of Failed Run",
    datasource='AzureMonitor',
    description="This panel displays the number of failed run in Azure Function",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": null,
      }
  ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        traces
        | where $__timeFilter(timestamp)
        | where cloud_RoleName in ($functionApp)
        | where operation_Name in ($functiontype)
        | where isnotempty(message)
        | extend msg = parse_json(message)
        | extend correlationId = tostring(coalesce(msg["x_correlation_id"], msg["correlationId"]))
        | where msg has_cs "Failed"
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where isnotempty(correlationId)
        | summarize latest_timestamp = max(timestamp) by correlationId
        | summarize Failedcount = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};

local LandingLastSuccessIngestion =
  statPanel.new(
    title="Landing Zone: Last Successful Ingestion",
    fields='/^Time$/',
    datasource='Azure SQL Server',
    description="This panel displays the last successful ingestion time for landing zone",
    ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT
              top(1)
              DATEADD(SECOND, MAX([timestamp]), '1970-01-01')
          FROM
              [observability].[event]
            WHERE  project_name in ('oss.glb.glb.cdm_tddi_aris')
            AND publisher_name ='custom_pipeline'
            AND landing_zone IN ('landing')
            AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
            AND metric_name IN ('processing_finished_date')
            ",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};
local LandingSuccessCount =
  statPanel.new(
    title="Landing Zone: Total Successful Records",
    datasource='Azure SQL Server',
    description="This panel displays the total number of successful records in landing zone",
    colorMode='background'
    ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql=" SELECT
            SUM(MaxRows) AS [Landing Zone Requests]
            FROM (
                SELECT
                    project_name,
                    MAX(metric_value) AS MaxRows
                FROM [observability].[event] 
                 WHERE  project_name in ('oss.glb.glb.cdm_tddi_aris')
                    AND publisher_name ='custom_pipeline'
                    AND landing_zone IN ('landing')
                    AND metric_name = 'rows_count'
                    AND event_type = 'processingfinished'
                    AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                GROUP BY project_name
            ) AS sub",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: ""
      },
      graphMode: "none",
    }
};

local HistoryLastSuccessIngestion =
  statPanel.new(
    title="History Zone: Last Successful Ingestion",
    fields='/^Time$/',
    datasource='Azure SQL Server',
    description="This panel displays the last successful ingestion time for history zone",
    ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT
              top(1)
              DATEADD(SECOND, MAX([timestamp]), '1970-01-01')
          FROM
              [observability].[event]
          WHERE  project_name in ('oss.glb.glb.cdm_tddi_aris', 'glb.glb.glb.aris')
            AND landing_zone IN ('history')
            AND publisher_name = 'data_asset_builder'
            AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
            AND metric_name IN ('processing_finished_date')
            ",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};
local HistorySuccessCount =
  statPanel.new(
    title="History Zone: Total Successful Records",
    datasource='Azure SQL Server',
    description="This panel displays the total number of successful records in history zone",
    colorMode='background'
    ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT
            SUM(MaxRows) AS [history Zone Requests]
            FROM (
                SELECT
                    dataset_name,
                    MAX(metric_value) AS MaxRows
                FROM [observability].[event]
                WHERE project_name in ('oss.glb.glb.cdm_tddi_aris', 'glb.glb.glb.aris')
                    AND publisher_name = 'data_asset_builder'
                    AND landing_zone IN ('history')
                    AND metric_name = 'rows_count'
                    AND event_type = 'processingfinished'
                    AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                GROUP BY dataset_name
            ) AS sub",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: ""
      },
      graphMode: "none",
    }
};

local StandardizedLastSuccessIngestion =
  statPanel.new(
    title="Standardized Zone: Last Successful Ingestion",
    fields='/^Time$/',
    datasource='Azure SQL Server',
    description="This panel displays the last successful ingestion time for standardized zone",
    ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT
              top(1)
              DATEADD(SECOND, MAX([timestamp]), '1970-01-01')
          FROM
              [observability].[event]
          WHERE  project_name in ('oss.glb.glb.cdm_tddi_aris', 'glb.glb.glb.aris')
            AND landing_zone IN ('standardized')
            AND publisher_name = 'data_asset_builder'
            AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
            AND metric_name IN ('processing_finished_date')
            ",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};
local StandardizedSuccessCount =
  statPanel.new(
    title="Standardized Zone: Total Successful Records",
    datasource='Azure SQL Server',
    description="This panel displays the total number of successful records in standardized zone",
    colorMode='background'
    ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
        SELECT
                SUM(MaxRows) AS [standardized Zone Requests]
                FROM (
                    SELECT
                        dataset_name,
                        MAX(metric_value) AS MaxRows
                    FROM [observability].[event]
                    WHERE project_name in ('oss.glb.glb.cdm_tddi_aris', 'glb.glb.glb.aris')
                        AND publisher_name = 'data_asset_builder'
                        AND landing_zone IN ('standardized')
                        AND metric_name = 'rows_count'
                        AND event_type = 'processingfinished'
                        AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                    GROUP BY dataset_name
                ) AS sub",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: ""
      },
      graphMode: "none",
    }
};

local CdmdatalakeLastSuccessIngestion =
  statPanel.new(
    title="Cdm_data_lake Zone:: Last Successful Ingestion",
    fields='/^Time$/',
    datasource='Azure SQL Server',
    description="This panel displays the last successful ingestion time for Cdm_data_lake zone",
    ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT
              top(1)
              DATEADD(SECOND, MAX([timestamp]), '1970-01-01')
          FROM
              [observability].[event]
          WHERE  project_name in ('glb.glb.glb.aris')
            AND landing_zone = 'cdm_data_lake'
            AND publisher_name = 'custom_pipeline'
            AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
            AND metric_name IN ('processing_finished_date')
            
            ",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};
local  CdmdatalakeSuccessCount =
  statPanel.new(
    title="Cdm_data_lake Zone : Total Successful Records",
    datasource='Azure SQL Server',
    description="This panel displays the total number of successful records in cdm_data_lake Zone",
    colorMode='background'
    ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT
            SUM(MaxRows) AS [standardized Zone Requests]
            FROM (
                SELECT
                    dataset_name,
                    MAX(metric_value) AS MaxRows
                FROM [observability].[event]
                WHERE project_name in ('glb.glb.glb.aris')
                    AND publisher_name = 'custom_pipeline'
                    AND landing_zone IN ('cdm_data_lake')
                    AND metric_name = 'rows_count'
                    AND event_type = 'processingfinished'
                    AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                GROUP BY dataset_name
            ) AS sub
      ",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: ""
      },
      graphMode: "none",
    }
};


local Status = row.new(title="Status", collapse=true)
    .addPanel(ApimLastRequest,gridPos={h: 3, w: 8, x: 0, y: 19})
    .addPanel(ApimLastSucessRequest,gridPos={h: 3, w: 8, x: 8, y: 19})
    .addPanel(ApimLastFailedRequest,gridPos={h: 3, w: 8, x: 16, y: 19})
    .addPanel(AzfLastRun,gridPos={h: 3, w: 8, x: 0, y: 22})
    .addPanel(AzfLastSuccessRun,gridPos={h: 3, w: 8, x: 8, y: 22})
    .addPanel(AzfLastFailedRun,gridPos={h: 3, w: 8, x: 16, y: 22})
    .addPanel(LandingLastSuccessIngestion,gridPos={h: 3, w: 12, x: 0, y: 25})
    .addPanel(LandingSuccessCount,gridPos={h: 3, w: 12, x: 12, y: 25})
    .addPanel(HistoryLastSuccessIngestion,gridPos={h: 3, w: 12, x: 0, y: 28})
    .addPanel(HistorySuccessCount,gridPos={h: 3, w: 12, x: 12, y: 28})
    .addPanel(StandardizedLastSuccessIngestion,gridPos={h: 3, w: 12, x: 0, y: 31})
    .addPanel(StandardizedSuccessCount,gridPos={h: 3, w: 12, x: 12, y: 31})
    .addPanel(CdmdatalakeLastSuccessIngestion,gridPos={h: 3, w: 12, x: 0, y: 34})
    .addPanel(CdmdatalakeSuccessCount,gridPos={h: 3, w: 12, x: 12, y: 34});

############################ APIM ############################

local ApiTotalRequests = grafana.graphPanel.new(
    title="Total API Requests",
    datasource='AzureMonitor',
    description="This panel displays the total number of requests in APIM using Timeseries",
    fill=0,
    points=true,
    pointradius=5,
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where isnotempty(customDimensions)
        | where customDimensions has "API Name"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend lastpart = tostring(customDimensions["API Name"])
        | summarize totalrequests = count() by bin(timestamp, 5m), lastpart
        | order by timestamp asc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          __systemRef: "hideSeriesFrom",
          matcher: {
            id: "byNames",
            options: {
              mode: "exclude",
              names: [
                "totalrequests"
              ],
              prefix: "All except:",
              readOnly: true
            }
          },
          properties: [
            {
              id: "custom.hideFrom",
              value: {
                legend: false,
                tooltip: false,
                viz: true
              }
            }
          ]
        },
        {
          matcher: {
            id: "byName",
            options: "totalrequests"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "blue",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local ApiRequestNumberByAPIName = grafana.barChart.new(
    title="Requests by API Name",
    description='This panel displays the total number of requests by API name in APIM using barchart',
    datasource='AzureMonitor',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where isnotempty(customDimensions)
        | where customDimensions has "API Name"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend lastpart = tostring(customDimensions["API Name"])
        | summarize totalrequests = count() by lastpart
        | order by totalrequests desc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "totalrequests"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "blue",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local ApiRequests = grafana.graphPanel.new(
    title="Requests (Successful & Failed)",
    datasource='AzureMonitor',
    description="This panel displays the total number of requests in APIM using Timeseries",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend lastpart = tostring(customDimensions["API Name"])
        | extend ResultType = iff(success == true, "success", "Failure")
        | summarize totalrequests = count() by ResultType, bin(timestamp, 5m)
        | order by timestamp asc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "totalrequests success"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "green",
                mode: "fixed"
              }
            }
          ]
        },
        {
          matcher: {
            id: "byName",
            options: "totalrequests Failure"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "red",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local ApiRequestByStatusCode = grafana.pieChartPanel.new(
    title="Request by Status Code",
    datasource='AzureMonitor',
    description="This panel displays the request by status code using pie chart",
    legendType="Right side",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests 
        | where $__timeFilter(timestamp)
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend lastpart = tostring(customDimensions["API Name"]) 
        | summarize Count=count() by resultCode
        | evaluate pivot(resultCode, sum(Count))
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "right",
      calcs: [],
      values: [
          "value", "percent"
        ]
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "401"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "red",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local ApimLastFailedRequestTable = tablePanel.new(
    title="Last Failed APIM Events",
    datasource='AzureMonitor',
    description="This panel displays the table of failed requests of each timestamp with their resultCode, duration, API Name, RequestSize, Correlation ID and IdemopotencyKey in a table format",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
       requests
       | where $__timeFilter(timestamp)
       | where success == False
       | where tostring(customDimensions.["Request-x-region"]) in ($region)
       | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
       | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
       | where tostring(customDimensions["API Name"]) has_any ($apiName)
       | project timestamp, resultCode, duration, APIName=customDimensions["API Name"], RequestSize=customMeasurements.["Request Size"], CorrelationId=customDimensions.["Request-x-correlation-id"]
       | order by timestamp desc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
){
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "APIName"
          },
          properties: [
            {
              id: "custom.width",
              value: 284
            }
          ]
        }
      ]
  }
};

local ApiLogs = logPanel.new(
    title="API Error logs",
    datasource='AzureMonitor',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where success == "False"
        | where customDimensions has "API Name"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend statuscode = resultCode
        | where statuscode != 200
        | order by timestamp desc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
);

local APIM = row.new(title="APIM", collapse=true)
    .addPanel(ApiTotalRequests,gridPos={h: 8, w: 24, x: 0, y: 38})
    .addPanel(ApiRequestNumberByAPIName,gridPos={h: 8, w: 24, x: 0, y: 46})
    .addPanel(ApiRequests,gridPos={h: 8, w: 24, x: 0, y: 54})
    .addPanel(ApiRequestByStatusCode,gridPos={h: 8, w: 24, x: 0, y: 62})
    .addPanel(ApimLastFailedRequestTable,gridPos={h: 8, w: 24, x: 0, y: 70})
    .addPanel(ApiLogs,gridPos={h: 8, w: 24, x: 0, y: 78});

############################ Azure Function ############################

local AZTotalRequests = grafana.graphPanel.new(
    title="Total Azure Function Requests",
    datasource='AzureMonitor',
    description="This panel displays the total number of requests in Azure Function using Timeseries",
    fill=0,
    points=true,
    pointradius=5,
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        traces
        | where $__timeFilter(timestamp)
        | where cloud_RoleName in ($functionApp)
        | where operation_Name in ($functiontype)
        | where isnotempty(message)
        | extend msg = parse_json(message)
        | extend correlationId = tostring(coalesce(msg["x_correlation_id"], msg["correlationId"]))
        | where msg has_cs "Success! Found 1020 matching records"
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where isnotempty(correlationId)
        | extend headers = parse_json(tostring(msg["headers"]))
        | summarize latest_timestamp = max(timestamp) by correlationId
        | summarize totalrequests = count() by bin(latest_timestamp, 5m)
        | order by latest_timestamp asc  
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "totalrequests"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "blue",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local AZRequests = grafana.barChart.new(
    title="Run by day (Failed & Successful)",
    datasource='AzureMonitor',
    description="This panel displays the number of run by day",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        traces
        | where $__timeFilter(timestamp)
        | where cloud_RoleName in ($functionApp)
        | where operation_Name in ($functiontype)
        | where isnotempty(message)
        | extend msg = parse_json(message)
        | extend correlationId = tostring(coalesce(msg["x_correlation_id"], msg["correlationId"]))
        | where msg has_cs "Success! Found 1020 matching records"
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where isnotempty(correlationId)
        | summarize RunNumber=count() by format_datetime(timestamp,'MM/dd/yyyy')
        | order by timestamp asc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "totalrequests"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "blue",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local AZDuplicateSuccessRequest = tablePanel.new(
    title="Duplicate key by Day",
    datasource='AzureMonitor',
    description="This panel displays the duplicate key by day",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        traces
        | where $__timeFilter(timestamp)
        | where cloud_RoleName in ($functionApp)
        | where operation_Name in ($functiontype)
        | where isnotempty(message)
        | extend msg = parse_json(message)
        | extend correlationId = tostring(coalesce(msg["x_correlation_id"], msg["correlationId"]))
        | where msg has_cs "Success! Found 1020 matching records"
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where isnotempty(correlationId)
        | summarize Count=count() by correlationId , format_datetime(timestamp,'MM/dd/yyyy')
        | where Count > 1
        | order by timestamp desc       
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
);

local AZRequestByStatusCode = grafana.pieChartPanel.new(
    title="Request by Status Code",
    datasource='AzureMonitor',
    description="This panel displays the request by status code using pie chart",
    legendType="Right side",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        traces
        | where $__timeFilter(timestamp)
        | where cloud_RoleName in ($functionApp)
        | where operation_Name in ($functiontype)
        | where isnotempty(message)
        | extend msg = parse_json(message)
        | extend correlationId = tostring(coalesce(msg["x_correlation_id"], msg["correlationId"]))
        | where msg has_cs "Success! Found 1020 matching records"
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where isnotempty(correlationId)
        | extend statuscode = 200
        | extend ResultType = "success"
        | summarize latest_timestamp = max(timestamp) by correlationId, statuscode
        | summarize Count = count() by statuscode
        | evaluate pivot(statuscode, sum(Count))
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "right",
      calcs: [],
      values: [
          "value", "percent"
        ]
    }
  }
};

local AZLogs = logPanel.new(
    title="Azure Function Error logs",
    datasource='AzureMonitor',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        traces
        | where $__timeFilter(timestamp)
        | where cloud_RoleName in ($functionApp)
        | where operation_Name in ($functiontype)
        | where isnotempty(message)
        | extend msg = parse_json(message)
        | extend correlationId = tostring(coalesce(msg["x_correlation_id"], msg["correlationId"]))
        | where msg has_cs "Fail"
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where isnotempty(correlationId)
        | order by timestamp desc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
);

local AzureFunction = row.new(title="Azure Function", collapse=true)
    .addPanel(AZTotalRequests,gridPos={h: 8, w: 24, x: 0, y: 79})
    .addPanel(AZRequests,gridPos={h: 8, w: 12, x: 0, y: 87})
    .addPanel(AZDuplicateSuccessRequest,gridPos={h: 8, w: 12, x: 12, y: 87})
    .addPanel(AZRequestByStatusCode,gridPos={h: 8, w: 12, x: 0, y: 95})
    .addPanel(AZLogs,gridPos={h: 8, w: 12, x: 12, y: 95});

############################ Standardized Zone ############################

local StandardizedZone = grafana.tablePanel.new(
  title='Dataset Ingestion History Overview',
  datasource='Azure SQL Server',
  description="This table panel displays the Dataset Ingestion History Overview."
).addTarget(
  target=sql_target(
    rawSql="
    WITH FilteredEvents AS (
    SELECT
        job_id,
        context_id,
        project_name,
        dataset_name,
        landing_zone,
        subscription_id,
        takeoff_zone,
        timestamp,
        metric_name,
        metric_value
    FROM [observability].[event]
    WHERE
        project_name IN (
            'oss.glb.glb.cdm_tddi_aris',
            'glb.glb.glb.aris'
        )
        AND landing_zone IN (
            'standardized',
            'history',
            'landing',
            'cdm_data_lake'
        )
        AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
        AND metric_name IN (
            'processing_started_date',
            'processing_finished_date',
            'processing_exit_code',
            'rows_count',
            'content_latest_date'
        )
),
 
MergedEvents AS (
    SELECT
        job_id,
        context_id,
        timestamp,
        project_name,
        dataset_name,
        landing_zone,
        subscription_id,
        takeoff_zone,
        [processing_started_date]  AS processing_started_date_value,
        [processing_finished_date] AS processing_finished_date_value,
        [processing_exit_code]     AS processing_exit_code_value,
        [content_latest_date]      AS content_latest_date,
        [rows_count]               AS rows_count_value
    FROM FilteredEvents
    PIVOT (
        MAX(metric_value)
        FOR metric_name IN (
            [processing_started_date],
            [processing_finished_date],
            [processing_exit_code],
            [rows_count],
            [content_latest_date]
        )
    ) AS PivotTable
),
 
Finalevents AS (
    SELECT
        MAX(project_name) AS [Application Source],
        MAX(dataset_name) AS [Dataset],
        MAX(landing_zone) AS [Zone],
 
        MAX(
            CASE subscription_id
                WHEN '6b4a5b3f-1015-42da-a46a-2890a5abed30' THEN 'IFM CORE PROD'
                WHEN '2698ca5b-bf81-43fb-8fe2-f0e21bf068e5' THEN 'IFM CORE UAT/TEST'
                WHEN '746ac5b9-70eb-4c76-bdf4-0664bfdff2ea' THEN 'IFM CORE DEV'
                WHEN 'cf25f2a1-4d40-45af-bb81-87ec46112b3e' THEN 'SDX STA/PRD'
                WHEN 'c0978b9d-b809-45f4-aa76-391ceb2cfdba' THEN 'SDX DEV/TEST'
                WHEN '8eaa3d95-3cd2-49d8-b44a-7ea47a6fb58b' THEN 'SDX SILVER'
                WHEN 'daf86ec1-725c-493f-bf09-a1f129b8588a' THEN 'SDX INT/UAT'
                WHEN 'fea1e9f0-0e20-426f-906e-bc76e5a566ad' THEN 'SDX Sandbox'
                WHEN '6e3fc63f-851b-4fc7-8499-48f6a9c28a65' THEN 'SDX Global Shared Services'
                ELSE 'Undefined'
            END
        ) AS [Subscription],
 
        MAX(takeoff_zone) + ' to ' + MAX(landing_zone) AS [Activity],
 
        CASE
            WHEN SUM(CASE WHEN processing_exit_code_value NOT IN (0,1,2) THEN 1 ELSE 0 END) > 0
                THEN 'Failed'
            WHEN MAX(processing_started_date_value) IS NOT NULL
                 AND MAX(processing_finished_date_value) IS NULL
                THEN 'Running'
            WHEN COUNT(CASE WHEN processing_exit_code_value = 0 THEN 1 END) > 0
                THEN 'Succeeded'
            WHEN COUNT(CASE WHEN processing_exit_code_value = 1 THEN 1 END) > 0
                THEN 'No New Data'
            WHEN COUNT(CASE WHEN processing_exit_code_value = 2 THEN 1 END) > 0
                THEN 'Skipped'
            ELSE 'Unknown'
        END AS [Status],
 
        DATEADD(SECOND, MAX(timestamp), '1970-01-01') AS [Landed at],
 
        DATEDIFF(SECOND, '19700101', GETUTCDATE()) - MAX(timestamp) AS [Landed Since],
 
        DATEDIFF(SECOND, '19700101', GETUTCDATE()) - MAX(content_latest_date) AS [Freshness],
 
        CAST(
            MAX(processing_finished_date_value)
            - MAX(processing_started_date_value)
            AS BIGINT
        ) AS [Duration],
 
        ISNULL(
            CAST(CAST(MAX(rows_count_value) AS BIGINT) AS VARCHAR),
            'N/A'
        ) AS [Rows]
 
    FROM MergedEvents
    GROUP BY job_id, context_id
)
 
SELECT
    [Application Source],
    [Dataset],
    [Zone],
    [Subscription],
    [Activity],
    [Status]
FROM Finalevents
ORDER BY [Landed at] DESC;",
    format='table'
  )
);

local StandardizedZoneRow = row.new(title="Dataset Ingestion History Overview", collapse=true)
    .addPanel(panel=StandardizedZone,gridPos={h: 10, w: 24, x: 0, y: 103});

############################ Dashboard ############################

grafana.dashboard.new(
  title='Aris API Monitoring ',
  time_from='now-24h',
  timezone="utc",
  editable='false',
  schemaVersion=37,
  uid='Aris-monitoring-tracker',
  tags=['monitoring', 'observability'])

.addTemplate(ProjectAppinsightsSubscription)
.addTemplate(ProjectAppinsightsRG)
.addTemplate(ProjectAppinsights)
.addTemplate(ProjectAppInsightsNamespace)

.addTemplate(template_API)
.addTemplate(template_functionApp)
.addTemplate(template_functiontype)
.addTemplate(template_country)
.addTemplate(template_region)
.addTemplate(template_source)
.addTemplate(template_correlationid)

.addPanel(panel=TotalRequestsPanels, gridPos={h: 4, w: 24, x: 0, y: 0})
.addPanel(panel=TrankingSource, gridPos={h: 7, w: 24, x: 0, y: 4})
.addPanel(panel=TrankingSourcetoTarget, gridPos={h: 7, w: 24, x: 0, y: 11})
.addPanel(panel=Status, gridPos={h: 1, w: 24, x: 0, y: 18})
.addPanel(panel=APIM, gridPos={h: 1, w: 24, x: 0, y: 37})
.addPanel(panel=AzureFunction, gridPos={h: 1, w: 24, x: 0, y: 78})
.addPanel(panel=StandardizedZoneRow, gridPos={h: 1, w: 24, x: 0, y: 103})