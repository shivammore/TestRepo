local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local stat = grafana.statPanel;
local table = grafana.tablePanel;
local slo = 80;

//global filters
local projectTemplate =  tmpl.custom(
    name='project_name',
    current='all',
    query='oss.noram.us.ukglabor',
    includeAll=true,
    multi=true,
    label="Application Source"
);

local datasetTemplate = tmpl.custom(
    name='dataset_name',
    query= 'accrualcode,accrualprofile,accruals_vac_plan,AccrualSummary,accrualtran,basewagerthist,can_employee_data_import,can_labor_category_entry,combohomeacct,customdatadef,d_jobcode,d_segmentation,d_unit,employeerate,epretim_a,exceptiontype,geofencing_mainlocation,geofencing_request,hr_jobdescriptions,jobcode_master,jobcode_servicetype_xref,known_places,labor_category,laborforecast,laborleveldef,laborstandards,labortaskgroups,labortasks,location_sets,m_employmentstatus,non_sdx_emps,org,org_path_master,orgtype,paycode,payperiod,payrule,payruleids,person,person_accrualprofile,personcstmdata,prsncstmdatemm,s_krs_org,s_krs_servicetype_cc_xref,s_krs_servicetype_job_xref,s_krs_wfcjob,sdxo_fg_id_upload,sdxunit,shiftassignmnt,shiftcode,shiftsegment,shiftsegmnttype,timecard_audit,timecard_exceptions,timecard_extended_exception,timecard_historicalcorrections,timecard_paycodeedits_entries,timecard_processedsegments,timecard_punches_exception,timecard_punches_notes,timecard_response200,timecard_scheduledtotal,timecard_scheduleshifts,timecard_totals_aggregatedtotals,timecard_totalsummary,timecard_workedshifts_workedspan,timecard_workholidaycredits,ukg_jobcodes,ukg_location_hierarchy,vhr_employeeall,vhr_employeeallwithfinancehierarchy,wfcjob,wfcjoborg,wtkemployee',
    current='all',
    includeAll=true,
    multi=true,
    label='Dataset Name'
);

local stageTemplate =  tmpl.custom(
    name='landing_zone',
    current='all',
    query='history,landing,standardized',
    includeAll=true,
    multi=true,
    label="Zone"
);

local statusTemplate =  tmpl.custom(
    name='status',
    current='all',
    query='Succeeded,Failed,No New Data,Running,Skipped',
    includeAll=true,
    multi=true,
    label="Ingestion Status"
);

local HidedContext =
    grafana.template.new(
    name='context',
    datasource='Azure SQL Server',
    query="
    SELECT distinct(context_id)
    FROM [observability].[event]
    WHERE
  dataset_name IN ($dataset_name)
  AND landing_zone IN ($landing_zone)
  AND project_name IN ($project_name)
        ",
    current='all',
    refresh='load',
    hide = true,
    includeAll=true,
    multi=false,
    label='context'
);

//panels
local generatePanelCount =
  stat.new(
    title='Total Datasets',
    datasource='Azure SQL Server',
    description="The total dataset we have in database within the source. It could refer to a database table, a file, or any other structured form of data, depending on how the dataset is constructed."
  )
  // Use the length of the sources list as the value to display
  .addTarget(
    target=grafana.sql.target(
      rawSql="with cte as (select '${dataset_name:csv}' as val)
	              select (LEN(val) - LEN(REPLACE(val, ',', ''))) + 1 from cte;",
      format='table'
    )
);
local SLOPanel = stat.new(
    title='SLO',
    datasource='Azure SQL Server',
    description="This is a benchmark defined by the proprietors or stakeholders of a data ingestion pipeline.
    It signifies the anticipated and aspired level of efficiency, reliability, and quality for data ingestion processes.
    Such a goal provides a tangible metric against which the actual performance of the data ingestion can be evaluated,ensuring that the pipeline operates in alignment with stakeholder expectations and requirements.")
    .addTarget(target=grafana.sql.target(rawSql= "SELECT 80 AS 'slo'", format='table'))
    .addOverridesByFieldName(field='slo',properties=[{id: 'unit', value: 'percent'}]
);
local generateSLIPanel =
    local SLISqlQuery = "   
            WITH
                CombinedValues AS (
                    SELECT *
                    FROM (VALUES ('oss.noram.us.ukglabor', 'accrualcode', 'landing', 'oss.noram.us.ukglabor_accrualcode_landing', 86400), ('oss.noram.us.ukglabor', 'accrualcode', 'history', 'oss.noram.us.ukglabor_accrualcode_history', 86400), ('oss.noram.us.ukglabor', 'accrualcode', 'standardized', 'oss.noram.us.ukglabor_accrualcode_standardized', 86400), ('oss.noram.us.ukglabor', 'accrualprofile', 'landing', 'oss.noram.us.ukglabor_accrualprofile_landing', 86400), ('oss.noram.us.ukglabor', 'accrualprofile', 'history', 'oss.noram.us.ukglabor_accrualprofile_history', 86400), ('oss.noram.us.ukglabor', 'accrualprofile', 'standardized', 'oss.noram.us.ukglabor_accrualprofile_standardized', 86400), ('oss.noram.us.ukglabor', 'accruals_vac_plan', 'landing', 'oss.noram.us.ukglabor_accruals_vac_plan_landing', 86400), ('oss.noram.us.ukglabor', 'accruals_vac_plan', 'history', 'oss.noram.us.ukglabor_accruals_vac_plan_history', 86400), ('oss.noram.us.ukglabor', 'accruals_vac_plan', 'standardized', 'oss.noram.us.ukglabor_accruals_vac_plan_standardized', 86400), ('oss.noram.us.ukglabor', 'AccrualSummary', 'landing', 'oss.noram.us.ukglabor_AccrualSummary_landing', 86400), ('oss.noram.us.ukglabor', 'AccrualSummary', 'history', 'oss.noram.us.ukglabor_AccrualSummary_history', 86400), ('oss.noram.us.ukglabor', 'AccrualSummary', 'standardized', 'oss.noram.us.ukglabor_AccrualSummary_standardized', 86400), ('oss.noram.us.ukglabor', 'accrualtran', 'landing', 'oss.noram.us.ukglabor_accrualtran_landing', 86400), ('oss.noram.us.ukglabor', 'accrualtran', 'history', 'oss.noram.us.ukglabor_accrualtran_history', 86400), ('oss.noram.us.ukglabor', 'accrualtran', 'standardized', 'oss.noram.us.ukglabor_accrualtran_standardized', 86400), ('oss.noram.us.ukglabor', 'basewagerthist', 'landing', 'oss.noram.us.ukglabor_basewagerthist_landing', 86400), ('oss.noram.us.ukglabor', 'basewagerthist', 'history', 'oss.noram.us.ukglabor_basewagerthist_history', 86400), ('oss.noram.us.ukglabor', 'basewagerthist', 'standardized', 'oss.noram.us.ukglabor_basewagerthist_standardized', 86400), ('oss.noram.us.ukglabor', 'can_employee_data_import', 'landing', 'oss.noram.us.ukglabor_can_employee_data_import_landing', 86400), ('oss.noram.us.ukglabor', 'can_employee_data_import', 'history', 'oss.noram.us.ukglabor_can_employee_data_import_history', 86400), ('oss.noram.us.ukglabor', 'can_employee_data_import', 'standardized', 'oss.noram.us.ukglabor_can_employee_data_import_standardized', 86400), ('oss.noram.us.ukglabor', 'can_labor_category_entry', 'landing', 'oss.noram.us.ukglabor_can_labor_category_entry_landing', 86400), ('oss.noram.us.ukglabor', 'can_labor_category_entry', 'history', 'oss.noram.us.ukglabor_can_labor_category_entry_history', 86400), ('oss.noram.us.ukglabor', 'can_labor_category_entry', 'standardized', 'oss.noram.us.ukglabor_can_labor_category_entry_standardized', 86400), ('oss.noram.us.ukglabor', 'combohomeacct', 'landing', 'oss.noram.us.ukglabor_combohomeacct_landing', 86400), ('oss.noram.us.ukglabor', 'combohomeacct', 'history', 'oss.noram.us.ukglabor_combohomeacct_history', 86400), ('oss.noram.us.ukglabor', 'combohomeacct', 'standardized', 'oss.noram.us.ukglabor_combohomeacct_standardized', 86400), ('oss.noram.us.ukglabor', 'customdatadef', 'landing', 'oss.noram.us.ukglabor_customdatadef_landing', 86400), ('oss.noram.us.ukglabor', 'customdatadef', 'history', 'oss.noram.us.ukglabor_customdatadef_history', 86400), ('oss.noram.us.ukglabor', 'customdatadef', 'standardized', 'oss.noram.us.ukglabor_customdatadef_standardized', 86400), ('oss.noram.us.ukglabor', 'd_jobcode', 'landing', 'oss.noram.us.ukglabor_d_jobcode_landing', 86400), ('oss.noram.us.ukglabor', 'd_jobcode', 'history', 'oss.noram.us.ukglabor_d_jobcode_history', 86400), ('oss.noram.us.ukglabor', 'd_jobcode', 'standardized', 'oss.noram.us.ukglabor_d_jobcode_standardized', 86400), ('oss.noram.us.ukglabor', 'd_segmentation', 'landing', 'oss.noram.us.ukglabor_d_segmentation_landing', 86400), ('oss.noram.us.ukglabor', 'd_segmentation', 'history', 'oss.noram.us.ukglabor_d_segmentation_history', 86400), ('oss.noram.us.ukglabor', 'd_segmentation', 'standardized', 'oss.noram.us.ukglabor_d_segmentation_standardized', 86400), ('oss.noram.us.ukglabor', 'd_unit', 'landing', 'oss.noram.us.ukglabor_d_unit_landing', 86400), ('oss.noram.us.ukglabor', 'd_unit', 'history', 'oss.noram.us.ukglabor_d_unit_history', 86400), ('oss.noram.us.ukglabor', 'd_unit', 'standardized', 'oss.noram.us.ukglabor_d_unit_standardized', 86400), ('oss.noram.us.ukglabor', 'employeerate', 'landing', 'oss.noram.us.ukglabor_employeerate_landing', 86400), ('oss.noram.us.ukglabor', 'employeerate', 'history', 'oss.noram.us.ukglabor_employeerate_history', 86400), ('oss.noram.us.ukglabor', 'employeerate', 'standardized', 'oss.noram.us.ukglabor_employeerate_standardized', 86400), ('oss.noram.us.ukglabor', 'epretim_a', 'landing', 'oss.noram.us.ukglabor_epretim_a_landing', 86400), ('oss.noram.us.ukglabor', 'epretim_a', 'history', 'oss.noram.us.ukglabor_epretim_a_history', 86400), ('oss.noram.us.ukglabor', 'epretim_a', 'standardized', 'oss.noram.us.ukglabor_epretim_a_standardized', 86400), ('oss.noram.us.ukglabor', 'exceptiontype', 'landing', 'oss.noram.us.ukglabor_exceptiontype_landing', 86400), ('oss.noram.us.ukglabor', 'exceptiontype', 'history', 'oss.noram.us.ukglabor_exceptiontype_history', 86400), ('oss.noram.us.ukglabor', 'exceptiontype', 'standardized', 'oss.noram.us.ukglabor_exceptiontype_standardized', 86400), ('oss.noram.us.ukglabor', 'geofencing_mainlocation', 'landing', 'oss.noram.us.ukglabor_geofencing_mainlocation_landing', 86400), ('oss.noram.us.ukglabor', 'geofencing_mainlocation', 'history', 'oss.noram.us.ukglabor_geofencing_mainlocation_history', 86400), ('oss.noram.us.ukglabor', 'geofencing_mainlocation', 'standardized', 'oss.noram.us.ukglabor_geofencing_mainlocation_standardized', 86400), ('oss.noram.us.ukglabor', 'geofencing_request', 'landing', 'oss.noram.us.ukglabor_geofencing_request_landing', 86400), ('oss.noram.us.ukglabor', 'geofencing_request', 'history', 'oss.noram.us.ukglabor_geofencing_request_history', 86400), ('oss.noram.us.ukglabor', 'geofencing_request', 'standardized', 'oss.noram.us.ukglabor_geofencing_request_standardized', 86400), ('oss.noram.us.ukglabor', 'hr_jobdescriptions', 'landing', 'oss.noram.us.ukglabor_hr_jobdescriptions_landing', 86400), ('oss.noram.us.ukglabor', 'hr_jobdescriptions', 'history', 'oss.noram.us.ukglabor_hr_jobdescriptions_history', 86400), ('oss.noram.us.ukglabor', 'hr_jobdescriptions', 'standardized', 'oss.noram.us.ukglabor_hr_jobdescriptions_standardized', 86400), ('oss.noram.us.ukglabor', 'jobcode_master', 'landing', 'oss.noram.us.ukglabor_jobcode_master_landing', 86400), ('oss.noram.us.ukglabor', 'jobcode_master', 'history', 'oss.noram.us.ukglabor_jobcode_master_history', 86400), ('oss.noram.us.ukglabor', 'jobcode_master', 'standardized', 'oss.noram.us.ukglabor_jobcode_master_standardized', 86400), ('oss.noram.us.ukglabor', 'jobcode_servicetype_xref', 'landing', 'oss.noram.us.ukglabor_jobcode_servicetype_xref_landing', 86400), ('oss.noram.us.ukglabor', 'jobcode_servicetype_xref', 'history', 'oss.noram.us.ukglabor_jobcode_servicetype_xref_history', 86400), ('oss.noram.us.ukglabor', 'jobcode_servicetype_xref', 'standardized', 'oss.noram.us.ukglabor_jobcode_servicetype_xref_standardized', 86400), ('oss.noram.us.ukglabor', 'known_places', 'landing', 'oss.noram.us.ukglabor_known_places_landing', 86400), ('oss.noram.us.ukglabor', 'known_places', 'history', 'oss.noram.us.ukglabor_known_places_history', 86400), ('oss.noram.us.ukglabor', 'known_places', 'standardized', 'oss.noram.us.ukglabor_known_places_standardized', 86400), ('oss.noram.us.ukglabor', 'labor_category', 'landing', 'oss.noram.us.ukglabor_labor_category_landing', 86400), ('oss.noram.us.ukglabor', 'labor_category', 'history', 'oss.noram.us.ukglabor_labor_category_history', 86400), ('oss.noram.us.ukglabor', 'labor_category', 'standardized', 'oss.noram.us.ukglabor_labor_category_standardized', 86400), ('oss.noram.us.ukglabor', 'laborforecast', 'landing', 'oss.noram.us.ukglabor_laborforecast_landing', 86400), ('oss.noram.us.ukglabor', 'laborforecast', 'history', 'oss.noram.us.ukglabor_laborforecast_history', 86400), ('oss.noram.us.ukglabor', 'laborforecast', 'standardized', 'oss.noram.us.ukglabor_laborforecast_standardized', 86400), ('oss.noram.us.ukglabor', 'laborleveldef', 'landing', 'oss.noram.us.ukglabor_laborleveldef_landing', 86400), ('oss.noram.us.ukglabor', 'laborleveldef', 'history', 'oss.noram.us.ukglabor_laborleveldef_history', 86400), ('oss.noram.us.ukglabor', 'laborleveldef', 'standardized', 'oss.noram.us.ukglabor_laborleveldef_standardized', 86400), ('oss.noram.us.ukglabor', 'laborstandards', 'landing', 'oss.noram.us.ukglabor_laborstandards_landing', 86400), ('oss.noram.us.ukglabor', 'laborstandards', 'history', 'oss.noram.us.ukglabor_laborstandards_history', 86400), ('oss.noram.us.ukglabor', 'laborstandards', 'standardized', 'oss.noram.us.ukglabor_laborstandards_standardized', 86400), ('oss.noram.us.ukglabor', 'labortaskgroups', 'landing', 'oss.noram.us.ukglabor_labortaskgroups_landing', 86400), ('oss.noram.us.ukglabor', 'labortaskgroups', 'history', 'oss.noram.us.ukglabor_labortaskgroups_history', 86400), ('oss.noram.us.ukglabor', 'labortaskgroups', 'standardized', 'oss.noram.us.ukglabor_labortaskgroups_standardized', 86400), ('oss.noram.us.ukglabor', 'location_sets', 'landing', 'oss.noram.us.ukglabor_location_sets_landing', 86400), ('oss.noram.us.ukglabor', 'location_sets', 'history', 'oss.noram.us.ukglabor_location_sets_history', 86400), ('oss.noram.us.ukglabor', 'location_sets', 'standardized', 'oss.noram.us.ukglabor_location_sets_standardized', 86400), ('oss.noram.us.ukglabor', 'labortasks', 'landing', 'oss.noram.us.ukglabor_labortasks_landing', 86400), ('oss.noram.us.ukglabor', 'labortasks', 'history', 'oss.noram.us.ukglabor_labortasks_history', 86400), ('oss.noram.us.ukglabor', 'labortasks', 'standardized', 
                            'oss.noram.us.ukglabor_labortasks_standardized', 86400), ('oss.noram.us.ukglabor', 'm_employmentstatus', 'landing', 'oss.noram.us.ukglabor_m_employmentstatus_landing', 86400), ('oss.noram.us.ukglabor', 'm_employmentstatus', 'history', 'oss.noram.us.ukglabor_m_employmentstatus_history', 86400), ('oss.noram.us.ukglabor', 'm_employmentstatus', 'standardized', 'oss.noram.us.ukglabor_m_employmentstatus_standardized', 86400), ('oss.noram.us.ukglabor', 'non_sdx_emps', 'landing', 'oss.noram.us.ukglabor_non_sdx_emps_landing', 86400), ('oss.noram.us.ukglabor', 'non_sdx_emps', 'history', 'oss.noram.us.ukglabor_non_sdx_emps_history', 86400), ('oss.noram.us.ukglabor', 'non_sdx_emps', 'standardized', 'oss.noram.us.ukglabor_non_sdx_emps_standardized', 86400), ('oss.noram.us.ukglabor', 'org', 'landing', 'oss.noram.us.ukglabor_org_landing', 86400), ('oss.noram.us.ukglabor', 'org', 'history', 'oss.noram.us.ukglabor_org_history', 86400), ('oss.noram.us.ukglabor', 'org', 'standardized', 'oss.noram.us.ukglabor_org_standardized', 86400), ('oss.noram.us.ukglabor', 'org_path_master', 'landing', 'oss.noram.us.ukglabor_org_path_master_landing', 86400), ('oss.noram.us.ukglabor', 'org_path_master', 'history', 'oss.noram.us.ukglabor_org_path_master_history', 86400), ('oss.noram.us.ukglabor', 'org_path_master', 'standardized', 'oss.noram.us.ukglabor_org_path_master_standardized', 86400), ('oss.noram.us.ukglabor', 'orgtype', 'landing', 'oss.noram.us.ukglabor_orgtype_landing', 86400), ('oss.noram.us.ukglabor', 'orgtype', 'history', 'oss.noram.us.ukglabor_orgtype_history', 86400), ('oss.noram.us.ukglabor', 'orgtype', 'standardized', 'oss.noram.us.ukglabor_orgtype_standardized', 86400), ('oss.noram.us.ukglabor', 'paycode', 'landing', 'oss.noram.us.ukglabor_paycode_landing', 86400), ('oss.noram.us.ukglabor', 'paycode', 'history', 'oss.noram.us.ukglabor_paycode_history', 86400), ('oss.noram.us.ukglabor', 'paycode', 'standardized', 'oss.noram.us.ukglabor_paycode_standardized', 86400), ('oss.noram.us.ukglabor', 'payperiod', 'landing', 'oss.noram.us.ukglabor_payperiod_landing', 86400), ('oss.noram.us.ukglabor', 'payperiod', 'history', 'oss.noram.us.ukglabor_payperiod_history', 86400), ('oss.noram.us.ukglabor', 'payperiod', 'standardized', 'oss.noram.us.ukglabor_payperiod_standardized', 86400), ('oss.noram.us.ukglabor', 'payrule', 'landing', 'oss.noram.us.ukglabor_payrule_landing', 86400), ('oss.noram.us.ukglabor', 'payrule', 'history', 'oss.noram.us.ukglabor_payrule_history', 86400), ('oss.noram.us.ukglabor', 'payrule', 'standardized', 'oss.noram.us.ukglabor_payrule_standardized', 86400), ('oss.noram.us.ukglabor', 'payruleids', 'landing', 'oss.noram.us.ukglabor_payruleids_landing', 86400), ('oss.noram.us.ukglabor', 'payruleids', 'history', 'oss.noram.us.ukglabor_payruleids_history', 86400), ('oss.noram.us.ukglabor', 'payruleids', 'standardized', 'oss.noram.us.ukglabor_payruleids_standardized', 86400), ('oss.noram.us.ukglabor', 'person', 'landing', 'oss.noram.us.ukglabor_person_landing', 86400), ('oss.noram.us.ukglabor', 'person', 'history', 'oss.noram.us.ukglabor_person_history', 86400), ('oss.noram.us.ukglabor', 'person', 'standardized', 'oss.noram.us.ukglabor_person_standardized', 86400), ('oss.noram.us.ukglabor', 'personcstmdata', 'landing', 'oss.noram.us.ukglabor_personcstmdata_landing', 86400), ('oss.noram.us.ukglabor', 'personcstmdata', 'history', 'oss.noram.us.ukglabor_personcstmdata_history', 86400), ('oss.noram.us.ukglabor', 'personcstmdata', 'standardized', 'oss.noram.us.ukglabor_personcstmdata_standardized', 86400), ('oss.noram.us.ukglabor', 'prsncstmdatemm', 'landing', 'oss.noram.us.ukglabor_prsncstmdatemm_landing', 86400), ('oss.noram.us.ukglabor', 'prsncstmdatemm', 'history', 'oss.noram.us.ukglabor_prsncstmdatemm_history', 86400), ('oss.noram.us.ukglabor', 'prsncstmdatemm', 'standardized', 'oss.noram.us.ukglabor_prsncstmdatemm_standardized', 86400), ('oss.noram.us.ukglabor', 's_krs_org', 'landing', 'oss.noram.us.ukglabor_s_krs_org_landing', 86400), ('oss.noram.us.ukglabor', 's_krs_org', 'history', 'oss.noram.us.ukglabor_s_krs_org_history', 86400), ('oss.noram.us.ukglabor', 's_krs_org', 'standardized', 'oss.noram.us.ukglabor_s_krs_org_standardized', 86400), ('oss.noram.us.ukglabor', 's_krs_servicetype_cc_xref', 'landing', 'oss.noram.us.ukglabor_s_krs_servicetype_cc_xref_landing', 86400), ('oss.noram.us.ukglabor', 's_krs_servicetype_cc_xref', 'history', 'oss.noram.us.ukglabor_s_krs_servicetype_cc_xref_history', 86400), ('oss.noram.us.ukglabor', 's_krs_servicetype_cc_xref', 'standardized', 'oss.noram.us.ukglabor_s_krs_servicetype_cc_xref_standardized', 86400), ('oss.noram.us.ukglabor', 's_krs_servicetype_job_xref', 'landing', 'oss.noram.us.ukglabor_s_krs_servicetype_job_xref_landing', 86400), ('oss.noram.us.ukglabor', 's_krs_servicetype_job_xref', 'history', 'oss.noram.us.ukglabor_s_krs_servicetype_job_xref_history', 86400), ('oss.noram.us.ukglabor', 's_krs_servicetype_job_xref', 'standardized', 'oss.noram.us.ukglabor_s_krs_servicetype_job_xref_standardized', 86400), ('oss.noram.us.ukglabor', 's_krs_wfcjob', 'landing', 'oss.noram.us.ukglabor_s_krs_wfcjob_landing', 86400), ('oss.noram.us.ukglabor', 's_krs_wfcjob', 'history', 'oss.noram.us.ukglabor_s_krs_wfcjob_history', 86400), ('oss.noram.us.ukglabor', 's_krs_wfcjob', 'standardized', 'oss.noram.us.ukglabor_s_krs_wfcjob_standardized', 86400), ('oss.noram.us.ukglabor', 'sdxo_fg_id_upload', 'landing', 'oss.noram.us.ukglabor_sdxo_fg_id_upload_landing', 86400), ('oss.noram.us.ukglabor', 'sdxo_fg_id_upload', 'history', 'oss.noram.us.ukglabor_sdxo_fg_id_upload_history', 86400), ('oss.noram.us.ukglabor', 'sdxo_fg_id_upload', 'standardized', 'oss.noram.us.ukglabor_sdxo_fg_id_upload_standardized', 86400), ('oss.noram.us.ukglabor', 'sdxunit', 'landing', 'oss.noram.us.ukglabor_sdxunit_landing', 86400), ('oss.noram.us.ukglabor', 'sdxunit', 'history', 'oss.noram.us.ukglabor_sdxunit_history', 86400), ('oss.noram.us.ukglabor', 'sdxunit', 'standardized', 'oss.noram.us.ukglabor_sdxunit_standardized', 86400), ('oss.noram.us.ukglabor', 'shiftassignmnt', 'landing', 'oss.noram.us.ukglabor_shiftassignmnt_landing', 86400), ('oss.noram.us.ukglabor', 'shiftassignmnt', 'history', 'oss.noram.us.ukglabor_shiftassignmnt_history', 86400), ('oss.noram.us.ukglabor', 'shiftassignmnt', 'standardized', 'oss.noram.us.ukglabor_shiftassignmnt_standardized', 86400), ('oss.noram.us.ukglabor', 'shiftcode', 'landing', 'oss.noram.us.ukglabor_shiftcode_landing', 86400), ('oss.noram.us.ukglabor', 'shiftcode', 'history', 'oss.noram.us.ukglabor_shiftcode_history', 86400), ('oss.noram.us.ukglabor', 'shiftcode', 'standardized', 'oss.noram.us.ukglabor_shiftcode_standardized', 86400), ('oss.noram.us.ukglabor', 'shiftsegment', 'landing', 'oss.noram.us.ukglabor_shiftsegment_landing', 86400), ('oss.noram.us.ukglabor', 'shiftsegment', 'history', 'oss.noram.us.ukglabor_shiftsegment_history', 86400), ('oss.noram.us.ukglabor', 'shiftsegment', 'standardized', 'oss.noram.us.ukglabor_shiftsegment_standardized', 86400), ('oss.noram.us.ukglabor', 'shiftsegmnttype', 'landing', 'oss.noram.us.ukglabor_shiftsegmnttype_landing', 86400), ('oss.noram.us.ukglabor', 'shiftsegmnttype', 'history', 'oss.noram.us.ukglabor_shiftsegmnttype_history', 86400), ('oss.noram.us.ukglabor', 'shiftsegmnttype', 'standardized', 'oss.noram.us.ukglabor_shiftsegmnttype_standardized', 86400), ('oss.noram.us.ukglabor', 'timecard_exceptions', 'landing', 'oss.noram.us.ukglabor_timecard_exceptions_landing', 86400), ('oss.noram.us.ukglabor', 'timecard_exceptions', 'history', 'oss.noram.us.ukglabor_timecard_exceptions_history', 86400), ('oss.noram.us.ukglabor', 'timecard_exceptions', 'standardized', 'oss.noram.us.ukglabor_timecard_exceptions_standardized', 86400), ('oss.noram.us.ukglabor', 'timecard_extended_exception', 'landing', 'oss.noram.us.ukglabor_timecard_extended_exception_landing', 86400), ('oss.noram.us.ukglabor', 'timecard_extended_exception', 'history', 'oss.noram.us.ukglabor_timecard_extended_exception_history', 86400), ('oss.noram.us.ukglabor', 'timecard_extended_exception', 'standardized', 'oss.noram.us.ukglabor_timecard_extended_exception_standardized', 86400), ('oss.noram.us.ukglabor', 'timecard_historicalcorrections', 'landing', 'oss.noram.us.ukglabor_timecard_historicalcorrections_landing', 86400), ('oss.noram.us.ukglabor', 'timecard_historicalcorrections', 'history', 'oss.noram.us.ukglabor_timecard_historicalcorrections_history', 86400), ('oss.noram.us.ukglabor', 'timecard_historicalcorrections', 'standardized', 'oss.noram.us.ukglabor_timecard_historicalcorrections_standardized', 86400), ('oss.noram.us.ukglabor', 'timecard_paycodeedits_entries', 'landing', 'oss.noram.us.ukglabor_timecard_paycodeedits_entries_landing', 86400), ('oss.noram.us.ukglabor', 'timecard_paycodeedits_entries', 'history', 'oss.noram.us.ukglabor_timecard_paycodeedits_entries_history', 86400), ('oss.noram.us.ukglabor', 'timecard_paycodeedits_entries', 'standardized', 'oss.noram.us.ukglabor_timecard_paycodeedits_entries_standardized', 86400), ('oss.noram.us.ukglabor', 'timecard_processedsegments', 'landing', 'oss.noram.us.ukglabor_timecard_processedsegments_landing', 86400), ('oss.noram.us.ukglabor', 'timecard_processedsegments', 'history', 'oss.noram.us.ukglabor_timecard_processedsegments_history', 86400), ('oss.noram.us.ukglabor', 'timecard_processedsegments', 'standardized', 'oss.noram.us.ukglabor_timecard_processedsegments_standardized', 86400), ('oss.noram.us.ukglabor', 'timecard_punches_exception', 'landing', 'oss.noram.us.ukglabor_timecard_punches_exception_landing', 86400), ('oss.noram.us.ukglabor', 'timecard_punches_exception', 'history', 'oss.noram.us.ukglabor_timecard_punches_exception_history', 86400), ('oss.noram.us.ukglabor', 'timecard_punches_exception', 'standardized', 'oss.noram.us.ukglabor_timecard_punches_exception_standardized', 86400), ('oss.noram.us.ukglabor', 'timecard_punches_notes', 'landing', 'oss.noram.us.ukglabor_timecard_punches_notes_landing', 86400),
                            ('oss.noram.us.ukglabor', 'timecard_punches_notes', 'history', 'oss.noram.us.ukglabor_timecard_punches_notes_history', 86400), ('oss.noram.us.ukglabor', 'timecard_punches_notes', 'standardized', 'oss.noram.us.ukglabor_timecard_punches_notes_standardized', 86400), ('oss.noram.us.ukglabor', 'timecard_response200', 'landing', 'oss.noram.us.ukglabor_timecard_response200_landing', 86400), ('oss.noram.us.ukglabor', 'timecard_response200', 'history', 'oss.noram.us.ukglabor_timecard_response200_history', 86400), ('oss.noram.us.ukglabor', 'timecard_response200', 'standardized', 'oss.noram.us.ukglabor_timecard_response200_standardized', 86400), ('oss.noram.us.ukglabor', 'timecard_scheduledtotal', 'landing', 'oss.noram.us.ukglabor_timecard_scheduledtotal_landing', 86400), ('oss.noram.us.ukglabor', 'timecard_scheduledtotal', 'history', 'oss.noram.us.ukglabor_timecard_scheduledtotal_history', 86400), ('oss.noram.us.ukglabor', 'timecard_scheduledtotal', 'standardized', 'oss.noram.us.ukglabor_timecard_scheduledtotal_standardized', 86400), ('oss.noram.us.ukglabor', 'timecard_scheduleshifts', 'landing', 'oss.noram.us.ukglabor_timecard_scheduleshifts_landing', 86400), ('oss.noram.us.ukglabor', 'timecard_scheduleshifts', 'history', 'oss.noram.us.ukglabor_timecard_scheduleshifts_history', 86400), ('oss.noram.us.ukglabor', 'timecard_scheduleshifts', 'standardized', 'oss.noram.us.ukglabor_timecard_scheduleshifts_standardized', 86400), ('oss.noram.us.ukglabor', 'timecard_totals_aggregatedtotals', 'landing', 'oss.noram.us.ukglabor_timecard_totals_aggregatedtotals_landing', 86400), ('oss.noram.us.ukglabor', 'timecard_totals_aggregatedtotals', 'history', 'oss.noram.us.ukglabor_timecard_totals_aggregatedtotals_history', 86400), ('oss.noram.us.ukglabor', 'timecard_totals_aggregatedtotals', 'standardized', 'oss.noram.us.ukglabor_timecard_totals_aggregatedtotals_standardized', 86400), ('oss.noram.us.ukglabor', 'timecard_totalsummary', 'landing', 'oss.noram.us.ukglabor_timecard_totalsummary_landing', 86400), ('oss.noram.us.ukglabor', 'timecard_totalsummary', 'history', 'oss.noram.us.ukglabor_timecard_totalsummary_history', 86400), ('oss.noram.us.ukglabor', 'timecard_totalsummary', 'standardized', 'oss.noram.us.ukglabor_timecard_totalsummary_standardized', 86400), ('oss.noram.us.ukglabor', 'timecard_workedshifts_workedspan', 'landing', 'oss.noram.us.ukglabor_timecard_workedshifts_workedspan_landing', 86400), ('oss.noram.us.ukglabor', 'timecard_workedshifts_workedspan', 'history', 'oss.noram.us.ukglabor_timecard_workedshifts_workedspan_history', 86400), ('oss.noram.us.ukglabor', 'timecard_workedshifts_workedspan', 'standardized', 'oss.noram.us.ukglabor_timecard_workedshifts_workedspan_standardized', 86400), ('oss.noram.us.ukglabor', 'timecard_workholidaycredits', 'landing', 'oss.noram.us.ukglabor_timecard_workholidaycredits_landing', 86400), ('oss.noram.us.ukglabor', 'timecard_workholidaycredits', 'history', 'oss.noram.us.ukglabor_timecard_workholidaycredits_history', 86400), ('oss.noram.us.ukglabor', 'timecard_workholidaycredits', 'standardized', 'oss.noram.us.ukglabor_timecard_workholidaycredits_standardized', 86400), ('oss.noram.us.ukglabor', 'ukg_jobcodes', 'landing', 'oss.noram.us.ukglabor_ukg_jobcodes_landing', 86400), ('oss.noram.us.ukglabor', 'ukg_jobcodes', 'history', 'oss.noram.us.ukglabor_ukg_jobcodes_history', 86400), ('oss.noram.us.ukglabor', 'ukg_jobcodes', 'standardized', 'oss.noram.us.ukglabor_ukg_jobcodes_standardized', 86400), ('oss.noram.us.ukglabor', 'ukg_location_hierarchy', 'landing', 'oss.noram.us.ukglabor_ukg_location_hierarchy_landing', 86400), ('oss.noram.us.ukglabor', 'ukg_location_hierarchy', 'history', 'oss.noram.us.ukglabor_ukg_location_hierarchy_history', 86400), ('oss.noram.us.ukglabor', 'ukg_location_hierarchy', 'standardized', 'oss.noram.us.ukglabor_ukg_location_hierarchy_standardized', 86400), ('oss.noram.us.ukglabor', 'vhr_employeeall', 'landing', 'oss.noram.us.ukglabor_vhr_employeeall_landing', 86400), ('oss.noram.us.ukglabor', 'vhr_employeeall', 'history', 'oss.noram.us.ukglabor_vhr_employeeall_history', 86400), ('oss.noram.us.ukglabor', 'vhr_employeeall', 'standardized', 'oss.noram.us.ukglabor_vhr_employeeall_standardized', 86400), ('oss.noram.us.ukglabor', 'vhr_employeeallwithfinancehierarchy', 'landing', 'oss.noram.us.ukglabor_vhr_employeeallwithfinancehierarchy_landing', 86400), ('oss.noram.us.ukglabor', 'vhr_employeeallwithfinancehierarchy', 'history', 'oss.noram.us.ukglabor_vhr_employeeallwithfinancehierarchy_history', 86400), ('oss.noram.us.ukglabor', 'vhr_employeeallwithfinancehierarchy', 'standardized', 'oss.noram.us.ukglabor_vhr_employeeallwithfinancehierarchy_standardized', 86400), ('oss.noram.us.ukglabor', 'wfcjob', 'landing', 'oss.noram.us.ukglabor_wfcjob_landing', 86400), ('oss.noram.us.ukglabor', 'wfcjob', 'history', 'oss.noram.us.ukglabor_wfcjob_history', 86400), ('oss.noram.us.ukglabor', 'wfcjob', 'standardized', 'oss.noram.us.ukglabor_wfcjob_standardized', 86400), ('oss.noram.us.ukglabor', 'wfcjoborg', 'landing', 'oss.noram.us.ukglabor_wfcjoborg_landing', 86400), ('oss.noram.us.ukglabor', 'wfcjoborg', 'history', 'oss.noram.us.ukglabor_wfcjoborg_history', 86400), ('oss.noram.us.ukglabor', 'wfcjoborg', 'standardized', 'oss.noram.us.ukglabor_wfcjoborg_standardized', 86400), ('oss.noram.us.ukglabor', 'wtkemployee', 'landing', 'oss.noram.us.ukglabor_wtkemployee_landing', 86400), ('oss.noram.us.ukglabor', 'wtkemployee', 'history', 'oss.noram.us.ukglabor_wtkemployee_history', 86400), ('oss.noram.us.ukglabor', 'wtkemployee', 'standardized', 'oss.noram.us.ukglabor_wtkemployee_standardized', 86400), ('oss.noram.us.ukglabor', 'person_accrualprofile', 'landing', 'oss.noram.us.ukglabor_person_accrualprofile_landing', 86400), ('oss.noram.us.ukglabor', 'person_accrualprofile', 'history', 'oss.noram.us.ukglabor_person_accrualprofile_history', 86400), ('oss.noram.us.ukglabor', 'person_accrualprofile', 'standardized', 'oss.noram.us.ukglabor_person_accrualprofile_standardized', 86400), ('oss.noram.us.ukglabor', 'timecard_audit', 'landing', 'oss.noram.us.ukglabor_timecard_audit_landing', 86400), ('oss.noram.us.ukglabor', 'timecard_audit', 'history', 'oss.noram.us.ukglabor_timecard_audit_history', 86400), ('oss.noram.us.ukglabor', 'timecard_audit', 'standardized', 'oss.noram.us.ukglabor_timecard_audit_standardized', 86400)) AS t (project_name, dataset_name, landing_zone, context_id, ttl)
                    WHERE context_id IN (${context:sqlstring}+'')
                ),
                RawEvents AS (
                    SELECT
                        [timestamp],
                        context_id,
                        job_id,
                        metric_value
                    FROM
                        [observability].[event]
                    WHERE
                        metric_name = 'processing_exit_code'
                        AND event_type = 'processingfinished'
                        AND context_id IN (${context:sqlstring}+'')
                        AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
                ),
                DistinctJobs AS (
                    SELECT DISTINCT
                        context_id,
                        job_id,
                        metric_value
                    FROM
                        RawEvents
                ),
                IngestionSum AS (
                    SELECT
                        context_id,
                        SUM(CASE WHEN metric_value = 0 THEN 1 ELSE 0 END) AS Succeeded,
                        SUM(CASE WHEN metric_value = 1 THEN 1 ELSE 0 END) AS No_Data,
                        SUM(CASE WHEN metric_value = -1 THEN 1 ELSE 0 END) AS Failed
                    FROM
                        DistinctJobs
                    GROUP BY
                        context_id
                ),
                FilteredAndAdded AS (
                        SELECT
                            timestamp,
                            context_id,
                            metric_value
                        FROM (
                            SELECT
                                timestamp,
                                context_id,
                                metric_value
                            FROM
                                RawEvents
                            WHERE
                                metric_value = 0
            
                            UNION ALL
            
                            SELECT
                                $__unixEpochTo() AS timestamp,  -- Current UTC timestamp as Unix time
                                context_id,
                                0 AS metric_value
                            FROM
                                (SELECT DISTINCT context_id FROM RawEvents WHERE metric_value = 0) AS UniqueContexts
            
                            UNION ALL
            
                            SELECT
                                $__unixEpochFrom() AS timestamp,  -- Current UTC timestamp as Unix time
                                context_id,
                                0 AS metric_value
                            FROM
                                (SELECT DISTINCT context_id FROM RawEvents WHERE metric_value = 0) AS UniqueContexts
                            ) AS CombinedFilteredResults
                ),
                EventDifferences AS (
                    SELECT
                        context_id,
                        timestamp,
                        metric_value,
                        LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
                        CASE
                            WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                                timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                            ELSE NULL
                        END AS time_difference
                    FROM
                        FilteredAndAdded
                    WHERE
                        metric_value = 0
                ),
                Slis AS (
                    SELECT
                        cv.project_name AS 'Application Source',
                        cv.dataset_name AS 'Dataset Name',
                        cv.landing_zone AS 'Zone',
                        cv.ttl AS 'TTL',
                        COALESCE(iso.Succeeded, 0) AS 'Succeeded',
                        COALESCE(iso.No_Data, 0) AS 'No New Data',
                        COALESCE(iso.Failed, 0) AS 'Failed',
                        COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
                        CASE
                            WHEN COALESCE(iso.Succeeded, 0) = 0 THEN NULL
                            WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
                            ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / ($__unixEpochTo() - $__unixEpochFrom()))
                        END AS SLI
                    FROM
                        CombinedValues AS cv
                    LEFT JOIN
                        IngestionSum AS iso
                    ON
                        cv.context_id = iso.context_id
                    LEFT JOIN
                        EventDifferences AS ed
                    ON
                        cv.context_id = ed.context_id
                        AND ed.time_difference > cv.ttl
                    GROUP BY
                        cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed
                )

            SELECT
                CASE
                    WHEN COUNT(*) != COUNT(SLI) THEN 0  -- If any SLI is NULL, return 0
                    WHEN MIN(SLI) < 0 then 0
                    ELSE AVG(SLI)
                END AS 'Percentage'
            FROM
                Slis;

    ";

    stat.new(
        title='SLI',
        datasource='Azure SQL Server',
        description= "SLI (Service Level Indicator) measures the freshness and accuracy of data ingestion pipelines based on SLO (Service Level Objective) benchmarks set
by DAOs and Data Governors. Stakeholders define the SLOs for datasets in a standardized Excel template.  
 SLI: Selected time range (in hours) - Downtime (in hours)/Selected time range (in hours) * 100  
 Example 1: For a dataset with a 2-day time range and 1-day downtime: SLI: 48-24/48 * 100 = 50%                                                                                                                                                                                                                                
 Example 2: For a dataset with a 7-day time range and half-day downtime: SLI: 168-12/168 * 100 = 92.8%.")
        .addTarget(target=grafana.sql.target(rawSql=SLISqlQuery, format='table'))
        .addOverridesByFieldName(
        field='Percentage',
        properties=[{id: 'unit', value: 'percent'},
        {
            "id": "thresholds",
            "value": {
            "mode": "absolute",
            "steps": [
                { "color": "light-gray", "value": null },
                { "color": "light-red", "value": 0 },
                { "color": "light-yellow", "value": 80 },
                { "color": "light-green", "value": 80*1.1 }
            ]
            }
        }
        ]
);
local generateIngestionPipelinesByCondition(title, color, code) =
   local sqlQuery = std.format("
       
        SELECT COUNT(*)
        FROM(
                SELECT distinct job_id, context_id
                FROM [observability].[event]
                WHERE metric_name='processing_exit_code'
                AND event_type='processingfinished'
                AND metric_value=%d
                AND context_id in ($context + '')
                AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
                AND dataset_name IN ($dataset_name)
                AND landing_zone IN ($landing_zone)
                AND project_name IN ($project_name)
            ) AS SubQuery

        ", [code]
    );

    grafana.statPanel.new(title, datasource='Azure SQL Server', colorMode='background')
    .addThresholds([{ value: 0, color: color }])
    .addTarget(target=grafana.sql.target(rawSql=sqlQuery, format='table')
);

local GenerateSuccessRatio =
    local sqlQuery = "
		SELECT
            CASE WHEN COUNT(*) = 0 THEN 100 
            ELSE COUNT(CASE WHEN metric_value != -1 THEN 1 ELSE NULL END) * 100.0 / COUNT(*) 
            END AS ratio
        FROM ( select distinct job_id, context_id, metric_value from[observability].[event]
                  WHERE metric_name= 'processing_exit_code'
                  AND event_type =  'processingfinished'
                  AND context_id in ($context + '')
                  AND context_id IN (${context:sqlstring}+'')
                  AND timestamp >= $__unixEpochFrom()
                  AND timestamp < $__unixEpochTo()
              ) As distinct_records
    ";
        
    grafana.statPanel.new(
    title='Success Ratio Indicator',
    datasource='Azure SQL Server',
    description= "The Pipeline Success Ratio Indicator provides a clear metric to gauge the effectiveness of
    a data ingestion pipeline by comparing successful operations against failures and no new data. "
    ).addTarget(target=grafana.sql.target(rawSql=sqlQuery,format='table'))
    .addOverridesByFieldName(field='ratio',properties=[{id: 'unit', value: 'percent'}]
);

local DatasetFreshness = 
    local sqlQuery = " 
    WITH
        FilteredEvents AS (
            SELECT
                job_id,
                context_id,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                timestamp,
                metric_name,
                metric_value
            FROM
                [observability].[event]
            WHERE
                context_id in ($context + '')
                --context_id IN ('oss.glb.glb.dynamify_sdx_getallowances_history','oss.glb.glb.dynamify_sdx_getallowances_landing','oss.glb.glb.dynamify_sdx_getallowances_standardized','oss.glb.glb.dynamify_sdx_menudataexportobject_history','oss.glb.glb.dynamify_sdx_menudataexportobject_landing','oss.glb.glb.dynamify_sdx_menudataexportobject_standardized','oss.glb.glb.dynamify_sdx_tradescommercexportobject_history','oss.glb.glb.dynamify_sdx_tradescommercexportobject_landing','oss.glb.glb.dynamify_sdx_tradescommercexportobject_standardized','oss.glb.glb.dynamify_sdx_mealdeal_history','oss.glb.glb.dynamify_sdx_mealdeal_landing','oss.glb.glb.dynamify_sdx_mealdeal_standardized'+'')
                --context_id IN ('oss.glb.glb.dynamify_sdx_menudataexportobject_history','oss.glb.glb.dynamify_sdx_menudataexportobject_landing','oss.glb.glb.dynamify_sdx_menudataexportobject_standardized'+'')
                AND dataset_name  in ($dataset_name)
                AND project_name  in ($project_name)
                AND metric_name IN ('processing_started_date', 'processing_finished_date', 'processing_exit_code', 'rows_count', 'content_latest_date')
        ),
        MergedEvents AS (
            SELECT
                job_id,
                context_id,
                timestamp,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                [processing_started_date] AS processing_started_date_value,
                [processing_finished_date] AS processing_finished_date_value,
                [processing_exit_code] AS processing_exit_code_value,
                [content_latest_date] AS content_latest_date,
                [rows_count] AS rows_count_value
            FROM
                FilteredEvents
            PIVOT (
                MAX(metric_value)
                FOR metric_name IN ([processing_started_date], [processing_finished_date], [processing_exit_code], [rows_count], [content_latest_date])
            ) AS PivotTable
        ),
        Finalevents as
        (
        SELECT
            MAX(project_name) AS 'Application Source',
            MAX(dataset_name) AS 'Dataset',
            MAX(landing_zone) AS 'Zone',
            MAX(
                CASE subscription_id
                    WHEN '6b4a5b3f-1015-42da-a46a-2890a5abed30' THEN 'IFM CORE PROD'
                    WHEN '2698ca5b-bf81-43fb-8fe2-f0e21bf068e5' THEN 'IFM CORE UAT/TEST'
                    WHEN '746ac5b9-70eb-4c76-bdf4-0664bfdff2ea' THEN 'IFM CORE DEV'
                    WHEN 'cf25f2a1-4d40-45af-bb81-87ec46112b3e' THEN 'SDX STA/PRD'
                    WHEN 'c0978b9d-b809-45f4-aa76-391ceb2cfdba' THEN 'SDX DEV/TEST'
                    WHEN '8eaa3d95-3cd2-49d8-b44a-7ea47a6fb58b' THEN 'SDX SILVER'
                    WHEN 'daf86ec1-725c-493f-bf09-a1f129b8588a' THEN 'SDX INT/UAT'
                    WHEN 'fea1e9f0-0e20-426f-906e-bc76e5a566ad' THEN 'SDX Sandbox'
                    WHEN '6e3fc63f-851b-4fc7-8499-48f6a9c28a65' THEN 'SDX Global Shared Services'
                    ELSE 'Undefined'
            END
            ) AS 'Subscription',
            MAX(takeoff_zone) + ' to ' + MAX(landing_zone) AS 'Activity',
            CASE
                WHEN MAX(processing_exit_code_value) = 0 THEN 'Succeeded'
                WHEN MAX(processing_exit_code_value) = 1 THEN 'No New Data'
                WHEN MAX(processing_exit_code_value) = 2 THEN 'Skipped'
                WHEN MAX(processing_exit_code_value) IS NULL THEN 'Running'
                ELSE 'Failed'
            END AS 'Status',
            DATEADD(SECOND, MAX([timestamp]), '1970-01-01') AS 'Landed at',
            DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([timestamp]) AS 'Landed Since',
            DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([content_latest_date]) AS 'Freshness',
            CAST(MAX(processing_finished_date_value) - MAX(processing_started_date_value) AS BIGINT) AS 'Duration',
            ISNULL(CAST(CAST(MAX(rows_count_value) AS BIGINT) AS VARCHAR), 'N/A') AS 'Rows'
        FROM MergedEvents
        GROUP BY job_id, context_id
        ),
        Eventsdata as(
            Select [Application Source] as ApplicationSource, Dataset,Zone, Subscription, Activity, Status,[Landed at] as LandedAt,[Landed Since] as LandedSince,[Freshness] as Freshness, Duration,[Rows] as IngestedRows from Finalevents
            where Status in ($status)
        ),
 
        finaldata as (select
            ApplicationSource ,
            Dataset,
            case
                   when count(case when Activity = 'landing to history' and status = 'succeeded' then 1 end) >= 1
                   and count(case when Activity = 'history to standardized' and status = 'succeeded' then 1 end) >= 1
                then 'OK'        
                else 'NOT OK'
            end as [Overall Status],
            Subscription as [Datalake Location],
            case
                when count(case when Activity = 'landing to history' and status = 'succeeded' then 1 end) >= 1
                then 'OK'
                else 'NOT OK'
            end as [Bronze History Status],
            case
                when count(case when Activity = 'history to standardized' and status = 'succeeded' then 1 end) >= 1                    
        then 'OK'
                else 'NOT OK'
            end as [Bronze Standardized Status],    
            max(case
                when Activity = 'landing to history' then LandedAt
                end)
        as [Pipe Line Execution StartTime],
            max(case
                when Activity = 'history to standardized' then LandedAt
                end)
        as [Pipe Line Execution EndTime],
 
            datediff(second,
            min(case
                when Activity = 'landing to history' then LandedAt
                end),current_timestamp
            ) as [Pipe Line Executed Since],
            max(Freshness) as Freshness,
            datediff(second,
            min(case when Activity = 'landing to history' then landedAt end),
            max(case when Activity = 'history to standardized' then landedAt end)
           ) as 'Total Execution Time',
           convert(Date, LandedAt) as executedDate
        From Eventsdata
        group by ApplicationSource,
            Dataset,
            subscription,
            convert(Date, LandedAt)
        ),
        RankedData as
        (
            select  ApplicationSource,
                    Dataset,
                    [Datalake Location],
                    executedDate,
                    case
                    when executedDate < getdate()
                    then DatedIff(second,max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                        else
                        DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Overall Refresh Status],
                    case when executedDate < getdate()
                then DatedIff(second, max([Pipe Line Execution StartTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    else
                    DatedIff(second, max([Pipe Line Execution StartTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Bronze History Refresh Status],
                case when executedDate < getdate()
                then DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    else
                    DatedIff(second,max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Bronze Standardized Refresh Status],
                row_number() over (partition by ApplicationSource, Dataset order by executedDate desc) as rownum,
                    [Pipe Line Execution EndTime],
                [Pipe Line Execution StartTime],
                [Pipe Line Executed Since],
                    Freshness,
                    [Total Execution Time],
                 86400 as [Freshness Threshold]
        from finalData
            where  [Overall Status] = 'OK'
        )
        select ApplicationSource,
            Dataset,
            [Freshness Threshold] as 'Threshold',
            [Overall Refresh Status] as 'Freshness Refresh Status',
            [Bronze History Refresh Status],
            [Bronze Standardized Refresh Status],
            [Pipe Line Execution StartTime],
            [Pipe Line Execution EndTime],
            Freshness,
            ([Freshness Threshold] - [Overall Refresh Status]) AS Differenceintime,
			CASE
				WHEN ([Freshness Threshold] - [Overall Refresh Status]) < 0 THEN 1
				WHEN ([Freshness Threshold] - [Overall Refresh Status]) > 0 THEN 2
				ELSE 0
			END AS Colour_Code
        from RankedData
        where  rownum = 1
        order by executedDate desc
   
   ";
   table.new(
    title = 'Tracking Data Freshness',
    datasource = 'Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Pipe Line Execution StartTime',properties=[{id: 'unit', value: 's'},{id: 'custom.width',value: 226}]
    ).addOverridesByFieldName(field='Pipe Line Execution EndTime',properties=[{id: 'unit', value: 's'},{id: 'custom.width',value: 229}]
    ).addOverridesByFieldName(field='Freshness',properties=[{id: 'unit', value: 's'},{id: 'custom.width',value: 133},{id: 'custom.hidden', value: true}]
    ).addOverridesByFieldName(field='ApplicationSource',properties=[{id: 'custom.width',value: 199}]
    ).addOverridesByFieldName(field='Dataset',properties=[{id: 'custom.width',value: 214}]
    ).addOverridesByFieldName(field='Threshold',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Freshness Refresh Status',properties=[{id: 'unit',value: "s"}]
    ).addOverridesByFieldName(field='Colour_Code',properties=[{id: 'custom.cellOptions',value: {type: 'color-background', applyToRow: true}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'green',value: null},{color: 'light-orange',value: 0},{color: 'light-red',value: 1},{color: 'super-light-green',value: 2}]}},{id: 'custom.hidden', value: true}]
    ).addOverridesByFieldName(field='Differenceintime',properties=[{id: 'custom.hidden',value: true}]
    ).addOverridesByFieldName(field='Bronze History Refresh Status',properties=[{id: 'unit',value: "s"}]
    ).addOverridesByFieldName(field='Bronze Standardized Refresh Status',properties=[{id: 'unit',value: "s"}]
);

local DatasetVolumeVolumeCheckStandardized = 
    local sqlQuery = " 
        SELECT replace(project_name, '_', '.') as 'Application Source',
                table_name as 'Dataset Name',
                rundate as 'Transaction Date',
            'Data volume >= 1000' as 'Threshold',
                row_count as 'Transaction count' 
        FROM [observability].[UKGpro_volume_data]
        WHERE replace(project_name, '_', '.') in ($project_name)
        and datediff(second, '1970-01-01 00:00:00', rundate) BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
        and zone = 'Standardized'
        order by rundate desc;
    ";
   table.new(
    title = 'Volume check - Standardized',
    datasource = 'Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Threshold',properties=[{id: 'custom.width',value: 437}]
    ).addOverridesByFieldName(field='Transaction count',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'green'}]}},{id: 'mappings',value: [{options: {'from':0, 'result': {color: 'red','index': 0}, 'to': 1000}, type: 'range'}]}]
    ).addOverridesByFieldName(field='Dataset Name',properties=[{id: 'custom.width', 'value': 212 }]
    ).addOverridesByFieldName(field='Application Source',properties=[{ id: 'custom.width', 'value': 188 }]
    ).addOverridesByFieldName(field='Transaction Date',properties=[{id: 'custom.width', 'value': 193 }]
);

local DatasetVolumeVolumnCheckHistory = 
    local sqlQuery = " 
        SELECT replace(project_name, '_', '.') as 'Application Source',
                table_name as 'Dataset Name',
                rundate as 'Transaction Date',
            'Data volume >= 1000' as 'Threshold',
                row_count as 'Transaction count' 
        FROM [observability].[UKGpro_volume_data]
        WHERE replace(project_name, '_', '.') in ($project_name)
        and datediff(second, '1970-01-01 00:00:00', rundate) BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
        and zone = 'history'
        order by rundate desc
    ";
   table.new(
    title = 'Volume check - History',
    datasource = 'Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Threshold',properties=[{id: 'custom.width',value: 437}]
    ).addOverridesByFieldName(field='Transaction count',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'green'}]}},{id: 'mappings',value: [{options: {'from':0, 'result': {color: 'red','index': 0}, 'to': 1000}, type: 'range'}]}]
    ).addOverridesByFieldName(field='Dataset Name',properties=[{id: 'custom.width', 'value': 212 }]
    ).addOverridesByFieldName(field='Application Source',properties=[{ id: 'custom.width', 'value': 188 }]
    ).addOverridesByFieldName(field='Transaction Date',properties=[{id: 'custom.width', 'value': 193 }]
);

local DbtpipelineMonitoring = 
    local sqlQuery = " 
        select 
            dateadd(second, t.exec_ts, '1970-01-01') as ExecutionTime,
            t.project_name as 'PipleineName',
            case when t.exit_code = 0 
                    Then 'Succeeded' 
                    Else 'Failed' 
            End as Status 
            from (
                select event_id, 
                        project_name, 
                        max(timestamp) as exec_ts, 
                        max(metric_value) as exit_code 
                from observability.event
                where project_name = 'oss.noram.us.ukglaborDBT' 
                        and event_type = 'processingfinished' 
                        and metric_name = 'processing_exit_code'
                group by event_id, project_name
            ) t
            ORDER BY ExecutionTime desc;
    ";
   table.new(
    title = 'DBT Pipeline Monitoring',
    datasource = 'Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(
        field='Status',
    properties=[
    { id: 'custom.cellOptions', value: { type: 'color-text' } },
    { id: 'mappings',
      value: [{
        type: 'value',
        options: {
          'Succeeded': { color: 'green', index: 0 },
          'Failed': { color: 'red', index: 3 },
        }
      }]
    }
  ]
);

local DatasetIngestionHistory = 
    local sqlQuery = "  
    WITH 
        FilteredEvents AS (
            SELECT
                job_id,
                context_id,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                timestamp,
                metric_name,
                metric_value
            FROM
                [observability].[event]
            WHERE
                context_id IN (${context:sqlstring}+'')
                AND dataset_name in ($dataset_name)
                AND landing_zone IN ($landing_zone)
                AND project_name in ($project_name)
                AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                AND metric_name IN ('processing_started_date', 'processing_finished_date', 'processing_exit_code', 'rows_count', 'content_latest_date')
        ),
        MergedEvents AS (
            SELECT
                job_id,
                context_id,
                timestamp,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                [processing_started_date] AS processing_started_date_value,
                [processing_finished_date] AS processing_finished_date_value,
                [processing_exit_code] AS processing_exit_code_value,
                [content_latest_date] AS content_latest_date,
                [rows_count] AS rows_count_value
            FROM
                FilteredEvents
            PIVOT (
                MAX(metric_value)
                FOR metric_name IN ([processing_started_date], [processing_finished_date], [processing_exit_code], [rows_count], [content_latest_date])
            ) AS PivotTable
        ),
        Finalevents as(
            SELECT
                MAX(project_name) AS 'Application Source',
                MAX(dataset_name) AS 'Dataset',
                MAX(landing_zone) AS 'Zone',
                MAX(
                    CASE subscription_id
                    WHEN '6b4a5b3f-1015-42da-a46a-2890a5abed30' THEN 'IFM CORE PROD'
                    WHEN '2698ca5b-bf81-43fb-8fe2-f0e21bf068e5' THEN 'IFM CORE UAT/TEST'
                    WHEN '746ac5b9-70eb-4c76-bdf4-0664bfdff2ea' THEN 'IFM CORE DEV'
                    WHEN 'cf25f2a1-4d40-45af-bb81-87ec46112b3e' THEN 'SDX STA/PRD'
                    WHEN 'c0978b9d-b809-45f4-aa76-391ceb2cfdba' THEN 'SDX DEV/TEST'
                    WHEN '8eaa3d95-3cd2-49d8-b44a-7ea47a6fb58b' THEN 'SDX SILVER'
                    WHEN 'daf86ec1-725c-493f-bf09-a1f129b8588a' THEN 'SDX INT/UAT'
                    WHEN 'fea1e9f0-0e20-426f-906e-bc76e5a566ad' THEN 'SDX Sandbox'
                    WHEN '6e3fc63f-851b-4fc7-8499-48f6a9c28a65' THEN 'SDX Global Shared Services'
                    ELSE 'Undefined'
                    END
                ) AS 'Subscription',
                MAX(takeoff_zone) + ' to ' + MAX(landing_zone) AS 'Activity',
                case 
                    when sum(case when processing_exit_code_value not in (0,1,2) then 1 else 0 end) > 0 then 'Failed'
                    when count(case when processing_exit_code_value = 0 then 1 end) > 0 then 'Succeeded'
                    when count(case when processing_exit_code_value = 1 then 1 end) > 0 then 'No New Data'
                    when count(case when processing_exit_code_value = 2 then 1 end) > 0 then 'Skipped'
                End as 'Status',
                DATEADD(SECOND, MAX([timestamp]), '1970-01-01') AS 'Landed at',
                DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([timestamp]) AS 'Landed Since',
                DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([content_latest_date]) AS 'Freshness',
                CAST(MAX(processing_finished_date_value) - MAX(processing_started_date_value) AS BIGINT) AS 'Duration',
                ISNULL(CAST(CAST(MAX(rows_count_value) AS BIGINT) AS VARCHAR), 'N/A') AS 'Rows'
            FROM MergedEvents
            GROUP BY job_id, context_id
        )
        Select[Application Source], Dataset,Zone, Subscription, Activity, Status,[Landed at],Rows from Finalevents
        where Status in ($status)
        ORDER BY[Landed at] DESC;    
   ";
   table.new(
    title = 'Data Ingestion History - Overview',
    datasource = 'Azure SQL Server'
    )
    .addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table'))
    .addOverridesByFieldName(
  field='Rows',
  properties=[
    { id: 'custom.cellOptions', value: { type: 'color-text' } },
    { id: 'mappings',
      value: [{
        type: 'value',
        options: {
          'N/A': { color: 'red', index: 0 }
        }
      }]
    }
  ]
  ).addOverridesByFieldName(
  field='Status',
  properties=[
    { id: 'custom.cellOptions', value: { type: 'color-text' } },
    { id: 'mappings',
      value: [{
        type: 'value',
        options: {
          'Succeeded': { color: 'green', index: 0 },
          'No New Data': { color: 'yellow', index: 1 },
          'Running': { color: 'gray', index: 2 },
          'Failed': { color: 'red', index: 3 },
        }
      }]
    }
  ]
);

local getDashboardAlertsPanel(alertName) =
    grafana.alertlist.new(
    title = std.format("Dashboard Alerts Observability UKG Pro %s ",alertName),
    onlyAlertsOnDashboard = true,
    )
    +{
    'options' :
        {
        "dashboardAlerts": false,
        "sortOrder" : 1,
        "maxItems": -1,
        "alertName": alertName,
        "stateFilter": {
            "firing": true,
            "pending": true,
            "noData": true,
            "normal": true,
            "error": true
            }
        }
    }
    + {
    "sortOrder": 1,
};

grafana.dashboard.new(
  title='UKG Pro Dashboard',
  refresh='5m',
  time_from='now-7d',
  editable=true,
  timezone='utc',
  schemaVersion=39,
  uid='ukg_pro_dashboard',
  tags=['Noram', 'observability', 'SDX'])
  
//global filters
.addTemplate(projectTemplate)
.addTemplate(datasetTemplate)
.addTemplate(stageTemplate)
.addTemplate(statusTemplate)
.addTemplate(HidedContext)

//panels
.addPanel(panel = generatePanelCount,gridPos={h:3,w:8,x:0,y:0})
.addPanel(panel = SLOPanel,gridPos={h:3,w:8,x:8,y:0})
.addPanel(panel = generateSLIPanel,gridPos={h:3,w:8,x:16,y:0})

.addPanel(generateIngestionPipelinesByCondition('Succeeded', 'green', 0),gridPos={h: 3, w: 6, x: 0, y: 3})
.addPanel(generateIngestionPipelinesByCondition('No New Data', 'yellow', 1),gridPos={h: 3, w: 6, x: 6, y: 3})
.addPanel(generateIngestionPipelinesByCondition('Failed', 'red', -1),gridPos={h: 3, w: 6, x: 12, y: 3})
.addPanel(panel = GenerateSuccessRatio,gridPos={h: 3, w: 6, x: 18, y: 3})

//added succeed panel

.addPanel(grafana.text.new(mode='markdown',content='Succeeded: Count of Ingestion Pipelines Run Successfully during the selected period for the selected datasets.',transparent= true),gridPos={h: 3, w: 6, x: 0, y: 6})
    
.addPanel(grafana.text.new(mode='markdown',content='No New Data: Count of Ingestion Pipelines triggered but no data pushed from Integration during the selected period for the selected dataset(s).',transparent= true),gridPos={h: 3, w: 6, x: 6, y: 6})
    
.addPanel(grafana.text.new(mode='markdown',content='Failed: Count of Ingestion Pipelines Failed during the selected period for the selected dataset(s).',transparent= true),gridPos={h: 3, w: 6, x: 12, y: 6})
    
.addPanel(grafana.text.new(mode='markdown',content='Success ratio: It is calculated as ((Success+ No New Data)/ (success + No New Data + Failed)) * 100.',transparent= true),gridPos={h: 3, w: 6, x: 18, y: 6})


.addPanel(
    row.new(
        title="Tracking Data Freshness",
        showTitle=true,
        collapse=true
    ).addPanel(panel = DatasetFreshness,gridPos={h:10,w:24,x:0,y:10}),
    gridPos={h:1,w:24,x:0,y:9}
)

.addPanel(
    row.new(
        title="Data Volume Statistics",
        showTitle=true,
        collapse=true
    ).addPanel(panel = DatasetVolumeVolumeCheckStandardized,gridPos={h:9,w:24,x:0,y:20}
    ).addPanel(panel =DatasetVolumeVolumnCheckHistory,gridPos={h:9,w:24,x:0,y:30}
    ),
    gridPos={h:1,w:24,x:0,y:10}
)

.addPanel(
    row.new(
        title="DBT Pipeline Monitoring Status",
        showTitle=true,
        collapse=true
    ).addPanel(panel = DbtpipelineMonitoring,gridPos={h:9,w:24,x:0,y:30}
    ),
    gridPos={h:1,w:24,x:0,y:11}
)

.addPanel(
    row.new(
        title="Dataset Ingestion History Overview",
        showTitle=true,
        collapse=true
    ).addPanel(panel = DatasetIngestionHistory,gridPos={h:10,w:24,x:0,y:12}),
    gridPos={h:1,w:24,x:0,y:12}
)
.addPanel(
    row.new(
        title="Dashboard Alerts",
        showTitle=true,
        collapse=true
    ).addPanel(panel = getDashboardAlertsPanel('oss.noram.us.ukglabor'),gridPos={h:12,w:24,x:0,y:22}),
    gridPos={h:1,w:24,x:0,y:23}
)