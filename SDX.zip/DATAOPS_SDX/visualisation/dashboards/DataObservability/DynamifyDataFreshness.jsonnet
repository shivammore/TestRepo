local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local stat = grafana.statPanel;
local table = grafana.tablePanel;
local slo = 80;

//global filters
local projectTemplate =  tmpl.custom(
    name='project_name',
    current='all',
    query='oss.glb.glb.dynamify_sdx',
    includeAll=true,
    multi=true,
    label="Application Source"
);

local datasetTemplate = tmpl.custom(
    name='dataset_name',
    query= 'getallowances,menudataexportobject,tradescommercexportobject,mealdeal',
    current='all',
    includeAll=true,
    multi=true,
    label='Dataset Name'
);

local stageTemplate =  tmpl.custom(
    name='landing_zone',
    current='all',
    query='history,landing,standardized',
    includeAll=true,
    multi=true,
    label="Zone"
);

local statusTemplate =  tmpl.custom(
    name='status',
    current='all',
    query='Succeeded,Failed,No New Data,Running,Skipped',
    includeAll=true,
    multi=true,
    label="Ingestion Status"
);

local HidedContext =
    grafana.template.new(
    name='context',
    datasource='Azure SQL Server',
    query="
        SELECT distinct(context_id)
        FROM [observability].[event]
        WHERE
    dataset_name IN ($dataset_name)
    AND landing_zone IN ($landing_zone)
    AND project_name IN ($project_name)
        ",
    current='all',
    refresh='load',
    hide = true,
    includeAll=true,
    multi=false,
    label='context'
);

//panels
local generatePanelCount =
  stat.new(
    title='Total Datasets',
    datasource='Azure SQL Server',
    description="@todo"
  )
  // Use the length of the sources list as the value to display
  .addTarget(
    target=grafana.sql.target(
      rawSql="with cte as (select '${dataset_name:csv}' as val)
	              select (LEN(val) - LEN(REPLACE(val, ',', ''))) + 1 from cte;",
      format='table'
    )
);

local SLOPanel = stat.new(
    title='SLO',
    datasource='Azure SQL Server',
    description="This is a benchmark defined by the proprietors or stakeholders of a data ingestion pipeline.
    It signifies the anticipated and aspired level of efficiency, reliability, and quality for data ingestion processes.
    Such a goal provides a tangible metric against which the actual performance of the data ingestion can be evaluated,ensuring that the pipeline operates in alignment with stakeholder expectations and requirements.")
    .addTarget(target=grafana.sql.target(rawSql= "SELECT 80 AS SLO", format='table'))
    .addOverridesByFieldName(field='SLO',properties=[{id: 'unit', value: 'percent'}]
);

local generateSLIPanel =
    local SLISqlQuery = "   
        WITH
        CombinedValues AS (
            SELECT *
            FROM (VALUES ('oss.glb.glb.dynamify_sdx', 'tradescommercexportobject', 'landing', 'oss.glb.glb.dynamify_sdx_tradescommercexportobject_landing', 86400), ('oss.glb.glb.dynamify_sdx', 'tradescommercexportobject', 'history', 'oss.glb.glb.dynamify_sdx_tradescommercexportobject_history', 86400), ('oss.glb.glb.dynamify_sdx', 'tradescommercexportobject', 'standardized', 'oss.glb.glb.dynamify_sdx_tradescommercexportobject_standardized', 86400), ('oss.glb.glb.dynamify_sdx', 'getallowances', 'landing', 'oss.glb.glb.dynamify_sdx_getallowances_landing', 604800), ('oss.glb.glb.dynamify_sdx', 'getallowances', 'history', 'oss.glb.glb.dynamify_sdx_getallowances_history', 604800), ('oss.glb.glb.dynamify_sdx', 'getallowances', 'standardized', 'oss.glb.glb.dynamify_sdx_getallowances_standardized', 604800), ('oss.glb.glb.dynamify_sdx', 'menudataexportobject', 'landing', 'oss.glb.glb.dynamify_sdx_menudataexportobject_landing', 604800), ('oss.glb.glb.dynamify_sdx', 'menudataexportobject', 'history', 'oss.glb.glb.dynamify_sdx_menudataexportobject_history', 604800), ('oss.glb.glb.dynamify_sdx', 'menudataexportobject', 'standardized', 'oss.glb.glb.dynamify_sdx_menudataexportobject_standardized', 604800),('oss.glb.glb.dynamify_sdx', 'mealdeal', 'landing', 'oss.glb.glb.dynamify_sdx_mealdeal_landing', 604800),('oss.glb.glb.dynamify_sdx', 'mealdeal', 'history', 'oss.glb.glb.dynamify_sdx_mealdeal_history', 604800),('oss.glb.glb.dynamify_sdx', 'mealdeal', 'standardized', 'oss.glb.glb.dynamify_sdx_mealdeal_standardized', 604800)) AS t (project_name, dataset_name, landing_zone, context_id, ttl)
           WHERE context_id IN (${context:sqlstring}+'')
        ),
        RawEvents AS (
                SELECT
                    [timestamp],
                    context_id,
                    job_id,
                    metric_value
                FROM
                    [observability].[event]
                WHERE
                    metric_name = 'processing_exit_code'
                    AND event_type = 'processingfinished'
                    AND context_id IN (${context:sqlstring}+'')
                    AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
            ),
            DistinctJobs AS (
                SELECT DISTINCT
                    context_id,
                    job_id,
                    metric_value
                FROM
                    RawEvents
            ),
            IngestionSum AS (
                SELECT
                    context_id,
                    SUM(CASE WHEN metric_value = 0 THEN 1 ELSE 0 END) AS Succeeded,
                    SUM(CASE WHEN metric_value = 1 THEN 1 ELSE 0 END) AS No_Data,
                    SUM(CASE WHEN metric_value = -1 THEN 1 ELSE 0 END) AS Failed
                FROM
                    DistinctJobs
                GROUP BY
                    context_id
            ),
            FilteredAndAdded AS (
                SELECT
                    timestamp,
                    context_id,
                    metric_value
                FROM (
                    SELECT
                        timestamp,
                        context_id,
                        metric_value
                    FROM
                        RawEvents
                    WHERE
                        metric_value = 0
    
                    UNION ALL
    
                    SELECT
                    $__unixEpochTo() AS timestamp,  -- Current UTC timestamp as Unix time
                        context_id,
                        0 AS metric_value
                    FROM
                        (SELECT DISTINCT context_id FROM RawEvents WHERE metric_value = 0) AS UniqueContexts
    
                    UNION ALL
    
                    SELECT
                    $__unixEpochFrom() AS timestamp,  -- Current UTC timestamp as Unix time
                        context_id,
                        0 AS metric_value
                    FROM (SELECT DISTINCT context_id FROM RawEvents WHERE metric_value = 0) AS UniqueContexts
                ) AS CombinedFilteredResults
        	),
            EventDifferences AS (
                SELECT
                    context_id,
                    timestamp,
                    metric_value,
                    LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
                    CASE
                        WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                            timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                        ELSE NULL
                    END AS time_difference
                FROM
                    FilteredAndAdded
                WHERE
                    metric_value = 0
            ),
            Slis AS (
                SELECT
                    cv.project_name AS 'Application Source',
                    cv.dataset_name AS 'DatasetName',
                    cv.landing_zone AS 'Zone',
                    cv.ttl AS 'TTL',
                    COALESCE(iso.Succeeded, 0) AS 'Succeeded',
                    COALESCE(iso.No_Data, 0) AS 'No New Data',
                    COALESCE(iso.Failed, 0) AS 'Failed',
                    COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
                    CASE
                        WHEN COALESCE(iso.Succeeded, 0) = 0 THEN 0
                        WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
                        ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / ($__unixEpochTo() - $__unixEpochFrom()))
                    END AS SLI
                FROM
                    CombinedValues AS cv
                LEFT JOIN
                    IngestionSum AS iso
                ON
                    cv.context_id = iso.context_id
                LEFT JOIN
                    EventDifferences AS ed
                ON
                    cv.context_id = ed.context_id
                    AND ed.time_difference > cv.ttl
                GROUP BY
                    cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed
            )
            select AVG(SLI) as 'SLI Percentage'  from Slis
    ";

    stat.new(
        title='SLI',
        datasource='Azure SQL Server',
        description= "The SLI(Service Level Indicator) is a measurable metric closely monitored by stakeholders to
        evaluate the operational performance and efficiency of a data ingestion pipeline. It is calculated here as a 
        percentage of up-to-date ingestions, by calculating the percentage of ingestionDelay for ingestions against 
        the specific timeframe(by application source, dataset name, zone). An ingestion is up to date if the difference 
        between two ingestions is lower than the ttl. For Example, If there is no IngestionDelay for ingestions over 
        specific timeframe then SLI is 100.")
        .addTarget(target=grafana.sql.target(rawSql=SLISqlQuery, format='table'))
        .addOverridesByFieldName(
        field='SLI Percentage',
        properties=[{id: 'unit', value: 'percent'},
        {
            "id": "thresholds",
            "value": {
            "mode": "absolute",
            "steps": [
                { "color": "light-gray", "value": null },
                { "color": "light-red", "value": 0 },
                { "color": "light-yellow", "value": 80 },
                { "color": "light-green", "value": 80*1.1 }
            ]
            }
        }
        ]
);

local generateIngestionPipelinesByCondition(title, color, code) =
   local sqlQuery = std.format("
        SELECT COUNT(*)
        FROM(
                SELECT distinct job_id, context_id
                FROM [observability].[event]
                WHERE metric_name='processing_exit_code'
                AND event_type='processingfinished'
                AND metric_value=%d
                AND context_id in ('oss.glb.glb.dynamify_sdx_tradescommercexportobject_landing','oss.glb.glb.dynamify_sdx_tradescommercexportobject_history','oss.glb.glb.dynamify_sdx_tradescommercexportobject_standardized', 'oss.glb.glb.dynamify_sdx_getallowances_landing','oss.glb.glb.dynamify_sdx_getallowances_history','oss.glb.glb.dynamify_sdx_getallowances_standardized', 'oss.glb.glb.dynamify_sdx_menudataexportobject_landing','oss.glb.glb.dynamify_sdx_menudataexportobject_history','oss.glb.glb.dynamify_sdx_menudataexportobject_standardized','oss.glb.glb.dynamify_sdx_mealdeal_landing','oss.glb.glb.dynamify_sdx_mealdeal_history','oss.glb.glb.dynamify_sdx_mealdeal_standardized' +'')
                AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
                AND dataset_name IN ($dataset_name)
                AND landing_zone IN ($landing_zone)
                AND project_name IN ($project_name)
            ) AS SubQuery
        ", [code]
    );

    grafana.statPanel.new(title, datasource='Azure SQL Server', colorMode='background')
    .addThresholds([{ value: 0, color: color }])
    .addTarget(target=grafana.sql.target(rawSql=sqlQuery, format='table')
);

local GenerateSuccessRatio =
    local sqlQuery = "
       SELECT
            CASE WHEN COUNT(*) = 0 THEN 100 
            ELSE COUNT(CASE WHEN metric_value != -1 THEN 1 ELSE NULL END) * 100.0 / COUNT(*) 
            END AS ratio
        FROM ( select distinct job_id, context_id, metric_value from[observability].[event]
                  WHERE metric_name= 'processing_exit_code'
                  AND event_type =  'processingfinished'
                   AND context_id in ('oss.glb.glb.dynamify_sdx_tradescommercexportobject_landing','oss.glb.glb.dynamify_sdx_tradescommercexportobject_history','oss.glb.glb.dynamify_sdx_tradescommercexportobject_standardized', 'oss.glb.glb.dynamify_sdx_getallowances_landing','oss.glb.glb.dynamify_sdx_getallowances_history','oss.glb.glb.dynamify_sdx_getallowances_standardized', 'oss.glb.glb.dynamify_sdx_menudataexportobject_landing','oss.glb.glb.dynamify_sdx_menudataexportobject_history','oss.glb.glb.dynamify_sdx_menudataexportobject_standardized','oss.glb.glb.dynamify_sdx_mealdeal_landing','oss.glb.glb.dynamify_sdx_mealdeal_history','oss.glb.glb.dynamify_sdx_mealdeal_standardized'+'')
                  AND context_id IN (${context:sqlstring}+'')
                  AND timestamp >= $__unixEpochFrom()
                  AND timestamp < $__unixEpochTo()
              ) As distinct_records
    ";
        
    grafana.statPanel.new(
    title='Success Ratio Indicator',
    datasource='Azure SQL Server',
    description= "The Pipeline Success Ratio Indicator provides a clear metric to gauge the effectiveness of
    a data ingestion pipeline by comparing successful operations against failures and no new data. "
    ).addTarget(target=grafana.sql.target(rawSql=sqlQuery,format='table'))
    .addOverridesByFieldName(field='ratio',properties=[{id: 'unit', value: 'percent'}]
);

local SLIDynamify = 
    local sqlQuery = "
         WITH
        CombinedValues AS (
            SELECT *
            FROM (VALUES ('oss.glb.glb.dynamify_sdx', 'tradescommercexportobject', 'landing', 'oss.glb.glb.dynamify_sdx_tradescommercexportobject_landing', 86400), ('oss.glb.glb.dynamify_sdx', 'tradescommercexportobject', 'history', 'oss.glb.glb.dynamify_sdx_tradescommercexportobject_history', 86400), ('oss.glb.glb.dynamify_sdx', 'tradescommercexportobject', 'standardized', 'oss.glb.glb.dynamify_sdx_tradescommercexportobject_standardized', 86400), ('oss.glb.glb.dynamify_sdx', 'getallowances', 'landing', 'oss.glb.glb.dynamify_sdx_getallowances_landing', 604800), ('oss.glb.glb.dynamify_sdx', 'getallowances', 'history', 'oss.glb.glb.dynamify_sdx_getallowances_history', 604800), ('oss.glb.glb.dynamify_sdx', 'getallowances', 'standardized', 'oss.glb.glb.dynamify_sdx_getallowances_standardized', 604800), ('oss.glb.glb.dynamify_sdx', 'menudataexportobject', 'landing', 'oss.glb.glb.dynamify_sdx_menudataexportobject_landing', 604800), ('oss.glb.glb.dynamify_sdx', 'menudataexportobject', 'history', 'oss.glb.glb.dynamify_sdx_menudataexportobject_history', 604800), ('oss.glb.glb.dynamify_sdx', 'menudataexportobject', 'standardized', 'oss.glb.glb.dynamify_sdx_menudataexportobject_standardized', 604800),('oss.glb.glb.dynamify_sdx', 'mealdeal', 'landing', 'oss.glb.glb.dynamify_sdx_mealdeal_landing', 604800),('oss.glb.glb.dynamify_sdx', 'mealdeal', 'history', 'oss.glb.glb.dynamify_sdx_mealdeal_history', 604800),('oss.glb.glb.dynamify_sdx', 'mealdeal', 'standardized', 'oss.glb.glb.dynamify_sdx_mealdeal_standardized', 604800) ) AS t (project_name, dataset_name, landing_zone, context_id, ttl)
           WHERE context_id IN (${context:sqlstring}+'')
        ),
        RawEvents AS (
                SELECT
                    [timestamp],
                    context_id,
                    job_id,
                    metric_value
                FROM
                    [observability].[event]
                WHERE
                    metric_name = 'processing_exit_code'
                    AND event_type = 'processingfinished'
                    AND context_id IN (${context:sqlstring}+'')
                    AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
            ),
            DistinctJobs AS (
                SELECT DISTINCT
                    context_id,
                    job_id,
                    metric_value
                FROM
                    RawEvents
            ),
            IngestionSum AS (
                SELECT
                    context_id,
                    SUM(CASE WHEN metric_value = 0 THEN 1 ELSE 0 END) AS Succeeded,
                    SUM(CASE WHEN metric_value = 1 THEN 1 ELSE 0 END) AS No_Data,
                    SUM(CASE WHEN metric_value = -1 THEN 1 ELSE 0 END) AS Failed
                FROM
                    DistinctJobs
                GROUP BY
                    context_id
            ),
            FilteredAndAdded AS (
                SELECT
                    timestamp,
                    context_id,
                    metric_value
                FROM (
                    SELECT
                        timestamp,
                        context_id,
                        metric_value
                    FROM
                        RawEvents
                    WHERE
                        metric_value = 0
    
                    UNION ALL
    
                    SELECT
                    $__unixEpochTo() AS timestamp,  -- Current UTC timestamp as Unix time
                        context_id,
                        0 AS metric_value
                    FROM
                        (SELECT DISTINCT context_id FROM RawEvents WHERE metric_value = 0) AS UniqueContexts
    
                    UNION ALL
    
                    SELECT
                    $__unixEpochFrom() AS timestamp,  -- Current UTC timestamp as Unix time
                        context_id,
                        0 AS metric_value
                    FROM (SELECT DISTINCT context_id FROM RawEvents WHERE metric_value = 0) AS UniqueContexts
                ) AS CombinedFilteredResults
        	),
            EventDifferences AS (
                SELECT
                    context_id,
                    timestamp,
                    metric_value,
                    LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
                    CASE
                        WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                            timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                        ELSE NULL
                    END AS time_difference
                FROM
                    FilteredAndAdded
                WHERE
                    metric_value = 0
            ),
            Slis AS (
                SELECT
                    cv.project_name AS 'Application Source',
                    cv.dataset_name AS 'DatasetName',
                    cv.landing_zone AS 'Zone',
                    cv.ttl AS 'TTL',
                    COALESCE(iso.Succeeded, 0) AS 'Succeeded',
                    COALESCE(iso.No_Data, 0) AS 'No New Data',
                    COALESCE(iso.Failed, 0) AS 'Failed',
                    COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
                    CASE
                        WHEN COALESCE(iso.Succeeded, 0) = 0 THEN 0
                        WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
                        ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / ($__unixEpochTo() - $__unixEpochFrom()))
                    END AS SLI
                FROM
                    CombinedValues AS cv
                LEFT JOIN
                    IngestionSum AS iso
                ON
                    cv.context_id = iso.context_id
                LEFT JOIN
                    EventDifferences AS ed
                ON
                    cv.context_id = ed.context_id
                    AND ed.time_difference > cv.ttl
                GROUP BY
                    cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed
            )
            select AVG(SLI) as 'SLI Percentage',DatasetName as 'Dataset Name' from Slis
            group by DatasetName";

    grafana.barChart.new(
        title='SLI',
        datasource='Azure SQL Server',
        description= "The SLI(Service Level Indicator) is a measurable metric closely monitored by stakeholders to
        evaluate the operational performance and efficiency of a data ingestion pipeline. It is calculated here as a 
        percentage of up-to-date ingestions, by calculating the percentage of ingestionDelay for ingestions against 
        the specific timeframe(by application source, dataset name, zone). An ingestion is up to date if the difference 
        between two ingestions is lower than the ttl. For Example, If there is no IngestionDelay for ingestions over 
        specific timeframe then SLI is 100.")
        .addTarget(target=grafana.sql.target(rawSql=sqlQuery, format='table')
        ).addOption('xTickLabelRotation',0
        ).addOption('xTickLabelMaxLength', 100
        ).addOption('colorByField', 'SLI Percentage'
        ).addOption('showValue','always'
        ).addOption('barWidth',0.9
        ).addOverridesByFieldName(field='SLI Percentage',properties=[{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'light-red', value: null },{ color: 'light-green', value: 80 }]}},{id:'color',value:{mode : 'thresholds'}},{id: 'custom.axisSoftMax', value: 110},{id: 'custom.text',valueSize: 15}]
);

local SLIForDynamify =
    local sqlQuery = " 
        WITH
            CombinedValues AS (
                SELECT *
                FROM (VALUES ('oss.glb.glb.dynamify_sdx', 'tradescommercexportobject', 'landing', 'oss.glb.glb.dynamify_sdx_tradescommercexportobject_landing', 86400), ('oss.glb.glb.dynamify_sdx', 'tradescommercexportobject', 'history', 'oss.glb.glb.dynamify_sdx_tradescommercexportobject_history', 86400), ('oss.glb.glb.dynamify_sdx', 'tradescommercexportobject', 'standardized', 'oss.glb.glb.dynamify_sdx_tradescommercexportobject_standardized', 86400), ('oss.glb.glb.dynamify_sdx', 'getallowances', 'landing', 'oss.glb.glb.dynamify_sdx_getallowances_landing', 604800), ('oss.glb.glb.dynamify_sdx', 'getallowances', 'history', 'oss.glb.glb.dynamify_sdx_getallowances_history', 604800), ('oss.glb.glb.dynamify_sdx', 'getallowances', 'standardized', 'oss.glb.glb.dynamify_sdx_getallowances_standardized', 604800), ('oss.glb.glb.dynamify_sdx', 'menudataexportobject', 'landing', 'oss.glb.glb.dynamify_sdx_menudataexportobject_landing', 604800), ('oss.glb.glb.dynamify_sdx', 'menudataexportobject', 'history', 'oss.glb.glb.dynamify_sdx_menudataexportobject_history', 604800), ('oss.glb.glb.dynamify_sdx', 'menudataexportobject', 'standardized', 'oss.glb.glb.dynamify_sdx_menudataexportobject_standardized', 604800),('oss.glb.glb.dynamify_sdx', 'mealdeal', 'landing', 'oss.glb.glb.dynamify_sdx_mealdeal_landing', 604800),('oss.glb.glb.dynamify_sdx', 'mealdeal', 'history', 'oss.glb.glb.dynamify_sdx_mealdeal_history', 604800),('oss.glb.glb.dynamify_sdx', 'mealdeal', 'standardized', 'oss.glb.glb.dynamify_sdx_mealdeal_standardized', 604800) ) AS t (project_name, dataset_name, landing_zone, context_id, ttl)
                where context_id IN ('oss.glb.glb.dynamify_sdx_tradescommercexportobject_landing','oss.glb.glb.dynamify_sdx_tradescommercexportobject_history','oss.glb.glb.dynamify_sdx_tradescommercexportobject_standardized', 'oss.glb.glb.dynamify_sdx_getallowances_landing','oss.glb.glb.dynamify_sdx_getallowances_history','oss.glb.glb.dynamify_sdx_getallowances_standardized', 'oss.glb.glb.dynamify_sdx_menudataexportobject_landing','oss.glb.glb.dynamify_sdx_menudataexportobject_history','oss.glb.glb.dynamify_sdx_menudataexportobject_standardized','oss.glb.glb.dynamify_sdx_mealdeal_landing','oss.glb.glb.dynamify_sdx_mealdeal_history','oss.glb.glb.dynamify_sdx_mealdeal_standardized' +'')
            ),

            RawEventsM AS (
                SELECT
                    [timestamp],
                    DateName(mm,DATEADD(SECOND,timestamp,'1970-01-01')) as Month_Name,
                    context_id,
                    job_id,
                    metric_value
                FROM
                    [observability].[event]
                WHERE
                    metric_name = 'processing_exit_code'
                    AND event_type = 'processingfinished'
                    AND context_id IN ('oss.glb.glb.dynamify_sdx_tradescommercexportobject_landing','oss.glb.glb.dynamify_sdx_tradescommercexportobject_history','oss.glb.glb.dynamify_sdx_tradescommercexportobject_standardized', 'oss.glb.glb.dynamify_sdx_getallowances_landing','oss.glb.glb.dynamify_sdx_getallowances_history','oss.glb.glb.dynamify_sdx_getallowances_standardized', 'oss.glb.glb.dynamify_sdx_menudataexportobject_landing','oss.glb.glb.dynamify_sdx_menudataexportobject_history','oss.glb.glb.dynamify_sdx_menudataexportobject_standardized','oss.glb.glb.dynamify_sdx_mealdeal_landing','oss.glb.glb.dynamify_sdx_mealdeal_history','oss.glb.glb.dynamify_sdx_mealdeal_standardized' +'')
                    AND [timestamp] >=  DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(),-1)))) AND [timestamp] < DATEDIFF(second,'1970-01-01',convert(date,GETDATE()))
            ),
            DistinctJobsM AS (
                SELECT DISTINCT
                    context_id,
                    Month_Name,
                    job_id,
                    metric_value
                FROM
                    RawEventsM
            ),
            IngestionSumM AS (
                SELECT
                    context_id,Month_Name,
                    SUM(CASE WHEN metric_value = 0 THEN 1 ELSE 0 END) AS Succeeded,
                    SUM(CASE WHEN metric_value = 1 THEN 1 ELSE 0 END) AS No_Data,
                    SUM(CASE WHEN metric_value = -1 THEN 1 ELSE 0 END) AS Failed
                FROM
                    DistinctJobsM
                GROUP BY
                    context_id,Month_Name
            ),
            FilteredAndAddedM AS (
                SELECT
                    timestamp,
                    context_id,
                    Month_Name,
                    metric_value
                FROM
                (
                    SELECT
                        timestamp,
                        context_id,
                        Month_Name,
                        metric_value
                    FROM
                        RawEventsM
                    WHERE
                        metric_value = 0 and Month_Name=DateName(mm,GETDATE())

                    UNION ALL

                    SELECT
                        DATEDIFF(second,'1970-01-01',convert(date,GETDATE())) AS timestamp,  -- Current UTC timestamp as Unix time
                        context_id,Month_Name,
                        0 AS metric_value
                    FROM
                        (SELECT DISTINCT context_id,Month_Name FROM RawEventsM WHERE metric_value = 0 and Month_Name=DateName(mm,GETDATE())) AS UniqueContexts

                    UNION ALL

                    SELECT
                        DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(),-1)))) AS timestamp,  -- Current UTC timestamp as Unix time
                        context_id,Month_Name,
                        0 AS metric_value
                    FROM
                        (SELECT DISTINCT context_id,Month_Name FROM RawEventsM WHERE metric_value = 0 and Month_Name=DateName(mm,GETDATE())) AS UniqueContexts
                ) AS CombinedFilteredResults
            ),
            EventDifferencesM AS (
                SELECT
                    context_id,
                    timestamp,
                    Month_Name,
                    metric_value,
                    LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
                    CASE
                        WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                            timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                        ELSE NULL
                    END AS time_difference
                FROM
                    FilteredAndAddedM  
            ),
            SLIM AS (
                    SELECT
                        cv.project_name AS 'Application Source',
                        cv.dataset_name AS 'DatasetName',
                        cv.landing_zone AS 'Zone',
                        cv.ttl AS 'TTL',
                        COALESCE(iso.Succeeded, 0) AS 'Succeeded',
                        COALESCE(iso.No_Data, 0) AS 'No New Data',
                        COALESCE(iso.Failed, 0) AS 'Failed',
                        COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
                        CASE
                            WHEN COALESCE(iso.Succeeded, 0) = 0 THEN 0
                            WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
                            ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / (DATEDIFF(second,'1970-01-01',convert(date,GETDATE()))-DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(),-1))))))
                        END AS SLIM
                        
                    FROM
                        CombinedValues AS cv
                    LEFT JOIN
                        IngestionSumM AS iso
                    ON
                        cv.context_id = iso.context_id
                    LEFT JOIN
                        EventDifferencesM AS ed
                    ON
                        cv.context_id = ed.context_id
                        AND ed.time_difference > cv.ttl
                    GROUP BY
                        cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed
            ),

            RawEventsM1 AS (
                SELECT
                    [timestamp],
                    DateName(mm,DATEADD(SECOND,timestamp,'1970-01-01')) as Month_Name,
                    context_id,
                    job_id,
                    metric_value
                FROM
                    [observability].[event]
                WHERE
                    metric_name = 'processing_exit_code'
                    AND event_type = 'processingfinished'
                    AND context_id IN ('oss.glb.glb.dynamify_sdx_tradescommercexportobject_landing','oss.glb.glb.dynamify_sdx_tradescommercexportobject_history','oss.glb.glb.dynamify_sdx_tradescommercexportobject_standardized', 'oss.glb.glb.dynamify_sdx_getallowances_landing','oss.glb.glb.dynamify_sdx_getallowances_history','oss.glb.glb.dynamify_sdx_getallowances_standardized', 'oss.glb.glb.dynamify_sdx_menudataexportobject_landing','oss.glb.glb.dynamify_sdx_menudataexportobject_history','oss.glb.glb.dynamify_sdx_menudataexportobject_standardized','oss.glb.glb.dynamify_sdx_mealdeal_landing','oss.glb.glb.dynamify_sdx_mealdeal_history','oss.glb.glb.dynamify_sdx_mealdeal_standardized' +'')
                    AND [timestamp] <  DATEDIFF(second,'1970-01-01',DATEADD(SECOND, -1, DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(), -1))))) AND [timestamp] >= DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, EOMONTH(GETDATE(), -2)))
            ),
            DistinctJobsM1 AS (
                SELECT Distinct
                    context_id,
                    Month_Name,
                    job_id,
                    metric_value
                FROM
                    RawEventsM1
            ),
            IngestionSumM1 AS (
                SELECT
                    context_id,Month_Name,
                    SUM(CASE WHEN metric_value = 0 THEN 1 ELSE 0 END) AS Succeeded,
                    SUM(CASE WHEN metric_value = 1 THEN 1 ELSE 0 END) AS No_Data,
                    SUM(CASE WHEN metric_value = -1 THEN 1 ELSE 0 END) AS Failed
                FROM
                    DistinctJobsM1
                GROUP BY
                    context_id,Month_Name
            ),
            FilteredAndAddedM1 AS (
                SELECT
                    timestamp,
                    context_id,
                    Month_Name,
                    metric_value
                FROM
                (
                    SELECT
                        timestamp,
                        context_id,
                        Month_Name,
                        metric_value
                    FROM
                        RawEventsM1
                    WHERE
                        metric_value = 0 and Month_Name=DateName(mm,DATEADD(Month,-1,GETDATE()))

                    UNION ALL

                    SELECT
                    DATEDIFF(second,'1970-01-01',DATEADD(SECOND, -1, DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(), -1))))) AS timestamp,  -- Current UTC timestamp as Unix time
                        context_id,Month_Name,
                        0 AS metric_value
                    FROM
                        (SELECT DISTINCT context_id,Month_Name FROM RawEventsM1 WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(Month,-1,GETDATE()))) AS UniqueContexts

                    UNION ALL

                    SELECT
                        DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, EOMONTH(GETDATE(), -2))) AS timestamp,  -- Current UTC timestamp as Unix time
                        context_id,Month_Name,
                        0 AS metric_value
                    FROM
                        (SELECT DISTINCT context_id,Month_Name FROM RawEventsM1 WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(Month,-1,GETDATE()))) AS UniqueContexts
                ) AS CombinedFilteredResults
            ),
            EventDifferencesM1 AS (
                SELECT
                    context_id,
                    timestamp,
                    Month_Name,
                    metric_value,
                    LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
                    CASE
                        WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                            timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                        ELSE NULL
                    END AS time_difference
                FROM
                    FilteredAndAddedM1  
            ),
            SLIM1 AS (
                    SELECT
                        cv.project_name AS 'Application Source',
                        cv.dataset_name AS 'DatasetName',
                        cv.landing_zone AS 'Zone',
                        cv.ttl AS 'TTL',
                        COALESCE(iso.Succeeded, 0) AS 'Succeeded',
                        COALESCE(iso.No_Data, 0) AS 'No New Data',
                        COALESCE(iso.Failed, 0) AS 'Failed',
                        COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
                        CASE
                            WHEN COALESCE(iso.Succeeded, 0) = 0 THEN 0
                            WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
                            ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / (DATEDIFF(second,'1970-01-01',DATEADD(SECOND, -1, DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(), -1)))))-DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, EOMONTH(GETDATE(), -2)))))
                        END AS SLIM1
                        
                    FROM
                        CombinedValues AS cv
                    LEFT JOIN
                        IngestionSumM1 AS iso
                    ON
                        cv.context_id = iso.context_id
                    LEFT JOIN
                        EventDifferencesM1 AS ed
                    ON
                        cv.context_id = ed.context_id
                        AND ed.time_difference > cv.ttl
                    GROUP BY
                        cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed
            ),

            RawEventsM2 AS (
                SELECT
                    [timestamp],
                    DateName(mm,DATEADD(SECOND,timestamp,'1970-01-01')) as Month_Name,
                    context_id,
                    job_id,
                    metric_value
                FROM
                    [observability].[event]
                WHERE
                    metric_name = 'processing_exit_code'
                    AND event_type = 'processingfinished'
                    AND context_id IN ('oss.glb.glb.dynamify_sdx_tradescommercexportobject_landing','oss.glb.glb.dynamify_sdx_tradescommercexportobject_history','oss.glb.glb.dynamify_sdx_tradescommercexportobject_standardized', 'oss.glb.glb.dynamify_sdx_getallowances_landing','oss.glb.glb.dynamify_sdx_getallowances_history','oss.glb.glb.dynamify_sdx_getallowances_standardized', 'oss.glb.glb.dynamify_sdx_menudataexportobject_landing','oss.glb.glb.dynamify_sdx_menudataexportobject_history','oss.glb.glb.dynamify_sdx_menudataexportobject_standardized','oss.glb.glb.dynamify_sdx_mealdeal_landing','oss.glb.glb.dynamify_sdx_mealdeal_history','oss.glb.glb.dynamify_sdx_mealdeal_standardized' +'')
                    AND [timestamp] >= DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, EOMONTH(GETDATE(), -3))) AND [timestamp] < DATEDIFF(second,'1970-01-01',DATEADD(SECOND, -1, DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(), -2)))))
            ),
            DistinctJobsM2 AS (
                SELECT DISTINCT
                    context_id,
                    Month_Name,
                    job_id,
                    metric_value
                FROM
                    RawEventsM2
            ),
            IngestionSumM2 AS (
                SELECT
                    context_id,Month_Name,
                    SUM(CASE WHEN metric_value = 0 THEN 1 ELSE 0 END) AS Succeeded,
                    SUM(CASE WHEN metric_value = 1 THEN 1 ELSE 0 END) AS No_Data,
                    SUM(CASE WHEN metric_value = -1 THEN 1 ELSE 0 END) AS Failed
                FROM
                    DistinctJobsM2
                GROUP BY
                    context_id,Month_Name
            ),
            FilteredAndAddedM2 AS (
                SELECT
                    timestamp,
                    context_id,
                    Month_Name,
                    metric_value
                FROM
                (
                    SELECT
                        timestamp,
                        context_id,
                        Month_Name,
                        metric_value
                    FROM
                        RawEventsM2
                    WHERE
                        metric_value = 0 and Month_Name=DateName(mm,DATEADD(Month,-2,GETDATE()))

                    UNION ALL

                    SELECT
                        DATEDIFF(second,'1970-01-01',DATEADD(SECOND, -1, DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(), -2))))) AS timestamp,  -- Current UTC timestamp as Unix time
                        context_id,Month_Name,
                        0 AS metric_value
                    FROM
                        (SELECT DISTINCT context_id,Month_Name FROM RawEventsM2 WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(Month,-2,GETDATE()))) AS UniqueContexts

                    UNION ALL

                    SELECT
                        DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, EOMONTH(GETDATE(), -3))) AS timestamp,  -- Current UTC timestamp as Unix time
                        context_id,Month_Name,
                        0 AS metric_value
                    FROM
                        (SELECT DISTINCT context_id,Month_Name FROM RawEventsM2 WHERE metric_value = 0 and Month_Name=DateName(mm,DATEADD(Month,-2,GETDATE()))) AS UniqueContexts
                ) AS CombinedFilteredResults
            ),
            EventDifferencesM2 AS (
                SELECT
                    context_id,
                    timestamp,
                    Month_Name,
                    metric_value,
                    LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
                    CASE
                        WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                            timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                        ELSE NULL
                    END AS time_difference
                FROM
                    FilteredAndAddedM2  
            ),
            SLIM2 AS (
                    SELECT
                        cv.project_name AS 'Application Source',
                        cv.dataset_name AS 'DatasetName',
                        cv.landing_zone AS 'Zone',
                        cv.ttl AS 'TTL',
                        COALESCE(iso.Succeeded, 0) AS 'Succeeded',
                        COALESCE(iso.No_Data, 0) AS 'No New Data',
                        COALESCE(iso.Failed, 0) AS 'Failed',
                        COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
                        CASE
                            WHEN COALESCE(iso.Succeeded, 0) = 0 THEN 0
                            WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
                        ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / (DATEDIFF(second,'1970-01-01',DATEADD(SECOND, -1, DATEADD(DAY, 1, convert(DATETIME,EOMONTH(GETDATE(), -2)))))-DATEDIFF(second,'1970-01-01',DATEADD(DAY, 1, EOMONTH(GETDATE(), -3)))))
                        END AS SLIM2
                        
                    FROM
                        CombinedValues AS cv
                    LEFT JOIN
                        IngestionSumM2 AS iso
                    ON
                        cv.context_id = iso.context_id
                    LEFT JOIN
                        EventDifferencesM2 AS ed
                    ON
                        cv.context_id = ed.context_id
                        AND ed.time_difference > cv.ttl
                    GROUP BY
                        cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed
            ),

            sliValues as (
                    SELECT s.DatasetName AS Dataset_Name, '80%' AS SLO, Avg(SLIM) AS SLI_CurrentMonth, Avg(SLIM1) AS SLI_PreviousMonth, Avg(SLIM2) AS SLI_LastBeforeMonth
                    FROM SLIM AS s
                        LEFT JOIN SLIM1 AS s1 ON s.DatasetName=s1.DatasetName
                        LEFT JOIN SLIM2 AS s2 ON s.DatasetName=s2.DatasetName
                    where s.DatasetName in ($dataset_name) 
                    GROUP BY s.DatasetName
                )
            SELECT * from sliValues  
    ";  
    grafana.tablePanel.new(
        title='SLI for Dynamify - Table View',
        datasource='Azure SQL Server',
        description="SLI Of all data sets of Dynamify_SDX for last 3 months"
        ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
        ).addOverridesByFieldName(field='SLI_CurrentMonth',properties=[ { 'id': 'unit', 'value': 'percent' }, { 'id': 'custom.cellOptions', 'value': { 'type': 'color-text' } }, { 'id': 'thresholds', 'value': { 'mode': 'absolute', 'steps': [ { 'color': 'red' }, { 'color': 'green', 'value': 80 } ] } } ]
        ).addOverridesByFieldName(field='SLI_PreviousMonth',properties=[ { 'id': 'unit', 'value': 'percent' }, { 'id': 'custom.cellOptions', 'value': { 'type': 'color-text' } }, { 'id': 'thresholds', 'value': { 'mode': 'absolute', 'steps': [ { 'color': 'red' }, { 'color': 'green', 'value': 80 } ] } } ]
        ).addOverridesByFieldName(field='SLI_LastBeforeMonth',properties=[ { 'id': 'unit', 'value': 'percent' }, { 'id': 'custom.cellOptions', 'value': { 'type': 'color-text' } }, { 'id': 'thresholds', 'value': { 'mode': 'absolute', 'steps': [ { 'color': 'red' }, { 'color': 'green', 'value': 80 } ] } } ]
);

local Sourcetotargetmetric = 
    local sqlQuery = "      
    with 
        cte as (
            SELECT [project_name],[dataset_name],[record_date],max([record_count]) as 'Bronze Standardized Count'
            FROM [observability].[redfinedrecordcount]
            group by [project_name],[dataset_name],[record_date]
        ),

        cte2 as (
            select [project_name],[dataset_name],[record_date],max([total_count]) as 'Source Data Count' 
            from [observability].[dynamifysourcecount]
            group by [project_name],[dataset_name],[record_date]
        )
            Select s.[project_name] as 'Application Source',
                s.[dataset_name] as 'Dataset Name',
                'Source and Bronze Standardized records perfect match' as Threshold,
                Format(s.record_date, 'yyyy-MM-dd') as 'Transaction Date',
                [Source Data Count],
                [Bronze Standardized Count],
                [Source Data Count]-[Bronze Standardized Count] as 'Volume Difference'
                from cte as t,cte2 as s
                where s.record_date=t.record_date and s.dataset_name = t.dataset_name
                and datediff(second, '1970-01-01 00:00:00', s.record_date) BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                and s.dataset_name in ($dataset_name)
                order by s.[record_date] desc
   ";
   table.new(
    title = 'Source vs Target Volume Difference',
    datasource = 'Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Dataset Name',properties=[{id: 'custom.width', 'value': 210 }]
    ).addOverridesByFieldName(field='Application Source',properties=[{id: 'custom.width', 'value': 200}]
    ).addOverridesByFieldName(field='Threshold',properties=[{id: 'custom.width', 'value': 392}]
    ).addOverridesByFieldName(field='Volume Difference',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'red',value: null},{color: 'green',value: 0},{color: 'red',value: 1},{color: 'red',value: -1}]}}]
);

local DatasetVolumeTradescommercexportobject = 
    local sqlQuery = " 
    with 
        latestrecords as (
            select * from [observability].[redfinedrecordcount] as r where project_name = 'oss.glb.glb.dynamify_sdx'
            and job_execution_timestamp = (select max(job_execution_timestamp) from [observability].[redfinedrecordcount] 
            where project_name = r.project_name and record_date = r.record_date)
        )
        select lr.project_name as 'Application Source', lr.dataset_name as 'Dataset Name', Format(lr.record_date, 'yyyy-MM-dd') as 'Transaction Date', '5% variance over the last 4 weeks on same days' As 'Threshold',
            lr.record_count as 'Transaction Count',
            (Coalesce((select record_count from latestrecords where record_date = dateadd(day, -7, lr.record_date)), 0) +
            Coalesce((select record_count from latestrecords where record_date = dateadd(day, -14, lr.record_date)), 0) +
            Coalesce((select record_count from latestrecords where record_date = dateadd(day, -21, lr.record_date)), 0) +
            Coalesce((select record_count from latestrecords where record_date = dateadd(day, -28, lr.record_date)), 0)
            ) / 4.0 as 'Average Row Count',
            case
            when ((Coalesce((select record_count from latestrecords where record_date = dateadd(day, -7, lr.record_date)), 0) +
                Coalesce((select record_count from latestrecords where record_date = dateadd(day, -14, lr.record_date)), 0) +
                Coalesce((select record_count from latestrecords where record_date = dateadd(day, -21, lr.record_date)), 0) +
                Coalesce((select record_count from latestrecords where record_date = dateadd(day, -28, lr.record_date)), 0)
                ) / 4.0) = 0 then NULL
            else (lr.record_count -
                (Coalesce((select record_count from latestrecords where record_date = dateadd(day, -7, lr.record_date)), 0) +
                Coalesce((select record_count from latestrecords where record_date = dateadd(day, -14, lr.record_date)), 0) +
                Coalesce((select record_count from latestrecords where record_date = dateadd(day, -21, lr.record_date)), 0) +
                Coalesce((select record_count from latestrecords where record_date = dateadd(day, -28, lr.record_date)), 0)
                ) / 4.0
                ) / ((Coalesce((select record_count from latestrecords where record_date = dateadd(day, -7, lr.record_date)), 0) +
                Coalesce((select record_count from latestrecords where record_date = dateadd(day, -14, lr.record_date)), 0) +
                Coalesce((select record_count from latestrecords where record_date = dateadd(day, -21, lr.record_date)), 0) +
                Coalesce((select record_count from latestrecords where record_date = dateadd(day, -28, lr.record_date)), 0)
                ) / 4.0
            ) * 100
            end as 'Volume Check',
            Coalesce((select record_count from latestrecords where record_date = dateadd(day, -7, lr.record_date)), 0) as 'Date-7 Count',
            Coalesce((select record_count from latestrecords where record_date = dateadd(day, -14, lr.record_date)), 0) as 'Date-14 Count',
            Coalesce((select record_count from latestrecords where record_date = dateadd(day, -21, lr.record_date)), 0) as 'Date-21 Count',
            Coalesce((select record_count from latestrecords where record_date = dateadd(day, -28, lr.record_date)), 0) as 'Date-28 Count'
            from latestrecords lr
            where datediff(second, '1970-01-01 00:00:00', record_date) BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
            ORDER BY  record_date desc
   ";
   table.new(
    title = 'Data Volume [Tradescommercexportobject]- Tabular View',
    datasource = 'Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Threshold',properties=[{id: 'custom.width',value: 245}]
    ).addOverridesByFieldName(field='Volume Check',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'red'}]}},{id: 'mappings',value: [{options: {'from':-5, 'result': {color: 'green','index': 0}, 'to': 5}, type: 'range'}]}, {id: 'unit', value: 'percent'}]
    ).addOverridesByFieldName(field='Dataset Name',properties=[{id: 'custom.width', 'value': 212 }]
    ).addOverridesByFieldName(field='Application Source',properties=[{ id: 'custom.width', 'value': 188 }]
    ).addOverridesByFieldName(field='Transaction Date',properties=[{ id: 'custom.width', 'value': 193 }]
    ).addOverridesByFieldName(field='ingestedtimestamp',properties=[{ id: 'custom.width', 'value': 187 }]
);

local DatasetVolumeTradescommercexportobjectYearToDateVolumeCheck = 
    local sqlQuery = " 
    with 
        latestrecords as (
            select * from [observability].[redfinedrecordcount] as r where project_name = 'oss.glb.glb.dynamify_sdx'
            and job_execution_timestamp = (select max(job_execution_timestamp) from [observability].[redfinedrecordcount] 
            where project_name = r.project_name and record_date = r.record_date)
        ),
        final as (
            select lr.project_name as 'Application Source', lr.dataset_name as 'Dataset Name', Format(lr.record_date, 'yyyy-MM-dd') as 'Transaction Date',
                case 
                when (Year(lr.record_date))%4 != 0 then DATEADD(day,1,dateadd(year, -1, lr.record_date))
                when (Year(lr.record_date))%4 = 0 then DATEADD(day,2,dateadd(year, -1, lr.record_date))
                end as 'last year',
                /*DATENAME(dw,lr.record_date) as 'Transaction-day',*/
                Coalesce((select record_count from latestrecords where record_date = dateadd(day, -1, lr.record_date)), 0) as 'D-1 Count',
                case 
                when (Year(lr.record_date))%4 != 0 then Coalesce((select record_count from latestrecords where record_date = DATEADD(day,1,dateadd(year, -1, lr.record_date))), 0)
                when (Year(lr.record_date))%4 = 0 then Coalesce((select record_count from latestrecords where record_date = DATEADD(day,2,dateadd(year, -1, lr.record_date))), 0)
                end as 'Date-year count',
                case 
                when (Year(lr.record_date))%4 != 0 then (DATEADD(day,1,dateadd(year, -1, lr.record_date)))
                when (Year(lr.record_date))%4 = 0 then DATEADD(day,2,dateadd(year, -1, lr.record_date))
                end as 'Date-year',
                '20% variance over the last year on same days' As 'Threshold',
                lr.record_count as 'Transaction Count'   
            from latestrecords lr
        )
        select [Application Source],[Dataset Name],[Transaction Date],Threshold,[Transaction Count],
        case when [D-1 Count]-[Date-year count] = 0 or [Date-year count] = 0 then NULL
        else ((cast([Transaction Count] as float)-[Date-year count])/[Date-year count])*100 end as 'Volume Check',
        [Date-year count] as 'Last Year Count'
        from final
        where datediff(second, '1970-01-01 00:00:00',[Transaction Date]) BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
        order by [Transaction Date] desc
    ";
   table.new(
    title = 'Day-Year Volume Check [Tradescommercexportobject]- Tabular View',
    datasource = 'Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Threshold',properties=[{id: 'custom.width',value: 345}]
    ).addOverridesByFieldName(field='Volume Check',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'red'}]}},{id: 'mappings',value: [{options: {'from':-20, 'result': {color: 'green','index': 0}, 'to': 20}, type: 'range'}]}, {id: 'unit', value: 'percent'}]
    ).addOverridesByFieldName(field='Dataset Name',properties=[{id: 'custom.width', 'value': 212 }]
    ).addOverridesByFieldName(field='Application Source',properties=[{ id: 'custom.width', 'value': 188 }]
    ).addOverridesByFieldName(field='Transaction Date',properties=[{ id: 'custom.width', 'value': 193 }]
);

local DatasetVolumeTradescommercexportobjectDate7VolumeCheck = 
    local sqlQuery = " 
    with 
        latestrecords as (
            select * from [observability].[redfinedrecordcount] as r where project_name = 'oss.glb.glb.dynamify_sdx'
            and job_execution_timestamp = (select max(job_execution_timestamp) from [observability].[redfinedrecordcount] 
            where project_name = r.project_name and record_date = r.record_date)
        )
        select lr.project_name as 'Application Source', lr.dataset_name as 'Dataset Name', Format(lr.record_date, 'yyyy-MM-dd') as 'Transaction Date', '10% variance over the last 7 days on same days' As 'Threshold',
            lr.record_count as 'Transaction Count',
            case
            when Coalesce((select record_count from latestrecords where record_date = dateadd(day, -7, lr.record_date)), 0) = 0 then NULL
            else (lr.record_count - Coalesce((select record_count from latestrecords where record_date = dateadd(day, -7, lr.record_date)),0)) * 100.0/Coalesce((select record_count from latestrecords where record_date = dateadd(day, -7, lr.record_date)), 0)
            end as 'Volume Check',
            Coalesce((select record_count from latestrecords where record_date = dateadd(day, -7, lr.record_date)), 0) as 'Date-7 Count'
        from latestrecords lr
        where datediff(second, '1970-01-01 00:00:00', record_date) BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
        ORDER BY  record_date desc
    ";
   table.new(
    title = 'Day-7 Volume Check [Tradescommercexportobject]- Tabular View',
    datasource = 'Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Threshold',properties=[{id: 'custom.width',value: 345}]
    ).addOverridesByFieldName(field='Volume Check',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'red'}]}},{id: 'mappings',value: [{options: {'from':-10, 'result': {color: 'green','index': 0}, 'to': 10}, type: 'range'}]}, {id: 'unit', value: 'percent'}]
    ).addOverridesByFieldName(field='Dataset Name',properties=[{id: 'custom.width', 'value': 212 }]
    ).addOverridesByFieldName(field='Application Source',properties=[{ id: 'custom.width', 'value': 188 }]
    ).addOverridesByFieldName(field='Transaction Date',properties=[{ id: 'custom.width', 'value': 193 }]
);

local DatasetVolumeMenudataexportobject = 
    local sqlQuery = " 
    select distinct project_name as 'Application Source',
		 dataset_name as 'Dataset Name',
		 format(DATEADD(SECOND, timestamp, '1970-01-01'), 'yyyy-MM-dd') as 'Transaction Date' , 
		 'Weekly data volume > 4000' as 'Threshold',
		metric_value as 'Transaction count'
	from [observability].[event] as r 
	where project_name = 'oss.glb.glb.dynamify_sdx' 
		and dataset_name = 'menudataexportobject' 
		and landing_zone = 'Standardized' 
		and metric_name = 'rows_count' 
		and event_type = 'processingfinished' 
        and timestamp = (select max(timestamp) from [observability].[event] 
        where project_name = r.project_name and timestamp = r.timestamp)
	    and timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
		order by FORMAT(DATEADD(SECOND, timestamp, '1970-01-01'), 'yyyy-MM-dd') desc
   ";
   table.new(
    title = 'Data Volume [Menudataexportobject] - Tabular View',
    datasource = 'Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Threshold',properties=[{id: 'custom.width',value: 245}]
    ).addOverridesByFieldName(field='Transaction count',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'green'}]}},{id: 'mappings',value: [{options: {'from':0, 'result': {color: 'red','index': 0}, 'to': 3999}, type: 'range'}]}]
    ).addOverridesByFieldName(field='Dataset Name',properties=[{id: 'custom.width', 'value': 212 }]
    ).addOverridesByFieldName(field='Application Source',properties=[{ id: 'custom.width', 'value': 188 }]
    ).addOverridesByFieldName(field='Transaction Date',properties=[{ id: 'custom.width', 'value': 193 }]
);
local DatasetVolumeGetAllowances = 
    local sqlQuery = " 
    select distinct project_name as 'Application Source',
		 dataset_name as 'Dataset Name',
		 format(DATEADD(SECOND, timestamp, '1970-01-01'), 'yyyy-MM-dd') as 'Transaction Date' , 
		 'Weekly data volume > 2000' as 'Threshold',
		metric_value as 'Transaction count'
	from [observability].[event] as r 
	where project_name = 'oss.glb.glb.dynamify_sdx' 
		and dataset_name = 'getallowances' 
		and landing_zone = 'Standardized' 
		and metric_name = 'rows_count' 
		and event_type = 'processingfinished' 
        and timestamp = (select max(timestamp) from [observability].[event] 
        where project_name = r.project_name and timestamp = r.timestamp)
	    and timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
		order by FORMAT(DATEADD(SECOND, timestamp, '1970-01-01'), 'yyyy-MM-dd') desc
   ";
   table.new(
    title = 'Data Volume [Getallowances] - Tabular View',
    datasource = 'Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Threshold',properties=[{id: 'custom.width',value: 245}]
    ).addOverridesByFieldName(field='Transaction count',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'green'}]}},{id: 'mappings',value: [{options: {'from':0, 'result': {color: 'red','index': 0}, 'to': 1999}, type: 'range'}]}]
    ).addOverridesByFieldName(field='Dataset Name',properties=[{id: 'custom.width', 'value': 212 }]
    ).addOverridesByFieldName(field='Application Source',properties=[{ id: 'custom.width', 'value': 188 }]
    ).addOverridesByFieldName(field='Transaction Date',properties=[{ id: 'custom.width', 'value': 193 }]
);
local DatasetVolumeMealDeal = 
    local sqlQuery = " 
    select distinct project_name as 'Application Source',
		 dataset_name as 'Dataset Name',
		 format(DATEADD(SECOND, timestamp, '1970-01-01'), 'yyyy-MM-dd') as 'Transaction Date' , 
		 'Weekly data volume > 1500' as 'Threshold',
		metric_value as 'Transaction count'
	from [observability].[event] as r 
	where project_name = 'oss.glb.glb.dynamify_sdx' 
		and dataset_name = 'mealdeal' 
		and landing_zone = 'Standardized' 
		and metric_name = 'rows_count' 
		and event_type = 'processingfinished' 
        and timestamp = (select max(timestamp) from [observability].[event] 
        where project_name = r.project_name and timestamp = r.timestamp)
	    and timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
		order by FORMAT(DATEADD(SECOND, timestamp, '1970-01-01'), 'yyyy-MM-dd') desc
   ";
   table.new(
    title = 'Data Volume [Mealdeal] - Tabular View',
    datasource = 'Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Threshold',properties=[{id: 'custom.width',value: 245}]
    ).addOverridesByFieldName(field='Transaction count',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'green'}]}},{id: 'mappings',value: [{options: {'from':0, 'result': {color: 'red','index': 0}, 'to': 1499}, type: 'range'}]}]
    ).addOverridesByFieldName(field='Dataset Name',properties=[{id: 'custom.width', 'value': 212 }]
    ).addOverridesByFieldName(field='Application Source',properties=[{ id: 'custom.width', 'value': 188 }]
    ).addOverridesByFieldName(field='Transaction Date',properties=[{ id: 'custom.width', 'value': 193 }]
);

local DatasetIngestionHistory = 
    local sqlQuery = " 
    WITH 
        FilteredEvents AS (
            SELECT
                job_id,
                context_id,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                timestamp,
                metric_name,
                metric_value
            FROM
                [observability].[event]
            WHERE
                context_id IN (${context:sqlstring}+'')
                AND dataset_name in ($dataset_name)
                AND landing_zone IN ($landing_zone)
                AND project_name in ($project_name)
                AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                AND metric_name IN ('processing_started_date', 'processing_finished_date', 'processing_exit_code', 'rows_count', 'content_latest_date')
        ),
        MergedEvents AS (
            SELECT
                job_id,
                context_id,
                timestamp,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                [processing_started_date] AS processing_started_date_value,
                [processing_finished_date] AS processing_finished_date_value,
                [processing_exit_code] AS processing_exit_code_value,
                [content_latest_date] AS content_latest_date,
                [rows_count] AS rows_count_value
            FROM
                FilteredEvents
            PIVOT (
                MAX(metric_value)
                FOR metric_name IN ([processing_started_date], [processing_finished_date], [processing_exit_code], [rows_count], [content_latest_date])
            ) AS PivotTable
        ),
        Finalevents as(
            SELECT
                MAX(project_name) AS 'Application Source',
                MAX(dataset_name) AS 'Dataset',
                MAX(landing_zone) AS 'Zone',
                MAX(
                    CASE subscription_id
                    WHEN '6b4a5b3f-1015-42da-a46a-2890a5abed30' THEN 'IFM CORE PROD'
                    WHEN '2698ca5b-bf81-43fb-8fe2-f0e21bf068e5' THEN 'IFM CORE UAT/TEST'
                    WHEN '746ac5b9-70eb-4c76-bdf4-0664bfdff2ea' THEN 'IFM CORE DEV'
                    WHEN 'cf25f2a1-4d40-45af-bb81-87ec46112b3e' THEN 'SDX STA/PRD'
                    WHEN 'c0978b9d-b809-45f4-aa76-391ceb2cfdba' THEN 'SDX DEV/TEST'
                    WHEN '8eaa3d95-3cd2-49d8-b44a-7ea47a6fb58b' THEN 'SDX SILVER'
                    WHEN 'daf86ec1-725c-493f-bf09-a1f129b8588a' THEN 'SDX INT/UAT'
                    WHEN 'fea1e9f0-0e20-426f-906e-bc76e5a566ad' THEN 'SDX Sandbox'
                    WHEN '6e3fc63f-851b-4fc7-8499-48f6a9c28a65' THEN 'SDX Global Shared Services'
                    ELSE 'Undefined'
                    END
                ) AS 'Subscription',
                MAX(takeoff_zone) + ' to ' + MAX(landing_zone) AS 'Activity',
                case 
                    when sum(case when processing_exit_code_value not in (0,1,2) then 1 else 0 end) > 0 then 'Failed'
                    when count(case when processing_exit_code_value = 0 then 1 end) > 0 then 'Succeeded'
                    when count(case when processing_exit_code_value = 1 then 1 end) > 0 then 'No New Data'
                    when count(case when processing_exit_code_value = 2 then 1 end) > 0 then 'Skipped'
                End as 'Status',
                DATEADD(SECOND, MAX([timestamp]), '1970-01-01') AS 'Landed at',
                DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([timestamp]) AS 'Landed Since',
                DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([content_latest_date]) AS 'Freshness',
                CAST(MAX(processing_finished_date_value) - MAX(processing_started_date_value) AS BIGINT) AS 'Duration',
                ISNULL(CAST(CAST(MAX(rows_count_value) AS BIGINT) AS VARCHAR), 'N/A') AS 'Rows'
            FROM MergedEvents
            GROUP BY job_id, context_id
        )
        Select[Application Source], Dataset,Zone, Subscription, Activity, Status,[Landed at] from Finalevents
        where Status in ($status)
        ORDER BY[Landed at] DESC
   ";
   table.new(
    title = 'Data Ingestion History - Overview',
    datasource = 'Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Landed Since',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Freshness',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Duration',properties=[{id: 'unit', value: 's'}]
);

local DatasetFreshness = 
    local sqlQuery = " 
    WITH
        FilteredEvents AS (
            SELECT
                job_id,
                context_id,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                timestamp,
                metric_name,
                metric_value
            FROM
                [observability].[event]
            WHERE
                context_id IN ('oss.glb.glb.dynamify_sdx_getallowances_history','oss.glb.glb.dynamify_sdx_getallowances_landing','oss.glb.glb.dynamify_sdx_getallowances_standardized','oss.glb.glb.dynamify_sdx_menudataexportobject_history','oss.glb.glb.dynamify_sdx_menudataexportobject_landing','oss.glb.glb.dynamify_sdx_menudataexportobject_standardized','oss.glb.glb.dynamify_sdx_tradescommercexportobject_history','oss.glb.glb.dynamify_sdx_tradescommercexportobject_landing','oss.glb.glb.dynamify_sdx_tradescommercexportobject_standardized','oss.glb.glb.dynamify_sdx_mealdeal_history','oss.glb.glb.dynamify_sdx_mealdeal_landing','oss.glb.glb.dynamify_sdx_mealdeal_standardized'+'')
                --context_id IN ('oss.glb.glb.dynamify_sdx_menudataexportobject_history','oss.glb.glb.dynamify_sdx_menudataexportobject_landing','oss.glb.glb.dynamify_sdx_menudataexportobject_standardized'+'')
                AND dataset_name  in ($dataset_name)
                AND project_name  in ($project_name)
                AND metric_name IN ('processing_started_date', 'processing_finished_date', 'processing_exit_code', 'rows_count', 'content_latest_date')
        ),
        MergedEvents AS (
            SELECT
                job_id,
                context_id,
                timestamp,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                [processing_started_date] AS processing_started_date_value,
                [processing_finished_date] AS processing_finished_date_value,
                [processing_exit_code] AS processing_exit_code_value,
                [content_latest_date] AS content_latest_date,
                [rows_count] AS rows_count_value
            FROM
                FilteredEvents
            PIVOT (
                MAX(metric_value)
                FOR metric_name IN ([processing_started_date], [processing_finished_date], [processing_exit_code], [rows_count], [content_latest_date])
            ) AS PivotTable
        ),
        Finalevents as
        (
        SELECT
            MAX(project_name) AS 'Application Source',
            MAX(dataset_name) AS 'Dataset',
            MAX(landing_zone) AS 'Zone',
            MAX(
                CASE subscription_id
                    WHEN '6b4a5b3f-1015-42da-a46a-2890a5abed30' THEN 'IFM CORE PROD'
                    WHEN '2698ca5b-bf81-43fb-8fe2-f0e21bf068e5' THEN 'IFM CORE UAT/TEST'
                    WHEN '746ac5b9-70eb-4c76-bdf4-0664bfdff2ea' THEN 'IFM CORE DEV'
                    WHEN 'cf25f2a1-4d40-45af-bb81-87ec46112b3e' THEN 'SDX STA/PRD'
                    WHEN 'c0978b9d-b809-45f4-aa76-391ceb2cfdba' THEN 'SDX DEV/TEST'
                    WHEN '8eaa3d95-3cd2-49d8-b44a-7ea47a6fb58b' THEN 'SDX SILVER'
                    WHEN 'daf86ec1-725c-493f-bf09-a1f129b8588a' THEN 'SDX INT/UAT'
                    WHEN 'fea1e9f0-0e20-426f-906e-bc76e5a566ad' THEN 'SDX Sandbox'
                    WHEN '6e3fc63f-851b-4fc7-8499-48f6a9c28a65' THEN 'SDX Global Shared Services'
                    ELSE 'Undefined'
            END
            ) AS 'Subscription',
            MAX(takeoff_zone) + ' to ' + MAX(landing_zone) AS 'Activity',
            CASE
                WHEN MAX(processing_exit_code_value) = 0 THEN 'Succeeded'
                WHEN MAX(processing_exit_code_value) = 1 THEN 'No New Data'
                WHEN MAX(processing_exit_code_value) = 2 THEN 'Skipped'
                WHEN MAX(processing_exit_code_value) IS NULL THEN 'Running'
                ELSE 'Failed'
            END AS 'Status',
            DATEADD(SECOND, MAX([timestamp]), '1970-01-01') AS 'Landed at',
            DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([timestamp]) AS 'Landed Since',
            DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([content_latest_date]) AS 'Freshness',
            CAST(MAX(processing_finished_date_value) - MAX(processing_started_date_value) AS BIGINT) AS 'Duration',
            ISNULL(CAST(CAST(MAX(rows_count_value) AS BIGINT) AS VARCHAR), 'N/A') AS 'Rows'
        FROM MergedEvents
        GROUP BY job_id, context_id
        ),
        Eventsdata as(
            Select [Application Source] as ApplicationSource, Dataset,Zone, Subscription, Activity, Status,[Landed at] as LandedAt,[Landed Since] as LandedSince,[Freshness] as Freshness, Duration,[Rows] as IngestedRows from Finalevents
            where Status in ($status)
        ),
 
        finaldata as (select
            ApplicationSource ,
            Dataset,
            case
                   when count(case when Activity = 'landing to history' and status = 'succeeded' then 1 end) >= 1
                   and count(case when Activity = 'history to standardized' and status = 'succeeded' then 1 end) >= 1
                then 'OK'        
                else 'NOT OK'
            end as [Overall Status],
            Subscription as [Datalake Location],
            case
                when count(case when Activity = 'landing to history' and status = 'succeeded' then 1 end) >= 1
                then 'OK'
                else 'NOT OK'
            end as [Bronze History Status],
            case
                when count(case when Activity = 'history to standardized' and status = 'succeeded' then 1 end) >= 1                    
        then 'OK'
                else 'NOT OK'
            end as [Bronze Standardized Status],    
            max(case
                when Activity = 'landing to history' then LandedAt
                end)
        as [Pipe Line Execution StartTime],
            max(case
                when Activity = 'history to standardized' then LandedAt
                end)
        as [Pipe Line Execution EndTime],
 
            datediff(second,
            min(case
                when Activity = 'landing to history' then LandedAt
                end),current_timestamp
            ) as [Pipe Line Executed Since],
            max(Freshness) as Freshness,
            datediff(second,
            min(case when Activity = 'landing to history' then landedAt end),
            max(case when Activity = 'history to standardized' then landedAt end)
           ) as 'Total Execution Time',
           convert(Date, LandedAt) as executedDate
        From Eventsdata
        group by ApplicationSource,
            Dataset,
            subscription,
            convert(Date, LandedAt)
        ),
        RankedData as
        (
            select  ApplicationSource,
                    Dataset,
                    [Datalake Location],
                    executedDate,
                    case
                    when executedDate < getdate()
                    then DatedIff(second,max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                        else
                        DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Overall Refresh Status],
                    case when executedDate < getdate()
                then DatedIff(second, max([Pipe Line Execution StartTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    else
                    DatedIff(second, max([Pipe Line Execution StartTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Bronze History Refresh Status],
                case when executedDate < getdate()
                then DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    else
                    DatedIff(second,max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Bronze Standardized Refresh Status],
                row_number() over (partition by ApplicationSource, Dataset order by executedDate desc) as rownum,
                    [Pipe Line Execution EndTime],
                [Pipe Line Execution StartTime],
                [Pipe Line Executed Since],
                    Freshness,
                    [Total Execution Time],
                case when Dataset != 'tradescommercexportobject'
                then 604800
                    else 86400
            end as [Freshness Threshold]
        from finalData
            where  [Overall Status] = 'OK'
        )
        select ApplicationSource,
            Dataset,
            [Freshness Threshold] as 'Threshold',
            [Overall Refresh Status] as 'Freshness Refresh Status',
            [Bronze History Refresh Status],
            [Bronze Standardized Refresh Status],
            [Pipe Line Execution StartTime],
            [Pipe Line Execution EndTime],
            Freshness,
            ([Freshness Threshold] - [Overall Refresh Status]) AS Differenceintime,
			CASE
				WHEN ([Freshness Threshold] - [Overall Refresh Status]) < 0 THEN 1
				WHEN ([Freshness Threshold] - [Overall Refresh Status]) > 0 THEN 2
				ELSE 0
			END AS Colour_Code
        from RankedData
        where  rownum = 1
        order by executedDate desc
   
   ";
   table.new(
    title = 'Tracking Data Freshness',
    datasource = 'Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Pipe Line Execution StartTime',properties=[{id: 'unit', value: 's'},{id: 'custom.width',value: 226}]
    ).addOverridesByFieldName(field='Pipe Line Execution EndTime',properties=[{id: 'unit', value: 's'},{id: 'custom.width',value: 229}]
    ).addOverridesByFieldName(field='Freshness',properties=[{id: 'unit', value: 's'},{id: 'custom.width',value: 133},{id: 'custom.hidden', value: true}]
    ).addOverridesByFieldName(field='Total Execution Time',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Total Time',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='ApplicationSource',properties=[{id: 'custom.width',value: 199}]
    ).addOverridesByFieldName(field='Dataset',properties=[{id: 'custom.width',value: 214}]
    ).addOverridesByFieldName(field='Threshold',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Freshness Refresh Status',properties=[{id: 'unit',value: "s"}]
    ).addOverridesByFieldName(field='Colour_Code',properties=[{id: 'custom.cellOptions',value: {type: 'color-background', applyToRow: true}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'green',value: null},{color: 'light-orange',value: 0},{color: 'light-red',value: 1},{color: 'super-light-green',value: 2}]}},{id: 'custom.hidden', value: true}]
    ).addOverridesByFieldName(field='Differenceintime',properties=[{id: 'custom.hidden',value: true}]
    ).addOverridesByFieldName(field='Bronze History Refresh Status',properties=[{id: 'unit',value: "s"}]
    ).addOverridesByFieldName(field='Bronze Standardized Refresh Status',properties=[{id: 'unit',value: "s"}]
);

local getDashboardAlertsPanel(alertName) =
grafana.alertlist.new(
title = std.format("Dashboard Alerts Observability %s",alertName),
onlyAlertsOnDashboard = true,
)
+{
'options' :
    {
    "dashboardAlerts": false,
    "sortOrder" : 1,
    "maxItems": 20,
    "alertName": alertName,
    "stateFilter": {
          "firing": true,
          "pending": true,
          "noData": true,
          "normal": true,
          "error": true
        }
    }
}
+ {
"sortOrder": 1,
};

//row sections

grafana.dashboard.new(
  title='Dynamify_SDX',
  refresh='5m',
  time_from='now-7d',
  editable=true,
  timezone='utc',
  schemaVersion=37,
  uid='21EiXdsfddd15H')

//global filters
.addTemplate(projectTemplate)
.addTemplate(datasetTemplate)
.addTemplate(stageTemplate)
.addTemplate(statusTemplate)
.addTemplate(HidedContext)

//panels
.addPanel(panel = generatePanelCount,gridPos={h:3,w:8,x:0,y:0})
.addPanel(panel = SLOPanel,gridPos={h:3,w:8,x:8,y:0})
.addPanel(panel = generateSLIPanel,gridPos={h:3,w:8,x:16,y:0})

.addPanel(generateIngestionPipelinesByCondition('Succeeded', 'green', 0),gridPos={h: 3, w: 6, x: 0, y: 5})
.addPanel(generateIngestionPipelinesByCondition('No New Data', 'yellow', 1),gridPos={h: 3, w: 6, x: 6, y: 5})
.addPanel(generateIngestionPipelinesByCondition('Failed', 'red', -1),gridPos={h: 3, w: 6, x: 12, y: 5})
.addPanel(panel = GenerateSuccessRatio,gridPos={h: 3, w: 6, x: 18, y: 5})

.addPanel(grafana.text.new(mode='markdown',content='Succeeded: Count of Ingestion Pipelines Run Successfully during the selected period for the selected dataset(s).',transparent= true),gridPos={h: 3, w: 6, x: 0, y: 6})
.addPanel(grafana.text.new(mode='markdown',content='No New Data: Count of Ingestion Pipelines triggered but no data pushed from Integration during the selected period for the selected dataset(s).',transparent= true),gridPos={h: 3, w: 6, x: 6, y: 6})
.addPanel(grafana.text.new(mode='markdown',content='Failed: Count of Ingestion Pipelines Failed during the selected period for the selected dataset(s).',transparent= true),gridPos={h: 3, w: 6, x: 12, y: 6})
.addPanel(grafana.text.new(mode='markdown',content='Success ratio: It is calculated as ((Success+ No New Data)/ (success + No New Data + Failed)) * 100.',transparent= true),gridPos={h: 3, w: 6, x: 18, y: 6})

.addPanel(
    row.new(
        title="SLI Trend Based on Time Range - Dynamify_SDX",
        showTitle=true,
        collapse=true
    ).addPanel(panel = SLIDynamify,gridPos = {h:8,w:24,x:0,y:65}),
    gridPos={h:8,w:24,x:0,y:66}
)

.addPanel(
    row.new(
        title="SLI Monthly Trend - Dynamify_SDX",
        showTitle=true,
        collapse=true
     ).addPanel(panel = SLIForDynamify,gridPos={h:8,w:24,x:0,y:57}),
    gridPos={h:1,w:24,x:0,y:56}
)

.addPanel(
    row.new(
        title="Tracking Data Freshness",
        showTitle=true,
        collapse=true
    ).addPanel(panel = DatasetFreshness,gridPos={h:10,w:24,x:0,y:11}),
    gridPos={h:1,w:24,x:0,y:10}
)
.addPanel(
    row.new(
        title="Data Volume Statistics",
        showTitle=true,
        collapse=true
    ).addPanel(panel = Sourcetotargetmetric,gridPos={h:9,w:24,x:0,y:11}
    ).addPanel(panel = DatasetVolumeTradescommercexportobject,gridPos={h:9,w:24,x:0,y:20}
    ).addPanel(panel = DatasetVolumeTradescommercexportobjectDate7VolumeCheck,gridPos={h:9,w:24,x:0,y:30}
    ).addPanel(panel = DatasetVolumeTradescommercexportobjectYearToDateVolumeCheck,gridPos={h:9,w:24,x:0,y:40}
    ).addPanel(panel = DatasetVolumeMenudataexportobject,gridPos={h:9,w:24,x:0,y:50}
    ).addPanel(panel = DatasetVolumeGetAllowances,gridPos={h:9,w:24,x:0,y:60}
    ).addPanel(panel = DatasetVolumeMealDeal,gridPos={h:9,w:24,x:0,y:70}),
    gridPos={h:1,w:24,x:0,y:10}
)
.addPanel(
    row.new(
        title="Dataset Ingestion History Overview",
        showTitle=true,
        collapse=true
    ).addPanel(panel = DatasetIngestionHistory,gridPos={h:10,w:24,x:0,y:81}),
    gridPos={h:1,w:24,x:0,y:80}
)
.addPanel(
    row.new(
        title="Dashboard Alerts",
        showTitle=true,
        collapse=true
    ).addPanel(panel = getDashboardAlertsPanel('dynamify_sdx'),gridPos={h:10,w:24,x:0,y:91}),
    gridPos={h:1,w:24,x:0,y:90}
)
/*
.addPanel(
    row.new(
        title="Data Ingestion Latest Status",
        showTitle=true,
        collapse=true
    ).addPanel(panel = DatasetIngestionHistoryCombined,gridPos={h:10,w:24,x:0,y:60}),
    gridPos={h:1,w:24,x:0,y:55}
)
*/