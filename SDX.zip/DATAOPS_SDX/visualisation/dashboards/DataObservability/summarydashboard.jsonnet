local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;
local tablePanel = grafana.tablePanel;
local logPanel =  grafana.logPanel;

############################ Dashboard APIM Varaibles ############################

local projectName = "Innovorder";

local template_correlationid = tmpl.text(
  name='correlationid',
	label='Correlation Id',
){
  hide:2
};

local CustomLogTable =  tmpl.custom(
    name='CustomLogTable',
    current='InnovorderConsumerTransactions_CL',
    query='InnovorderConsumerTransactions_CL',
    includeAll=false,
    multi=false,
    hide=true
);

local ProjectAppinsightsSubscription = tmpl.new(
    name='sub_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>AppinsightsSubscription'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Subscription of Application Insight",
    hide=true
);
local ProjectAppinsightsRG =  tmpl.new(
    name='rg_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>AppinsightsRG'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Resource Group of Application Insight",
    hide=true
);
local ProjectAppinsights =  tmpl.new(
    name='appinsights_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>Appinsights'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Application Insights",
    hide=true
);
local AppInsightsNamespaceTemplate =  tmpl.custom(
    name='ns_appinsights',
    current='microsoft.insights/components',
    query='microsoft.insights/components',
    includeAll=false,
    multi=false,
    hide=true
);

############################ Dashboard Azure Function Varaibles ############################

local HipSubcriptionTemplate =  tmpl.new(
    name='sub_hip',
    datasource='Azure SQL Server',
    query="Select value from grafana.APIMetadataInformation where field = 'HipSubcription'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="HIP: Subscription",
    hide=true
);
local HipRgTemplate =  tmpl.new(
    name='rg_hip',
    datasource='Azure SQL Server',
    query="Select value from grafana.APIMetadataInformation where field = 'HipResourceGroup'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="HIP: Resource Group",
    hide=true
);
local HipLoganalyticsworkspaceTemplate =  tmpl.new(
    name='resource_hip_loganalyticsworkspace',
    datasource='Azure SQL Server',
    query="Select value from grafana.APIMetadataInformation where field = 'HipLoganalyticsworkspace'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="HIP: Log Analytics Workspace",
    hide=true
);
local LoganalyticsworkspaceNamespaceTemplate =  tmpl.custom(
    name='ns_loganalyticsworkspace',
    current='Microsoft.OperationalInsights/workspaces',
    query='Microsoft.OperationalInsights/workspaces',
    includeAll=false,
    multi=false,
    hide=true
);


############################ Dashboard Service Bus Varaibles ############################

local HipServiceBusTemplate =  tmpl.new(
    name='resource_servicebus',
    datasource='Azure SQL Server',
    query="Select value from grafana.APIMetadataInformation where field = 'HipServiceBusName'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="HIP: ServiceBus",
    hide=true
);

local ServiceBusNamespaceTemplate =  tmpl.custom(
    name='ns_servicebus',
    current='microsoft.servicebus/namespaces',
    query='microsoft.servicebus/namespaces',
    includeAll=false,
    multi=false,
    hide=true
);

############################ EventHub Variables ############################

local EventhubNamespaceTemplate =  tmpl.custom(
    name='ns_eventhub',
    current='microsoft.eventhub/namespaces',
    query='microsoft.eventhub/namespaces',
    includeAll=false,
    multi=false,
    hide=true
);

local HipEventhubTemplate =  tmpl.new(
    name='resource_eventhub',
    datasource='Azure SQL Server',
    query="Select value from grafana.APIMetadataInformation where field = 'HipEventhubName'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="HIP: Eventhub",
    hide=true
);

############################ Status ############################

local ApimSucessRequest = statPanel.new(
    title="APIM : Successful Requests",
    datasource='AzureMonitor',
    description="This panel displays the number of successful requests in APIM",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
  steps=[
    { "color": "green", "value": null }
  ]
)
  .addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where success == "True"
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey
        | summarize Total_Success = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
) {
    options: {
      graphMode: "none",
    },
    fieldConfig: {
      overrides: [
        {
          matcher: {
            id: "byName",
            options: "Total_Success"
          },
          properties: [
            {
              id: "unit",
              value : "short"
            },
            {
                id: "color",
                value: {
                mode: "fixed",
                fixedColor: "green"
                }
            }
          ]
        }
      ]
  }
};
local ApimFailedRequest = statPanel.new(
    title="APIM : Failed Requests",
    datasource='AzureMonitor',
    description="This panel displays the number of failed requests in APIM",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": null,
      },
  ]
).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
      let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where success != "True"
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey
        | summarize Total_Failed = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
) {
    options: {
      graphMode: "none",
    },
    fieldConfig: {
      overrides: [
        {
          matcher: {
            id: "byName",
            options: "Total_Failed"
          },
          properties: [
            {
              id: "unit",
              value : "short"
            },{
                id: "color",
                value: {
                mode: "fixed",
                fixedColor: "red"
                }
            }
          ]
        }
      ]
  }
};

local AzfSuccessRun = statPanel.new(
    title="Azure Function: Successful Requests",
    datasource='AzureMonitor',
    description="This panel displays the number of successful run in Azure Function",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
  steps=[
    { "color": "green", "value": null }
  ]
).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        ${CustomLogTable}
        | where $__timeFilter(TimeGenerated)
        | where StatusCode_d == 200
        | where isempty("$correlationid") or CorrelationId in~ (correlationIds)
        | extend idempotencykey = IdempotencyKey_s
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(TimeGenerated) by idempotencykey
        | summarize Total_Success = count()
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'time_series'
  )
) {
    options: {
      graphMode: "none",
    },
    fieldConfig: {
      overrides: [
        {
          matcher: {
            id: "byName",
            options: "Total_Success"
          },
          properties: [
            {
              id: "unit",
              value : "short"
            },{
                id: "color",
                value: {
                mode: "fixed",
                fixedColor: "green"
                }
            }
          ]
        }
      ]
  }
};

local AzfFailedRun = statPanel.new(
    title="Azure Function: Failed Requests",
    datasource='AzureMonitor',
    description="This panel displays the number of failed run in Azure Function",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
 ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": null,
      },
  ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        ${CustomLogTable}
        | where $__timeFilter(TimeGenerated)
        | where StatusCode_d != 200
        | where isempty("$correlationid") or CorrelationId in~ (correlationIds)
        | extend idempotencykey = IdempotencyKey_s
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(TimeGenerated) by idempotencykey
        | summarize Total_Failed = count()
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'time_series'
  )
) {
    options: {
      graphMode: "none",
    },
    fieldConfig: {
      overrides: [
        {
          matcher: {
            id: "byName",
            options: "Total_Failed"
          },
          properties: [
            {
              id: "unit",
              value : "short"
            },{
                id: "color",
                value: {
                mode: "fixed",
                fixedColor: "red"
                }
            }
          ]
        }
        
      ]
  }
};

local ServiceBusSuccessfulRequests = statPanel.new(
    title="Service Bus: Total Successful Requests",
    datasource='AzureMonitor',
    description="This panel displays the total successful requests for Service Bus",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields='/^Time$/'
  ).addThresholds(
  steps=[
    { "color": "green", "value": null }
  ]
){
    "targets": [
    {
      "datasource": {
        "type": "grafana-azure-monitor-datasource",
        "uid": "AzureMonitor"
      },
      "azureMonitor": {
        "aggregation": "Total",
        "metricName": "SuccessfulRequests",
        "metricNamespace": "$ns_servicebus",
        "region": "",
        "resources": [
          {
            "metricNamespace": "$ns_servicebus",
            "region": "",
            "resourceGroup": "$rg_hip",
            "resourceName": "$resource_servicebus",
            "subscription": "$sub_hip"
          }
        ],
        "timeGrain": "auto",
      },
      "queryType": "Azure Monitor",
      "refId": "A",
      "subscription": "$sub_hip"
    }
  ],
  }{
    options: {
      graphMode: "none",
    },
    fieldConfig: {
      overrides: [
        {
          matcher: {
            id: "byName",
            options: "Successful Requests"
          },
          properties: [
            {
              id: "unit"
            },{
                id: "color",
                value: {
                mode: "fixed",
                fixedColor: "green"
                }
            }
          ]
        }
      ]
  }
};
local ServiceBusFailedRequests = statPanel.new(
    title="Service Bus : Failed Requests",
    datasource='AzureMonitor',
    description="This panel displays the total Failed requests for Service Bus",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields='/^Time$/'
 ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": null,
      },
  ]
  ){
    "targets": [
    {
      "datasource": {
        "type": "grafana-azure-monitor-datasource",
        "uid": "AzureMonitor"
      },
      "azureMonitor": {
        "aggregation": "Total",
        "metricName": "UserErrors",
        "metricNamespace": "$ns_servicebus",
        "region": "",
        "resources": [
          {
            "metricNamespace": "$ns_servicebus",
            "region": "",
            "resourceGroup": "$rg_hip",
            "resourceName": "$resource_servicebus",
            "subscription": "$sub_hip"
          }
        ],
        "timeGrain": "auto",
      },
      "queryType": "Azure Monitor",
      "refId": "A",
      "subscription": "$sub_hip"
    },
    {
      "azureMonitor": {
        "aggregation": "Total",
        "allowedTimeGrainsMs": [
          60000,
          300000,
          900000,
          1800000,
          3600000,
          21600000,
          43200000,
          86400000
        ],
        "dimensionFilters": [],
        "metricName": "ThrottledRequests",
        "metricNamespace": "$ns_servicebus",
        "region": "",
        "resources": [
          {
            "metricNamespace": "$ns_servicebus",
            "region": "",
            "resourceGroup": "$rg_hip",
            "resourceName": "$resource_servicebus",
            "subscription": "$sub_hip"
          }
        ],
        "timeGrain": "auto"
      },
      "datasource": {
        "type": "grafana-azure-monitor-datasource",
        "uid": "AzureMonitor"
      },
      "hide": false,
      "queryType": "Azure Monitor",
      "refId": "B",
      "subscription": "$sub_hip"
    }
  ],
}{
    "transformations": [
    {
      "id": "calculateField",
      "options": {
        "alias": "Failed Requests",
        "binary": {
          "left": "User Errors.",
          "right": "Throttled Requests."
        },
        "mode": "binary",
        "reduce": {
          "reducer": "sum"
        },
        "replaceFields": true
      }
    }
  ],
}
{
    options: {
      graphMode: "none",
    },
    fieldConfig: {
      overrides: [
        {
          matcher: {
            id: "byName",
            options: "Failed Requests"
          },
          properties: [
            {
              id: "unit"
            },{
                id: "color",
                value: {
                mode: "fixed",
                fixedColor: "red"
                }
            }
          ]
        }
      ]
  }
};


local EventHubSuccessfulRequests = statPanel.new(
    title="EventHub: Successful Requests",
    datasource='AzureMonitor',
    description="This panel displays the Successfull Requests in EventHub",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
  steps=[
    { "color": "green", "value": null }
  ]
){
    "targets":[{
      "datasource": {
        "type": "grafana-azure-monitor-datasource",
        "uid": "AzureMonitor"
      },
      "refId": "A",
      "queryType": "Azure Monitor",
      "azureMonitor": {
        "aggregation": "Total",
        "timeGrain": "auto",
        "allowedTimeGrainsMs": [
          60000,
          300000,
          900000,
          1800000,
          3600000,
          21600000,
          43200000,
          86400000
        ],
        "metricNamespace": "$ns_eventhub",
        "resources": [
          {
            "subscription": "$sub_project",
            "metricNamespace": "$ns_eventhub",
            "resourceGroup": "$rg_project",
            "resourceName": "$resource_eventhub"
          }
        ],
        "metricName": "SuccessfulRequests",
        "dimensionFilters": []
      },
      "subscription": "$sub_project"
    }]
  } {
    options: {
      graphMode: "none",
    },
    fieldConfig: {
      overrides: [
        {
          matcher: {
            id: "byName",
            options: "Successful Requests"
          },
          properties: [
            {
              id: "unit",
              value : "short"
            },{
                id: "color",
                value: {
                mode: "fixed",
                fixedColor: "green"
                }
            }
          ]
        }
      ]
  }
};

local EventHubFailedRequests = statPanel.new(
    title="EventHub : Failed Requests",
    datasource='AzureMonitor',
    description="This panel displays Failed Requests for EventHub",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields='/^Time$/'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": null,
      },
  ]
)
  {
    "targets": [
    {
      "datasource": {
        "type": "grafana-azure-monitor-datasource",
        "uid": "AzureMonitor"
      },
      "azureMonitor": {
        "aggregation": "Total",
        "metricName": "UserErrors",
        "metricNamespace": "$ns_eventhub",
        "region": "",
        "resources": [
          {
            "metricNamespace": "$ns_eventhub",
            "region": "",
            "resourceGroup": "$rg_hip",
            "resourceName": "$resource_eventhub",
            "subscription": "$sub_hip"
          }
        ],
        "timeGrain": "auto",
      },
      "queryType": "Azure Monitor",
      "refId": "A",
      "subscription": "$sub_hip"
    },
    {
      "azureMonitor": {
        "aggregation": "Total",
        "allowedTimeGrainsMs": [
          60000,
          300000,
          900000,
          1800000,
          3600000,
          21600000,
          43200000,
          86400000
        ],
        "dimensionFilters": [],
        "metricName": "ThrottledRequests",
        "metricNamespace": "$ns_eventhub",
        "region": "",
        "resources": [
          {
            "metricNamespace": "$ns_eventhub",
            "region": "",
            "resourceGroup": "$rg_hip",
            "resourceName": "$resource_eventhub",
            "subscription": "$sub_hip"
          }
        ],
        "timeGrain": "auto"
      },
      "datasource": {
        "type": "grafana-azure-monitor-datasource",
        "uid": "AzureMonitor"
      },
      "hide": false,
      "queryType": "Azure Monitor",
      "refId": "B",
      "subscription": "$sub_hip"
    }
  ],
}{
    "transformations": [
    {
      "id": "calculateField",
      "options": {
        "alias": "Failed Requests",
        "binary": {
          "left": "User Errors.",
          "right": "Throttled Requests."
        },
        "mode": "binary",
        "reduce": {
          "reducer": "sum"
        },
        "replaceFields": true
      }
    }
  ],
}
{
    options: {
      graphMode: "none",
    },
    fieldConfig: {
      overrides: [
        {
          matcher: {
            id: "byName",
            options: "Failed Requests"
          },
          properties: [
            {
              id: "unit",
              value : "short"
            },{
                id: "color",
                value: {
                mode: "fixed",
                fixedColor: "red"
                }
            }
          ]
        }
      ]
  }
};

local DABSuccessIngestion =
  statPanel.new(
    title="DAB: Successful Ingestions",
    fields='/^Time$/',
    datasource='Azure SQL Server',
    description="This metric represents new ingests in success over a time slot",
  ).addThresholds(
  steps=[
    { "color": "green", "value": null }
  ]
).addTarget(
    target=grafana.sql.target(
      rawSql="
            SELECT COUNT(*)
            FROM [observability].[event]
            WHERE metric_name = 'processing_exit_code'
              AND event_type = 'processingfinished'
              AND metric_value in (0,1)
              AND publisher_name = 'data_asset_builder'
              AND [timestamp] >= DATEDIFF(SECOND, '1970-01-01', $__timeFrom())
              AND [timestamp] < DATEDIFF(SECOND, '1970-01-01', $__timeTo())
            ",
            format='table'
    )
  )
{
    options: {
      graphMode: "none",
    },
    fieldConfig: {
      overrides: [
        {
          matcher: {
            id: "byName",
            options: "Value"
          },
          properties: [
            {
              id: "unit",
              value : "short"
            },{
                id: "color",
                value: {
                mode: "fixed",
                fixedColor: "green"
                }
            }
          ]
        }
      ]
  }
};  

local DABFailedIngestion =
  statPanel.new(
    title="DAB: Failed Ingestions",
    fields='/^Time$/',
    datasource='Azure SQL Server',
    description="This metric represents new ingests in Failed over a time slot",
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": null,
      },
  ]
).addTarget(
    target=grafana.sql.target(
      rawSql="
            SELECT COUNT(*)
            FROM [observability].[event]
            WHERE metric_name = 'processing_exit_code'
              AND event_type = 'processingfinished'
              AND metric_value = -1
              AND publisher_name = 'data_asset_builder'
              AND [timestamp] >= DATEDIFF(SECOND, '1970-01-01', $__timeFrom())
              AND [timestamp] < DATEDIFF(SECOND, '1970-01-01', $__timeTo())
            ",
            format='table'
        )
  ) 
{
    options: {
      graphMode: "none",
    },
    fieldConfig: {
      overrides: [
        {
          matcher: {
            id: "byName",
            options: "Value"
          },
          properties: [
            {
              id: "unit",
              value : "short"
            },{
                id: "color",
                value: {
                mode: "fixed",
                fixedColor: "red"
                }
            }
          ]
        }
      ]
  }
}; 

local ADFSuccessfulJobs =
  statPanel.new(
    title="ADF: Successful Jobs",
    fields='/^Time$/',
    datasource='Azure SQL Server',
    description="This panel displays the ADF Successful jobs for the selected time frame.",
  ).addThresholds(
  steps=[
    { "color": "green", "value": null }
  ]
).addTarget(
    target=grafana.sql.target(
      rawSql="
            Select count(*) from [observability].[insights-diagnostics-logs] 
            where [observability].[insights-diagnostics-logs].Status = 'Succeeded' and
            DATEDIFF(second, '1970-01-01', [insights-diagnostics-logs].Startdate) >= $__unixEpochFrom() and 
            DATEDIFF(second, '1970-01-01', [insights-diagnostics-logs].Startdate) < $__unixEpochTo();
            ",
            format='table'
        )
  ) 
{
    options: {
      graphMode: "none",
    },
    fieldConfig: {
      overrides: [
        {
          matcher: {
            id: "byName",
            options: "Value"
          },
          properties: [
            {
              id: "unit",
              value : "short"
            },{
                id: "color",
                value: {
                mode: "fixed",
                fixedColor: "green"
                }
            }
          ]
        }
      ]
  }
};

local ADFFailedJobs =
  statPanel.new(
    title="ADF: Failed Jobs",
    fields='/^Time$/',
    datasource='Azure SQL Server',
    description="This panel displays the ADF Failed jobs for the selected time frame.",
 ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": null,
      },
  ]
).addTarget(
    target=grafana.sql.target(
      rawSql="
                select count(*) from [observability].[insights-diagnostics-logs] 
                where [observability].[insights-diagnostics-logs].Status = 'Failed' and
                DATEDIFF(second, '1970-01-01', [insights-diagnostics-logs].Startdate) >= $__unixEpochFrom() and 
                DATEDIFF(second, '1970-01-01', [insights-diagnostics-logs].Startdate) < $__unixEpochTo();
                ",
            format='table'
        )
  ) 
{
    options: {
      reduceOptions: {
      values: false,
      calcs: [
      "mean"
      ],
      },
      graphMode: "none",
    },
    fieldConfig: {
      overrides: [
        {
          matcher: {
            id: "byName",
            options: "Value"
          },
          properties: [
            {
              id: "unit",
              value : "short"
            },{
                id: "color",
                value: {
                mode: "fixed",
                fixedColor: "red"
                }
            }
          ]
        }
      ]
  }
};

local DremioSuccessfulRequests = statPanel.new(
    title="Dremio: Successful Requests",
    datasource='Azure SQL Server',
    description="This panel displays successful dremio query executions for selected timeslot",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields='/^Time$/'
  ).addThresholds(
  steps=[
    { "color": "green", "value": null }
  ]
).addTarget(
    target=grafana.sql.target(
    rawSql="",
    format='table'
    )
  ) 
{
    options: {
      graphMode: "none",
    },
    fieldConfig: {
      overrides: [
        {
          matcher: {
            id: "byName",
            options: "Successful Requests"
          },
          properties: [
            {
              id: "unit"
            },{
                id: "color",
                value: {
                mode: "fixed",
                fixedColor: "green"
                }
            }
          ]
        }
      ]
  }
};

local DremioFailedRequests = statPanel.new(
    title="Dremio: Failed Requests",
    datasource='Azure SQL Server',
    description="This panel displays Failed dremio query executions for selected timeslot",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields='/^Time$/'
).addThresholds(
    steps=[
      {
        "color": "red",
        "value": null
      },
  ]
  ).addTarget(
    target=grafana.sql.target(
    rawSql="",
    format='table'
    )
  )
{
    options: {
      graphMode: "none",
    },
    fieldConfig: {
      overrides: [
        {
          matcher: {
            id: "byName",
            options: "Failed Requests"
          },
          properties: [
            {
              id: "unit", 
              value: "short"
            },{
                id: "color",
                value: {
                mode: "thresholds"
                }
            }
          ]
        }
      ]
  }
};



local Status = row.new(title="Status", collapse=true)
    .addPanel(ApimSucessRequest,gridPos={h: 4, w: 12, x: 0, y: 1})
    .addPanel(ApimFailedRequest,gridPos={h: 4, w: 12, x: 12, y: 1})
    .addPanel(AzfSuccessRun,gridPos={h: 4, w: 12, x: 0, y: 5})
    .addPanel(AzfFailedRun,gridPos={h: 4, w: 12, x: 12, y: 5})
    .addPanel(ServiceBusSuccessfulRequests,gridPos={h: 4, w: 12, x: 0, y: 9})
    .addPanel(ServiceBusFailedRequests,gridPos={h: 4, w: 12, x: 12, y: 9})
    .addPanel(EventHubSuccessfulRequests,gridPos={h: 4, w: 12, x: 0, y: 13})
    .addPanel(EventHubFailedRequests,gridPos={h: 4, w: 12, x: 12, y: 13})
    .addPanel(DABSuccessIngestion,gridPos={h: 4, w: 12, x: 0, y: 17})
    .addPanel(DABFailedIngestion,gridPos={h: 4, w: 12, x: 12, y: 17})
    .addPanel(DremioSuccessfulRequests,gridPos={h: 4, w: 12, x: 0, y: 21})
    .addPanel(DremioFailedRequests,gridPos={h: 4, w: 12, x: 12, y: 21})
    .addPanel(ADFSuccessfulJobs,gridPos={h: 4, w: 12, x: 0, y: 25})
    .addPanel(ADFFailedJobs,gridPos={h: 4, w: 12, x: 12, y: 25});

local APIMFailedRequestlogs = tablePanel.new(
    title="APIM Failed Request logs",
    datasource='AzureMonitor',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where success == "False"
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | extend
            Request_timestamp=timestamp,
            Request_name=name
        | join kind=inner (
            exceptions 
            | summarize outerMessage= make_set( outerMessage) by operation_Id
            ) on operation_Id
        | summarize arg_max(Request_timestamp, *) by operation_Id, idempotencykey
        | project Request_timestamp, operation_Name, outerMessage
        | order by Request_timestamp desc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
) {
    "options": {
    "showHeader": true,
    "cellHeight": "sm",
    "footer": {
      "show": false,
      "reducer": [
        "sum"
      ],
      "countRows": false,
      "fields": ""
    },
    "sortBy": []
  },
  "fieldConfig": {
    "defaults": {
      "custom": {
        "align": "auto",
        "cellOptions": {
          "type": "auto"
        },
        "inspect": false,
        "filterable": true
      },
      "mappings": [],
      "thresholds": {
        "mode": "absolute",
        "steps": [
          {
            "color": "green",
            "value": null
          },
          {
            "color": "red",
            "value": 80
          }
        ]
      },
      "color": {
        "mode": "thresholds"
      }
    },
    "overrides": [
      {
        "matcher": {
          "id": "byName",
          "options": "Request_timestamp1"
        },
        "properties": [
          {
            "id": "custom.hidden",
            "value": true
          }
        ]
      },
      {
        "matcher": {
          "id": "byName",
          "options": "Request_name"
        },
        "properties": [
          {
            "id": "custom.width",
            "value": 438
          }
        ]
      },
      {
        "matcher": {
          "id": "byName",
          "options": "operation_Name"
        },
        "properties": [
          {
            "id": "custom.width",
            "value": 305
          }
        ]
      },
      {
        "matcher": {
          "id": "byName",
          "options": "Request_timestamp"
        },
        "properties": [
          {
            "id": "custom.width",
            "value": 179
          }
        ]
      }
    ]
  },
};

local AzureFunctionFailedRequestlogs = tablePanel.new(
    title="Azure Function Failed Request logs",
    datasource='AzureMonitor',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        ${CustomLogTable}
        | where $__timeFilter(TimeGenerated)
        | where StatusCode_d != 200
        | where isempty("$correlationid") or CorrelationId in~ (correlationIds)
        | extend idempotencykey = IdempotencyKey_s
        | where isnotempty(idempotencykey)
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'logs'
  )
) {
    "options": {
    "showHeader": true,
    "cellHeight": "sm",
    "footer": {
      "show": false,
      "reducer": [
        "sum"
      ],
      "countRows": false,
      "fields": ""
    },
    "sortBy": []
  },
  "fieldConfig": {
    "defaults": {
      "custom": {
        "align": "auto",
        "cellOptions": {
          "type": "auto"
        },
        "inspect": false
      },
      "mappings": [],
      "thresholds": {
        "mode": "absolute",
        "steps": [
          {
            "color": "green",
            "value": null
          },
          {
            "color": "red",
            "value": 80
          }
        ]
      },
      "color": {
        "mode": "thresholds"
      }
    },
    "overrides": [
      {
        "matcher": {
          "id": "byName",
          "options": "Request_timestamp1"
        },
        "properties": [
          {
            "id": "custom.hidden",
            "value": true
          }
        ]
      },
      {
        "matcher": {
          "id": "byName",
          "options": "Request_name"
        },
        "properties": [
          {
            "id": "custom.width",
            "value": 438
          }
        ]
      }
    ]
  },
};

local DABPanel = tablePanel.new(
    title="DAB Ingestion Error Logs",
    datasource = "Loki Container",
    description="Failed Ingestion Logs metric provides an overview of failure reason for failed ingestions for selected Application Source, Dataset,Landing Zone. It also provides an ability to search for specific failed ingestion over this table view by using text search box. These view helps us see error messages displaying on Grafana dashboards regarding failed ingestions in order to be able know quickly what are the ingestion issues.",
){
    "targets": [
    {
      "datasource": {
        "type": "loki",
        "uid": "P994D17B6B12A6692"
      },
      "editorMode": "code",
      "expr": "{level=\"error\", landing_zone=~\"$stage\"} |~\"$text_search\"",
      "legendFormat": "",
      "queryType": "range",
      "refId": "A"
    }
  ],
}{
    "fieldConfig": {
    "defaults": {
      "custom": {
        "align": "auto",
        "cellOptions": {
          "type": "auto"
        },
        "inspect": false
      },
      "mappings": [],
      "thresholds": {
        "mode": "absolute",
        "steps": [
          {
            "color": "green",
            "value": null
          },
          {
            "color": "red",
            "value": 80
          }
        ]
      }
    },
    "overrides": [
      {
        "matcher": {
          "id": "byName",
          "options": "Application Source"
        },
        "properties": [
          {
            "id": "custom.filterable",
            "value": "true"
          }
        ]
      },
      {
        "matcher": {
          "id": "byName",
          "options": "Dataset"
        },
        "properties": [
          {
            "id": "custom.filterable",
            "value": "true"
          }
        ]
      },
      {
        "matcher": {
          "id": "byName",
          "options": "Zone"
        },
        "properties": [
          {
            "id": "custom.filterable",
            "value": "true"
          }
        ]
      },
      {
        "matcher": {
          "id": "byName",
          "options": "Landed At"
        },
        "properties": [
          {
            "id": "custom.filterable",
            "value": "true"
          }
        ]
      },
      {
        "matcher": {
          "id": "byName",
          "options": "Error Message"
        },
        "properties": [
          {
            "id": "custom.filterable",
            "value": "true"
          }
        ]
      }
    ]
  },
}{
    "transformations": [
    {
      "id": "extractFields",
      "options": {
        "source": "labels"
      }
    },
    {
      "id": "filterFieldsByName",
      "options": {
        "include": {
          "names": [
            "Time",
            "Line",
            "dataset_name",
            "landing_zone",
            "project_name"
          ]
        }
      }
    },
    {
      "id": "organize",
      "options": {
        "indexByName": {
          "Line": 4,
          "Time": 3,
          "dataset_name": 1,
          "landing_zone": 2,
          "project_name": 0
        },
        "renameByName": {
          "Line": "Error Message",
          "Time": "Landed At",
          "dataset_name": "Dataset",
          "landing_zone": "Zone",
          "project_name": "Application Source"
        }
      }
    }
  ],
};

local ADFPipelineTable = 
local sqlQuery = "SELECT [observability].[insights-diagnostics-logs].Name as 'Job Name', 
                [observability].[insights-diagnostics-logs].Category as 'Category',
                [observability].[insights-diagnostics-logs].StartDate as 'Timestamp',
                [observability].[insights-diagnostics-logs].AzureResource as 'Resource' FROM [observability].[insights-diagnostics-logs]
                where [observability].[insights-diagnostics-logs].Name is NOT NULL and [observability].[insights-diagnostics-logs].Status = 'Failed' and
                    DATEDIFF(second, '1970-01-01', [insights-diagnostics-logs].Startdate) >= $__unixEpochFrom() and 
                    DATEDIFF(second, '1970-01-01', [insights-diagnostics-logs].Startdate) < $__unixEpochTo()
                order by  [observability].[insights-diagnostics-logs].StartDate desc;
      ";
      grafana.tablePanel.new(
        title='ADF Failed Logs',
        datasource='Azure SQL Server',
        description="This table lists all the Jobs for the selected source(s)"
        ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    );


local ErrorLogHistory = row.new(title="Error Log History", collapse=true)
    .addPanel(APIMFailedRequestlogs,gridPos={h: 10, w: 24, x: 0, y: 2})
    .addPanel(AzureFunctionFailedRequestlogs,gridPos={h: 10, w: 24, x: 0, y: 12})
    .addPanel(DABPanel,gridPos={h: 10, w: 24, x: 0, y: 22})
    .addPanel(ADFPipelineTable,gridPos={h: 10, w: 24, x: 0, y: 32});

######################### Dashboard ###################

grafana.dashboard.new(
  title='Executive Summary Dashboard',
  time_from='now-24h',
  timezone="utc",
  editable='false',
  schemaVersion=37,
  uid='Summary-Dashboard',
  tags=['Summary','monitoring', 'observability'])

.addTemplate(ProjectAppinsightsSubscription)
.addTemplate(ProjectAppinsightsRG)
.addTemplate(ProjectAppinsights)
.addTemplate(AppInsightsNamespaceTemplate)
.addTemplate(CustomLogTable)
.addTemplate(template_correlationid)

.addTemplate(HipSubcriptionTemplate)
.addTemplate(HipRgTemplate)
.addTemplate(HipLoganalyticsworkspaceTemplate)
.addTemplate(LoganalyticsworkspaceNamespaceTemplate)


.addTemplate(HipServiceBusTemplate)
.addTemplate(ServiceBusNamespaceTemplate)
.addTemplate(HipEventhubTemplate)
.addTemplate(EventhubNamespaceTemplate)


.addPanel(panel=Status, gridPos={h: 1, w: 24, x: 0, y: 15})
.addPanel(panel=ErrorLogHistory, gridPos={h: 1, w: 24, x: 0, y: 25})