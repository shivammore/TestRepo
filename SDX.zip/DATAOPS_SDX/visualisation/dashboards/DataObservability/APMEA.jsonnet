local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;
local tablePanel = grafana.tablePanel;
local logPanel =  grafana.logPanel;

############################ Dashboard Varaibles ############################

local projectName = "APMEA";

local ProjectAppinsightsSubscription = tmpl.new(
    name='sub_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>AppinsightsSubscription'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Subscription of Application Insight",
    hide=true
);
local ProjectAppinsightsRG =  tmpl.new(
    name='rg_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>AppinsightsRG'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Resource Group of Application Insight",
    hide=true
);
local ProjectAppinsights =  tmpl.new(
    name='appinsights_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>Appinsights'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Application Insights",
    hide=true
);
local ProjectAppInsightsNamespace =  tmpl.custom(
    name='ns_appinsights',
    current='microsoft.insights/components',
    query='microsoft.insights/components',
    includeAll=false,
    multi=false,
    label="Project: AppInsights Namespace",
    hide=true
);
local ProjectServiceBus1 =  tmpl.new(
    name='resource_servicebus1',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>ServiceBusName1'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: ServiceBus 1",
    hide=true
);
local ProjectServiceBus2 =  tmpl.new(
    name='resource_servicebus2',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>ServiceBusName2'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: ServiceBus 2",
    hide=true
);
local ProjectServiceBus3 =  tmpl.new(
    name='resource_servicebus3',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>ServiceBusName3'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: ServiceBus 3",
    hide=true
);
local ProjectServiceBus4 =  tmpl.new(
    name='resource_servicebus4',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>ServiceBusName4'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: ServiceBus 4",
    hide=true
);
local ProjectServiceBusNamespace =  tmpl.custom(
    name='ns_servicebus',
    current='microsoft.servicebus/namespaces',
    query='microsoft.servicebus/namespaces',
    includeAll=false,
    multi=false,
    label="Project: ServiceBus Namespace",
    hide=true
);
local ProjectAppinsightsRG2 =  tmpl.new(
    name='rg_project2',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>AppinsightsRG2'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Resource Group of Application Insight 2",
    hide=true
);
local ProjectAppinsights2 =  tmpl.new(
    name='appinsights_project2',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>Appinsights2'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Application Insights 2",
    hide=true
);
local ProjectLogAnalyticsWorkspace =  tmpl.new(
    name='loganalyticsworkspace_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>LogAnalyticsWorkspace'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Log Analytics Workspace",
    hide=true
);
local LoganalyticsworkspaceNamespaceTemplate =  tmpl.custom(
    name='ns_loganalyticsworkspace',
    current='Microsoft.OperationalInsights/workspaces',
    query='Microsoft.OperationalInsights/workspaces',
    includeAll=false,
    multi=false,
    hide=true
);

############################ Dashboard filters ############################

local template_API =  tmpl.custom(
    name='apiName',
    current='all',
    query='Article, bankstatement, businesspartner, chartofaccount, costcenter, employee, employementinformation, exchangerate, expenseclaim, glaccount, glentry, GoodsReceipt, hfmaccount, Menu, Payment, position, Product, profitcenter, PurchaseOrder, PurchasePrice, PurchaseRequisition, RebateAgreement, Recipe, RetailItem, RetailPrice, salescontract, salesinvoice, StockMovement, Supplier, wbs',
    includeAll=true,
    multi=true,
    label='API Name'
);

local template_country =  tmpl.new(
    name='country',
    datasource='AzureMonitor',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Country',
    queryType='Azure Log Analytics',
    query=|||
            requests
            | where isnotempty(customDimensions)
            | extend country = tostring(customDimensions["Request-x-country-of-origin"])
            | where isnotempty(country)
            | distinct country
            | order by country asc
        |||,
    resources=[
      "/subscriptions/$sub_project/resourceGroups/$rg_project2/providers/$ns_appinsights/$appinsights_project2"
    ]
);

local template_region =  tmpl.new(
    name='region',
    datasource='AzureMonitor',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Region',
    queryType='Azure Log Analytics',
    query=|||
            requests
            | where isnotempty(customDimensions)
            | extend region = tostring(customDimensions.["Request-x-region"])
            | where isnotempty(region)
            | distinct region
            | order by region asc
        |||,
    resources=[
      "/subscriptions/$sub_project/resourceGroups/$rg_project2/providers/$ns_appinsights/$appinsights_project2"
    ]
);

local template_source =  tmpl.new(
    name='source',
    datasource='AzureMonitor',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Source App ID',
    queryType='Azure Log Analytics',
    query=|||
            requests
            | where isnotempty(customDimensions)
            | extend source = tostring(customDimensions.["Request-x-source-application-id"])
            | where isnotempty(source)
            | distinct source
            | order by source asc
        |||,
    resources=[
      "/subscriptions/$sub_project/resourceGroups/$rg_project2/providers/$ns_appinsights/$appinsights_project2"
    ]
);

local template_correlationid = tmpl.text(
    name='correlationid',
	label='Correlation Id'
);

local template_functionApp =  tmpl.new(
    name='functionApp',
    datasource='Azure SQL Server',
    query="SELECT functionapp FROM [dbo].[FunctionAppDetails] where Apiname in ($apiName) ORDER BY functionapp ASC",
    refresh='load',
    includeAll=true,
    multi=true,
    label="Function App",
);

############################ Summary panels ############################

local TotalRequestsPanels = statPanel.new(
  title="Total Ingested Records",
  datasource='-- Mixed --',
  description="This panel displays the total number of ingested records received across all services, including APIM, Azure Functions, Service Bus, Landing Zone,  History Zone and Standardized Zone, based on the selected timestamp.",
  graphMode='none',
  reducerFunction='sum',
  orientation="vertical",
  justifyMode= "center",
  transparent=true
)
.addThresholds(
  steps=[
    { "color": "red", "value": 0 },
    { "color": "green", "value": 1 },
  ]
)
.addTarget({
  refId: "A",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project2/providers/$ns_appinsights/$appinsights_project2"
    ],
    query: |||
      let correlationIds = split("$correlationid", ",");
      requests
      | where $__timeFilter(timestamp)
      | where success == "True"
      | where tostring(customDimensions.["Request-x-region"]) in ($region)
      | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
      | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
      | where tostring(customDimensions["API Name"]) has_any ($apiName)
      | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
      | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
      | where isnotempty(idempotencykey)
      | summarize latest_timestamp = max(timestamp) by idempotencykey
      | summarize ['API Requests'] = count()
    |||
  }
})
.addTarget({
  refId: "B",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"
    ],
    query: |||
      let correlationIds = split("$correlationid", ",");
      AppTraces
      | where $__timeFilter(TimeGenerated) 
      | where AppRoleName in ($functionApp)
      | where isnotempty(Message)
      | extend msgjson = parse_json(Message)
      | extend correlationId   = tostring(msgjson.x_correlation_id)
            , idempotancyKey   = tostring(msgjson.x_idempotency_key)
            , countryOrigin   = tostring(msgjson.x_country_of_origin)
            , region          = tostring(msgjson.x_region)
            , sourceAppId     = tostring(msgjson.x_source_application_id)
            , statusCode      = tostring(msgjson.status_code)
      | where isnotempty(correlationId)
      | where isnotempty(idempotancyKey)
      | where isempty("$correlationid") or correlationId in~ (correlationIds)
      | where countryOrigin in ($country)
      | where region in ($region)
      | where sourceAppId in ($source)
      | where statusCode == "200"
      | summarize latest_timestamp = max(TimeGenerated) by idempotancyKey
      | summarize ['Azure Function Requests'] = count()
    |||
  }
})
.addTarget({
  refId: "C",
  datasource: {
    type: "__expr__",
    uid: "__expr__",
    name: "Expression"
  },
  type: "math",
  hide: false,
  expression: "$G + $H + $I + $J"
})
.addTarget({
  refId: "D",
  datasource: {
    type: "datasource",
    uid: "AzureSQLServer"
  },
  rawMode: true,
  format: "table",
  rawQuery: true,
  rawSql: "SELECT
            count(*) AS [Landing Zone Requests]               
            FROM [observability].[event]
            WHERE project_name LIKE '%apmea%'
                AND landing_zone IN ('landing')
                AND metric_name='processing_exit_code'
                AND event_type='processingfinished'
                AND metric_value=0
                AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()",
  query: {
    alias: "Landing Requests",
    format: "table",
    rawEditor: true,
    rawQuery: true,
    rawSql: "SELECT
              count(*) AS [Landing Zone Requests]               
              FROM [observability].[event]
              WHERE project_name LIKE '%apmea%'
                  AND landing_zone IN ('landing')
                  AND metric_name='processing_exit_code'
                  AND event_type='processingfinished'
                  AND metric_value=0
                  AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()"
  }
})
.addTarget({
  refId: "E",
  datasource: {
    type: "datasource",
    uid: "AzureSQLServer"
  },
  rawMode: true,
  format: "table",
  rawQuery: true,
  rawSql: "SELECT
            count(*) AS [History Zone Requests]               
            FROM [observability].[event]
            WHERE project_name LIKE '%apmea%'
                AND landing_zone IN ('history')
                AND metric_name='processing_exit_code'
                AND event_type='processingfinished'
                AND metric_value=0
                AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()",
  query: {
    alias: "History Requests",
    format: "table",
    rawEditor: true,
    rawQuery: true,
    rawSql: "SELECT
              count(*) AS [History Zone Requests]               
              FROM [observability].[event]
              WHERE project_name LIKE '%apmea%'
                  AND landing_zone IN ('history')
                  AND metric_name='processing_exit_code'
                  AND event_type='processingfinished'
                  AND metric_value=0
                  AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()"
  }
})
.addTarget({
  refId: "F",
  datasource: {
    type: "datasource",
    uid: "Azure SQL Server"
  },
  rawMode: true,
  format: "table",
  rawQuery: true,
  rawSql: "SELECT
            count(*) AS [Standardized Zone Requests]               
            FROM [observability].[event]
            WHERE project_name LIKE '%apmea%'
                AND landing_zone IN ('standardized')
                AND metric_name='processing_exit_code'
                AND event_type='processingfinished'
                AND metric_value=0
                AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()",
  query: {
    alias: "Standardized Zone Requests",
    format: "table",
    rawEditor: true,
    rawQuery: true,
    rawSql: "SELECT
              count(*) AS [Standardized Zone Requests]               
              FROM [observability].[event]
              WHERE project_name LIKE '%apmea%'
                  AND landing_zone IN ('standardized')
                  AND metric_name='processing_exit_code'
                  AND event_type='processingfinished'
                  AND metric_value=0
                  AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()"
  }
})
.addTarget({
  refId: "G",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Monitor",
  azureMonitor: {
    aggregation: "Total",
    alias: "Service Bus Requests 1",
    allowedTimeGrainsMs: [
      60000,
      300000,
      900000,
      1800000,
      3600000,
      21600000,
      43200000,
      86400000
    ],
    metricName: "IncomingMessages",
    metricNamespace: "$ns_servicebus",
    region: "",
    resources: [
      {
        metricNamespace: "$ns_servicebus",
        region: "",
        resourceGroup: "$rg_project",
        resourceName: "$resource_servicebus1",
        subscription: "$sub_project"
      }
    ],
    timeGrain: "auto"
  },
  subscription: "$sub_project",
  hide: true
})
.addTarget({
  refId: "H",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Monitor",
  azureMonitor: {
    aggregation: "Total",
    alias: "Service Bus Requests 2",
    allowedTimeGrainsMs: [
      60000,
      300000,
      900000,
      1800000,
      3600000,
      21600000,
      43200000,
      86400000
    ],
    metricName: "IncomingMessages",
    metricNamespace: "$ns_servicebus",
    region: "",
    resources: [
      {
        metricNamespace: "$ns_servicebus",
        region: "",
        resourceGroup: "$rg_project",
        resourceName: "$resource_servicebus2",
        subscription: "$sub_project"
      }
    ],
    timeGrain: "auto"
  },
  subscription: "$sub_project",
  hide: true
})
.addTarget({
  refId: "I",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Monitor",
  azureMonitor: {
    aggregation: "Total",
    alias: "Service Bus Requests 3",
    allowedTimeGrainsMs: [
      60000,
      300000,
      900000,
      1800000,
      3600000,
      21600000,
      43200000,
      86400000
    ],
    metricName: "IncomingMessages",
    metricNamespace: "$ns_servicebus",
    region: "",
    resources: [
      {
        metricNamespace: "$ns_servicebus",
        region: "",
        resourceGroup: "$rg_project",
        resourceName: "$resource_servicebus3",
        subscription: "$sub_project"
      }
    ],
    timeGrain: "auto"
  },
  subscription: "$sub_project",
  hide: true
})
.addTarget({
  refId: "J",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Monitor",
  azureMonitor: {
    aggregation: "Total",
    alias: "Service Bus Requests 4",
    allowedTimeGrainsMs: [
      60000,
      300000,
      900000,
      1800000,
      3600000,
      21600000,
      43200000,
      86400000
    ],
    metricName: "IncomingMessages",
    metricNamespace: "$ns_servicebus",
    region: "",
    resources: [
      {
        metricNamespace: "$ns_servicebus",
        region: "",
        resourceGroup: "$rg_project",
        resourceName: "$resource_servicebus4",
        subscription: "$sub_project"
      }
    ],
    timeGrain: "auto"
  },
  subscription: "$sub_project",
  hide: true
})
.addOverridesByFieldName(
  field='C',
  properties=[
    { id: 'unit' },
    { id: 'displayName', value: 'Service Bus Requests' }
  ]
);

local TrankingSource = grafana.tablePanel.new(
  title="Tracking APIM to Standardized Zone Difference",
  datasource='-- Mixed --',
  description="This table panel displays the details of tracking APIM to standardized zone difference.",
)
.addTarget({
  refId: "B",
  datasource: {
    type: "datasource",
    uid: "Azure SQL Server"
  },
  rawMode: true,
  format: "table",
  rawQuery: true,
  rawSql: "
    SELECT
        FORMAT(DATEADD(SECOND, MAX([timestamp]), '1970-01-01'), 'yyyy-MM-dd') AS [TransactionDate],
        REPLACE(dataset_name, '_', '') AS [Dataset Name],
        'Source To Target Perfect Match' AS [Threshold],
        COUNT(*) AS [Standardized Record Count]
    FROM
        [observability].[event]
    WHERE
        project_name LIKE '%apmea%'
        AND landing_zone = 'standardized'
        AND metric_name = 'processing_exit_code'
        AND event_type = 'processingfinished'
        AND metric_value = 0
        AND [timestamp] BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
    GROUP BY
        dataset_name
    ORDER BY
        FORMAT(DATEADD(SECOND, MAX([timestamp]), '1970-01-01'), 'yyyy-MM-dd');",
    query: {
    alias: "Standardized Requests",
    format: "table",
    rawEditor: true,
    rawQuery: true,
    rawSql: "
      SELECT
          FORMAT(DATEADD(SECOND, MAX([timestamp]), '1970-01-01'), 'yyyy-MM-dd') AS [TransactionDate],
          REPLACE(dataset_name, '_', '') AS [Dataset Name],
          'Source To Target Perfect Match' AS [Threshold],
          COUNT(*) AS [Standardized Record Count]
      FROM
          [observability].[event]
      WHERE
          project_name LIKE '%apmea%'
          AND landing_zone = 'standardized'
          AND metric_name = 'processing_exit_code'
          AND event_type = 'processingfinished'
          AND metric_value = 0
          AND [timestamp] BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
      GROUP BY
          dataset_name
      ORDER BY
          FORMAT(DATEADD(SECOND, MAX([timestamp]), '1970-01-01'), 'yyyy-MM-dd');",
      }
})
.addTarget({
  refId: "B",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project2/providers/$ns_appinsights/$appinsights_project2"
    ],
    query: |||
      let correlationIds = split("$correlationid", ",");
      requests
      | where $__timeFilter(timestamp)
      | where success == "True"
      | where tostring(customDimensions.["Request-x-region"]) in ($region)
      | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
      | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
      | where tostring(customDimensions["API Name"]) has_any ($apiName)
      | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
      | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
      | where isnotempty(idempotencykey)
      | summarize latest_timestamp = max(timestamp) by idempotencykey
      | summarize APIM_Record_Count = count(), stamp = max(latest_timestamp) by bin(latest_timestamp, 1d)
      | project TransactionDate = format_datetime(stamp, "yyyy-MM-dd"), APIM_Record_Count
      | order by TransactionDate desc
    |||
  }
})
.addOverridesByFieldName(field='Difference',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'red',value: ''}]}},{id: 'mappings',value: [{options: {from: 0,result: {color: 'green',index: 1},to: 0}, type: 'range'}]}])
  {
  transformations: [
    {
      id: 'joinByField',
      options: {
        byField: 'TransactionDate',
        mode: 'outerTabular',
      },
    },
    {
      id: 'calculateField',
      options: {
        alias: 'Difference',
        binary: {
          left: 'APIM_Record_Count',
          operator: '-',
          right: 'Standardized Record Count',
        },
        mode: 'binary',
        reduce: {
          reducer: 'sum',
        },
      },
    },
  ],
}
{   
  options: {
    showHeader: true,
    cellHeight: "sm",
    footer: {
    show: false,
    reducer: [
      "sum"
    ],
    countRows: false,
    fields: ""
    }
  }
};

local TrankingSourceAPIMtoAZ = grafana.tablePanel.new(
  title="Tracking APIM to Azure Function Difference",
  datasource='-- Mixed --',
  description="This table panel displays the details of tracking APIM to azure function difference.",
)
.addTarget({
  refId: "A",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project2/providers/$ns_appinsights/$appinsights_project2"
    ],
    query: |||
      let correlationIds = split("$correlationid", ",");
      requests
      | where $__timeFilter(timestamp)
      | where success == "True"
      | where tostring(customDimensions.["Request-x-region"]) in ($region)
      | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
      | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
      | where tostring(customDimensions["API Name"]) has_any ($apiName)
      | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
      | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
      | where isnotempty(idempotencykey)
      | summarize latest_timestamp = max(timestamp) by idempotencykey
      | summarize APIM_Record_Count = count(), stamp = max(latest_timestamp) by bin(latest_timestamp, 1d)
      | project TransactionDate = format_datetime(stamp, "yyyy-MM-dd"), APIM_Record_Count
      | order by TransactionDate desc
    |||
  }
})
.addTarget({
  refId: "B",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"
    ],
    query: |||
      let correlationIds = split("$correlationid", ",");
      AppTraces
      | where $__timeFilter(TimeGenerated) 
      | where AppRoleName in ($functionApp)
      | where isnotempty(Message)
      | extend msgjson = parse_json(Message)
      | extend correlationId   = tostring(msgjson.x_correlation_id)
            , idempotancyKey   = tostring(msgjson.x_idempotency_key)
            , countryOrigin   = tostring(msgjson.x_country_of_origin)
            , region          = tostring(msgjson.x_region)
            , sourceAppId     = tostring(msgjson.x_source_application_id)
            , statusCode      = tostring(msgjson.status_code)
      | where isnotempty(correlationId)
      | where isnotempty(idempotancyKey)
      | where isempty("$correlationid") or correlationId in~ (correlationIds)
      | where countryOrigin in ($country)
      | where region in ($region)
      | where sourceAppId in ($source)
      | where statusCode == "200"
      | summarize latest_timestamp = max(TimeGenerated) by idempotancyKey
      | summarize Azure_Function_record_count = count(), stamp = max(latest_timestamp) by bin(latest_timestamp, 1d)
      | project TransactionDate = format_datetime(latest_timestamp, "yyyy-MM-dd"), Azure_Function_record_count
      | order by TransactionDate desc
    |||
  }
})
.addOverridesByFieldName(field='Difference',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'red',value: ''}]}},{id: 'mappings',value: [{options: {from: 0,result: {color: 'green',index: 1},to: 0}, type: 'range'}]}])
  {
  transformations: [
    {
      id: 'joinByField',
      options: {
        byField: 'TransactionDate',
        mode: 'inner',
      },
    },
    {
      id: 'calculateField',
      options: {
        alias: 'Difference',
        binary: {
          left: 'APIM_Record_Count',
          operator: '-',
          right: 'Azure_Function_record_count',
        },
        mode: 'binary',
        reduce: {
          reducer: 'sum',
        },
      },
    },
  ],
}
{   
  options: {
    showHeader: true,
    cellHeight: "sm",
    footer: {
    show: false,
    reducer: [
      "sum"
    ],
    countRows: false,
    fields: ""
    }
  }
};

############################ Status ############################

local ApimLastRequest = statPanel.new(
    title="APIM: Last Request",
    datasource='AzureMonitor',
    description="This panel displays the last request time send to APIM",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields="/.*/",
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | summarize tostring(format_datetime(max(timestamp),'yyyy-MM-dd HH:mm:ss'))
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project2/providers/$ns_appinsights/$appinsights_project2"],
	resultFormat= 'logs'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/.*/"
      },
      graphMode: "none",
    }
};
local ApimLastSucessRequest = statPanel.new(
    title="APIM: Number of Successful Requests",
    datasource='AzureMonitor',
    description="This panel displays the number of successful requests in APIM",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where success == "True"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey
        | summarize Total_Success = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project2/providers/$ns_appinsights/$appinsights_project2"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};
local ApimLastFailedRequest = statPanel.new(
    title="APIM: Number of Failed Requests",
    datasource='AzureMonitor',
    description="This panel displays the number of failed requests in APIM",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": null,
      },
  ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where success != "True"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey
        | summarize Total_Failed = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project2/providers/$ns_appinsights/$appinsights_project2"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};

local AzfLastRun = statPanel.new(
    title="Azure Function: Last Run",
    datasource='AzureMonitor',
    description="This panel displays the last run time for Azure Function",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields="/.*/"
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        AppTraces
        | where $__timeFilter(TimeGenerated) 
        | where AppRoleName in ($functionApp)
        | where isnotempty(Message)
        | extend msgjson = parse_json(Message)
        | extend correlationId   = tostring(msgjson.x_correlation_id)
              , idempotancyKey   = tostring(msgjson.x_idempotency_key)
              , countryOrigin   = tostring(msgjson.x_country_of_origin)
              , region          = tostring(msgjson.x_region)
              , sourceAppId     = tostring(msgjson.x_source_application_id)
              , statusCode      = tostring(msgjson.status_code)
        | where isnotempty(correlationId)
        | where isnotempty(idempotancyKey)
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where countryOrigin in ($country)
        | where region in ($region)
        | where sourceAppId in ($source)
        | summarize tostring(format_datetime(max(TimeGenerated),'yyyy-MM-dd HH:mm:ss'))
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"],
	resultFormat= 'logs'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/.*/"
      },
      graphMode: "none",
    }
};
local AzfLastSuccessRun = statPanel.new(
    title="Azure Function: Number of Successful Run",
    datasource='AzureMonitor',
    description="This panel displays the number of successful run in Azure Function",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        AppTraces
        | where $__timeFilter(TimeGenerated) 
        | where AppRoleName in ($functionApp)
        | where isnotempty(Message)
        | extend msgjson = parse_json(Message)
        | extend correlationId   = tostring(msgjson.x_correlation_id)
              , idempotancyKey   = tostring(msgjson.x_idempotency_key)
              , countryOrigin   = tostring(msgjson.x_country_of_origin)
              , region          = tostring(msgjson.x_region)
              , sourceAppId     = tostring(msgjson.x_source_application_id)
              , statusCode      = tostring(msgjson.status_code)
        | where isnotempty(correlationId)
        | where isnotempty(idempotancyKey)
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where countryOrigin in ($country)
        | where region in ($region)
        | where sourceAppId in ($source)
        | where statusCode == "200"
        | summarize latest_timestamp = max(TimeGenerated) by idempotancyKey
        | summarize Successcount = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};

local AzfLastFailedRun = statPanel.new(
    title="Azure Function: Number of Failed Run",
    datasource='AzureMonitor',
    description="This panel displays the number of failed run in Azure Function",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": null,
      }
  ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        AppTraces
        | where $__timeFilter(TimeGenerated) 
        | where AppRoleName in ($functionApp)
        | where isnotempty(Message)
        | extend msgjson = parse_json(Message)
        | extend correlationId   = tostring(msgjson.x_correlation_id)
              , idempotancyKey   = tostring(msgjson.x_idempotency_key)
              , countryOrigin   = tostring(msgjson.x_country_of_origin)
              , region          = tostring(msgjson.x_region)
              , sourceAppId     = tostring(msgjson.x_source_application_id)
              , statusCode      = tostring(msgjson.status_code)
        | where isnotempty(correlationId)
        | where isnotempty(idempotancyKey)
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where countryOrigin in ($country)
        | where region in ($region)
        | where sourceAppId in ($source)
        | where statusCode != "200"
        | summarize latest_timestamp = max(TimeGenerated) by idempotancyKey
        | summarize Failedcount = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};

local ServiceBusLastIncomingMessages = statPanel.new(
    title="ServiceBus: Last Incoming Messages",
    datasource='AzureMonitor',
    description="This panel displays the last incoming messages time for ServiceBus",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields='/^Time$/'
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='None',
    metricName='IncomingMessages',
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus1",
    subscription="$sub_project",
    alias="Incoming Messages 1",
   )
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='None',
    metricName='IncomingMessages',
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus2",
    subscription="$sub_project",
    alias="Incoming Messages 2",
   )
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='None',
    metricName='IncomingMessages',
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus3",
    subscription="$sub_project",
    alias="Incoming Messages 3",
   )
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='None',
    metricName='IncomingMessages',
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus4",
    subscription="$sub_project",
    alias="Incoming Messages 4",
  )
)
{
  "transformations": [
    {
      "id": "calculateField",
      "options": {
        "mode": "reduceRow",
        "reduce": {
          "reducer": "lastNotNull",
          "include": [
            "Incoming Messages 1",
            "Incoming Messages 2",
            "Incoming Messages 3",
            "Incoming Messages 4"
          ]
        },
        "replaceFields": true
      }
    }
  ]
}
{
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};
local ServiceBusLastOutgoingMessages = statPanel.new(
    title="ServiceBus: Last Outgoing Messages",
    datasource='AzureMonitor',
    description="This panel displays the last outgoing messages time for ServiceBus",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields='/^Time$/'
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='None',
    metricName='OutgoingMessages',
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus1",
    subscription="$sub_project",
    alias="Outgoing Messages 1",
   )
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='None',
    metricName='OutgoingMessages',
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus2",
    subscription="$sub_project",
    alias="Outgoing Messages 2",
   )
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='None',
    metricName='OutgoingMessages',
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus3",
    subscription="$sub_project",
    alias="Outgoing Messages 3",
   )
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='None',
    metricName='OutgoingMessages',
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus4",
    subscription="$sub_project",
    alias="Outgoing Messages 4",
  )
)
{
  "transformations": [
    {
      "id": "calculateField",
      "options": {
        "mode": "reduceRow",
        "reduce": {
          "reducer": "lastNotNull",
          "include": [
            "Outgoing Messages 1",
            "Outgoing Messages 2",
            "Outgoing Messages 3",
            "Outgoing Messages 4"
          ]
        },
        "replaceFields": true
      }
    }
  ]
}
{
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};

local ServiceBusUserErrors = statPanel.new(
    title="ServiceBus: User Errors",
    datasource='AzureMonitor',
    description="This panel displays the number of user errors in ServiceBus",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": null,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='Total',
    metricName='UserErrors',
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus1",
    subscription="$sub_project",
    alias="User Errors 1",
   )
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='Total',
    metricName='UserErrors',
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus2",
    subscription="$sub_project",
    alias="User Errors 2",
   )
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='Total',
    metricName='UserErrors',
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus3",
    subscription="$sub_project",
    alias="User Errors 3",
   )
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='Total',
    metricName='UserErrors',
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus4",
    subscription="$sub_project",
    alias="User Errors 4",
   )
){
  "transformations": [
    {
      "id": "calculateField",
      "options": {
        "mode": "reduceRow",
        "reduce": {
          "reducer": "sum",
          "include": [
            "User Errors 1",
            "User Errors 2",
            "User Errors 3",
            "User Errors 4"
          ]
        },
        "binary": {
          "left": "User Errors 1",
          "right": "User Errors 2"
        },
        "replaceFields": true
      }
    }
  ]
} 
{
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    },
};

local LandingLastSuccessIngestion =
  statPanel.new(
    title="Landing Zone: Last Successful Ingestion",
    fields='/^Time$/',
    datasource='Azure SQL Server',
    description="This panel displays the last successful ingestion time for landing zone",
    ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT
              top(1)
              DATEADD(SECOND, MAX([timestamp]), '1970-01-01')
          FROM
              [observability].[event]
          WHERE
            project_name LIKE '%apmea%'
            AND landing_zone IN ('landing')
            AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
            AND metric_name IN ('processing_finished_date')
            ",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};
local LandingSuccessCount =
  statPanel.new(
    title="Landing Zone: Total Successful Records",
    datasource='Azure SQL Server',
    description="This panel displays the total number of successful records in landing zone",
    colorMode='background'
    ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT
        count(*) AS [Landing Zone Requests]               
        FROM [observability].[event]
        WHERE project_name LIKE '%apmea%'
            AND landing_zone IN ('landing')
            AND metric_name='processing_exit_code'
            AND event_type='processingfinished'
            AND metric_value=0
            AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: ""
      },
      graphMode: "none",
    }
};

local HistoryLastSuccessIngestion =
  statPanel.new(
    title="History Zone: Last Successful Ingestion",
    fields='/^Time$/',
    datasource='Azure SQL Server',
    description="This panel displays the last successful ingestion time for history zone",
    ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT
              top(1)
              DATEADD(SECOND, MAX([timestamp]), '1970-01-01')
          FROM
              [observability].[event]
          WHERE
            project_name LIKE '%apmea%'
            AND landing_zone IN ('history')
            AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
            AND metric_name IN ('processing_finished_date')
            ",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};
local HistorySuccessCount =
  statPanel.new(
    title="History Zone: Total Successful Records",
    datasource='Azure SQL Server',
    description="This panel displays the total number of successful records in history zone",
    colorMode='background'
    ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT
        count(*) AS [History Zone Requests]               
        FROM [observability].[event]
        WHERE project_name LIKE '%apmea%'
            AND landing_zone IN ('history')
            AND metric_name='processing_exit_code'
            AND event_type='processingfinished'
            AND metric_value=0
            AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: ""
      },
      graphMode: "none",
    }
};

local StandardizedLastSuccessIngestion =
  statPanel.new(
    title="Standardized Zone: Last Successful Ingestion",
    fields='/^Time$/',
    datasource='Azure SQL Server',
    description="This panel displays the last successful ingestion time for standardized zone",
    ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT
              top(1)
              DATEADD(SECOND, MAX([timestamp]), '1970-01-01')
          FROM
              [observability].[event]
          WHERE
            project_name LIKE '%apmea%'
            AND landing_zone IN ('standardized')
            AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
            AND metric_name IN ('processing_finished_date')
            ",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};
local StandardizedSuccessCount =
  statPanel.new(
    title="Standardized Zone: Total Successful Records",
    datasource='Azure SQL Server',
    description="This panel displays the total number of successful records in standardized zone",
    colorMode='background'
    ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT
        count(*) AS [Standardized Zone Requests]               
        FROM [observability].[event]
        WHERE project_name LIKE '%apmea%'
            AND landing_zone IN ('standardized')
            AND metric_name='processing_exit_code'
            AND event_type='processingfinished'
            AND metric_value=0
            AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: ""
      },
      graphMode: "none",
    }
};

local Status = row.new(title="Status", collapse=true)
    .addPanel(ApimLastRequest,gridPos={h: 3, w: 8, x: 0, y: 19})
    .addPanel(ApimLastSucessRequest,gridPos={h: 3, w: 8, x: 8, y: 19})
    .addPanel(ApimLastFailedRequest,gridPos={h: 3, w: 8, x: 16, y: 19})
    .addPanel(AzfLastRun,gridPos={h: 3, w: 8, x: 0, y: 22})
    .addPanel(AzfLastSuccessRun,gridPos={h: 3, w: 8, x: 8, y: 22})
    .addPanel(AzfLastFailedRun,gridPos={h: 3, w: 8, x: 16, y: 22})
    .addPanel(ServiceBusLastIncomingMessages,gridPos={h: 3, w: 8, x: 0, y: 25})
    .addPanel(ServiceBusLastOutgoingMessages,gridPos={h: 3, w: 8, x: 8, y: 25})
    .addPanel(ServiceBusUserErrors,gridPos={h: 3, w: 8, x: 16, y: 25})
    .addPanel(LandingLastSuccessIngestion,gridPos={h: 3, w: 12, x: 0, y: 28})
    .addPanel(LandingSuccessCount,gridPos={h: 3, w: 12, x: 12, y: 28})
    .addPanel(HistoryLastSuccessIngestion,gridPos={h: 3, w: 12, x: 0, y: 31})
    .addPanel(HistorySuccessCount,gridPos={h: 3, w: 12, x: 12, y: 31})
    .addPanel(StandardizedLastSuccessIngestion,gridPos={h: 3, w: 12, x: 0, y: 34})
    .addPanel(StandardizedSuccessCount,gridPos={h: 3, w: 12, x: 12, y: 34});

############################ APIM ############################

local ApiTotalRequests = grafana.graphPanel.new(
    title="Total API Requests",
    datasource='AzureMonitor',
    description="This panel displays the total number of requests in APIM using Timeseries",
    fill=0,
    points=true,
    pointradius=5,
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
      let correlationIds = split("$correlationid", ",");
      requests
      | where $__timeFilter(timestamp)
      | where isnotempty(customDimensions)
      | where customDimensions has "API Name"
      | where tostring(customDimensions.["Request-x-region"]) in ($region)
      | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
      | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
      | where tostring(customDimensions["API Name"]) has_any ($apiName)
      | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
      | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
      | extend lastpart = tostring(customDimensions["API Name"])
      | where isnotempty(idempotencykey)
      | summarize latest_timestamp = max(timestamp) by idempotencykey, lastpart
      | summarize totalrequests = count() by bin(latest_timestamp, 5m), lastpart
      | order by latest_timestamp asc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project2/providers/$ns_appinsights/$appinsights_project2"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          __systemRef: "hideSeriesFrom",
          matcher: {
            id: "byNames",
            options: {
              mode: "exclude",
              names: [
                "totalrequests"
              ],
              prefix: "All except:",
              readOnly: true
            }
          },
          properties: [
            {
              id: "custom.hideFrom",
              value: {
                legend: false,
                tooltip: false,
                viz: true
              }
            }
          ]
        },
        {
          matcher: {
            id: "byName",
            options: "totalrequests"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "blue",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local ApiRequestNumberByAPIName = grafana.barChart.new(
    title="Requests by API Name",
    description='This panel displays the total number of requests by API name in APIM using barchart',
    datasource='AzureMonitor',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where isnotempty(customDimensions)
        | where customDimensions has "API Name"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | extend lastpart = tostring(customDimensions["API Name"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey, lastpart
        | summarize totalrequests = count() by lastpart
        | order by totalrequests desc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project2/providers/$ns_appinsights/$appinsights_project2"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "totalrequests"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "blue",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local ApiRequests = grafana.graphPanel.new(
    title="Requests (Successful & Failed)",
    datasource='AzureMonitor',
    description="This panel displays the total number of requests in APIM using Timeseries",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | extend lastpart = tostring(customDimensions["API Name"])
        | where isnotempty(idempotencykey)
        | extend ResultType = iff(success == true, "success", "Failure")
        | summarize latest_timestamp = max(timestamp) by idempotencykey, lastpart, ResultType
        | summarize totalrequests = count() by ResultType, bin(latest_timestamp, 5m)
        | order by latest_timestamp asc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project2/providers/$ns_appinsights/$appinsights_project2"],
	resultFormat= 'time_series'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "totalrequests success"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "green",
                mode: "fixed"
              }
            }
          ]
        },
        {
          matcher: {
            id: "byName",
            options: "totalrequests Failure"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "red",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local ApiRequestByStatusCode = grafana.pieChartPanel.new(
    title="Request by Status Code",
    datasource='AzureMonitor',
    description="This panel displays the request by status code using pie chart",
    legendType="Right side",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests 
        | where $__timeFilter(timestamp)
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | extend lastpart = tostring(customDimensions["API Name"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey, resultCode 
        | summarize Count=count() by resultCode
        | evaluate pivot(resultCode, sum(Count))
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project2/providers/$ns_appinsights/$appinsights_project2"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "right",
      calcs: [],
      values: [
          "value", "percent"
        ]
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "401"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "red",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local ApimLastFailedRequestTable = tablePanel.new(
    title="Last Failed APIM Events",
    datasource='AzureMonitor',
    description="This panel displays the table of failed requests of each timestamp with their resultCode, duration, API Name, RequestSize, Correlation ID and IdemopotencyKey in a table format",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where success == False
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | project timestamp, resultCode, duration, APIName=customDimensions["API Name"], RequestSize=customMeasurements.["Request Size"], CorrelationId=customDimensions.["Request-x-correlation-id"], IdempotencyKey=customDimensions.["Request-x-idempotency-key"]
        | order by timestamp desc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project2/providers/$ns_appinsights/$appinsights_project2"],
	resultFormat= 'logs'
  )
){
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "APIName"
          },
          properties: [
            {
              id: "custom.width",
              value: 284
            }
          ]
        }
      ]
  }
};

local ApiLogs = logPanel.new(
    title="API Unique Idempotency Key Error logs",
    datasource='AzureMonitor',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
      let correlationIds = split("$correlationid", ",");
      requests
      | where $__timeFilter(timestamp)
      | where success == "False"
      | where customDimensions has "API Name"
      | where tostring(customDimensions.["Request-x-region"]) in ($region)
      | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
      | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
      | where tostring(customDimensions["API Name"]) has_any ($apiName)
      | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
      | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
      | where isnotempty(idempotencykey)
      | extend statuscode = resultCode
      | where statuscode != 200
      | order by timestamp desc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project2/providers/$ns_appinsights/$appinsights_project2"],
	resultFormat= 'logs'
  )
);

local APIM = row.new(title="APIM", collapse=true)
    .addPanel(ApiTotalRequests,gridPos={h: 8, w: 24, x: 0, y: 10})
    .addPanel(ApiRequestNumberByAPIName,gridPos={h: 8, w: 24, x: 0, y: 18})
    .addPanel(ApiRequests,gridPos={h: 8, w: 24, x: 0, y: 26})
    .addPanel(ApiRequestByStatusCode,gridPos={h: 8, w: 24, x: 0, y: 32})
    .addPanel(ApimLastFailedRequestTable,gridPos={h: 8, w: 24, x: 0, y: 40})
    .addPanel(ApiLogs,gridPos={h: 8, w: 24, x: 0, y: 48});

############################ Azure Function ############################

local AZTotalRequests = grafana.graphPanel.new(
    title="Total Azure Function Requests",
    datasource='AzureMonitor',
    description="This panel displays the total number of requests in Azure Function using Timeseries",
    fill=0,
    points=true,
    pointradius=5,
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        AppTraces
        | where $__timeFilter(TimeGenerated) 
        | where AppRoleName in ($functionApp)
        | where isnotempty(Message)
        | extend msgjson = parse_json(Message)
        | extend correlationId   = tostring(msgjson.x_correlation_id)
              , idempotancyKey   = tostring(msgjson.x_idempotency_key)
              , countryOrigin   = tostring(msgjson.x_country_of_origin)
              , region          = tostring(msgjson.x_region)
              , sourceAppId     = tostring(msgjson.x_source_application_id)
              , statusCode      = tostring(msgjson.status_code)
        | where isnotempty(correlationId)
        | where isnotempty(idempotancyKey)
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where countryOrigin in ($country)
        | where region in ($region)
        | where sourceAppId in ($source)
        | summarize latest_timestamp = max(TimeGenerated) by idempotancyKey
        | summarize totalrequests = count() by bin(latest_timestamp, 5m)
        | order by latest_timestamp asc 
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "totalrequests"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "blue",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local AZRequests = grafana.barChart.new(
    title="Run by day (Failed & Successful)",
    datasource='AzureMonitor',
    description="This panel displays the number of run by day",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        AppTraces
        | where $__timeFilter(TimeGenerated) 
        | where AppRoleName in ($functionApp)
        | where isnotempty(Message)
        | extend msgjson = parse_json(Message)
        | extend correlationId   = tostring(msgjson.x_correlation_id)
              , idempotancyKey   = tostring(msgjson.x_idempotency_key)
              , countryOrigin   = tostring(msgjson.x_country_of_origin)
              , region          = tostring(msgjson.x_region)
              , sourceAppId     = tostring(msgjson.x_source_application_id)
              , statusCode      = tostring(msgjson.status_code)
        | where isnotempty(correlationId)
        | where isnotempty(idempotancyKey)
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where countryOrigin in ($country)
        | where region in ($region)
        | where sourceAppId in ($source)
        | summarize latest_timestamp = max(TimeGenerated) by idempotancyKey
        | summarize RunNumber=count() by format_datetime(latest_timestamp,'MM/dd/yyyy')
        | order by latest_timestamp asc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "totalrequests"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "blue",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local AZDuplicateSuccessRequest = tablePanel.new(
    title="Duplicate key by Day",
    datasource='AzureMonitor',
    description="This panel displays the duplicate key by day",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        AppTraces
        | where $__timeFilter(TimeGenerated) 
        | where AppRoleName in ($functionApp)
        | where isnotempty(Message)
        | extend msgjson = parse_json(Message)
        | extend correlationId   = tostring(msgjson.x_correlation_id)
              , idempotancyKey   = tostring(msgjson.x_idempotency_key)
              , countryOrigin   = tostring(msgjson.x_country_of_origin)
              , region          = tostring(msgjson.x_region)
              , sourceAppId     = tostring(msgjson.x_source_application_id)
              , statusCode      = tostring(msgjson.status_code)
        | where isnotempty(correlationId)
        | where isnotempty(idempotancyKey)
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where countryOrigin in ($country)
        | where region in ($region)
        | where sourceAppId in ($source)
        | summarize Count=count() by idempotancyKey , format_datetime(TimeGenerated,'MM/dd/yyyy')
        | where Count > 1
        | order by TimeGenerated desc   
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"],
	resultFormat= 'logs'
  )
);

local AZRequestByStatusCode = grafana.pieChartPanel.new(
    title="Request by Status Code",
    datasource='AzureMonitor',
    description="This panel displays the request by status code using pie chart",
    legendType="Right side",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        AppTraces
        | where $__timeFilter(TimeGenerated) 
        | where AppRoleName in ($functionApp)
        | where isnotempty(Message)
        | extend msgjson = parse_json(Message)
        | extend correlationId   = tostring(msgjson.x_correlation_id)
              , idempotancyKey   = tostring(msgjson.x_idempotency_key)
              , countryOrigin   = tostring(msgjson.x_country_of_origin)
              , region          = tostring(msgjson.x_region)
              , sourceAppId     = tostring(msgjson.x_source_application_id)
              , statusCode      = tostring(msgjson.status_code)
        | where isnotempty(correlationId)
        | where isnotempty(idempotancyKey)
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where countryOrigin in ($country)
        | where region in ($region)
        | where sourceAppId in ($source)
        | where statusCode == "200"
        | summarize latest_timestamp = max(TimeGenerated) by idempotancyKey, statusCode
        | summarize Count=count() by statusCode
        | evaluate pivot(statusCode, sum(Count)) 
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "right",
      calcs: [],
      values: [
          "value", "percent"
        ]
    }
  }
};

local AZLogs = logPanel.new(
    title="Azure Function Error logs",
    datasource='AzureMonitor',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||    
      let correlationIds = split("$correlationid", ",");
      AppTraces
      | where $__timeFilter(TimeGenerated) 
      | where AppRoleName in ($functionApp)
      | where isnotempty(Message)
      | extend msgjson = parse_json(Message)
      | extend correlationId   = tostring(msgjson.x_correlation_id)
            , idempotancyKey   = tostring(msgjson.x_idempotency_key)
            , countryOrigin   = tostring(msgjson.x_country_of_origin)
            , region          = tostring(msgjson.x_region)
            , sourceAppId     = tostring(msgjson.x_source_application_id)
            , statusCode      = tostring(msgjson.status_code)
      | where isnotempty(correlationId)
      | where isnotempty(idempotancyKey)
      | where isnotempty(statusCode)
      | where isempty("$correlationid") or correlationId in~ (correlationIds)
      | where statusCode startswith "4" or statusCode startswith "5"
      | order by TimeGenerated desc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"],
	resultFormat= 'logs'
  )
);

local AzureFunction = row.new(title="Azure Function", collapse=true)
    .addPanel(AZTotalRequests,gridPos={h: 8, w: 24, x: 0, y: 2})
    .addPanel(AZRequests,gridPos={h: 8, w: 12, x: 0, y: 19})
    .addPanel(AZDuplicateSuccessRequest,gridPos={h: 8, w: 12, x: 12, y: 19})
    .addPanel(AZRequestByStatusCode,gridPos={h: 8, w: 12, x: 0, y: 27})
    .addPanel(AZLogs,gridPos={h: 8, w: 12, x: 12, y: 27});

############################ Service Bus Finance and HR ############################

local ServiceBusIncommingMessagesFH = grafana.graphPanel.new(
    title="Total Incoming Messages",
    datasource='AzureMonitor',
    description="This panel displays the total incoming messages graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='IncomingMessages',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus1",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
 ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='IncomingMessages',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus2",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusOutgoingMessagesFH = grafana.graphPanel.new(
    title="Total Outgoing Messages",
    datasource='AzureMonitor',
    description="This panel displays the total outgoing messages  graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='OutgoingMessages',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus1",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
 ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='OutgoingMessages',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus2",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusSuccessfulRequestsFH = grafana.graphPanel.new(
    title="Total Successful Requests",
    datasource='AzureMonitor',
    description="This panel displays the total successful requests graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='SuccessfulRequests',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus1",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='SuccessfulRequests',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus2",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
  )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusCompleteMessageFH = grafana.graphPanel.new(
    title="Complete Messages ",
    datasource='AzureMonitor',
    description="This panel displays the total complete messages graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='CompleteMessage',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus1",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
  ).addTarget(
    target=grafana.azuremonitor.target(
      queryType='Azure Monitor',
      metricName='CompleteMessage',
      aggregation='Total',
      subscription="$sub_project",
      metricNamespace="$ns_servicebus",
      resourceGroup="$rg_project",
      resourceName="$resource_servicebus2",
      dimension="EntityName",
      dimensionOperator="eq",
      dimensionFilters="*",
  )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusActiveMessagesFH = grafana.graphPanel.new(
    title="Count of Active Messages in a Queue",
    datasource='AzureMonitor',
    description="This panel displays the count of active messages in a queue graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='ActiveMessages',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus1",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='ActiveMessages',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus2",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
  )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusScheduledMessagesFH = grafana.graphPanel.new(
    title="Count of Scheduled Messages in a Queue",
    datasource='AzureMonitor',
    description="This panel displays the count of scheduled messages in a queue graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='ScheduledMessages',
    aggregation='Average',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus1",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='ScheduledMessages',
    aggregation='Average',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus2",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
  )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusCountOfUserErrorsFH= grafana.pieChartPanel.new(
    title="Count Of User Errors",
    datasource='AzureMonitor',
    description="This panel displays the count of user errors graph for EventHub using Pie Chart",
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='UserErrors',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus1",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='UserErrors',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus2",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
  )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "right",
        values: [
          "value", "percent"
        ]
      }
    }
};
local ServiceBusAverageRequestSizeFH = grafana.graphPanel.new(
    title="Average Request Size",
    datasource='AzureMonitor',
    description="This panel displays the average request size graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='Size',
    aggregation='Average',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus1",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='Size',
    aggregation='Average',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus2",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
  )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};

local ServiceBusFH = row.new(title="Service Bus - Finance & Hr", collapse=true)
    .addPanel(ServiceBusIncommingMessagesFH,gridPos={h: 8, w: 12, x: 0, y:12})
    .addPanel(ServiceBusOutgoingMessagesFH,gridPos={h: 8, w: 12, x: 12, y: 12})
    .addPanel(ServiceBusSuccessfulRequestsFH,gridPos={h: 8, w: 12, x: 0, y: 20})
    .addPanel(ServiceBusCompleteMessageFH,gridPos={h: 8, w: 12, x: 12, y: 20})
    .addPanel(ServiceBusActiveMessagesFH,gridPos={h: 8, w: 12, x: 0, y: 28})
    .addPanel(ServiceBusScheduledMessagesFH,gridPos={h: 8, w: 12, x: 12, y: 28})
    .addPanel(ServiceBusCountOfUserErrorsFH,gridPos={h: 8, w: 12, x: 0, y: 36})
    .addPanel(ServiceBusAverageRequestSizeFH,gridPos={h: 8, w: 12, x: 12, y: 36});

############################ Service Bus Food and supply############################

local ServiceBusIncommingMessages = grafana.graphPanel.new(
    title="Total Incoming Messages",
    datasource='AzureMonitor',
    description="This panel displays the total incoming messages graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='IncomingMessages',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus3",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
 ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='IncomingMessages',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus4",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusOutgoingMessages = grafana.graphPanel.new(
    title="Total Outgoing Messages",
    datasource='AzureMonitor',
    description="This panel displays the total outgoing messages  graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='OutgoingMessages',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus3",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
 ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='OutgoingMessages',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus4",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusSuccessfulRequests = grafana.graphPanel.new(
    title="Total Successful Requests",
    datasource='AzureMonitor',
    description="This panel displays the total successful requests graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='SuccessfulRequests',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus3",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='SuccessfulRequests',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus4",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
  )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusCompleteMessage = grafana.graphPanel.new(
    title="Complete Messages ",
    datasource='AzureMonitor',
    description="This panel displays the total complete messages graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='CompleteMessage',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus3",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
  ).addTarget(
    target=grafana.azuremonitor.target(
      queryType='Azure Monitor',
      metricName='CompleteMessage',
      aggregation='Total',
      subscription="$sub_project",
      metricNamespace="$ns_servicebus",
      resourceGroup="$rg_project",
      resourceName="$resource_servicebus4",
      dimension="EntityName",
      dimensionOperator="eq",
      dimensionFilters="*",
  )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusActiveMessages = grafana.graphPanel.new(
    title="Count of Active Messages in a Queue",
    datasource='AzureMonitor',
    description="This panel displays the count of active messages in a queue graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='ActiveMessages',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus3",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='ActiveMessages',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus4",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
  )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusScheduledMessages = grafana.graphPanel.new(
    title="Count of Scheduled Messages in a Queue",
    datasource='AzureMonitor',
    description="This panel displays the count of scheduled messages in a queue graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='ScheduledMessages',
    aggregation='Average',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus3",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='ScheduledMessages',
    aggregation='Average',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus4",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
  )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusCountOfUserErrors= grafana.pieChartPanel.new(
    title="Count Of User Errors",
    datasource='AzureMonitor',
    description="This panel displays the count of user errors graph for EventHub using Pie Chart",
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='UserErrors',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus3",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='UserErrors',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus4",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
  )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "right",
        values: [
          "value", "percent"
        ]
      }
    }
};
local ServiceBusAverageRequestSize = grafana.graphPanel.new(
    title="Average Request Size",
    datasource='AzureMonitor',
    description="This panel displays the average request size graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='Size',
    aggregation='Average',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus3",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='Size',
    aggregation='Average',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus4",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
  )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};

local ServiceBusFS = row.new(title="Service Bus - Food & Supply", collapse=true)
    .addPanel(ServiceBusIncommingMessages,gridPos={h: 8, w: 12, x: 0, y:12})
    .addPanel(ServiceBusOutgoingMessages,gridPos={h: 8, w: 12, x: 12, y: 12})
    .addPanel(ServiceBusSuccessfulRequests,gridPos={h: 8, w: 12, x: 0, y: 20})
    .addPanel(ServiceBusCompleteMessage,gridPos={h: 8, w: 12, x: 12, y: 20})
    .addPanel(ServiceBusActiveMessages,gridPos={h: 8, w: 12, x: 0, y: 28})
    .addPanel(ServiceBusScheduledMessages,gridPos={h: 8, w: 12, x: 12, y: 28})
    .addPanel(ServiceBusCountOfUserErrors,gridPos={h: 8, w: 12, x: 0, y: 36})
    .addPanel(ServiceBusAverageRequestSize,gridPos={h: 8, w: 12, x: 12, y: 36});

############################ Standardized Zone ############################

local StandardizedZone = grafana.tablePanel.new(
  title='Standardized Ingestion Details - Table View',
  datasource='Azure SQL Server',
  description="This table panel displays the details of ingestion in the Standardized Zone."
).addTarget(
  target=sql_target(
    rawSql="
    SELECT
        project_name AS [Application Source],
        FORMAT(DATEADD(SECOND, MAX([timestamp]), '1970-01-01'), 'yyyy-MM-dd') AS [TransactionDate],
        REPLACE(dataset_name, '_', '') AS [Dataset Name],
        COUNT(*) AS [Transaction Count]
    FROM
        [observability].[event]
    WHERE
        project_name LIKE '%apmea%'
        AND landing_zone = 'standardized'
        AND metric_name = 'processing_exit_code'
        AND event_type = 'processingfinished'
        AND metric_value = 0
        AND [timestamp] BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
    GROUP BY
        project_name, dataset_name
    ORDER BY
        FORMAT(DATEADD(SECOND, MAX([timestamp]), '1970-01-01'), 'yyyy-MM-dd');",
    format='table'
  )
);

local StandardizedZoneRow = row.new(title="Standardized Ingestion Details - Table View", collapse=true)
    .addPanel(panel=StandardizedZone,gridPos={h: 10, w: 24, x: 0, y: 30});

############################ Dashboard ############################

grafana.dashboard.new(
  title='APMEA End to End Monitoring',
  time_from='now-3h',
  timezone="utc",
  editable='false',
  schemaVersion=37,
  uid='apmea-monitoring-tracker',
  tags=['monitoring', 'observability'])

.addTemplate(ProjectAppinsightsSubscription)
.addTemplate(ProjectAppinsightsRG)
.addTemplate(ProjectAppinsights)
.addTemplate(ProjectAppInsightsNamespace)
.addTemplate(ProjectAppinsightsRG2)
.addTemplate(ProjectAppinsights2)
.addTemplate(ProjectLogAnalyticsWorkspace)
.addTemplate(LoganalyticsworkspaceNamespaceTemplate)

.addTemplate(ProjectServiceBus1)
.addTemplate(ProjectServiceBus2)
.addTemplate(ProjectServiceBus3)
.addTemplate(ProjectServiceBus4)
.addTemplate(ProjectServiceBusNamespace)

.addTemplate(template_API)
.addTemplate(template_functionApp)
.addTemplate(template_country)
.addTemplate(template_region)
.addTemplate(template_source)
.addTemplate(template_correlationid)

.addPanel(panel=TotalRequestsPanels, gridPos={h: 4, w: 24, x: 0, y: 0})
.addPanel(panel=TrankingSource, gridPos={h: 7, w: 24, x: 0, y: 4})
.addPanel(panel=TrankingSourceAPIMtoAZ, gridPos={h: 7, w: 24, x: 0, y: 11})
.addPanel(panel=Status, gridPos={h: 1, w: 24, x: 0, y: 18})
.addPanel(panel=APIM, gridPos={h: 1, w: 24, x: 0, y: 19})
.addPanel(panel=AzureFunction, gridPos={h: 1, w: 24, x: 0, y: 20})
.addPanel(panel=ServiceBusFH, gridPos={h: 1, w: 24, x: 0, y: 21})
.addPanel(panel=ServiceBusFS, gridPos={h: 1, w: 24, x: 0, y: 22})
.addPanel(panel=StandardizedZoneRow, gridPos={h: 1, w: 24, x: 0, y: 23})