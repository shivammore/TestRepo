local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;
local tablePanel = grafana.tablePanel;
local logPanel =  grafana.logPanel;

############################ Dashboard Varaibles ############################

local projectName = "Innovorder";
local projectName2 = "D365";

local ProjectAppinsightsSubscription = tmpl.new(
    name='sub_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>AppinsightsSubscription'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Subscription of Application Insight",
    hide=true
);
local ProjectAppinsightsRG =  tmpl.new(
    name='rg_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName2>ResourceGroup'", "<projectName2>", projectName2 ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Resource Group of Log Analytics Workspace",
    hide=true
);
local ProjectAppinsightsRG2 =  tmpl.new(
    name='rg_project2',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>AppinsightsRG'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Resource Group of Application Insight",
    hide=true
);
local ProjectAppinsights =  tmpl.new(
    name='appinsights_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName2>Appinsights'", "<projectName2>", projectName2 ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Application Insights",
    hide=true
);
local ProjectAppinsights =  tmpl.new(
    name='appinsights_project2',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>Appinsights'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Application Insights",
    hide=true
);
local ProjectAppInsightsNamespace =  tmpl.custom(
    name='ns_appinsights',
    current='microsoft.insights/components',
    query='microsoft.insights/components',
    includeAll=false,
    multi=false,
    label="Project: AppInsights Namespace",
    hide=true
);
local ProjectServiceBus =  tmpl.new(
    name='resource_servicebus',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName2>ServiceBusName'", "<projectName2>", projectName2 ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: ServiceBus",
    hide=true
);
local ProjectServiceBusNamespace =  tmpl.custom(
    name='ns_servicebus',
    current='microsoft.servicebus/namespaces',
    query='microsoft.servicebus/namespaces',
    includeAll=false,
    multi=false,
    label="Project: ServiceBus Namespace",
    hide=true
);

############################ Dashboard filters ############################

local template_API =  tmpl.custom(
    name='Appsource',
    current='all',
    query='company,costcenter,employee,epmcontract,exchangerate,geographicalsite,glaccount,payment,proftcenter,profitcentergroup,project,wbs',
    includeAll=true,
    multi=true,
    label='Application Source'
);

local template_country =  tmpl.new(
    name='country',
    datasource='AzureMonitor',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Country',
    queryType='Azure Log Analytics',
    query=|||
            requests
            | where isnotempty(customDimensions)
            | extend country = tostring(customDimensions["Request-x-country-of-origin"])
            | where isnotempty(country)
            | distinct country
            | order by country asc
        |||,
    resources=[
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ]
);

local template_region =  tmpl.new(
    name='region',
    datasource='AzureMonitor',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Region',
    queryType='Azure Log Analytics',
    query=|||
            requests
            | where isnotempty(customDimensions)
            | extend region = tostring(customDimensions.["Request-x-region"])
            | where isnotempty(region)
            | distinct region
            | order by region asc
        |||,
    resources=[
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ]
);

local template_source =  tmpl.new(
    name='source',
    datasource='AzureMonitor',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Source App ID',
    queryType='Azure Log Analytics',
    query=|||
            requests
            | where isnotempty(customDimensions)
            | extend source = tostring(customDimensions.["Request-x-source-application-id"])
            | where isnotempty(source)
            | distinct source
            | order by source asc
        |||,
    resources=[
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ]
);

local template_correlationid = tmpl.text(
    name='correlationid',
	label='Correlation Id'
);

############################ Summary panels ############################

