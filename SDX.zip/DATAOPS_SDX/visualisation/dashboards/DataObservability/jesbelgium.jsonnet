local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local stat = grafana.statPanel;
local table = grafana.tablePanel;
local slo = 80;

//global filters
local projectTemplate =  tmpl.custom(
    name='project_name',
    current='all',
    query='oss.coe.be.jes',
    includeAll=true,
    multi=true,
    label="Application Source"
);

local datasetTemplate = tmpl.custom(
    name='dataset_name',
    query='receipts,operatingunits',
    current='all',
    includeAll=true,
    multi=true,
    label='Dataset Name'
);

local stageTemplate =  tmpl.custom(
    name='landing_zone',
    current='all',
    query='history,landing,standardized',
    includeAll=true,
    multi=true,
    label="Zone"
);

local statusTemplate =  tmpl.custom(
    name='status',
    current='all',
    query='Succeeded,Failed,No New Data,Running,Skipped',
    includeAll=true,
    multi=true,
    label="Ingestion Status"
);

local HidedContext =
    grafana.template.new(
    name='context',
    datasource='Azure SQL Server',
    query="
    SELECT distinct(context_id)
    FROM [observability].[event]
    WHERE
  dataset_name IN ($dataset_name)
  AND landing_zone IN ($landing_zone)
  AND project_name IN ($project_name)
        ",
    current='all',
    refresh='load',
    hide = true,
    includeAll=true,
    multi=false,
    label='context'
);

//panels
local generatePanelCount =
  stat.new(
    title='Total Datasets',
    datasource='Azure SQL Server',
    description="The total dataset we have in database within the source. It could refer to a database table, a file, or any other structured form of data, depending on how the dataset is constructed."
  )
  // Use the length of the sources list as the value to display
  .addTarget(
    target=grafana.sql.target(
      rawSql="with cte as (select '${dataset_name:csv}' as val)
	              select (LEN(val) - LEN(REPLACE(val, ',', ''))) + 1 from cte;",
      format='table'
    )
);
local SLOPanel = stat.new(
    title='SLO',
    datasource='Azure SQL Server',
    description="This is a benchmark defined by the proprietors or stakeholders of a data ingestion pipeline.
    It signifies the anticipated and aspired level of efficiency, reliability, and quality for data ingestion processes.
    Such a goal provides a tangible metric against which the actual performance of the data ingestion can be evaluated,ensuring that the pipeline operates in alignment with stakeholder expectations and requirements.")
    .addTarget(target=grafana.sql.target(rawSql= "SELECT 80 AS 'slo'", format='table'))
    .addOverridesByFieldName(field='slo',properties=[{id: 'unit', value: 'percent'}]
);
local generateSLIPanel =
    local SLISqlQuery = "   
            WITH
			CombinedValues AS (
							SELECT *
                    FROM (VALUES ('oss.coe.be.jes', 'receipts', 'standardized', 'oss.coe.be.jes_receipts_standardized', 86400), 
					 ('oss.coe.be.jes', 'receipts', 'history', 'oss.coe.be.jes_receipts_history', 86400), 
					 ('oss.coe.be.jes', 'receipts', 'landing', 'oss.coe.be.jes_receipts_landing', 86400), 
					 ('oss.coe.be.jes', 'operatingunits', 'standardized', 'oss.coe.be.jes_operatingunits_standardized', 86400), 
					 ('oss.coe.be.jes', 'operatingunits', 'history', 'oss.coe.be.jes_operatingunits_history', 86400),
					 ('oss.coe.be.jes', 'operatingunits', 'landing', 'oss.coe.be.jes_operatingunits_landing', 86400)) AS t (project_name, dataset_name, landing_zone, context_id, ttl)
					WHERE context_id IN (${context:sqlstring}+'')
			),
			RawEvents AS (
				SELECT
					[timestamp],
					context_id,
					job_id,
					metric_value
				FROM
					[observability].[event]
				WHERE
					metric_name = 'processing_exit_code'
					AND event_type = 'processingfinished'
					AND context_id IN (${context:sqlstring}+'')
					AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
			),
			DistinctJobs AS (
				SELECT DISTINCT
					context_id,
					job_id,
					metric_value
				FROM
					RawEvents
			),
			IngestionSum AS (
				SELECT
					context_id,
					SUM(CASE WHEN metric_value = 0 THEN 1 ELSE 0 END) AS Succeeded,
					SUM(CASE WHEN metric_value = 1 THEN 1 ELSE 0 END) AS No_Data,
					SUM(CASE WHEN metric_value = -1 THEN 1 ELSE 0 END) AS Failed
				FROM
					DistinctJobs
				GROUP BY
					context_id
			),
			FilteredAndAdded AS (
					SELECT
						timestamp,
						context_id,
						metric_value
					FROM (
						SELECT
							timestamp,
							context_id,
							metric_value
						FROM
							RawEvents
						WHERE
							metric_value = 0
		 
						UNION ALL
		 
						SELECT
							$__unixEpochTo() AS timestamp,  -- Current UTC timestamp as Unix time
							context_id,
							0 AS metric_value
						FROM
							(SELECT DISTINCT context_id FROM RawEvents WHERE metric_value = 0) AS UniqueContexts
		 
						UNION ALL
		 
						SELECT
							$__unixEpochFrom() AS timestamp,  -- Current UTC timestamp as Unix time
							context_id,
							0 AS metric_value
						FROM
							(SELECT DISTINCT context_id FROM RawEvents WHERE metric_value = 0) AS UniqueContexts
						) AS CombinedFilteredResults
			),
			EventDifferences AS (
				SELECT
					context_id,
					timestamp,
					metric_value,
					LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
					CASE
						WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
							timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
						ELSE NULL
					END AS time_difference
				FROM
					FilteredAndAdded
				WHERE
					metric_value = 0
			),
			Slis AS (
				SELECT
					cv.project_name AS 'Application Source',
					cv.dataset_name AS 'Dataset Name',
					cv.landing_zone AS 'Zone',
					cv.ttl AS 'TTL',
					COALESCE(iso.Succeeded, 0) AS 'Succeeded',
					COALESCE(iso.No_Data, 0) AS 'No New Data',
					COALESCE(iso.Failed, 0) AS 'Failed',
					COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
					CASE
						WHEN COALESCE(iso.Succeeded, 0) = 0 THEN NULL
						WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
						ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / ($__unixEpochTo() - $__unixEpochFrom()))
					END AS SLI
				FROM
					CombinedValues AS cv
				LEFT JOIN
					IngestionSum AS iso
				ON
					cv.context_id = iso.context_id
				LEFT JOIN
					EventDifferences AS ed
				ON
					cv.context_id = ed.context_id
					AND ed.time_difference > cv.ttl
				GROUP BY
					cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed
			)

		SELECT
			CASE
				WHEN COUNT(*) != COUNT(SLI) THEN 0  -- If any SLI is NULL, return 0
				WHEN MIN(SLI) < 0 then 0
				ELSE AVG(SLI)
			END AS 'Percentage'
		FROM
			Slis;

    ";

    stat.new(
        title='SLI',
        datasource='Azure SQL Server',
        description= "SLI (Service Level Indicator) measures the freshness and accuracy of data ingestion pipelines based on SLO (Service Level Objective) benchmarks set
by DAOs and Data Governors. Stakeholders define the SLOs for datasets in a standardized Excel template.  
 SLI: Selected time range (in hours) - Downtime (in hours)/Selected time range (in hours) * 100  
 Example 1: For a dataset with a 2-day time range and 1-day downtime: SLI: 48-24/48 * 100 = 50%                                                                                                                                                                                                                                
 Example 2: For a dataset with a 7-day time range and half-day downtime: SLI: 168-12/168 * 100 = 92.8%.")
        .addTarget(target=grafana.sql.target(rawSql=SLISqlQuery, format='table'))
        .addOverridesByFieldName(
        field='Percentage',
        properties=[{id: 'unit', value: 'percent'},
        {
            "id": "thresholds",
            "value": {
            "mode": "absolute",
            "steps": [
                { "color": "light-gray", "value": null },
                { "color": "light-red", "value": 0 },
                { "color": "light-yellow", "value": 80 },
                { "color": "light-green", "value": 80*1.1 }
            ]
            }
        }
        ]
);
local generateIngestionPipelinesByCondition(title, color, code) =
   local sqlQuery = std.format("
       
        SELECT COUNT(*)
        FROM(
                SELECT distinct job_id, context_id
                FROM [observability].[event]
                WHERE metric_name='processing_exit_code'
                AND event_type='processingfinished'
                AND metric_value=%d
                AND context_id in ('oss.coe.be.jes_operatingunits_history','oss.coe.be.jes_operatingunits_landing','oss.coe.be.jes_operatingunits_standardized','oss.coe.be.jes_receipts_history','oss.coe.be.jes_receipts_landing','oss.coe.be.jes_receipts_standardized' + '')
                AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
                AND dataset_name IN ($dataset_name)
                AND landing_zone IN ($landing_zone)
                AND project_name IN ($project_name)
            ) AS SubQuery

        ", [code]
    );

    grafana.statPanel.new(title, datasource='Azure SQL Server', colorMode='background')
    .addThresholds([{ value: 0, color: color }])
    .addTarget(target=grafana.sql.target(rawSql=sqlQuery, format='table')
);

local GenerateSuccessRatio =
    local sqlQuery = "
		SELECT
            CASE WHEN COUNT(*) = 0 THEN 100 
            ELSE COUNT(CASE WHEN metric_value != -1 THEN 1 ELSE NULL END) * 100.0 / COUNT(*) 
            END AS ratio
        FROM ( select distinct job_id, context_id, metric_value from[observability].[event]
                  WHERE metric_name= 'processing_exit_code'
                  AND event_type =  'processingfinished'
                  AND context_id IN ('oss.coe.be.jes_operatingunits_history','oss.coe.be.jes_operatingunits_landing','oss.coe.be.jes_operatingunits_standardized','oss.coe.be.jes_receipts_history','oss.coe.be.jes_receipts_landing','oss.coe.be.jes_receipts_standardized' + '')
                  AND context_id IN (${context:sqlstring}+'')
                  AND timestamp >= $__unixEpochFrom()
                  AND timestamp < $__unixEpochTo()
              ) As distinct_records
    ";
        
    grafana.statPanel.new(
    title='Success Ratio Indicator',
    datasource='Azure SQL Server',
    description= "The Pipeline Success Ratio Indicator provides a clear metric to gauge the effectiveness of
    a data ingestion pipeline by comparing successful operations against failures and no new data. "
    ).addTarget(target=grafana.sql.target(rawSql=sqlQuery,format='table'))
    .addOverridesByFieldName(field='ratio',properties=[{id: 'unit', value: 'percent'}]
);

local DatasetFreshness = 
    local sqlQuery = " 
    WITH
        FilteredEvents AS (
            SELECT
                job_id,
                context_id,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                timestamp,
                metric_name,
                metric_value
            FROM
                [observability].[event]
            WHERE
                context_id in ('oss.coe.be.jes_operatingunits_history','oss.coe.be.jes_operatingunits_landing','oss.coe.be.jes_operatingunits_standardized','oss.coe.be.jes_receipts_history','oss.coe.be.jes_receipts_landing','oss.coe.be.jes_receipts_standardized' + '')
                --context_id IN ('oss.glb.glb.dynamify_sdx_getallowances_history','oss.glb.glb.dynamify_sdx_getallowances_landing','oss.glb.glb.dynamify_sdx_getallowances_standardized','oss.glb.glb.dynamify_sdx_menudataexportobject_history','oss.glb.glb.dynamify_sdx_menudataexportobject_landing','oss.glb.glb.dynamify_sdx_menudataexportobject_standardized','oss.glb.glb.dynamify_sdx_tradescommercexportobject_history','oss.glb.glb.dynamify_sdx_tradescommercexportobject_landing','oss.glb.glb.dynamify_sdx_tradescommercexportobject_standardized','oss.glb.glb.dynamify_sdx_mealdeal_history','oss.glb.glb.dynamify_sdx_mealdeal_landing','oss.glb.glb.dynamify_sdx_mealdeal_standardized'+'')
                --context_id IN ('oss.glb.glb.dynamify_sdx_menudataexportobject_history','oss.glb.glb.dynamify_sdx_menudataexportobject_landing','oss.glb.glb.dynamify_sdx_menudataexportobject_standardized'+'')
                AND dataset_name  in ($dataset_name)
                AND project_name  in ($project_name)
                AND metric_name IN ('processing_started_date', 'processing_finished_date', 'processing_exit_code', 'rows_count', 'content_latest_date')
        ),
        MergedEvents AS (
            SELECT
                job_id,
                context_id,
                timestamp,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                [processing_started_date] AS processing_started_date_value,
                [processing_finished_date] AS processing_finished_date_value,
                [processing_exit_code] AS processing_exit_code_value,
                [content_latest_date] AS content_latest_date,
                [rows_count] AS rows_count_value
            FROM
                FilteredEvents
            PIVOT (
                MAX(metric_value)
                FOR metric_name IN ([processing_started_date], [processing_finished_date], [processing_exit_code], [rows_count], [content_latest_date])
            ) AS PivotTable
        ),
        Finalevents as
        (
        SELECT
            MAX(project_name) AS 'Application Source',
            MAX(dataset_name) AS 'Dataset',
            MAX(landing_zone) AS 'Zone',
            MAX(
                CASE subscription_id
                    WHEN '6b4a5b3f-1015-42da-a46a-2890a5abed30' THEN 'IFM CORE PROD'
                    WHEN '2698ca5b-bf81-43fb-8fe2-f0e21bf068e5' THEN 'IFM CORE UAT/TEST'
                    WHEN '746ac5b9-70eb-4c76-bdf4-0664bfdff2ea' THEN 'IFM CORE DEV'
                    WHEN 'cf25f2a1-4d40-45af-bb81-87ec46112b3e' THEN 'SDX STA/PRD'
                    WHEN 'c0978b9d-b809-45f4-aa76-391ceb2cfdba' THEN 'SDX DEV/TEST'
                    WHEN '8eaa3d95-3cd2-49d8-b44a-7ea47a6fb58b' THEN 'SDX SILVER'
                    WHEN 'daf86ec1-725c-493f-bf09-a1f129b8588a' THEN 'SDX INT/UAT'
                    WHEN 'fea1e9f0-0e20-426f-906e-bc76e5a566ad' THEN 'SDX Sandbox'
                    WHEN '6e3fc63f-851b-4fc7-8499-48f6a9c28a65' THEN 'SDX Global Shared Services'
                    ELSE 'Undefined'
            END
            ) AS 'Subscription',
            MAX(takeoff_zone) + ' to ' + MAX(landing_zone) AS 'Activity',
            CASE
                WHEN MAX(processing_exit_code_value) = 0 THEN 'Succeeded'
                WHEN MAX(processing_exit_code_value) = 1 THEN 'No New Data'
                WHEN MAX(processing_exit_code_value) = 2 THEN 'Skipped'
                WHEN MAX(processing_exit_code_value) IS NULL THEN 'Running'
                ELSE 'Failed'
            END AS 'Status',
            DATEADD(SECOND, MAX([timestamp]), '1970-01-01') AS 'Landed at',
            DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([timestamp]) AS 'Landed Since',
            DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([content_latest_date]) AS 'Freshness',
            CAST(MAX(processing_finished_date_value) - MAX(processing_started_date_value) AS BIGINT) AS 'Duration',
            ISNULL(CAST(CAST(MAX(rows_count_value) AS BIGINT) AS VARCHAR), 'N/A') AS 'Rows'
        FROM MergedEvents
        GROUP BY job_id, context_id
        ),
        Eventsdata as(
            Select [Application Source] as ApplicationSource, Dataset,Zone, Subscription, Activity, Status,[Landed at] as LandedAt,[Landed Since] as LandedSince,[Freshness] as Freshness, Duration,[Rows] as IngestedRows from Finalevents
            where Status in ($status)
        ),
 
        finaldata as (select
            ApplicationSource ,
            Dataset,
            case
                   when count(case when Activity = 'landing to history' and status = 'succeeded' then 1 end) >= 1
                   and count(case when Activity = 'history to standardized' and status = 'succeeded' then 1 end) >= 1
                then 'OK'        
                else 'NOT OK'
            end as [Overall Status],
            Subscription as [Datalake Location],
            case
                when count(case when Activity = 'landing to history' and status = 'succeeded' then 1 end) >= 1
                then 'OK'
                else 'NOT OK'
            end as [Bronze History Status],
            case
                when count(case when Activity = 'history to standardized' and status = 'succeeded' then 1 end) >= 1                    
        then 'OK'
                else 'NOT OK'
            end as [Bronze Standardized Status],    
            max(case
                when Activity = 'landing to history' then LandedAt
                end)
        as [Pipe Line Execution StartTime],
            max(case
                when Activity = 'history to standardized' then LandedAt
                end)
        as [Pipe Line Execution EndTime],
 
            datediff(second,
            min(case
                when Activity = 'landing to history' then LandedAt
                end),current_timestamp
            ) as [Pipe Line Executed Since],
            max(Freshness) as Freshness,
            datediff(second,
            min(case when Activity = 'landing to history' then landedAt end),
            max(case when Activity = 'history to standardized' then landedAt end)
           ) as 'Total Execution Time',
           convert(Date, LandedAt) as executedDate
        From Eventsdata
        group by ApplicationSource,
            Dataset,
            subscription,
            convert(Date, LandedAt)
        ),
        RankedData as
        (
            select  ApplicationSource,
                    Dataset,
                    [Datalake Location],
                    executedDate,
                    case
                    when executedDate < getdate()
                    then DatedIff(second,max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                        else
                        DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Overall Refresh Status],
                    case when executedDate < getdate()
                then DatedIff(second, max([Pipe Line Execution StartTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    else
                    DatedIff(second, max([Pipe Line Execution StartTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Bronze History Refresh Status],
                case when executedDate < getdate()
                then DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    else
                    DatedIff(second,max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Bronze Standardized Refresh Status],
                row_number() over (partition by ApplicationSource, Dataset order by executedDate desc) as rownum,
                    [Pipe Line Execution EndTime],
                [Pipe Line Execution StartTime],
                [Pipe Line Executed Since],
                    Freshness,
                    [Total Execution Time],
                    86400 as [Freshness Threshold]
        from finalData
            where  [Overall Status] = 'OK'
        )
        select ApplicationSource,
            Dataset,
            [Freshness Threshold] as 'Threshold',
            [Overall Refresh Status] as 'Freshness Refresh Status',
            [Bronze History Refresh Status],
            [Bronze Standardized Refresh Status],
            [Pipe Line Execution StartTime],
            [Pipe Line Execution EndTime],
            Freshness,
            ([Freshness Threshold] - [Overall Refresh Status]) AS Differenceintime,
			CASE
				WHEN ([Freshness Threshold] - [Overall Refresh Status]) < 0 THEN 1
				WHEN ([Freshness Threshold] - [Overall Refresh Status]) > 0 THEN 2
				ELSE 0
			END AS Colour_Code
        from RankedData
        where  rownum = 1
        order by executedDate desc
   
   ";
   table.new(
    title = 'Tracking Data Freshness',
    datasource = 'Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Pipe Line Execution StartTime',properties=[{id: 'unit', value: 's'},{id: 'custom.width',value: 226}]
    ).addOverridesByFieldName(field='Pipe Line Execution EndTime',properties=[{id: 'unit', value: 's'},{id: 'custom.width',value: 229}]
    ).addOverridesByFieldName(field='Freshness',properties=[{id: 'unit', value: 's'},{id: 'custom.width',value: 133},{id: 'custom.hidden', value: true}]
    ).addOverridesByFieldName(field='ApplicationSource',properties=[{id: 'custom.width',value: 199}]
    ).addOverridesByFieldName(field='Dataset',properties=[{id: 'custom.width',value: 214}]
    ).addOverridesByFieldName(field='Threshold',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Freshness Refresh Status',properties=[{id: 'unit',value: "s"}]
    ).addOverridesByFieldName(field='Colour_Code',properties=[{id: 'custom.cellOptions',value: {type: 'color-background', applyToRow: true}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'green',value: null},{color: 'light-orange',value: 0},{color: 'light-red',value: 1},{color: 'super-light-green',value: 2}]}},{id: 'custom.hidden', value: true}]
    ).addOverridesByFieldName(field='Differenceintime',properties=[{id: 'custom.hidden',value: true}]
    ).addOverridesByFieldName(field='Bronze History Refresh Status',properties=[{id: 'unit',value: "s"}]
    ).addOverridesByFieldName(field='Bronze Standardized Refresh Status',properties=[{id: 'unit',value: "s"}]
);

local DataVolumeeceiptsTabularView = 
    local sqlQuery = " 
        SELECT  project_name as [Application Source], 
            dataset_name as [Dataset Name], 
            format(record_date, 'yyyy-MM-dd') as [Transaction Date], 
            'Data volume > 1100' as [Threshold],
            sum(case when ingestion_layer = 'history' then record_count else 0 end) as [Bronze History Transaction Count],
            sum(case when ingestion_layer = 'standardized' then record_count else 0 end) as [Bronze Standardized Transaction Count] FROM [observability].[jes]
        where dataset_name = 'receipts' 
            and datediff(second, '1970-01-01 00:00:00',record_date) between $__unixEpochFrom() and $__unixEpochTo()
        group by 
            project_name, dataset_name, record_date
        order by [Transaction Date] desc
   ";
   table.new(
    title = 'Data Volume Receipts',
    datasource = 'Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Threshold',properties=[{id: 'custom.width',value: 245}]
    ).addOverridesByFieldName(field='Bronze History Transaction Count',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'green'}]}},{id: 'mappings',value: [{options: {'from':0, 'result': {color: 'red','index': 0}, 'to': 1099}, type: 'range'}]}]
    ).addOverridesByFieldName(field='Dataset Name',properties=[{id: 'custom.width', 'value': 212 }]
    ).addOverridesByFieldName(field='Application Source',properties=[{ id: 'custom.width', 'value': 188 }]
    ).addOverridesByFieldName(field='Transaction Date',properties=[{id: 'custom.width', 'value': 193 }]
    ).addOverridesByFieldName(field='Bronze Standardized Transaction Count',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'green'}]}},{id: 'mappings',value: [{options: {'from':0, 'result': {color: 'red','index': 0}, 'to': 1099}, type: 'range'}]}]
);

local DataVolumeOperatingUnitsTabularView = 
    local sqlQuery = "  
with date_list as (
            select cast(dateadd(second, $__unixEpochFrom(), '1970-01-01') as date) as txn_date
            union all
            select dateadd(day, 1, txn_date)
            from date_list
            where txn_date < cast(dateadd(second, $__unixEpochTo(), '1970-01-01') as date)
        )
        
        ,main as (
            select distinct
                project_name,
                dataset_name,
                cast(dateadd(second, timestamp, '1970-01-01') as date) as txn_date,
                sum(case when landing_zone = 'history' then metric_value else 0 end) as bronze_count,
                sum(case when landing_zone = 'standardized' then metric_value else 0 end) as silver_count
            from [observability].[event] as r
            where project_name = 'oss.coe.be.jes'
            and dataset_name = 'operatingunits'
            and landing_zone in ('standardized','history')
            and metric_name = 'rows_count'
            and event_type = 'processingfinished'
            and timestamp = (select max(timestamp) from [observability].[event] 
            where project_name = r.project_name and timestamp = r.timestamp)
            group by project_name, dataset_name, cast(dateadd(second, timestamp, '1970-01-01') as date)
        ),
        cte as (select
                    coalesce(b.project_name, 'oss.coe.be.jes') as [Application Source],
                    coalesce(b.dataset_name, 'operatingunits') as [Dataset Name],
                    format(d.txn_date, 'yyyy-MM-dd') as [Transaction Date],
                    'Data volume > 3' as [Threshold],
                    coalesce(b.bronze_count, 0) as [Bronze History Transaction Count],
                    coalesce(b.silver_count, 0) as [Bronze Standardized Transaction Count]
                from date_list d
                left join main b
                    on d.txn_date = b.txn_date 
                where datediff(second, '1970-01-01 00:00:00',d.txn_date) between $__unixEpochFrom() and $__unixEpochTo()
        )

        SELECT  p.project_name as [Application Source], 
            p.dataset_name as [Dataset Name], 
            format(p.record_date, 'yyyy-MM-dd') as [Transaction Date], 
            'Data volume > 3' as [Threshold],
            sum(case when ingestion_layer = 'history' then record_count else 0 end) as [Bronze History Transaction Count],
            max(coalesce(c.[Bronze Standardized Transaction Count], 0)) as [Bronze Standardized Transaction Count]
            FROM [observability].[jes] p
        inner join cte c
            on format(p.record_date, 'yyyy-MM-dd') = c.[Transaction Date]
        where p.dataset_name = 'operatingunits' 
            and datediff(second, '1970-01-01 00:00:00',p.record_date) between $__unixEpochFrom() and $__unixEpochTo()
        group by 
            p.project_name, p.dataset_name, p.record_date
        order by p.record_date desc
   ";
   table.new(
    title = 'Data Volume OperatingUnits',
    datasource = 'Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Threshold',properties=[{id: 'custom.width',value: 245}]
    ).addOverridesByFieldName(field='Bronze History Transaction Count',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'green'}]}},{id: 'mappings',value: [{options: {'from':0, 'result': {color: 'red','index': 0}, 'to': 2}, type: 'range'}]}]
    ).addOverridesByFieldName(field='Dataset Name',properties=[{id: 'custom.width', 'value': 212 }]
    ).addOverridesByFieldName(field='Application Source',properties=[{ id: 'custom.width', 'value': 188 }]
    ).addOverridesByFieldName(field='Transaction Date',properties=[{id: 'custom.width', 'value': 193 }]
    ).addOverridesByFieldName(field='Bronze Standardized Transaction Count',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'green'}]}},{id: 'mappings',value: [{options: {'from':0, 'result': {color: 'red','index': 0}, 'to': 2}, type: 'range'}]}]
);

local DatasetIngestionHistory = 
    local sqlQuery = "     
    WITH 
        FilteredEvents AS (
            SELECT
                job_id,
                context_id,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                timestamp,
                metric_name,
                metric_value
            FROM
                [observability].[event]
            WHERE
                context_id IN (${context:sqlstring}+'')
                AND dataset_name in ($dataset_name)
                AND landing_zone IN ($landing_zone)
                AND project_name in ($project_name)
                AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                AND metric_name IN ('processing_started_date', 'processing_finished_date', 'processing_exit_code', 'rows_count', 'content_latest_date')
        ),
        MergedEvents AS (
            SELECT
                job_id,
                context_id,
                timestamp,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                [processing_started_date] AS processing_started_date_value,
                [processing_finished_date] AS processing_finished_date_value,
                [processing_exit_code] AS processing_exit_code_value,
                [content_latest_date] AS content_latest_date,
                [rows_count] AS rows_count_value
            FROM
                FilteredEvents
            PIVOT (
                MAX(metric_value)
                FOR metric_name IN ([processing_started_date], [processing_finished_date], [processing_exit_code], [rows_count], [content_latest_date])
            ) AS PivotTable
        ),
        Finalevents as(
            SELECT
                MAX(project_name) AS 'Application Source',
                MAX(dataset_name) AS 'Dataset',
                MAX(landing_zone) AS 'Zone',
                MAX(
                    CASE subscription_id
                    WHEN '6b4a5b3f-1015-42da-a46a-2890a5abed30' THEN 'IFM CORE PROD'
                    WHEN '2698ca5b-bf81-43fb-8fe2-f0e21bf068e5' THEN 'IFM CORE UAT/TEST'
                    WHEN '746ac5b9-70eb-4c76-bdf4-0664bfdff2ea' THEN 'IFM CORE DEV'
                    WHEN 'cf25f2a1-4d40-45af-bb81-87ec46112b3e' THEN 'SDX STA/PRD'
                    WHEN 'c0978b9d-b809-45f4-aa76-391ceb2cfdba' THEN 'SDX DEV/TEST'
                    WHEN '8eaa3d95-3cd2-49d8-b44a-7ea47a6fb58b' THEN 'SDX SILVER'
                    WHEN 'daf86ec1-725c-493f-bf09-a1f129b8588a' THEN 'SDX INT/UAT'
                    WHEN 'fea1e9f0-0e20-426f-906e-bc76e5a566ad' THEN 'SDX Sandbox'
                    WHEN '6e3fc63f-851b-4fc7-8499-48f6a9c28a65' THEN 'SDX Global Shared Services'
                    ELSE 'Undefined'
                    END
                ) AS 'Subscription',
                MAX(takeoff_zone) + ' to ' + MAX(landing_zone) AS 'Activity',
                case 
                    when sum(case when processing_exit_code_value not in (0,1,2) then 1 else 0 end) > 0 then 'Failed'
                    when count(case when processing_exit_code_value = 0 then 1 end) > 0 then 'Succeeded'
                    when count(case when processing_exit_code_value = 1 then 1 end) > 0 then 'No New Data'
                    when count(case when processing_exit_code_value = 2 then 1 end) > 0 then 'Skipped'
                End as 'Status',
                DATEADD(SECOND, MAX([timestamp]), '1970-01-01') AS 'Landed at',
                DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([timestamp]) AS 'Landed Since',
                DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([content_latest_date]) AS 'Freshness',
                case when max(landing_zone) = 'landing' then right(job_id, charindex('_', reverse(job_id)) - 1) end as [Site Id],
                CAST(MAX(processing_finished_date_value) - MAX(processing_started_date_value) AS BIGINT) AS 'Duration',
                ISNULL(CAST(CAST(MAX(rows_count_value) AS BIGINT) AS VARCHAR), 'N/A') AS 'Rows'
            FROM MergedEvents
            GROUP BY job_id, context_id
        )
        Select[Application Source], Dataset,Zone, Subscription, Activity, Status,[Landed at], [Site Id], Rows from Finalevents
        where Status in ($status)
        ORDER BY[Landed at] DESC
   ";
   table.new(
    title = 'Data Ingestion History - Overview',
    datasource = 'Azure SQL Server'
    )
    .addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table'))
    .addOverridesByFieldName(field='Rows', properties=[
    { id: 'custom.displayMode', value: 'color-text' },
            {
                id: 'thresholds',
                value: {
                    mode: 'absolute',
                    steps: [{ color: 'text', value: null }],
                },
            },
    {
        id: 'mappings',
        value: [
            {
                options: {
                    'N/A': {
                        color: 'red',
                        index: 0,
                    }
                },
                type: 'value',
            }
        ],
    }]
    ).addOverridesByFieldName(field='Status',properties=
	[{ 
		id: 'custom.displayMode', value: 'color-text' 
	 },
	 {
		id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}
	 },
	 {
		id: 'mappings',value: [{type: 'value',options: {'Failed': {color: 'red','index': 3},'No New Data': {color: 'yellow','index': 1},'Running': {color: 'gray','index': 2},'Succeeded': {color: 'green','index': 0}}}]
	 }]);

local getDashboardAlertsPanel(alertName) =
    grafana.alertlist.new(
    title = std.format("%s Alerts",alertName),
    onlyAlertsOnDashboard = true,
    )
    +{
    'options' :
        {
        "dashboardAlerts": false,
        "sortOrder" : 1,
        "maxItems": -1,
        "alertName": alertName,
        "stateFilter": {
            "firing": true,
            "pending": true,
            "noData": true,
            "normal": true,
            "error": true
            }
        }
    }
    + {
    "sortOrder": 1,
};

grafana.dashboard.new(
  title='JES Belgium',
  refresh='5m',
  time_from='now-7d',
  editable=true,
  timezone='utc',
  schemaVersion=37,
  uid='21EiXdsfddd15H12')
  
//global filters
.addTemplate(projectTemplate)
.addTemplate(datasetTemplate)
.addTemplate(stageTemplate)
.addTemplate(statusTemplate)
.addTemplate(HidedContext)

//panels
.addPanel(panel = generatePanelCount,gridPos={h:3,w:8,x:0,y:0})
.addPanel(panel = SLOPanel,gridPos={h:3,w:8,x:8,y:0})
.addPanel(panel = generateSLIPanel,gridPos={h:3,w:8,x:16,y:0})

.addPanel(generateIngestionPipelinesByCondition('Succeeded', 'green', 0),gridPos={h: 3, w: 6, x: 0, y: 3})
.addPanel(generateIngestionPipelinesByCondition('No New Data', 'yellow', 1),gridPos={h: 3, w: 6, x: 6, y: 3})
.addPanel(generateIngestionPipelinesByCondition('Failed', 'red', -1),gridPos={h: 3, w: 6, x: 12, y: 3})
.addPanel(panel = GenerateSuccessRatio,gridPos={h: 3, w: 6, x: 18, y: 3})

//added succeed panel

.addPanel(grafana.text.new(mode='markdown',content='Succeeded: Count of Ingestion Pipelines Run Successfully during the selected period for the selected datasets.',transparent= true),gridPos={h: 3, w: 6, x: 0, y: 6})
    
.addPanel(grafana.text.new(mode='markdown',content='No New Data: Count of Ingestion Pipelines triggered but no data pushed from Integration during the selected period for the selected dataset(s).',transparent= true),gridPos={h: 3, w: 6, x: 6, y: 6})
    
.addPanel(grafana.text.new(mode='markdown',content='Failed: Count of Ingestion Pipelines Failed during the selected period for the selected dataset(s).',transparent= true),gridPos={h: 3, w: 6, x: 12, y: 6})
    
.addPanel(grafana.text.new(mode='markdown',content='Success ratio: It is calculated as ((Success+ No New Data)/ (success + No New Data + Failed)) * 100.',transparent= true),gridPos={h: 3, w: 6, x: 18, y: 6})


.addPanel(
    row.new(
        title="Tracking Data Freshness",
        showTitle=true,
        collapse=true
    ).addPanel(panel = DatasetFreshness,gridPos={h:10,w:24,x:0,y:10}),
    gridPos={h:1,w:24,x:0,y:9}
)

.addPanel(
    row.new(
        title="Data Volume Statistics",
        showTitle=true,
        collapse=true
    ).addPanel(panel = DataVolumeeceiptsTabularView,gridPos={h:9,w:24,x:0,y:21}
    ).addPanel(panel = DataVolumeOperatingUnitsTabularView,gridPos={h:9,w:24,x:0,y:30}
    ),
    gridPos={h:1,w:24,x:0,y:10}
)

.addPanel(
    row.new(
        title="Dataset Ingestion History Overview",
        showTitle=true,
        collapse=true
    ).addPanel(panel = DatasetIngestionHistory,gridPos={h:10,w:24,x:0,y:21}),
    gridPos={h:1,w:24,x:0,y:20}
)
.addPanel(
    row.new(
        title="Dashboard Alerts",
        showTitle=true,
        collapse=true
    ).addPanel(panel = getDashboardAlertsPanel('JES Belgium'),gridPos={h:12,w:24,x:0,y:32}),
    gridPos={h:1,w:24,x:0,y:31}
)