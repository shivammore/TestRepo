local grafana = import 'grafonnet/grafana.libsonnet';
 
local filterSourceWithAlerting(sources) = [ source for source in sources if std.objectHas(source, 'alerting') && source.alerting != null ];
 
local flatSources(objs) = [
    {
        project_name: if std.type(obj.project_name) == "string" then obj.project_name else pr,
        dataset_name: if std.type(obj.dataset_name) == "string" then obj.dataset_name else d,
        alerting: if std.type(obj.alerting) == "string" then obj.alerting else alerting,
    }
    for obj in objs
    for pr in if std.type(obj.project_name) == "array" then obj.project_name else [obj.project_name]
    for d in if std.type(obj.dataset_name) == "array" then obj.dataset_name else [obj.dataset_name]
    for alerting in if std.type(obj.alerting) == "array" then obj.alerting else [obj.alerting]
];
 
local filterVolumeAlertRows(sources) = [
    source for source in sources
    if std.objectHas(source, 'alerting') &&  // Check if 'alerting' field exists
        source.alerting.type == 'Volume_Check_UKG_Pro' &&
        std.objectHas(source.alerting, 'volume_check_threshold')
];

local filterDiffAlertRows(sources) = [
  source for source in sources
  if std.objectHas(source, 'alerting') && source.alerting.type == 'Data_Availability_Freshness'
];

local filterDbtAlertRows(sources) = [
  source for source in sources
  if std.objectHas(source, 'alerting') && source.alerting.type == 'DBT_Pipeline_Freshness'
];
 
local convertToGrafanaAlertVolume(source, title) =
    local volume_check_threshold = source.alerting.volume_check_threshold;
    local panelId = source.alerting.panel;
    local panelName = source.alerting.panelName;
    local channels = source.alerting.channels;
    local dataset_name = source.dataset_name;
    local project_name = source.project_name;
    local time = source.alerting.relativeTimeRange;
 
    local baseSql = "  
            SELECT replace(project_name, '_', '.') as 'Application Source',
             table_name as 'Dataset Name',
             rundate as 'Transaction Date',
             row_count as 'Transaction count' 
            FROM [observability].[UKGpro_volume_data]
            WHERE replace(project_name, '_', '.') in ('oss.noram.us.ukglabor')
            and datediff(second, '1970-01-01 00:00:00', rundate) BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
            and zone = 'Standardized'
            order by rundate desc;";
 
    local baseSql2 = "        
            SELECT replace(project_name, '_', '.') as 'Application Source',
                    table_name as 'Dataset Name',
                    rundate as 'Transaction Date',
                    row_count as 'Transaction count' 
            FROM [observability].[UKGpro_volume_data]
            WHERE replace(project_name, '_', '.') in ('oss.noram.us.ukglabor')
            and datediff(second, '1970-01-01 00:00:00', rundate) BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
            and zone = 'history'
            order by rundate desc;
    ";


local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
local silence_labels = std.join("::", envs);
local SQLQuery = if panelName == "Volume check - Standardized" then baseSql else baseSql2 ;

{
    "uid": std.md5(std.format("DataVolumeCheckUKGPro_%s_%s",[project_name,panelName])),
    "title": std.format("Data Volume Alert: UKG Pro ──── %s ──── %s",[project_name,panelName]),
    "condition": "C",
    "data": [
        {
            "refId": "A",
            "datasourceUid": "AzureSQLServer",
            "relativeTimeRange": { "from": time, "to": 0 },
            "model": {
            "format": "table",
            "hide": false,
            "intervalMs": 60000,
            "maxDataPoints": 43200,
            "rawQuery": true,
            "rawSql": SQLQuery,
            }
        },
        {
            "refId": "B",
            "relativeTimeRange": {
                "from": time,
                "to": 0
            },
            "datasourceUid": "__expr__",
            "model": {
                "conditions": [
                    {
                        "evaluator": {
                            "params": [
                            ],
                            "type": 'gt'
                        },
                        "operator": {
                            "type": "and"
                        },
                        "query": {
                            "params": [
                                "B"
                            ]
                        },
                        "reducer": {
                            "params": [],
                            "type": "last"
                        },
                        "type": "query"
                    }
                ],
                "datasource": {
                    "type": "__expr__",
                    "uid": "__expr__"
                },
                "expression": "A",
                "intervalMs": 1000,
                "maxDataPoints": 43200,
                "reducer": "last",
                "refId": "B",
                "type": "reduce"
            }
        },
        {
            "refId": "C",
            "relativeTimeRange": {
                "from": time,
                "to": 0
            },
            "datasourceUid": "__expr__",
            "model": {
                "conditions": [
                    { 
                        "evaluator": {
                            "params": [
                                volume_check_threshold
            
                            ],
                            "type": 'lt'
                        },
                        "operator": {
                            "type": "and"
                        },
                        "query": {
                            "params": [
                                "C"
                            ]
                        },
                        "reducer": {
                            "params": [],
                            "type": "last"
                        },
                        "type": "query"
                    }
                ],
                "datasource": {
                    "type": "__expr__",
                    "uid": "__expr__"
                },
                "expression": "B",
                "intervalMs": 1000,
                "maxDataPoints": 43200,
                "refId": "C",
                "type": "threshold"
            }
        }
    ],
    "noDataState": "NoData",
    "for": "5m",
    "annotations": {
        "__dashboardUid__": "ukg_pro_dashboard",
        "__panelId__": panelId,
    },
    "labels": {
        "alert_type": "Volume_Check",
        "volume_check_threshold": volume_check_threshold,
        "env": silence_labels,
        "severity": source.alerting.severity,
        "dashboard_title": title,
        "panel_name": panelName,
        "channels": std.join("::", channels),
    }
};

local convertToGrafanaAlertDiff2(source, title) =
  local DataAvailability = 
    "WITH
        FilteredEvents AS (
            SELECT
                job_id,
                context_id,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                timestamp,
                metric_name,
                metric_value
            FROM
                [observability].[event]
            WHERE
                context_id in ('oss.noram.us.ukglabor_accrualcode_history','oss.noram.us.ukglabor_accrualcode_landing','oss.noram.us.ukglabor_accrualcode_standardized','oss.noram.us.ukglabor_accrualprofile_history','oss.noram.us.ukglabor_accrualprofile_landing','oss.noram.us.ukglabor_accrualprofile_standardized','oss.noram.us.ukglabor_accruals_vac_plan_history','oss.noram.us.ukglabor_accruals_vac_plan_landing','oss.noram.us.ukglabor_accruals_vac_plan_standardized','oss.noram.us.ukglabor_accrualsummary_history','oss.noram.us.ukglabor_accrualsummary_landing','oss.noram.us.ukglabor_accrualsummary_standardized','oss.noram.us.ukglabor_accrualtran_history','oss.noram.us.ukglabor_accrualtran_landing','oss.noram.us.ukglabor_accrualtran_standardized','oss.noram.us.ukglabor_basewagerthist_history','oss.noram.us.ukglabor_basewagerthist_landing','oss.noram.us.ukglabor_basewagerthist_standardized','oss.noram.us.ukglabor_can_employee_data_import_history','oss.noram.us.ukglabor_can_employee_data_import_landing','oss.noram.us.ukglabor_can_employee_data_import_standardized','oss.noram.us.ukglabor_can_labor_category_entry_history','oss.noram.us.ukglabor_can_labor_category_entry_landing','oss.noram.us.ukglabor_can_labor_category_entry_standardized','oss.noram.us.ukglabor_combohomeacct_history','oss.noram.us.ukglabor_combohomeacct_landing','oss.noram.us.ukglabor_combohomeacct_standardized','oss.noram.us.ukglabor_customdatadef_history','oss.noram.us.ukglabor_customdatadef_landing','oss.noram.us.ukglabor_customdatadef_standardized','oss.noram.us.ukglabor_d_jobcode_history','oss.noram.us.ukglabor_d_jobcode_landing','oss.noram.us.ukglabor_d_jobcode_standardized','oss.noram.us.ukglabor_d_segmentation_history','oss.noram.us.ukglabor_d_segmentation_landing','oss.noram.us.ukglabor_d_segmentation_standardized','oss.noram.us.ukglabor_d_unit_history','oss.noram.us.ukglabor_d_unit_landing','oss.noram.us.ukglabor_d_unit_standardized','oss.noram.us.ukglabor_employeerate_history','oss.noram.us.ukglabor_employeerate_landing','oss.noram.us.ukglabor_employeerate_standardized','oss.noram.us.ukglabor_epretim_a_history','oss.noram.us.ukglabor_epretim_a_landing','oss.noram.us.ukglabor_epretim_a_standardized','oss.noram.us.ukglabor_exceptiontype_history','oss.noram.us.ukglabor_exceptiontype_landing','oss.noram.us.ukglabor_exceptiontype_standardized','oss.noram.us.ukglabor_geofencing_mainlocation_history','oss.noram.us.ukglabor_geofencing_mainlocation_landing','oss.noram.us.ukglabor_geofencing_mainlocation_standardized','oss.noram.us.ukglabor_geofencing_request_history','oss.noram.us.ukglabor_geofencing_request_landing','oss.noram.us.ukglabor_geofencing_request_standardized','oss.noram.us.ukglabor_hr_jobdescriptions_history','oss.noram.us.ukglabor_hr_jobdescriptions_landing','oss.noram.us.ukglabor_hr_jobdescriptions_standardized','oss.noram.us.ukglabor_jobcode_master_history','oss.noram.us.ukglabor_jobcode_master_landing','oss.noram.us.ukglabor_jobcode_master_standardized','oss.noram.us.ukglabor_jobcode_servicetype_xref_history','oss.noram.us.ukglabor_jobcode_servicetype_xref_landing','oss.noram.us.ukglabor_jobcode_servicetype_xref_standardized','oss.noram.us.ukglabor_known_places_history','oss.noram.us.ukglabor_known_places_landing','oss.noram.us.ukglabor_known_places_standardized','oss.noram.us.ukglabor_labor_category_history','oss.noram.us.ukglabor_labor_category_landing','oss.noram.us.ukglabor_labor_category_standardized','oss.noram.us.ukglabor_laborleveldef_history','oss.noram.us.ukglabor_laborleveldef_landing','oss.noram.us.ukglabor_laborleveldef_standardized','oss.noram.us.ukglabor_location_sets_history','oss.noram.us.ukglabor_location_sets_landing','oss.noram.us.ukglabor_location_sets_standardized','oss.noram.us.ukglabor_m_employmentstatus_history','oss.noram.us.ukglabor_m_employmentstatus_landing','oss.noram.us.ukglabor_m_employmentstatus_standardized','oss.noram.us.ukglabor_non_sdx_emps_history','oss.noram.us.ukglabor_non_sdx_emps_landing','oss.noram.us.ukglabor_non_sdx_emps_standardized','oss.noram.us.ukglabor_org_history','oss.noram.us.ukglabor_org_landing','oss.noram.us.ukglabor_org_path_master_history','oss.noram.us.ukglabor_org_path_master_landing','oss.noram.us.ukglabor_org_path_master_standardized','oss.noram.us.ukglabor_org_standardized','oss.noram.us.ukglabor_orgtype_history','oss.noram.us.ukglabor_orgtype_landing','oss.noram.us.ukglabor_orgtype_standardized','oss.noram.us.ukglabor_paycode_history','oss.noram.us.ukglabor_paycode_landing','oss.noram.us.ukglabor_paycode_standardized','oss.noram.us.ukglabor_payperiod_history','oss.noram.us.ukglabor_payperiod_landing','oss.noram.us.ukglabor_payperiod_standardized','oss.noram.us.ukglabor_payrule_history','oss.noram.us.ukglabor_payrule_landing','oss.noram.us.ukglabor_payrule_standardized','oss.noram.us.ukglabor_payruleids_history','oss.noram.us.ukglabor_payruleids_landing','oss.noram.us.ukglabor_payruleids_standardized','oss.noram.us.ukglabor_person_accrualprofile_history','oss.noram.us.ukglabor_person_accrualprofile_landing','oss.noram.us.ukglabor_person_accrualprofile_standardized','oss.noram.us.ukglabor_person_history','oss.noram.us.ukglabor_person_landing','oss.noram.us.ukglabor_person_standardized','oss.noram.us.ukglabor_personcstmdata_history','oss.noram.us.ukglabor_personcstmdata_landing','oss.noram.us.ukglabor_personcstmdata_standardized','oss.noram.us.ukglabor_prsncstmdatemm_history','oss.noram.us.ukglabor_prsncstmdatemm_landing','oss.noram.us.ukglabor_prsncstmdatemm_standardized','oss.noram.us.ukglabor_s_krs_org_history','oss.noram.us.ukglabor_s_krs_org_landing','oss.noram.us.ukglabor_s_krs_org_standardized','oss.noram.us.ukglabor_s_krs_servicetype_cc_xref_history','oss.noram.us.ukglabor_s_krs_servicetype_cc_xref_landing','oss.noram.us.ukglabor_s_krs_servicetype_cc_xref_standardized','oss.noram.us.ukglabor_s_krs_servicetype_job_xref_history','oss.noram.us.ukglabor_s_krs_servicetype_job_xref_landing','oss.noram.us.ukglabor_s_krs_servicetype_job_xref_standardized','oss.noram.us.ukglabor_s_krs_wfcjob_history','oss.noram.us.ukglabor_s_krs_wfcjob_landing','oss.noram.us.ukglabor_s_krs_wfcjob_standardized','oss.noram.us.ukglabor_sdxo_fg_id_upload_history','oss.noram.us.ukglabor_sdxo_fg_id_upload_landing','oss.noram.us.ukglabor_sdxo_fg_id_upload_standardized','oss.noram.us.ukglabor_sdxunit_history','oss.noram.us.ukglabor_sdxunit_landing','oss.noram.us.ukglabor_sdxunit_standardized','oss.noram.us.ukglabor_shiftassignmnt_history','oss.noram.us.ukglabor_shiftassignmnt_landing','oss.noram.us.ukglabor_shiftassignmnt_standardized','oss.noram.us.ukglabor_shiftcode_history','oss.noram.us.ukglabor_shiftcode_landing','oss.noram.us.ukglabor_shiftcode_standardized','oss.noram.us.ukglabor_shiftsegment_history','oss.noram.us.ukglabor_shiftsegment_landing','oss.noram.us.ukglabor_shiftsegment_standardized','oss.noram.us.ukglabor_shiftsegmnttype_history','oss.noram.us.ukglabor_shiftsegmnttype_landing','oss.noram.us.ukglabor_shiftsegmnttype_standardized','oss.noram.us.ukglabor_timecard_exceptions_history','oss.noram.us.ukglabor_timecard_exceptions_landing','oss.noram.us.ukglabor_timecard_exceptions_standardized','oss.noram.us.ukglabor_timecard_extended_exception_history','oss.noram.us.ukglabor_timecard_extended_exception_landing','oss.noram.us.ukglabor_timecard_extended_exception_standardized','oss.noram.us.ukglabor_timecard_historicalcorrections_history','oss.noram.us.ukglabor_timecard_historicalcorrections_landing','oss.noram.us.ukglabor_timecard_historicalcorrections_standardized','oss.noram.us.ukglabor_timecard_paycodeedits_entries_history','oss.noram.us.ukglabor_timecard_paycodeedits_entries_landing','oss.noram.us.ukglabor_timecard_processedsegments_history','oss.noram.us.ukglabor_timecard_processedsegments_landing','oss.noram.us.ukglabor_timecard_processedsegments_standardized','oss.noram.us.ukglabor_timecard_punches_exception_history','oss.noram.us.ukglabor_timecard_punches_exception_landing','oss.noram.us.ukglabor_timecard_punches_exception_standardized','oss.noram.us.ukglabor_timecard_punches_notes_history','oss.noram.us.ukglabor_timecard_punches_notes_landing','oss.noram.us.ukglabor_timecard_punches_notes_standardized','oss.noram.us.ukglabor_timecard_response200_history','oss.noram.us.ukglabor_timecard_response200_landing','oss.noram.us.ukglabor_timecard_response200_standardized','oss.noram.us.ukglabor_timecard_scheduledtotal_history','oss.noram.us.ukglabor_timecard_scheduledtotal_landing','oss.noram.us.ukglabor_timecard_scheduledtotal_standardized','oss.noram.us.ukglabor_timecard_scheduleshifts_history','oss.noram.us.ukglabor_timecard_scheduleshifts_landing','oss.noram.us.ukglabor_timecard_scheduleshifts_standardized','oss.noram.us.ukglabor_timecard_totals_aggregatedtotals_history','oss.noram.us.ukglabor_timecard_totals_aggregatedtotals_landing','oss.noram.us.ukglabor_timecard_totals_aggregatedtotals_standardized','oss.noram.us.ukglabor_timecard_totalsummary_history','oss.noram.us.ukglabor_timecard_totalsummary_landing','oss.noram.us.ukglabor_timecard_totalsummary_standardized','oss.noram.us.ukglabor_timecard_workedshifts_workedspan_history','oss.noram.us.ukglabor_timecard_workedshifts_workedspan_landing','oss.noram.us.ukglabor_timecard_workedshifts_workedspan_standardized','oss.noram.us.ukglabor_timecard_workholidaycredits_history','oss.noram.us.ukglabor_timecard_workholidaycredits_landing','oss.noram.us.ukglabor_ukg_jobcodes_history','oss.noram.us.ukglabor_ukg_jobcodes_landing','oss.noram.us.ukglabor_ukg_jobcodes_standardized','oss.noram.us.ukglabor_ukg_location_hierarchy_history','oss.noram.us.ukglabor_ukg_location_hierarchy_landing','oss.noram.us.ukglabor_ukg_location_hierarchy_standardized','oss.noram.us.ukglabor_vhr_employeeall_history','oss.noram.us.ukglabor_vhr_employeeall_landing','oss.noram.us.ukglabor_vhr_employeeall_standardized','oss.noram.us.ukglabor_vhr_employeeallwithfinancehierarchy_history','oss.noram.us.ukglabor_vhr_employeeallwithfinancehierarchy_landing','oss.noram.us.ukglabor_vhr_employeeallwithfinancehierarchy_standardized','oss.noram.us.ukglabor_wfcjob_history','oss.noram.us.ukglabor_wfcjob_landing','oss.noram.us.ukglabor_wfcjob_standardized','oss.noram.us.ukglabor_wfcjoborg_history','oss.noram.us.ukglabor_wfcjoborg_landing','oss.noram.us.ukglabor_wfcjoborg_standardized','oss.noram.us.ukglabor_wtkemployee_history','oss.noram.us.ukglabor_wtkemployee_landing','oss.noram.us.ukglabor_wtkemployee_standardized' + '')
                --context_id IN ('oss.glb.glb.dynamify_sdx_getallowances_history','oss.glb.glb.dynamify_sdx_getallowances_landing','oss.glb.glb.dynamify_sdx_getallowances_standardized','oss.glb.glb.dynamify_sdx_menudataexportobject_history','oss.glb.glb.dynamify_sdx_menudataexportobject_landing','oss.glb.glb.dynamify_sdx_menudataexportobject_standardized','oss.glb.glb.dynamify_sdx_tradescommercexportobject_history','oss.glb.glb.dynamify_sdx_tradescommercexportobject_landing','oss.glb.glb.dynamify_sdx_tradescommercexportobject_standardized','oss.glb.glb.dynamify_sdx_mealdeal_history','oss.glb.glb.dynamify_sdx_mealdeal_landing','oss.glb.glb.dynamify_sdx_mealdeal_standardized'+'')
                --context_id IN ('oss.glb.glb.dynamify_sdx_menudataexportobject_history','oss.glb.glb.dynamify_sdx_menudataexportobject_landing','oss.glb.glb.dynamify_sdx_menudataexportobject_standardized'+'')
                AND dataset_name  in ('accrualcode','accrualprofile','accruals_vac_plan','AccrualSummary','accrualtran','basewagerthist','can_employee_data_import','can_labor_category_entry','combohomeacct','customdatadef','d_jobcode','d_segmentation','d_unit','employeerate','epretim_a','exceptiontype','geofencing_mainlocation','geofencing_request','hr_jobdescriptions','jobcode_master','jobcode_servicetype_xref','known_places','labor_category','laborforecast','laborleveldef','laborstandards','labortaskgroups','labortasks','location_sets','m_employmentstatus','non_sdx_emps','org','org_path_master','orgtype','paycode','payperiod','payrule','payruleids','person','person_accrualprofile','personcstmdata','prsncstmdatemm','s_krs_org','s_krs_servicetype_cc_xref','s_krs_servicetype_job_xref','s_krs_wfcjob','sdxo_fg_id_upload','sdxunit','shiftassignmnt','shiftcode','shiftsegment','shiftsegmnttype','timecard_audit','timecard_exceptions','timecard_extended_exception','timecard_historicalcorrections','timecard_paycodeedits_entries','timecard_processedsegments','timecard_punches_exception','timecard_punches_notes','timecard_response200','timecard_scheduledtotal','timecard_scheduleshifts','timecard_totals_aggregatedtotals','timecard_totalsummary','timecard_workedshifts_workedspan','timecard_workholidaycredits','ukg_jobcodes','ukg_location_hierarchy','vhr_employeeall','vhr_employeeallwithfinancehierarchy','wfcjob','wfcjoborg','wtkemployee')
                AND project_name  in ('oss.noram.us.ukglabor')
                AND metric_name IN ('processing_started_date', 'processing_finished_date', 'processing_exit_code', 'rows_count', 'content_latest_date')
        ),
        MergedEvents AS (
            SELECT
                job_id,
                context_id,
                timestamp,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                [processing_started_date] AS processing_started_date_value,
                [processing_finished_date] AS processing_finished_date_value,
                [processing_exit_code] AS processing_exit_code_value,
                [content_latest_date] AS content_latest_date,
                [rows_count] AS rows_count_value
            FROM
                FilteredEvents
            PIVOT (
                MAX(metric_value)
                FOR metric_name IN ([processing_started_date], [processing_finished_date], [processing_exit_code], [rows_count], [content_latest_date])
            ) AS PivotTable
        ),
        Finalevents as
        (
        SELECT
            MAX(project_name) AS 'Application Source',
            MAX(dataset_name) AS 'Dataset',
            MAX(landing_zone) AS 'Zone',
            MAX(
                CASE subscription_id
                    WHEN '6b4a5b3f-1015-42da-a46a-2890a5abed30' THEN 'IFM CORE PROD'
                    WHEN '2698ca5b-bf81-43fb-8fe2-f0e21bf068e5' THEN 'IFM CORE UAT/TEST'
                    WHEN '746ac5b9-70eb-4c76-bdf4-0664bfdff2ea' THEN 'IFM CORE DEV'
                    WHEN 'cf25f2a1-4d40-45af-bb81-87ec46112b3e' THEN 'SDX STA/PRD'
                    WHEN 'c0978b9d-b809-45f4-aa76-391ceb2cfdba' THEN 'SDX DEV/TEST'
                    WHEN '8eaa3d95-3cd2-49d8-b44a-7ea47a6fb58b' THEN 'SDX SILVER'
                    WHEN 'daf86ec1-725c-493f-bf09-a1f129b8588a' THEN 'SDX INT/UAT'
                    WHEN 'fea1e9f0-0e20-426f-906e-bc76e5a566ad' THEN 'SDX Sandbox'
                    WHEN '6e3fc63f-851b-4fc7-8499-48f6a9c28a65' THEN 'SDX Global Shared Services'
                    ELSE 'Undefined'
            END
            ) AS 'Subscription',
            MAX(takeoff_zone) + ' to ' + MAX(landing_zone) AS 'Activity',
            CASE
                WHEN MAX(processing_exit_code_value) = 0 THEN 'Succeeded'
                WHEN MAX(processing_exit_code_value) = 1 THEN 'No New Data'
                WHEN MAX(processing_exit_code_value) = 2 THEN 'Skipped'
                WHEN MAX(processing_exit_code_value) IS NULL THEN 'Running'
                ELSE 'Failed'
            END AS 'Status',
            DATEADD(SECOND, MAX([timestamp]), '1970-01-01') AS 'Landed at',
            DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([timestamp]) AS 'Landed Since',
            DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([content_latest_date]) AS 'Freshness',
            CAST(MAX(processing_finished_date_value) - MAX(processing_started_date_value) AS BIGINT) AS 'Duration',
            ISNULL(CAST(CAST(MAX(rows_count_value) AS BIGINT) AS VARCHAR), 'N/A') AS 'Rows'
        FROM MergedEvents
        GROUP BY job_id, context_id
        ),
        Eventsdata as(
            Select [Application Source] as ApplicationSource, Dataset,Zone, Subscription, Activity, Status,[Landed at] as LandedAt,[Landed Since] as LandedSince,[Freshness] as Freshness, Duration,[Rows] as IngestedRows from Finalevents
            where Status in ('Succeeded','Failed','No New Data','Running','Skipped')
        ),
 
        finaldata as (select
            ApplicationSource ,
            Dataset,
            case
                   when count(case when Activity = 'landing to history' and status = 'succeeded' then 1 end) >= 1
                   and count(case when Activity = 'history to standardized' and status = 'succeeded' then 1 end) >= 1
                then 'OK'        
                else 'NOT OK'
            end as [Overall Status],
            Subscription as [Datalake Location],
            case
                when count(case when Activity = 'landing to history' and status = 'succeeded' then 1 end) >= 1
                then 'OK'
                else 'NOT OK'
            end as [Bronze History Status],
            case
                when count(case when Activity = 'history to standardized' and status = 'succeeded' then 1 end) >= 1                    
        then 'OK'
                else 'NOT OK'
            end as [Bronze Standardized Status],    
            max(case
                when Activity = 'landing to history' then LandedAt
                end)
        as [Pipe Line Execution StartTime],
            max(case
                when Activity = 'history to standardized' then LandedAt
                end)
        as [Pipe Line Execution EndTime],
 
            datediff(second,
            min(case
                when Activity = 'landing to history' then LandedAt
                end),current_timestamp
            ) as [Pipe Line Executed Since],
            max(Freshness) as Freshness,
            datediff(second,
            min(case when Activity = 'landing to history' then landedAt end),
            max(case when Activity = 'history to standardized' then landedAt end)
           ) as 'Total Execution Time',
           convert(Date, LandedAt) as executedDate
        From Eventsdata
        group by ApplicationSource,
            Dataset,
            subscription,
            convert(Date, LandedAt)
        ),
        RankedData as
        (
            select  ApplicationSource,
                    Dataset,
                    [Datalake Location],
                    executedDate,
                    case
                    when executedDate < getdate()
                    then DatedIff(second,max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                        else
                        DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Overall Refresh Status],
                    case when executedDate < getdate()
                then DatedIff(second, max([Pipe Line Execution StartTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    else
                    DatedIff(second, max([Pipe Line Execution StartTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Bronze History Refresh Status],
                case when executedDate < getdate()
                then DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    else
                    DatedIff(second,max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Bronze Standardized Refresh Status],
                row_number() over (partition by ApplicationSource, Dataset order by executedDate desc) as rownum,
                    [Pipe Line Execution EndTime],
                [Pipe Line Execution StartTime],
                [Pipe Line Executed Since],
                    Freshness,
                    [Total Execution Time],
                 86400 as [Freshness Threshold]
        from finalData
            where  [Overall Status] = 'OK'
        ),
        cte2 as (
            select ApplicationSource,
                Dataset,
                [Freshness Threshold] as 'Threshold',
                [Overall Refresh Status] as 'Freshness Refresh Status',
                [Bronze History Refresh Status],
                [Bronze Standardized Refresh Status],
                [Pipe Line Execution StartTime],
                [Pipe Line Execution EndTime],
                executedDate,
                Freshness,
                ([Freshness Threshold] - [Overall Refresh Status]) AS Differenceintime,
                CASE
                    WHEN ([Freshness Threshold] - [Overall Refresh Status]) < 0 THEN 1
                    WHEN ([Freshness Threshold] - [Overall Refresh Status]) > 0 THEN 2
                    ELSE 0
                END AS Colour_Code
            from RankedData
            where  rownum = 1
        )
        select Dataset as DatasetName, 
        CASE
            WHEN Threshold < 604800 THEN
                CAST(Threshold / 86400 AS VARCHAR(10)) + ' Day'
            ELSE
                CAST(Threshold / 604800 AS VARCHAR(10)) + ' Week'
            END AS FreshnessThreshold, 
        count(*) as [FailureCount] from cte2 where Colour_Code = 1
        group by Dataset,Threshold";

    local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
    local silence_labels = std.join("::", envs);
    local channels = source.alerting.channels;

    {
        "uid": std.md5(std.format("DataAvailabilityFreshness %s",source.project_name)),
        "title": std.format("Data Availability Freshness: %s", [source.project_name]),
        "condition": "B",
        "data": [
            {
                "refId": "A",
                "relativeTimeRange": {
                    "from": 172800,
                    "to": 0
                },
                "datasourceUid": "AzureSQLServer",
                "model": {
                    "editorMode": "code",
                    "format": "table",
                    "intervalMs": 60000,
                    "maxDataPoints": 43200,
                    "queryText": DataAvailability,
                    "rawEditor": true,
                    "rawQuery": true,
                    "rawSql": DataAvailability,
                    "refId": "A",
                    "sql": {
                        "columns": [
                            {
                                "parameters": [],
                                "type": "function"
                            }
                        ],
                        "groupBy": [
                            {
                                "property": {
                                    "type": "string"
                                },
                                "type": "groupBy"
                            }
                        ],
                        "limit": 50
                    }
                }
            },
            {
                "refId": "B",
                "relativeTimeRange": {
                    "from": 172800,
                    "to": 0
                },
                "datasourceUid": "__expr__",
                "model": {
                    "conditions": [
                        {
                            "evaluator": {
                                "params": [
                                    0
                                ],
                                "type": "gt"
                            },
                            "operator": {
                                "type": "and"
                            },
                            "query": {
                                "params": [
                                    "C"
                                ]
                            },
                            "reducer": {
                                "params": [],
                                "type": "last"
                            },
                            "type": "query"
                        }
                    ],
                    "expression": "A",
                    "intervalMs": 1000,
                    "maxDataPoints": 43200,
                    "refId": "B",
                    "type": "threshold"
                }
            }
        ],
        "dashboardUid": "ukg_pro_dashboard",
        "panelId": 14,
        "noDataState": "OK",
        "execErrState": "Error",
        "for": "5m",
        "labels": {
            "project_name": source.project_name,
            "alert_type": source.alerting.type,
            "env": silence_labels,
            "severity": source.alerting.severity,
            "dashboard_title": title,
            "channels": std.join("::", channels),
        },
        "annotations": {
            "__dashboardUid__": "ukg_pro_dashboard",
            "__panelId__": "14"
        },
        "isPaused": false,
    };
 
local convertToGrafanaAlertDiff3(source, title) =
  local DBTAvailability = 
    " with cte as (
        select 
            format(dateadd(second, t.exec_ts, '1970-01-01'), 'yyy-MM-dd HH:mm:ss') as ExecutionTime,
            t.project_name as 'PipleineName',
            case when t.exit_code = 0 
                    Then 'Succeeded' 
                    Else 'Failed' 
            End as Status,
            case when t.exit_code = 0 then 0
                else 1
            end as status_flag
            from (
                select event_id, 
                        project_name, 
                        max(timestamp) as exec_ts, 
                        max(metric_value) as exit_code 
                from observability.event
                where project_name = 'oss.noram.us.ukglaborDBT' 
                        and event_type = 'processingfinished' 
                        and metric_name = 'processing_exit_code'
                group by event_id, project_name
            ) t
        )
        select distinct ExecutionTime, Status, status_flag from cte
        where status_flag > 0
        ORDER BY ExecutionTime desc
    ";

    local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
    local silence_labels = std.join("::", envs);
    local channels = source.alerting.channels;

    {
        "uid": std.md5(std.format("DBTPipelineFreshness %s",source.project_name)),
        "title": std.format("DBT Pipeline Freshness: %s", [source.project_name]),
        "condition": "B",
        "data": [
            {
                "refId": "A",
                "relativeTimeRange": {
                    "from": 172800,
                    "to": 0
                },
                "datasourceUid": "AzureSQLServer",
                "model": {
                    "editorMode": "code",
                    "format": "table",
                    "intervalMs": 60000,
                    "maxDataPoints": 43200,
                    "queryText": DBTAvailability,
                    "rawEditor": true,
                    "rawQuery": true,
                    "rawSql": DBTAvailability,
                    "refId": "A",
                    "sql": {
                        "columns": [
                            {
                                "parameters": [],
                                "type": "function"
                            }
                        ],
                        "groupBy": [
                            {
                                "property": {
                                    "type": "string"
                                },
                                "type": "groupBy"
                            }
                        ],
                        "limit": 50
                    }
                }
            },
            {
                "refId": "B",
                "relativeTimeRange": {
                    "from": 172800,
                    "to": 0
                },
                "datasourceUid": "__expr__",
                "model": {
                    "conditions": [
                        {
                            "evaluator": {
                                "params": [
                                    0
                                ],
                                "type": "gt"
                            },
                            "operator": {
                                "type": "and"
                            },
                            "query": {
                                "params": [
                                    "C"
                                ]
                            },
                            "reducer": {
                                "params": [],
                                "type": "last"
                            },
                            "type": "query"
                        }
                    ],
                    "expression": "A",
                    "intervalMs": 1000,
                    "maxDataPoints": 43200,
                    "refId": "B",
                    "type": "threshold"
                }
            }
        ],
        "dashboardUid": "ukg_pro_dashboard",
        "panelId": 15,
        "noDataState": "OK",
        "execErrState": "Error",
        "for": "5m",
        "labels": {
            "project_name": source.project_name,
            "alert_type": source.alerting.type,
            "env": silence_labels,
            "severity": source.alerting.severity,
            "dashboard_title": title,
            "channels": std.join("::", channels),
        },
        "annotations": {
            "__dashboardUid__": "ukg_pro_dashboard",
            "__panelId__": "15"
        },
        "isPaused": false,
    };
  
local input_json = std.parseYaml(std.extVar("input"));
local dashboard_title = input_json.title;
local filtered_sources = filterSourceWithAlerting(input_json.sources);
local flat_sources = flatSources(filtered_sources);
local volume_threshold_alerts = filterVolumeAlertRows(flat_sources);
local volume_alerts_grafana = [convertToGrafanaAlertVolume(source, dashboard_title) for source in volume_threshold_alerts];

local data_availability_alerts = filterDiffAlertRows(flat_sources);
local data_availability_alerts_grafana = [convertToGrafanaAlertDiff2(source, dashboard_title) for source in data_availability_alerts];

local dbt_freshness_alerts = filterDbtAlertRows(flat_sources);
local dbt_freshness_alerts_grafana = [convertToGrafanaAlertDiff3(source, dashboard_title) for source in dbt_freshness_alerts];
 
{
    "apiVersion": 1,
    "groups": [
        {
        "orgId": 1,
        "name": "Volume Data Observability " + input_json.title,
        "folder": "Data Observability",
        "interval": "30m",
        rules: volume_alerts_grafana + data_availability_alerts_grafana + dbt_freshness_alerts_grafana,
        }
    ]
}
 