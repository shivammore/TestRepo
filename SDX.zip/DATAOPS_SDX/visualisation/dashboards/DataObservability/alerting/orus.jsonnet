local grafana = import 'grafonnet/grafana.libsonnet';
 
local filterSourceWithAlerting(sources) = [ source for source in sources if std.objectHas(source, 'alerting') && source.alerting != null ];
 
local flatSources(objs) = [
    {
        project_name: if std.type(obj.project_name) == "string" then obj.project_name else pr,
        dataset_name: if std.type(obj.dataset_name) == "string" then obj.dataset_name else d,
        alerting: if std.type(obj.alerting) == "string" then obj.alerting else alerting,
    }
    for obj in objs
    for pr in if std.type(obj.project_name) == "array" then obj.project_name else [obj.project_name]
    for d in if std.type(obj.dataset_name) == "array" then obj.dataset_name else [obj.dataset_name]
    for alerting in if std.type(obj.alerting) == "array" then obj.alerting else [obj.alerting]
];
 
local filterVolumeAlertRows(sources) = [
    source for source in sources
    if std.objectHas(source, 'alerting') &&  // Check if 'alerting' field exists
        source.alerting.type == 'Volume_Check_Orus' &&
        std.objectHas(source.alerting, 'volume_check_threshold')
];
 
local convertToGrafanaAlertVolume(source, title) =
    local volume_check_threshold = source.alerting.volume_check_threshold;
    local panelId = source.alerting.panel;
    local panelName = source.alerting.panelName;
    local channels = source.alerting.channels;
    local dataset_name = source.dataset_name;
    local project_name = source.project_name;
    local time = source.alerting.relativeTimeRange;
 
    local rawsql1 = " 
    with cte as
        (    select distinct project_name as 'Application Source',
                dataset_name as 'Dataset Name',
                timestamp as 'Timestamp',
                format(DATEADD(SECOND, timestamp, '1970-01-01'), 'yyyy-MM-dd') as 'Transaction Date' ,
                'Transaction Count is less than 50% of the previous week' as 'Threshold',
                metric_value as 'Transaction count',
            (
                select top 1 metric_value from observability.event as prev
                    where prev.project_name = r.project_name
                    and prev.dataset_name = r.dataset_name
                    and prev.landing_zone = 'standardized'
                    and prev.metric_name = 'rows_count'
                    and prev.event_type = 'processingfinished'
                    and format(dateadd(second, prev.timestamp, '1970-01-01'), 'yyyy-MM-dd') =
                        format(dateadd(second, r.timestamp - 7*24*60*60, '1970-01-01'), 'yyyy-MM-dd')
                ) as 'Last Week Transaction Count'
            from [observability].[event] as r
            where  project_name = 'oss.fr.fr.orus'
                and dataset_name in ('sol_ansaxe','sol_cat_article','sol_cat_ingredient','sol_cat_ingredient_produit','sol_cat_mercuriale','sol_cat_produit','sol_cat_produit_article_cp','sol_gestion_convive','sol_gestion_famille_recette_n1','sol_gestion_famille_recette_n2','sol_gestion_famille_recette_n3','sol_gestion_offre','sol_gestion_repas','sol_gestion_segment','sol_gestion_statut','sol_gestion_type_recette','sol_gestion_typologie_offre','sol_gestion_typologie_regime','sol_gestionfamillerecette_n3','sol_menu_convive','sol_menu_detail','sol_menu_entete','sol_menu_repas','sol_menu_typologie_regime','sol_produit_hc_national','sol_produit_hc_site','sol_recette','sol_recette_convive','sol_recette_info','sol_recette_ingredient','sol_recette_preparation','sol_recette_produit_hc','sol_recette_typologie_offre','sol_recette_typologie_regime','sol_site_typologie_offre')  
                and landing_zone = 'Standardized'
                and metric_name = 'rows_count'
                and event_type = 'processingfinished'
                and timestamp = (select max(timestamp) from [observability].[event]
                where project_name = r.project_name and timestamp = r.timestamp)
                and timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
        )
        select [Application Source] as project_name, [Dataset Name] as dataset_name,
            [Transaction Date] as transaction_date, [Threshold],
        cast(([Transaction Count]  - [Last Week Transaction Count]) / nullif([Last Week Transaction Count], 0) * 100 as decimal(10,2)) as 'Volume_Check' from cte
        order by Timestamp desc";
 
    local rawsql2 = "with cte as
        (    select distinct project_name as 'Application Source',
                dataset_name as 'Dataset Name',
                timestamp as 'Timestamp',
                format(DATEADD(SECOND, timestamp, '1970-01-01'), 'yyyy-MM-dd') as 'Transaction Date' ,
                'Transaction Count is less than 50% of the previous week' as 'Threshold',
                metric_value as 'Transaction count',
            (
                select top 1 metric_value from observability.event as prev
                    where prev.project_name = r.project_name
                    and prev.dataset_name = r.dataset_name
                    and prev.landing_zone = 'history'
                    and prev.metric_name = 'rows_count'
                    and prev.event_type = 'processingfinished'
                    and format(dateadd(second, prev.timestamp, '1970-01-01'), 'yyyy-MM-dd') =
                        format(dateadd(second, r.timestamp - 7*24*60*60, '1970-01-01'), 'yyyy-MM-dd')
                ) as 'Last Week Transaction Count'
            from [observability].[event] as r
            where project_name = 'oss.fr.fr.orus'
                and dataset_name in ('sol_ansaxe','sol_cat_article','sol_cat_ingredient','sol_cat_ingredient_produit','sol_cat_mercuriale','sol_cat_produit','sol_cat_produit_article_cp','sol_gestion_convive','sol_gestion_famille_recette_n1','sol_gestion_famille_recette_n2','sol_gestion_famille_recette_n3','sol_gestion_offre','sol_gestion_repas','sol_gestion_segment','sol_gestion_statut','sol_gestion_type_recette','sol_gestion_typologie_offre','sol_gestion_typologie_regime','sol_gestionfamillerecette_n3','sol_menu_convive','sol_menu_detail','sol_menu_entete','sol_menu_repas','sol_menu_typologie_regime','sol_produit_hc_national','sol_produit_hc_site','sol_recette','sol_recette_convive','sol_recette_info','sol_recette_ingredient','sol_recette_preparation','sol_recette_produit_hc','sol_recette_typologie_offre','sol_recette_typologie_regime','sol_site_typologie_offre')  
                and landing_zone = 'history'
                and metric_name = 'rows_count'
                and event_type = 'processingfinished'
                and timestamp = (select max(timestamp) from [observability].[event]
                where project_name = r.project_name and timestamp = r.timestamp)
                and timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
        )
        select [Application Source] as project_name, [Dataset Name] as dataset_name,
            [Transaction Date] as transaction_date, [Threshold],
        cast(([Transaction Count]  - [Last Week Transaction Count]) / nullif([Last Week Transaction Count], 0) * 100 as decimal(10,2)) as 'Volume_Check' from cte
        order by Timestamp desc";
 
 
local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
local silence_labels = std.join("::", envs);
local rawSql = if panelName == "Weekly Volume check - Standardized" then rawsql1 else rawsql2 ;

{
    "uid": std.md5(std.format("DataVolumeCheck_%s_%s",[project_name,panelName])),
    "title": std.format("Data Volume Alert: FFDI ──── %s ──── %s",[project_name,panelName]),
    "condition": "C",
    "data": [
        {
            "refId": "A",
            "datasourceUid": "AzureSQLServer",
            "relativeTimeRange": { "from": time, "to": 0 },
            "model": {
            "format": "table",
            "hide": false,
            "intervalMs": 1000,
            "maxDataPoints": 43200,
            "rawQuery": true,
            "rawSql": rawSql,
            }
        },
        {
            "refId": "B",
            "relativeTimeRange": {
                "from": time,
                "to": 0
            },
            "datasourceUid": "__expr__",
            "model": {
                "conditions": [
                    {
                        "evaluator": {
                            "params": [
                                -volume_check_threshold,
                                volume_check_threshold
                            ],
                            "type": 'outside_range'
                        },
                        "operator": {
                            "type": "and"
                        },
                        "query": {
                            "params": [
                                "B"
                            ]
                        },
                        "reducer": {
                            "params": [],
                            "type": "last"
                        },
                        "type": "query"
                    }
                ],
                "datasource": {
                    "type": "__expr__",
                    "uid": "__expr__"
                },
                "expression": "A",
                "intervalMs": 1000,
                "maxDataPoints": 43200,
                "reducer": "last",
                "refId": "B",
                "type": "reduce"
            }
        },
        {
            "refId": "C",
            "relativeTimeRange": {
                "from": time,
                "to": 0
            },
            "datasourceUid": "__expr__",
            "model": {
                "conditions": [
                    { 
                        "evaluator": {
                            "params": [
                                -volume_check_threshold,
                                volume_check_threshold
                            ],
                            "type": 'outside_range'
                        },
                        "operator": {
                            "type": "and"
                        },
                        "query": {
                            "params": [
                                "C"
                            ]
                        },
                        "reducer": {
                            "params": [],
                            "type": "last"
                        },
                        "type": "query"
                    }
                ],
                "datasource": {
                    "type": "__expr__",
                    "uid": "__expr__"
                },
                "expression": "B",
                "intervalMs": 1000,
                "maxDataPoints": 43200,
                "refId": "C",
                "type": "threshold"
            }
        }
    ],
    "noDataState": "OK",
    "for": "5m",
    "annotations": {
        "__dashboardUid__": "21EiXdsfddd15H1",
        "__panelId__": panelId,
    },
    "labels": {
        "alert_type": "Volume_Check",
        "volume_check_threshold": volume_check_threshold,
        "env": silence_labels,
        "severity": source.alerting.severity,
        "dashboard_title": title,
        "panel_name": panelName,
        "channels": std.join("::", channels),
    }
};
 
 
local input_json = std.parseYaml(std.extVar("input"));
local dashboard_title = input_json.title;
local filtered_sources = filterSourceWithAlerting(input_json.sources);
local flat_sources = flatSources(filtered_sources);
local volume_threshold_alerts = filterVolumeAlertRows(flat_sources);
local volume_alerts_grafana = [convertToGrafanaAlertVolume(source, dashboard_title) for source in volume_threshold_alerts];
 
{
    "apiVersion": 1,
    "groups": [
        {
        "orgId": 1,
        "name": "Volume Data Observability " + input_json.title,
        "folder": "Data Observability",
        "interval": "30m",
        rules: volume_alerts_grafana,
        }
    ]
}
 