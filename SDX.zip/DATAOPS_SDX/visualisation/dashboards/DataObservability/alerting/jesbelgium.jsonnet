local grafana = import 'grafonnet/grafana.libsonnet';
 
local filterSourceWithAlerting(sources) = [ source for source in sources if std.objectHas(source, 'alerting') && source.alerting != null ];
 
local flatSources(objs) = [
    {
        project_name: if std.type(obj.project_name) == "string" then obj.project_name else pr,
        dataset_name: if std.type(obj.dataset_name) == "string" then obj.dataset_name else d,
        alerting: if std.type(obj.alerting) == "string" then obj.alerting else alerting,
    }
    for obj in objs
    for pr in if std.type(obj.project_name) == "array" then obj.project_name else [obj.project_name]
    for d in if std.type(obj.dataset_name) == "array" then obj.dataset_name else [obj.dataset_name]
    for alerting in if std.type(obj.alerting) == "array" then obj.alerting else [obj.alerting]
];
 
local filterVolumeAlertRows(sources) = [
    source for source in sources
    if std.objectHas(source, 'alerting') &&  // Check if 'alerting' field exists
        source.alerting.type == 'Volume_Check_Jes' &&
        std.objectHas(source.alerting, 'volume_check_threshold')
];
 
local convertToGrafanaAlertVolume(source, title) =
    local volume_check_threshold = source.alerting.volume_check_threshold;
    local panelId = source.alerting.panel;
    local panelName = source.alerting.panelName;
    local channels = source.alerting.channels;
    local dataset_name = source.dataset_name;
    local project_name = source.project_name;
    local time = source.alerting.relativeTimeRange;
 
    local rawsql1 = " 
    with date_list as (
    select cast(dateadd(second, $__unixEpochFrom(), '1970-01-01') as date) as txn_date
    union all
    select dateadd(day, 1, txn_date)
    from date_list
    where txn_date < cast(dateadd(second, $__unixEpochTo(), '1970-01-01') as date)
)
 
    ,main as (
    select distinct
        project_name,
        dataset_name,
        cast(dateadd(second, timestamp, '1970-01-01') as date) as txn_date,
        sum(case when landing_zone = 'history' then metric_value else 0 end) as bronze_count,
        sum(case when landing_zone = 'standardized' then metric_value else 0 end) as silver_count
    from [observability].[event] as r
    where project_name = 'oss.coe.be.jes'
      and dataset_name = 'receipts'
      and landing_zone in ('standardized','history')
      and metric_name = 'rows_count'
      and event_type = 'processingfinished'
      and timestamp = (select max(timestamp) from [observability].[event] 
      where project_name = r.project_name and timestamp = r.timestamp)
      group by project_name, dataset_name, cast(dateadd(second, timestamp, '1970-01-01') as date)
)
 
    select
    coalesce(b.project_name, 'oss.coe.be.jes') as [Application Source],
    coalesce(b.dataset_name, 'receipts') as [Dataset Name],
    format(d.txn_date, 'yyyy-MM-dd') as [Transaction_Date],
    'Data volume > 1100' as [Threshold],
    cast(coalesce(b.silver_count, 0) as decimal(10,2)) as [Silver Transaction Count]
    from date_list d
    left join main b
    on d.txn_date = b.txn_date
    where datediff(second, '1970-01-01 00:00:00',d.txn_date) between $__unixEpochFrom() and $__unixEpochTo()
    order by d.txn_date desc
    option (maxrecursion 1000)

 ";
 
    local rawsql2 = " 
    with date_list as (
    select cast(dateadd(second, $__unixEpochFrom(), '1970-01-01') as date) as txn_date
    union all
    select dateadd(day, 1, txn_date)
    from date_list
    where txn_date < cast(dateadd(second, $__unixEpochTo(), '1970-01-01') as date)
)
    ,main as (
    select distinct
        project_name,
        dataset_name,
        cast(dateadd(second, timestamp, '1970-01-01') as date) as txn_date,
        sum(case when landing_zone = 'history' then metric_value else 0 end) as bronze_count,
        sum(case when landing_zone = 'standardized' then metric_value else 0 end) as silver_count
    from [observability].[event] as r
    where project_name = 'oss.coe.be.jes'
      and dataset_name = 'operatingunits'
      and landing_zone in ('standardized','history')
      and metric_name = 'rows_count'
      and event_type = 'processingfinished'
      and timestamp = (select max(timestamp) from [observability].[event] 
      where project_name = r.project_name and timestamp = r.timestamp)
      group by project_name, dataset_name, cast(dateadd(second, timestamp, '1970-01-01') as date)
)
 
    select
    coalesce(b.project_name, 'oss.coe.be.jes') as [Application Source],
    coalesce(b.dataset_name, 'operatingunits') as [Dataset Name],
    format(d.txn_date, 'yyyy-MM-dd') as [Transaction_Date],
    'Data volume > 3' as [Threshold],
    cast(coalesce(b.silver_count, 0) as decimal(10,2)) as [Silver Transaction Count]
    from date_list d
    left join main b
    on d.txn_date = b.txn_date
    where datediff(second, '1970-01-01 00:00:00',d.txn_date) between $__unixEpochFrom() and $__unixEpochTo()
    order by d.txn_date desc
    option (maxrecursion 1000)
";
 
 
local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
local silence_labels = std.join("::", envs);
local rawSql = if panelName == "Data Volume Receipts" then rawsql1 else rawsql2 ;

{
    "uid": std.md5(std.format("DataVolumeCheck_%s_%s",[project_name,panelName])),
    "title": std.format("Data Volume Alert: JES Belgium ──── %s ──── %s",[project_name,panelName]),
    "condition": "C",
    "data": [
        {
            "refId": "A",
            "datasourceUid": "AzureSQLServer",
            "relativeTimeRange": { "from": time, "to": 0 },
            "model": {
            "format": "table",
            "hide": false,
            "intervalMs": 60000,
            "maxDataPoints": 43200,
            "rawQuery": true,
            "rawSql": rawSql,
            }
        },
        {
            "refId": "B",
            "relativeTimeRange": {
                "from": time,
                "to": 0
            },
            "datasourceUid": "__expr__",
            "model": {
                "conditions": [
                    {
                        "evaluator": {
                            "params": [],
                            "type": "gt"
                        },
                        "operator": {
                            "type": "and"
                        },
                        "query": {
                            "params": [
                                "B"
                            ]
                        },
                        "reducer": {
                            "params": [],
                            "type": "last"
                        },
                        "type": "query"
                    }
                ],
                "datasource": {
                    "type": "__expr__",
                    "uid": "__expr__"
                },
                "expression": "A",
                "intervalMs": 1000,
                "maxDataPoints": 43200,
                "reducer": "last",
                "refId": "B",
                "type": "reduce"
            }
        },
        {
            "refId": "C",
            "relativeTimeRange": {
                "from": time,
                "to": 0
            },
            "datasourceUid": "__expr__",
            "model": {
                "conditions": [
                    { 
                        "evaluator": {
                            "params": [
                                volume_check_threshold
                            ],
                            "type": "lt"
                        },
                        "operator": {
                            "type": "and"
                        },
                        "query": {
                            "params": [
                                "C"
                            ]
                        },
                        "reducer": {
                            "params": [],
                            "type": "last"
                        },
                        "type": "query"
                    }
                ],
                "datasource": {
                    "type": "__expr__",
                    "uid": "__expr__"
                },
                "expression": "B",
                "intervalMs": 1000,
                "maxDataPoints": 43200,
                "refId": "C",
                "type": "threshold"
            }
        }
    ],
    "noDataState": "OK",
    "for": "5m",
    "annotations": {
        "__dashboardUid__": "21EiXdsfddd15H120",
        "__panelId__": panelId,
    },
    "labels": {
    "project_name": source.project_name,
    "dataset_name": source.dataset_name,
    "alert_type": "Volume_Check",
    "volume_check_threshold": volume_check_threshold,
    "env": silence_labels,
    "severity": source.alerting.severity,
    "dashboard_title": title,
    "panel_name": panelName,
    "channels": std.join("::", channels),
    }
}; 
 
local input_json = std.parseYaml(std.extVar("input"));
local dashboard_title = input_json.title;
local filtered_sources = filterSourceWithAlerting(input_json.sources);
local flat_sources = flatSources(filtered_sources);
local volume_threshold_alerts = filterVolumeAlertRows(flat_sources);
local volume_alerts_grafana = [convertToGrafanaAlertVolume(source, dashboard_title) for source in volume_threshold_alerts];
 
{
    "apiVersion": 1,
    "groups": [
        {
        "orgId": 1,
        "name": "Volume Data Observability " + input_json.title,
        "folder": "Data Observability",
        "interval": "30m",
        rules: volume_alerts_grafana,
        }
    ]
}
 