local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
 
local filterSourceWithAlerting(sources) = [ source for source in sources if std.objectHas(source, 'alerting') && source.alerting != null ];
 
local flatSources(objs) = [
  {
    project_name: if std.type(obj.project_name) == "string" then obj.project_name else pr,
    dataset_name: if std.type(obj.dataset_name) == "string" then obj.dataset_name else d,
    source_system: if std.objectHas(obj, 'source_system') then (
      if std.type(obj.source_system) == "string" then obj.source_system else sid
    ) else null,
    alerting: if std.type(obj.alerting) == "string" then obj.alerting else alerting,
    channels: alerting.channels,
  }
  for obj in objs
  for pr in if std.type(obj.project_name) == "array" then obj.project_name else [obj.project_name]
  for d in if std.type(obj.dataset_name) == "array" then obj.dataset_name else [obj.dataset_name]
  for sid in if std.objectHas(obj, 'source_system') then (
    if std.type(obj.source_system) == "array" then obj.source_system else [obj.source_system]
  ) else []
  for alerting in if std.type(obj.alerting) == "array" then obj.alerting else [obj.alerting]
];

local filterDiffAlertRows(sources) = [
  source for source in sources
  if std.objectHas(source, 'alerting') && source.alerting.type == 'APIM-Standardized'
];

local filterDiffAlertRows2(sources) = [
  source for source in sources
  if std.objectHas(source, 'alerting') && source.alerting.type == 'APIM-Azure'
];

local filterDiffAlertRows3(sources) = [
  source for source in sources
  if std.objectHas(source, 'alerting') && source.alerting.type == 'APIM-Freshness'
];

local filterDiffAlertRows4(sources) = [
  source for source in sources
  if std.objectHas(source, 'alerting') && source.alerting.type == 'TCPOS-Errors'
];

##-------------------------------------------------------------------------------------------------

local convertToGrafanaAlertDiff(source, title) =
  local channels = source.alerting.channels;
  local rawSql = std.format("
    WITH rankedrecords AS (
              SELECT
                  project_name AS 'Application Source',
                  dataset_name AS 'Dataset Name',
                  site_id AS 'Site ID',
                  record_date AS 'Transaction Date',
                  record_count AS 'Transaction Count',
                  PARSENAME(project_name, 1) AS source_system,
                  ROW_NUMBER() OVER (PARTITION BY record_date, site_id ORDER BY record_count DESC) AS rn
              FROM [observability].[food_distribution_consumer_transactions_custom_slo_metrics]
             WHERE record_date BETWEEN DATEADD(SECOND, $__unixEpochFrom(), '1970-01-01') AND DATEADD(SECOND, $__unixEpochTo(), '1970-01-01')
                    AND dataset_name = 'consumer_transaction' 
                    AND PARSENAME(project_name, 1) = '%s'
          )
          SELECT
              FORMAT([Transaction Date], 'yyyy-MM-dd') AS 'TransactionDate',
              SUM([Transaction Count]) AS 'Count'
          FROM rankedrecords
          WHERE rn = 1
          GROUP BY [Dataset Name], [Transaction Date]
          ORDER BY FORMAT([Transaction Date], 'yyyy-MM-dd') DESC;
        ", source.source_system);

    local rawKQL = std.format(|||
      requests
        | where timestamp >= startofday(now() - 1d) and timestamp < startofday(now())
        | where url contains "consumer-transactions"
        | where success == "True"
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | where tostring(customDimensions.["Request-x-source-application-id"]) == "%s"
        | summarize latest_timestamp = max(timestamp) by idempotencykey
        | summarize Count = count(), stamp = max(latest_timestamp) by bin(latest_timestamp, 1d)
        | project TransactionDate = format_datetime(stamp, "yyyy-MM-dd"), Count
        | order by TransactionDate desc
     |||, source.source_system);

    local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
    local silence_labels = std.join("::", envs);

 
   {
        "uid": std.md5(std.format("TrackingAPIMtoStandardizedZoneDifference %s",source.source_system)),
        "title": std.format("Tracking APIM to Standardized Zone Difference: %s", [source.source_system]),
        "condition": "D",
        "data": [
            {
                "refId": "A",
                "relativeTimeRange": {
                    "from": 172800,
                    "to": 86400
                },
                "datasourceUid": "AzureSQLServer",
                "model": {
                    "datasource": {
                        "type": "mssql",
                        "uid": "AzureSQLServer"
                    },
                    "format": "table",
                    "intervalMs": 60000,
                    "maxDataPoints": 43200,
                    "query": {
                        "alias": "Standardized Requests",
                        "format": "table",
                        "rawEditor": true,
                        "rawQuery": true,
                        "rawSql": rawSql
                    },
                    "rawMode": true,
                    "rawQuery": true,
                    "rawSql": rawSql,
                    "refId": "A"
                }
            },
            {
                "refId": "B",
                "queryType": "Azure Log Analytics",
                "relativeTimeRange": {
                    "from": 172800,
                    "to": 86400
                },
                "datasourceUid": "AzureMonitor",
                "model": {
                    "azureLogAnalytics": {
                        "dashboardTime": false,
                        "query": rawKQL,
                        "resources": [
                            "/subscriptions/cf25f2a1-4d40-45af-bb81-87ec46112b3e/resourceGroups/GLB-GLB-IENO-HIP-PRD-RG01/providers/microsoft.insights/components/azieai1kzf380"
                        ],
                        "resultFormat": "logs"
                    },
                    "azureMonitor": {
                        "allowedTimeGrainsMs": [],
                        "timeGrain": "auto"
                    },
                    "datasource": {
                        "type": "grafana-azure-monitor-datasource",
                        "uid": "AzureMonitor"
                    },
                    "hide": false,
                    "intervalMs": 1000,
                    "maxDataPoints": 43200,
                    "queryType": "Azure Log Analytics",
                    "refId": "B"
                }
            },
            {
                "refId": "C",
                "relativeTimeRange": {
                    "from": 600,
                    "to": 0
                },
                "datasourceUid": "__expr__",
                "model": {
                    "conditions": [
                        {
                            "evaluator": {
                                "params": [
                                    0,
                                    0
                                ],
                                "type": "gt"
                            },
                            "operator": {
                                "type": "and"
                            },
                            "query": {
                                "params": []
                            },
                            "reducer": {
                                "params": [],
                                "type": "avg"
                            },
                            "type": "query"
                        }
                    ],
                    "datasource": {
                        "name": "Expression",
                        "type": "__expr__",
                        "uid": "__expr__"
                    },
                    "expression": "$B - $A",
                    "hide": false,
                    "intervalMs": 1000,
                    "maxDataPoints": 43200,
                    "refId": "C",
                    "type": "math"
                }
            },
            {
                "refId": "D",
                "relativeTimeRange": {
                    "from": 600,
                    "to": 0
                },
                "datasourceUid": "__expr__",
                "model": {
                    "conditions": [
                        {
                            "evaluator": {
                                "params": [
                                    0,
                                    0
                                ],
                                "type": "outside_range"
                            },
                            "operator": {
                                "type": "and"
                            },
                            "query": {
                                "params": [
                                    "C"
                                ]
                            },
                            "reducer": {
                                "params": [],
                                "type": "last"
                            },
                            "type": "query"
                        }
                    ],
                    "datasource": {
                        "type": "__expr__",
                        "uid": "__expr__"
                    },
                    "expression": "C",
                    "hide": false,
                    "refId": "D",
                    "type": "threshold"
                }
            }
        ],
        "dashboardUid": "innovorder-ingestion-tracker",
        "panelId": 3,
        "noDataState": "OK",
        "execErrState": "Error",
        "for": "5m",
        "labels": {
            "project_name": source.project_name,
            "dataset_name": source.dataset_name,
            "source_system": source.source_system,
            "alert_type": source.alerting.type,
            "env": silence_labels,
            "severity": source.alerting.severity,
            "dashboard_title": title,
            "channels": std.format("ConsumerTransaction-%s", [source.source_system]),
        },
        "annotations": {
            "__dashboardUid__": "innovorder-ingestion-tracker",
            "__panelId__": "3"
        },
        "isPaused": false,
    };

local convertToGrafanaAlertDiff2(source, title) =
  local channels = source.alerting.channels;
    local rawKQL = std.format(|||
     requests
        | where timestamp >= startofday(now() - 1d) and timestamp < startofday(now())
        | where url contains "consumer-transactions"
        | where success == "True"
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | where tostring(customDimensions.["Request-x-source-application-id"]) == "%s"
        | summarize latest_timestamp = max(timestamp) by idempotencykey
        | summarize Count = count(), stamp = max(latest_timestamp) by bin(latest_timestamp, 1d)
        | project TransactionDate = format_datetime(stamp, "yyyy-MM-dd"), Count
        | order by TransactionDate desc
    |||, source.source_system);

    local rawKQL2 = std.format(|||
     InnovorderConsumerTransactions_CL
        | where TimeGenerated >= startofday(now() - 1d) and TimeGenerated < startofday(now())
        | where StatusCode_d in ('200', '201')
        | extend idempotencykey = IdempotencyKey_s
        | where isnotempty(idempotencykey)
        | where SourceApplicationId_s in ("%s")
        | summarize latest_timestamp = max(TimeGenerated) by idempotencykey
        | summarize Count = count(), stamp = max(latest_timestamp) by bin(latest_timestamp, 1d)
        | project TransactionDate = format_datetime(stamp, "yyyy-MM-dd"), Count
        | order by TransactionDate desc
    |||, source.source_system);

    local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
    local silence_labels = std.join("::", envs);
 
                {
                    "uid": std.md5(std.format("TrackingAPIMtoAzureFunctionDifference %s",source.source_system)),
                    "title": std.format("Tracking APIM to Azure Function Difference: %s", [source.source_system]),
                    "condition": "D",
                    "data": [
                        {
                            "refId": "A",
                            "queryType": "Azure Log Analytics",
                            "relativeTimeRange": {
                                "from": 172800,
                                "to": 0
                            },
                            "datasourceUid": "AzureMonitor",
                            "model": {
                                "azureLogAnalytics": {
                                    "dashboardTime": false,
                                    "query": rawKQL,
                                    "resources": [
                                        "/subscriptions/cf25f2a1-4d40-45af-bb81-87ec46112b3e/resourceGroups/GLB-GLB-IENO-HIP-PRD-RG01/providers/microsoft.insights/components/azieai1kzf380"
                                    ],
                                    "resultFormat": "logs",
                                    "timeColumn": "",
                                    "workspace": ""
                                },
                                "datasource": {
                                    "type": "grafana-azure-monitor-datasource",
                                    "uid": "AzureMonitor"
                                },
                                "editorMode": "code",
                                "format": "table",
                                "intervalMs": 1000,
                                "maxDataPoints": 43200,
                                "queryType": "Azure Log Analytics",
                                "rawQuery": true,
                                "rawSql": "",
                                "refId": "A",
                                "sql": {
                                    "columns": [
                                        {
                                            "parameters": [],
                                            "type": "function"
                                        }
                                    ],
                                    "groupBy": [
                                        {
                                            "property": {
                                                "type": "string"
                                            },
                                            "type": "groupBy"
                                        }
                                    ],
                                    "limit": 50
                                }
                            }
                        },
                        {
                            "refId": "B",
                            "queryType": "Azure Log Analytics",
                            "relativeTimeRange": {
                                "from": 172800,
                                "to": 0
                            },
                            "datasourceUid": "AzureMonitor",
                            "model": {
                                "azureLogAnalytics": {
                                    "dashboardTime": false,
                                    "query": rawKQL2,
                                    "resources": [
                                        "/subscriptions/cf25f2a1-4d40-45af-bb81-87ec46112b3e/resourceGroups/GLB-GLB-IENO-HIP-PRD-RG01/providers/Microsoft.OperationalInsights/workspaces/aziemm1ozv389"
                                    ],
                                    "resultFormat": "logs",
                                    "timeColumn": "",
                                    "workspace": ""
                                },
                                "dataset": "aziedb1kil452",
                                "datasource": {
                                    "type": "grafana-azure-monitor-datasource",
                                    "uid": "AzureMonitor"
                                },
                                "editorMode": "builder",
                                "format": "table",
                                "intervalMs": 1000,
                                "maxDataPoints": 43200,
                                "queryType": "Azure Log Analytics",
                                "rawSql": "",
                                "refId": "B"
                            }
                        },
                        {
                            "refId": "C",
                            "relativeTimeRange": {
                                "from": 0,
                                "to": 0
                            },
                            "datasourceUid": "__expr__",
                            "model": {
                                "conditions": [
                                    {
                                        "evaluator": {
                                            "params": [
                                                0,
                                                0
                                            ],
                                            "type": "gt"
                                        },
                                        "operator": {
                                            "type": "and"
                                        },
                                        "query": {
                                            "params": []
                                        },
                                        "reducer": {
                                            "params": [],
                                            "type": "avg"
                                        },
                                        "type": "query"
                                    }
                                ],
                                "datasource": {
                                    "name": "Expression",
                                    "type": "__expr__",
                                    "uid": "__expr__"
                                },
                                "expression": "$B - $A",
                                "hide": false,
                                "intervalMs": 1000,
                                "maxDataPoints": 43200,
                                "refId": "C",
                                "type": "math"
                            }
                        },
                        {
                            "refId": "D",
                            "relativeTimeRange": {
                                "from": 600,
                                "to": 0
                            },
                            "datasourceUid": "__expr__",
                            "model": {
                                "conditions": [
                                    {
                                        "evaluator": {
                                            "params": [
                                                0,
                                                0
                                            ],
                                            "type": "outside_range"
                                        },
                                        "operator": {
                                            "type": "and"
                                        },
                                        "query": {
                                            "params": [
                                                "C"
                                            ]
                                        },
                                        "reducer": {
                                            "params": [],
                                            "type": "last"
                                        },
                                        "type": "query"
                                    }
                                ],
                                "datasource": {
                                    "type": "__expr__",
                                    "uid": "__expr__"
                                },
                                "expression": "C",
                                "hide": false,
                                "refId": "D",
                                "type": "threshold"
                            }
                        }
                    ],
                    "dashboardUid": "innovorder-ingestion-tracker",
                    "panelId": 4,
                    "noDataState": "OK",
                    "execErrState": "Error",
                    "for": "5m",
                    "annotations": {
                        "__dashboardUid__": "innovorder-ingestion-tracker",
                        "__panelId__": "4"
                    },
                    "labels": {
                        "project_name": source.project_name,
                        "dataset_name": source.dataset_name,
                        "source_system": source.source_system,
                        "alert_type": source.alerting.type,
                        "env": silence_labels,
                        "severity": source.alerting.severity,
                        "dashboard_title": title,                                  
                        "channels": std.format("ConsumerTransaction-%s", [source.source_system]),
                    },
                    "isPaused": false,
                };

local convertToGrafanaAlertDiff3(source, title) =
  local channels = source.alerting.channels;
    local rawFreshness = std.format("
        with latestrecords as
          (
            select dataset_name as 'Dataset Name', Site_id as 'Site Id', Threshold = '259200',
              max(case when record_count > 0 then record_date END) over (partition by site_id) As 'Last Updated Record',
              record_date as 'Record Date',
              record_count as 'Record Count',
              row_number() over (partition by site_id order by record_date desc) as row_num,
              PARSENAME(project_name, 1) AS source_system
            from [observability].[food_distribution_consumer_transactions_custom_slo_metrics] 
            where PARSENAME(project_name, 1) = '%s'
          )
          select distinct lr.[Dataset name],
                  lr.[Site Id] as Site_id,
              lr.Threshold,
        case 
           when GetDate() >= DATEADD(Day, 1 , CAST(lr.[Last Updated Record] AS DATE))       
           Then DATEDIFF(second, DATEADD(DAY, 1, CAST(lr.[Last Updated Record] AS DATE)), GetDate())
        else Datediff(second, CAST(lr.[Last Updated Record] AS DATE), GetDate())
        End as [Freshness Status]
          from latestrecords lr
          left join [observability].[food_distribution_consumer_transactions_custom_slo_metrics] pd
              on lr.[Site Id] = pd.site_id
              and pd.record_date = DateAdd(Day, -1, lr.[Record Date])
          where lr.row_num = 1;
          ", source.source_system);

local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
local silence_labels = std.join("::", envs);
 
                {
                    "uid": std.md5(std.format("TrackingFreshness %s",source.source_system)),
                    "title": std.format("Tracking Freshness: %s", [source.source_system]),
                    "condition": "B",
                    "data": [
                        {
                            "refId": "A",
                            "relativeTimeRange": {
                                "from": 86400,
                                "to": 0
                            },
                            "datasourceUid": "AzureSQLServer",
                            "model": {
                                "datasource": {
                                    "type": "mssql",
                                    "uid": "AzureSQLServer"
                                },
                                "editorMode": "code",
                                "format": "table",
                                "intervalMs": 60000,
                                "maxDataPoints": 43200,
                                "rawEditor": true,
                                "rawQuery": true,
                                "rawSql": rawFreshness,
                                "refId": "A",
                                "sql": {
                                    "columns": [
                                        {
                                            "parameters": [],
                                            "type": "function"
                                        }
                                    ],
                                    "groupBy": [
                                        {
                                            "property": {
                                                "type": "string"
                                            },
                                            "type": "groupBy"
                                        }
                                    ],
                                    "limit": 50
                                }
                            }
                        },
                        {
                            "refId": "B",
                            "relativeTimeRange": {
                                "from": 86400,
                                "to": 0
                            },
                            "datasourceUid": "__expr__",
                            "model": {
                                "conditions": [
                                    {
                                        "evaluator": {
                                            "params": [
                                                259200
                                            ],
                                            "type": "gt"
                                        },
                                        "operator": {
                                            "type": "and"
                                        },
                                        "query": {
                                            "params": [
                                                "B"
                                            ]
                                        },
                                        "reducer": {
                                            "params": [],
                                            "type": "last"
                                        },
                                        "type": "query"
                                    }
                                ],
                                "datasource": {
                                    "type": "__expr__",
                                    "uid": "__expr__"
                                },
                                "expression": "A",
                                "intervalMs": 1000,
                                "maxDataPoints": 43200,
                                "refId": "B",
                                "type": "threshold"
                            }
                        }
                    ],
                    "dashboardUid": "innovorder-ingestion-tracker",
                    "panelId": 5,
                    "noDataState": "OK",
                    "execErrState": "Error",
                    "for": "5m",
                    "annotations": {
                        "__dashboardUid__": "innovorder-ingestion-tracker",
                        "__panelId__": "5"
                    },
                    "labels": {
                        "project_name": source.project_name,
                        "dataset_name": source.dataset_name,
                        "source_system": source.source_system,
                        "alert_type": source.alerting.type,
                        "env": silence_labels,
                        "severity": source.alerting.severity,
                        "dashboard_title": title,
                        "channels": std.format("ConsumerTransaction-%s", [source.source_system]),
                    },
                    "isPaused": false,
                };

local TCPOSerrordetails(source, title) =
  local channels = source.alerting.channels;
    local rawErrors = |||
        let functionApps = dynamic(['aziefn1qhb612']);
        traces
        | where timestamp >= ago(30m)
        | where isempty(functionApps) or cloud_RoleName in (functionApps)
        | where message contains "Error"
        | where message !contains "URL"
        | where message !contains "Host"
        | extend ErrorMessage = extract(@"Error\s*:\s*(.*)", 1, message)
        | where isnotempty(ErrorMessage)
        | summarize ErrorCount = count() by ErrorMessage, Timestamp = format_datetime(timestamp, "yyyy-MM-dd HH:mm:ss")
        | order by Timestamp desc
    |||;

local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
local silence_labels = std.join("::", envs);
 
        {
            "uid": "dezpydcg7m680c",
            "title": "Error/Exception details",
            "condition": "B",
            "data": [
                {
                    "refId": "A",
                    "queryType": "Azure Log Analytics",
                    "relativeTimeRange": {
                        "from": 1800,
                        "to": 0
                    },
                    "datasourceUid": "AzureMonitor",
                    "model": {
                        "azureLogAnalytics": {
                            "dashboardTime": false,
                            "query": rawErrors,
                            "resources": [
                                "/subscriptions/cf25f2a1-4d40-45af-bb81-87ec46112b3e/resourceGroups/GLB-GLB-IENO-HIP-PRD-RG01/providers/microsoft.insights/components/azieai1kzf380"
                            ],
                            "resultFormat": "logs",
                            "timeColumn": "",
                            "workspace": ""
                        },
                        "datasource": {
                            "type": "grafana-azure-monitor-datasource",
                            "uid": "AzureMonitor"
                        },
                        "intervalMs": 1000,
                        "maxDataPoints": 43200,
                        "queryType": "Azure Log Analytics",
                        "refId": "A"
                    }
                },
                {
                    "refId": "B",
                    "relativeTimeRange": {
                        "from": 1800,
                        "to": 0
                    },
                    "datasourceUid": "__expr__",
                    "model": {
                        "conditions": [
                            {
                                "evaluator": {
                                    "params": [
                                        0,
                                        0
                                    ],
                                    "type": "gt"
                                },
                                "operator": {
                                    "type": "and"
                                },
                                "query": {
                                    "params": []
                                },
                                "reducer": {
                                    "params": [],
                                    "type": "avg"
                                },
                                "type": "query"
                            }
                        ],
                        "datasource": {
                            "name": "Expression",
                            "type": "__expr__",
                            "uid": "__expr__"
                        },
                        "expression": "A",
                        "intervalMs": 1000,
                        "maxDataPoints": 43200,
                        "refId": "B",
                        "type": "threshold"
                    }
                }
            ],
            "dashboardUid": "innovorder-ingestion-tracker",
            "panelId": 12,
            "noDataState": "OK",
            "execErrState": "Alerting",
            "for": "5m",
            "labels": {
                "project_name": source.project_name,
                "dataset_name": source.dataset_name,
                "source_system": source.source_system,
                "alert_type": "TCPOS-Errors",
                "env": silence_labels,
                "severity": source.alerting.severity,
                "dashboard_title": title,
                "channels": std.format("ConsumerTransaction-%s-Error", [source.source_system]),
            },
            "annotations": {
                "__dashboardUid__": "innovorder-ingestion-tracker",
                "__panelId__": "12"
            },
        };

local input_json = std.parseYaml(std.extVar("input"));
local dashboard_title = input_json.title;
local filtered_sources = filterSourceWithAlerting(input_json.sources);
local flat_sources = flatSources(filtered_sources);
local diff_threshold_alerts = filterDiffAlertRows(flat_sources);
local diff_alerts_grafana = [convertToGrafanaAlertDiff(source, dashboard_title) for source in diff_threshold_alerts];

local diff_threshold_alerts2 = filterDiffAlertRows2(flat_sources);
local diff_alerts_grafana2 = [convertToGrafanaAlertDiff2(source, dashboard_title) for source in diff_threshold_alerts2];

local diff_threshold_alerts3 = filterDiffAlertRows3(flat_sources);
local diff_alerts_grafana3 = [convertToGrafanaAlertDiff3(source, dashboard_title) for source in diff_threshold_alerts3];

local tcpos_errors = filterDiffAlertRows4(flat_sources);
local tcpos_errors_alerts = [TCPOSerrordetails(source, dashboard_title) for source in tcpos_errors];


local all_alerts = diff_alerts_grafana + diff_alerts_grafana2 + diff_alerts_grafana3;

local source_systems = std.set(
  [alert.labels.source_system for alert in all_alerts]
);

local grouped_by_source = {
  [source]: [alert for alert in all_alerts if alert.labels.source_system == source]
  for source in source_systems
};

{
  "apiVersion": 1,
  "groups": [
    {
      "orgId": 1,
      "name": "Volume Data Observability " + input_json.title,
      "folder": "Data Observability",
      "interval": "30m",
      rules: grouped_by_source[source],
    }
    for source in std.objectFields(grouped_by_source)
    ] + [
    {
      "orgId": 1,
      "name": "TCPOS Errors Data Observability " + input_json.title,
      "folder": "Data Observability",
      "interval": "30m",
      rules: tcpos_errors_alerts,
    }
  ]
}