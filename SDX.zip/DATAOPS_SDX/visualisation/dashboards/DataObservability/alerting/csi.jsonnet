local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
 
local filterSourceWithAlerting(sources) = [ source for source in sources if std.objectHas(source, 'alerting') && source.alerting != null ];
 
local flatSources(objs) = [
  {
    project_name: if std.type(obj.project_name) == "string" then obj.project_name else pr,
    dataset_name: if std.type(obj.dataset_name) == "string" then obj.dataset_name else d,
    alerting: if std.type(obj.alerting) == "string" then obj.alerting else alerting,
    channels: alerting.channels,
  }
  for obj in objs
  for pr in if std.type(obj.project_name) == "array" then obj.project_name else [obj.project_name]
  for d in if std.type(obj.dataset_name) == "array" then obj.dataset_name else [obj.dataset_name]
  for alerting in if std.type(obj.alerting) == "array" then obj.alerting else [obj.alerting]
];

local filterSiteFreshnessAlertRows(sources) = [
  source for source in sources
  if std.objectHas(source, 'alerting') &&  
     source.alerting.type == 'Site-Freshness'
];



##-------------------------------------------------------------------------------------------------

local convertToGrafanaAlertSiteFreshness(source, title) =
  local channels = source.alerting.channels;
  local input_json = std.parseYaml(std.extVar("input"));
  local SiteFreshnessSQL = "
            with latestrecords as
          (
            select dataset_name as 'Dataset Name', Site_id as 'Site Id', Threshold = '259200',
              max(case when record_count > 0 then record_date END) over (partition by site_id) As 'Last Updated Record',
              record_date as 'Record Date',
              record_count as 'Record Count',
              row_number() over (partition by site_id order by record_date desc) as row_num,
              PARSENAME(project_name, 1) AS source_system
            from [observability].[pos_csi_anonymized_tickets_custom_slo_metrics]
            --where PARSENAME(project_name, 1) = 'innovorder'
          ),
          cte as (
                select distinct lr.[Dataset name] as [dataset_name],
                        lr.[Site Id] as Site_id,
                    lr.Threshold as [Threshold],
              case
                when GetDate() >= DATEADD(Day, 1 , CAST(lr.[Last Updated Record] AS DATE))      
                Then DATEDIFF(second, DATEADD(DAY, 1, CAST(lr.[Last Updated Record] AS DATE)), GetDate())
              else Datediff(second, CAST(lr.[Last Updated Record] AS DATE), GetDate())
              End as [Freshness Status]
              from latestrecords lr
                left join [observability].[pos_csi_anonymized_tickets_custom_slo_metrics] pd
                    on lr.[Site Id] = pd.site_id
                    and pd.record_date = DateAdd(Day, -1, lr.[Record Date])
                where lr.row_num = 1
          ),
          cte1 as (
            select Site_id,
            case when [Freshness Status] > 259200 then 1
                else 0 end as [Status]
            from cte
          )
          select Site_id, Status FROM cte1 where Status > 0
        ";

    local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
    local silence_labels = std.join("::", envs);

    {
        "uid": std.md5(std.format("Tracking Site Freshness:CSI %s",source.project_name)),
        "title": std.format("Tracking Site Freshness:CSI : %s", [source.project_name]),
        "condition": "B",
        "data": [
            {
                "refId": "A",
                "relativeTimeRange": {
                    "from": 172800,
                    "to": 0
                },
                "datasourceUid": "AzureSQLServer",
                "model": {
                    "datasource": {
                        "type": "mssql",
                        "uid": "AzureSQLServer"
                    },
                    "format": "table",
                    "intervalMs": 1000,
                    "maxDataPoints": 43200,
                    "query": {
                        "alias": "Standardized Requests",
                        "format": "table",
                        "rawEditor": true,
                        "rawQuery": true,
                        "rawSql": SiteFreshnessSQL
                    },
                    "rawMode": true,
                    "rawQuery": true,
                    "rawSql": SiteFreshnessSQL,
                    "refId": "A"
                }
            },
            {
                "refId": "B",
                "relativeTimeRange": {
                    "from": 172800,
                    "to": 0
                },
                "datasourceUid": "__expr__",
                "model": {
                    "conditions": [
                        {
                            "evaluator": {
                                "params": [
                                    0
                                ],
                                "type": "gt"
                            },
                            "operator": {
                                "type": "and"
                            },
                            "query": {
                                "params": [
                                    "C"
                                ]
                            },
                            "reducer": {
                                "params": [],
                                "type": "last"
                            },
                            "type": "query"
                        }
                    ],
                    "expression": "A",
                    "intervalMs": 1000,
                    "maxDataPoints": 43200,
                    "refId": "B",
                    "type": "threshold"
                }
            } 
        ],
        "dashboardUid": "ffdi_csi_dashboard",
        "panelId": 3,
        "noDataState": "OK",
        "execErrState": "Error",
        "for": "5m",
        "labels": {
            "project_name": source.project_name,
            "alert_type": source.alerting.type,
            "env": silence_labels,
            "severity": source.alerting.severity,
            "dashboard_title": title,
            "channels": std.join("::", channels),
        },
        "annotations": {
            "__dashboardUid__": "ffdi_csi_dashboard",
            "__panelId__": "3"
        },
        "isPaused": false,
    };

local input_json = std.parseYaml(std.extVar("input"));
local dashboard_title = input_json.title;
local filtered_sources = filterSourceWithAlerting(input_json.sources);
local flat_sources = flatSources(filtered_sources);


local site_freshness_alerts = filterSiteFreshnessAlertRows(flat_sources);
local site_freshness_rules_grafana = [convertToGrafanaAlertSiteFreshness(source, dashboard_title) for source in site_freshness_alerts];


{
  "apiVersion": 1,
  "groups": [
    {
      "orgId": 1,
      "name": "Volume Data Observability " + input_json.title,
      "folder": "Data Observability",
      "interval": "30m",
      rules: site_freshness_rules_grafana,
    },
  ]
}