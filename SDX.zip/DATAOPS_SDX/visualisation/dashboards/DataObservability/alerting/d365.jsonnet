local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
 
local filterSourceWithAlerting(sources) = [ source for source in sources if std.objectHas(source, 'alerting') && source.alerting != null ];
 
local flatSources(objs) = [
  {
    project_name: pr,
    alerting: alerting,
    channels: alerting.channels,
  }
 
  for obj in objs
 
  // project_name flattening (optional field)
  for pr in (
    if std.objectHas(obj, 'project_name') then
      (if std.type(obj.project_name) == "array"
       then obj.project_name
       else [obj.project_name])
    else [null]
  )
 
  // alerting flattening
  for alerting in (
    if std.type(obj.alerting) == "array"
    then obj.alerting
    else [obj.alerting]
  )
];

local filterDiffAlertRows(sources) = [
  source for source in sources
  if std.objectHas(source, 'alerting') && source.alerting.type == 'Data_Availability_D365'
];

local filterDiffAlertRows2(sources) = [
  source for source in sources
  if std.objectHas(source, 'alerting') && source.alerting.type == 'Technical_Freshness_D365'
];

##-------------------------------------------------------------------------------------------------

local convertToGrafanaAlertDiff(source, title) =
  local DataAvailability = std.format("
        WITH cte AS (
            SELECT 
                REPLACE(project_name, '_', '.') AS [Application Source], 
                table_name AS [Dataset Name],
                CASE 
                    WHEN row_count > 0 THEN 'Data Available' 
                    ELSE 'Data Not Available' 
                END AS [Data Availability Status],
                FORMAT(CAST(run_date AS DATE), 'yyyy-MM-dd') AS [Latest Refresh Date]
            FROM observability.d365_volume_data
            WHERE row_count >= 0
            AND table_name in ('account', 'activitypointer', 'adx_portalcomment', 'annotation', 'bookableresource', 'bookableresourcebooking', 'bookableresourcecategory', 'contact', 'contract', 'entitlement', 'ifm_assettype', 'ifm_contract', 'ifm_country', 'ifm_feedback', 'ifm_log', 'ifm_masterservicecategory', 'ifm_servicecategory', 'ifm_workordernote', 'incident', 'incidentresolution', 'msdyn_agreement', 'msdyn_customerasset', 'msdyn_expense', 'msdyn_priority', 'msdyn_project', 'msdyn_projectapproval', 'msdyn_projecttask', 'msdyn_resourcerequirement', 'msdyn_survey', 'msdyn_timeentry', 'msdyn_workorder', 'msdyn_workordertype', 'pricelevel', 'queue', 'quote', 'role', 'sdxmob_facility', 'sla', 'slaitem', 'slakpiinstance', 'systemuser', 'timezonedefinition', 'timezonerule', 'transactioncurrency')
            AND REPLACE(project_name, '_', '.') IN ('%s')
        )
        SELECT 
            [Dataset Name] as DatasetName, 
            COUNT(*) AS [Count]
        FROM cte
        WHERE [Data Availability Status] = 'Data Not Available'
        GROUP BY [Application Source], [Dataset Name]
        ORDER BY [Application Source], [Dataset Name];",source.project_name);

    local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
    local silence_labels = std.join("::", envs);
    local channels = if source.project_name == 'oss.coe.glb.d365' then 'FMD365COE'
                     else if source.project_name == 'oss.noram.glb.d365' then 'FMD365NORAM'
                     else 'FMD365APAC';

    {
        "uid": std.md5(std.format("DataAvailabilityFMD365 %s",source.project_name)),
        "title": std.format("Data Availability FM D365: %s", [source.project_name]),
        "condition": "B",
        "data": [
            {
                "refId": "A",
                "relativeTimeRange": {
                    "from": 172800,
                    "to": 0
                },
                "datasourceUid": "AzureSQLServer",
                "model": {
                    "editorMode": "code",
                    "format": "table",
                    "intervalMs": 60000,
                    "maxDataPoints": 43200,
                    "queryText": DataAvailability,
                    "rawEditor": true,
                    "rawQuery": true,
                    "rawSql": DataAvailability,
                    "refId": "A",
                    "sql": {
                        "columns": [
                            {
                                "parameters": [],
                                "type": "function"
                            }
                        ],
                        "groupBy": [
                            {
                                "property": {
                                    "type": "string"
                                },
                                "type": "groupBy"
                            }
                        ],
                        "limit": 50
                    }
                }
            },
            {
                "refId": "B",
                "relativeTimeRange": {
                    "from": 172800,
                    "to": 0
                },
                "datasourceUid": "__expr__",
                "model": {
                    "conditions": [
                        {
                            "evaluator": {
                                "params": [
                                    0
                                ],
                                "type": "gt"
                            },
                            "operator": {
                                "type": "and"
                            },
                            "query": {
                                "params": [
                                    "C"
                                ]
                            },
                            "reducer": {
                                "params": [],
                                "type": "last"
                            },
                            "type": "query"
                        }
                    ],
                    "expression": "A",
                    "intervalMs": 1000,
                    "maxDataPoints": 43200,
                    "refId": "B",
                    "type": "threshold"
                }
            }
        ],
        "dashboardUid": "fmd365dashbaord",
        "panelId": 31,
        "noDataState": "OK",
        "execErrState": "Error",
        "for": "5m",
        "labels": {
            "project_name": source.project_name,
            "alert_type": source.alerting.type,
            "env": silence_labels,
            "severity": source.alerting.severity,
            "dashboard_title": title,
            "channels": channels,
        },
        "annotations": {
            "__dashboardUid__": "fmd365dashbaord",
            "__panelId__": "31"
        },
        "isPaused": false,
    };

local convertToGrafanaAlertDiff2(source, title) =

  local datasetList = [
    'account', 'activitypointer', 'adx_portalcomment', 'annotation', 'bookableresource', 'bookableresourcebooking', 'bookableresourcecategory', 'contact', 'contract', 'entitlement', 'ifm_assettype', 'ifm_contract', 'ifm_country', 'ifm_feedback', 'ifm_log', 'ifm_masterservicecategory', 'ifm_servicecategory', 'ifm_workordernote', 'incident', 'incidentresolution', 'msdyn_agreement', 'msdyn_customerasset', 'msdyn_expense', 'msdyn_priority', 'msdyn_project', 'msdyn_projectapproval', 'msdyn_projecttask', 'msdyn_resourcerequirement', 'msdyn_survey', 'msdyn_timeentry', 'msdyn_workorder', 'msdyn_workordertype', 'pricelevel', 'queue', 'quote', 'role', 'sdxmob_facility', 'sla', 'slaitem', 'slakpiinstance', 'systemuser', 'timezonedefinition', 'timezonerule', 'transactioncurrency'
  ];

  local datasetInClause = "'" + std.join("','", datasetList) + "'";

  local caseClauseCoe =
    "case when r.dataset_name in ('queue', 'role') then 172800
                     when r.dataset_name in ('msdyn_timeentry') then 345600
                     WHEN r.dataset_name IN ('ifm_masterservicecategory','ifm_servicecategory', 'sla', 'slaitem') THEN 1209600
                     when r.dataset_name in ('sdxmob_facility') then 1814400
                     when r.dataset_name in ('ifm_assettype','ifm_contract','bookableresource', 'bookableresourcebooking', 'bookableresourcecategory', 'ifm_country', 'msdyn_agreement', 'msdyn_priority', 'msdyn_project', 'msdyn_projectapproval', 'msdyn_projecttask', 'msdyn_survey', 'msdyn_workordertype', 'quote', 'timezonedefinition', 'timezonerule', 'transactioncurrency') then 2419200
                      ELSE 86400 END";

  local caseClauseNoram =
    "case when r.dataset_name in ('queue', 'role') then 172800
                     when r.dataset_name in ('msdyn_timeentry') then 345600
                     WHEN r.dataset_name IN ('bookableresource') THEN 604800
                     WHEN r.dataset_name IN ('bookableresourcebooking', 'bookableresourcecategory', 'ifm_masterservicecategory','ifm_servicecategory', 'sla', 'slaitem') THEN 1209600
                     when r.dataset_name in ('sdxmob_facility') then 1814400
                     when r.dataset_name in ('ifm_assettype','ifm_contract', 'ifm_country', 'msdyn_agreement', 'msdyn_priority', 'msdyn_survey', 'msdyn_workordertype', 'quote', 'timezonedefinition', 'timezonerule', 'transactioncurrency') then 2419200
                      ELSE 86400 END";

  local caseClauseAPAC =
    "case when r.dataset_name in ('queue', 'role') then 172800
                     when r.dataset_name in ('msdyn_timeentry') then 345600
                     WHEN r.dataset_name IN ('bookableresource') THEN 604800
                     WHEN r.dataset_name IN ('ifm_masterservicecategory','bookableresourcebooking', 'bookableresourcecategory','ifm_servicecategory', 'sla', 'slaitem') THEN 1209600
                     when r.dataset_name in ('sdxmob_facility') then 1814400
                     when r.dataset_name in ('ifm_assettype','ifm_contract', 'ifm_country', 'msdyn_agreement', 'msdyn_priority', 'msdyn_project', 'msdyn_projectapproval', 'msdyn_survey', 'msdyn_workordertype', 'quote', 'timezonedefinition', 'timezonerule', 'transactioncurrency') then 2419200
                      ELSE 86400 END";

  local caseClause =
        if source.project_name == 'oss.noram.glb.d365' then caseClauseNoram
        else if source.project_name == 'oss.coe.glb.d365' then caseClauseCoe
        else caseClauseAPAC;

  local TechnicalFreshness = std.format("
        with rankeddata as (
        select project_name ,
                dataset_name,
                record_date as 'functional_date',
                record_count,
                group_by,
                   row_number() over (partition by project_name, dataset_name, group_by order by record_date desc) as rn
                    FROM [observability].[d365_custom_slo_metrics]
                where group_by = 'ingestion_date'
                and project_name = '%s'
                and dataset_name in (%s)
        ),
        avg_data as
            (
                select dataset_name, group_by, avg(record_count) as Average_transaction_count from rankeddata
                where datediff(day, functional_date, getdate()) between 7 and 28
                group by dataset_name, group_by
            ),
        cte1 as (
        select r.project_name as 'Application Source',
                r.dataset_name as 'Dataset Name',
                cast(r.functional_date as varchar) as 'Ingestion Date',
                %s AS [Freshness Threshold],
                cast(datediff(hour, r.functional_date, getdate()) as varchar) as 'Technical Freshness',
                datediff(second, r.functional_date, getdate()) as 'Technical Freshness Updated',  
                r.record_count as Transaction_Count,
                a.Average_transaction_count as [Average Transaction Count],
                case when
                    a.Average_transaction_count is NOT NULL
                        then cast((r.record_count - a.Average_transaction_count)* 4.0 / nullif(a.Average_transaction_count, 0) as decimal(10, 4))
                    else NULL
                end as 'Variance'
        FROM rankeddata r
        left join avg_data a on r.dataset_name = a.dataset_name and r.group_by = a.group_by
        where r.rn = 1 or r.rn IS NULL
        ),
        cte2 as (
        select [Application Source], [Dataset Name], [Ingestion Date],
            [Freshness Threshold], [Technical Freshness],
            case when [Technical Freshness Updated] < [Freshness Threshold] then 0 else 1 end as [Status] from cte1
            where [Dataset Name] in (%s)
        )
        select [Dataset Name] as DatasetName, 
        CASE
            WHEN [Freshness Threshold] < 604800 THEN
                CAST([Freshness Threshold] / 86400 AS VARCHAR(10)) + ' Day'
            ELSE
                CAST([Freshness Threshold] / 604800 AS VARCHAR(10)) + ' Week'
            END AS FreshnessThreshold, 
        count(*) as [FailureCount] from cte2 where [Status] = 1
        group by [Dataset Name],[Freshness Threshold]",        
        [
            source.project_name,
            datasetInClause,
            caseClause,
            datasetInClause,
        ]);

    local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
    local silence_labels = std.join("::", envs);
    local panelID = if source.project_name == 'oss.noram.glb.d365' then 19
        else if source.project_name == 'oss.coe.glb.d365' then 31
        else 20;
    local channels = if source.project_name == 'oss.coe.glb.d365' then 'FMD365COE'
                     else if source.project_name == 'oss.noram.glb.d365' then 'FMD365NORAM'
                     else 'FMD365APAC';

    {
        "uid": std.md5(std.format("TechnicalFreshnessFMD365 %s",source.project_name)),
        "title": std.format("Technical Freshness FM D365 : %s", [source.project_name]),
        "condition": "B",
        "data": [
            {
                "refId": "A",
                "relativeTimeRange": {
                    "from": 172800,
                    "to": 0
                },
                "datasourceUid": "AzureSQLServer",
                "model": {
                    "editorMode": "code",
                    "format": "table",
                    "intervalMs": 60000,
                    "maxDataPoints": 43200,
                    "queryText": TechnicalFreshness,
                    "rawEditor": true,
                    "rawQuery": true,
                    "rawSql": TechnicalFreshness,
                    "refId": "A",
                    "sql": {
                        "columns": [
                            {
                                "parameters": [],
                                "type": "function"
                            }
                        ],
                        "groupBy": [
                            {
                                "property": {
                                    "type": "string"
                                },
                                "type": "groupBy"
                            }
                        ],
                        "limit": 50
                    }
                }
            },
            {
                "refId": "B",
                "relativeTimeRange": {
                    "from": 172800,
                    "to": 0
                },
                "datasourceUid": "__expr__",
                "model": {
                    "conditions": [
                        {
                            "evaluator": {
                                "params": [
                                    0
                                ],
                                "type": "gt"
                            },
                            "operator": {
                                "type": "and"
                            },
                            "query": {
                                "params": [
                                    "C"
                                ]
                            },
                            "reducer": {
                                "params": [],
                                "type": "last"
                            },
                            "type": "query"
                        }
                    ],
                    "expression": "A",
                    "intervalMs": 1000,
                    "maxDataPoints": 43200,
                    "refId": "B",
                    "type": "threshold"
                }
            }
        ],
        "dashboardUid": "fmd365dashbaord",
        "panelId": panelID,
        "noDataState": "OK",
        "execErrState": "Error",
        "for": "5m",
        "labels": {
            "project_name": source.project_name,
            "alert_type": source.alerting.type,
            "env": silence_labels,
            "severity": source.alerting.severity,
            "dashboard_title": title,
            "channels": channels,
        },
        "annotations": {
            "__dashboardUid__": "fmd365dashbaord",
            "__panelId__": panelID
        },
        "isPaused": false,
    };

local input_json = std.parseYaml(std.extVar("input"));
local dashboard_title = input_json.title;
local filtered_sources = filterSourceWithAlerting(input_json.sources);
local flat_sources = flatSources(filtered_sources);

local data_availability_alerts = filterDiffAlertRows(flat_sources);
local diff_alerts_grafana = [convertToGrafanaAlertDiff(source, dashboard_title) for source in data_availability_alerts];

local technical_freshness_alerts = filterDiffAlertRows2(flat_sources);
local diff_alerts_grafana2 = [convertToGrafanaAlertDiff2(source, dashboard_title) for source in technical_freshness_alerts];

local all_alerts = diff_alerts_grafana + diff_alerts_grafana2;

local project_names = std.set(
  [alert.labels.project_name for alert in all_alerts]
);

local grouped_by_project = {
  [source]: [alert for alert in all_alerts if alert.labels.project_name == source]
  for source in project_names
};

{
  "apiVersion": 1,
  "groups": [
    {
      "orgId": 1,
      "name": "Volume Data Observability " + input_json.title,
      "folder": "Data Observability",
      "interval": "30m",
      rules: grouped_by_project[source],
    }
    for source in std.objectFields(grouped_by_project)
    ]
}