local grafana = import 'grafonnet/grafana.libsonnet';

local filterSourceWithAlerting(sources) = [ source for source in sources if std.objectHas(source, 'alerting') && source.alerting != null ];

local flatSources(objs) = [
    {
        project_name: if std.type(obj.project_name) == "string" then obj.project_name else pr,
        dataset_name: if std.type(obj.dataset_name) == "string" then obj.dataset_name else d,
        alerting: if std.type(obj.alerting) == "string" then obj.alerting else alerting,
    }
    for obj in objs
    for pr in if std.type(obj.project_name) == "array" then obj.project_name else [obj.project_name]
    for d in if std.type(obj.dataset_name) == "array" then obj.dataset_name else [obj.dataset_name]
    for alerting in if std.type(obj.alerting) == "array" then obj.alerting else [obj.alerting]
];

local filterVolumeAlertRows(sources) = [
    source for source in sources
    if std.objectHas(source, 'alerting') &&  // Check if 'alerting' field exists
        source.alerting.type == 'Volume_Check' &&
        std.objectHas(source.alerting, 'volume_check_threshold')
];

local convertToGrafanaAlertVolume(source, title) = 
    local volume_check_threshold = source.alerting.volume_check_threshold;
    local panelId = source.alerting.panel;
    local panelName = source.alerting.panelName;
    local channels = source.alerting.channels;
    local dataset_name = source.dataset_name;
    local time = source.alerting.relativeTimeRange;
    local exp = if dataset_name == 'tradescommercexportobject' then "outside_range" else "lt";

    // query for tradescommercexportobject Volume check threshold 5 %
    local queryThreshold5 = 
    "   
        WITH 
            latestrecords AS (
                SELECT * FROM [observability].[redefinedrecordcount] AS r
                WHERE project_name = 'oss.glb.glb.dynamify_sdx'
                AND job_execution_timestamp = (
                    SELECT MAX(job_execution_timestamp)
                    FROM [observability].[redefinedrecordcount]
                    WHERE project_name = r.project_name
                    AND record_date = r.record_date
                )
            ),
            cte as(
            SELECT
                lr.project_name AS 'Application Source',
                lr.dataset_name AS 'Dataset Name',
                FORMAT(lr.record_date, 'yyyy-MM-dd') AS 'Transaction_Date',
                ((lr.record_count -
                    (
                    COALESCE((SELECT record_count FROM latestrecords WHERE record_date = DATEADD(day, -7, lr.record_date)), 0) +
                    COALESCE((SELECT record_count FROM latestrecords WHERE record_date = DATEADD(day, -14, lr.record_date)), 0) +
                    COALESCE((SELECT record_count FROM latestrecords WHERE record_date = DATEADD(day, -21, lr.record_date)), 0) +
                    COALESCE((SELECT record_count FROM latestrecords WHERE record_date = DATEADD(day, -28, lr.record_date)), 0))
                    / 4.0))
                / (NULLIF(
                    (COALESCE((SELECT record_count FROM latestrecords WHERE record_date = DATEADD(day, -7, lr.record_date)), 0) +
                    COALESCE((SELECT record_count FROM latestrecords WHERE record_date = DATEADD(day, -14, lr.record_date)), 0) +
                    COALESCE((SELECT record_count FROM latestrecords WHERE record_date = DATEADD(day, -21, lr.record_date)), 0) +
                    COALESCE((SELECT record_count FROM latestrecords WHERE record_date = DATEADD(day, -28, lr.record_date)), 0))
                    / 4.0, 0)) * 100
                AS 'Volume Check'
            FROM latestrecords lr
            WHERE
                DATEDIFF(SECOND, '1970-01-01 00:00:00', record_date)
                BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
            GROUP BY lr.project_name, lr.dataset_name, lr.record_date, lr.record_count
            )
            select Transaction_Date,CONVERT(DECIMAL(10,2),COALESCE([Volume Check],0))  from cte
            
            ORDER BY [Transaction_Date] DESC;
    ";

     // query for Source vs Target panel volume diff
    local queryThreshold0 = 
    "      
        with 
            cte as (
                SELECT [project_name],[dataset_name],[record_date],max([record_count]) as 'Bronze Standardized Count'
                FROM [observability].[redefinedrecordcount]
                group by [project_name],[dataset_name],[record_date]
            ),

            cte2 as (
                select [project_name],[dataset_name],[record_date],max([total_count]) as 'Source Data Count' 
                from [observability].[dynamifysourcecount]
                group by [project_name],[dataset_name],[record_date]
            )
                Select s.[project_name] as 'Application Source',
                    s.[dataset_name] as 'Dataset Name',
                    Format(s.record_date, 'yyyy-MM-dd') as 'Transaction_Date',
                    [Source Data Count]-[Bronze Standardized Count] as 'Volume Difference'
                    from cte as t,cte2 as s
                    where s.record_date=t.record_date and s.dataset_name = t.dataset_name
                    and datediff(second, '1970-01-01 00:00:00', s.record_date) BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                    and s.dataset_name in ('getallowances','menudataexportobject','tradescommercexportobject','mealdeal')
                    order by s.[record_date] desc
    ";

    // query for tradescommercexportobject Volume check threshold 10 %

    local queryThreshold10 = 
    "       
        with 
            latestrecords as (
                select * from [observability].[redefinedrecordcount] as r where project_name = 'oss.glb.glb.dynamify_sdx'
                and job_execution_timestamp = (select max(job_execution_timestamp) from [observability].[redefinedrecordcount] 
                where project_name = r.project_name and record_date = r.record_date)
            ),
            cte as(
                select lr.project_name as 'Application Source', lr.dataset_name as 'Dataset Name', Format(lr.record_date, 'yyyy-MM-dd') as 'Transaction_Date', '10% variance over the last 7 days on same days' As 'Threshold',
                    lr.record_count as 'Transaction Count',
                    case
                    when Coalesce((select record_count from latestrecords where record_date = dateadd(day, -7, lr.record_date)), 0) = 0 then NULL
                    else (lr.record_count - Coalesce((select record_count from latestrecords where record_date = dateadd(day, -7, lr.record_date)),0)) * 100.0/Coalesce((select record_count from latestrecords where record_date = dateadd(day, -7, lr.record_date)), 0)
                    end as 'Volume Check',
                    Coalesce((select record_count from latestrecords where record_date = dateadd(day, -7, lr.record_date)), 0) as 'Date-7 Count'
                from latestrecords lr
                where datediff(second, '1970-01-01 00:00:00', record_date) BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
            )
        select Transaction_Date, CONVERT(DECIMAL(10,2),[Volume Check]) from cte
    ";

    // query for tradescommercexportobject Volume check threshold 20 %
    local queryThreshold20 = 
    "       
        with 
            latestrecords as (
                select * from [observability].[redefinedrecordcount] as r where project_name = 'oss.glb.glb.dynamify_sdx'
                and job_execution_timestamp = (select max(job_execution_timestamp) from [observability].[redefinedrecordcount] 
                where project_name = r.project_name and record_date = r.record_date)
            ),
            final as (
                select lr.project_name as 'Application Source', lr.dataset_name as 'Dataset Name', Format(lr.record_date, 'yyyy-MM-dd') as 'Transaction_Date',
                    case 
                    when (Year(lr.record_date))%4 != 0 then DATEADD(day,1,dateadd(year, -1, lr.record_date))
                    when (Year(lr.record_date))%4 = 0 then DATEADD(day,2,dateadd(year, -1, lr.record_date))
                    end as 'last year',
                    /*DATENAME(dw,lr.record_date) as 'Transaction-day',*/
                    Coalesce((select record_count from latestrecords where record_date = dateadd(day, -1, lr.record_date)), 0) as 'D-1 Count',
                    case 
                    when (Year(lr.record_date))%4 != 0 then Coalesce((select record_count from latestrecords where record_date = DATEADD(day,1,dateadd(year, -1, lr.record_date))), 0)
                    when (Year(lr.record_date))%4 = 0 then Coalesce((select record_count from latestrecords where record_date = DATEADD(day,2,dateadd(year, -1, lr.record_date))), 0)
                    end as 'Date-year count',
                    case 
                    when (Year(lr.record_date))%4 != 0 then (DATEADD(day,1,dateadd(year, -1, lr.record_date)))
                    when (Year(lr.record_date))%4 = 0 then DATEADD(day,2,dateadd(year, -1, lr.record_date))
                    end as 'Date-year',
                    '20% variance over the last year on same days' As 'Threshold',
                    lr.record_count as 'Transaction Count'   
                from latestrecords lr
            )
            select [Application Source],[Dataset Name],[Transaction_Date],
            case when [D-1 Count]-[Date-year count] = 0 or [Date-year count] = 0 then NULL
            else CONVERT(DECIMAL(10,2),((cast([Transaction Count] as float)-[Date-year count])/[Date-year count])*100) end as 'Volume Check'
            from final
            where datediff(second, '1970-01-01 00:00:00',[Transaction_Date]) BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
            order by [Transaction_Date] desc

    ";

    // query for Volume Count - getallowances,menudataexportobject,mealdeal 
    local queryVolume = std.format(
    "        
        select distinct project_name as 'Application Source',
            dataset_name as 'Dataset Name',
            format(DATEADD(SECOND, timestamp, '1970-01-01'), 'yyyy-MM-dd') as 'Transaction_Date' , 
            metric_value as 'Transaction count'
        from [observability].[event] as r 
        where project_name = 'oss.glb.glb.dynamify_sdx' 
            and dataset_name = '%s' 
            and landing_zone = 'Standardized' 
            and metric_name = 'rows_count' 
            and event_type = 'processingfinished' 
            and timestamp = (select max(timestamp) from [observability].[event] 
            where project_name = r.project_name and timestamp = r.timestamp)
            and timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
            order by FORMAT(DATEADD(SECOND, timestamp, '1970-01-01'), 'yyyy-MM-dd') desc
   
    ",dataset_name);

local rawSql = if volume_check_threshold == 5 then queryThreshold5 
    else if volume_check_threshold == 0 then queryThreshold0 
    else if volume_check_threshold == 10 then queryThreshold10
    else if volume_check_threshold == 20 then queryThreshold20 
    else queryVolume;

local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
local silence_labels = std.join("::", envs);
local params = if exp == "outside_range" then
                    [-volume_check_threshold,volume_check_threshold]
                else 
                    [volume_check_threshold]
;

{
    "uid": std.md5(std.format("DataVolume_min_%s",panelName)),
    "title": std.format("Data Volume Alert: %s ──── %s ──── %s", [source.project_name, source.dataset_name,panelName]),
    "condition": "C",
    "data": [
    {
        "refId": "A",
        "datasourceUid": "AzureSQLServer",
        "relativeTimeRange": { "from": time, "to": 0 },
        "model": {
        "format": "table",
        "hide": false,
        "intervalMs": 1000,
        "maxDataPoints": 43200,
        "rawQuery": true,
        "rawSql": rawSql,
        }
    },
    {
            "refId": "B",
            "relativeTimeRange": {
                "from": time,
                "to": 0
            },
            "datasourceUid": "__expr__",
            "model": {
                "conditions": [
                    {
                        "evaluator": {
                            "params": [volume_check_threshold],
                            "type": exp
                        },
                        "operator": {
                            "type": "and"
                        },
                        "query": {
                            "params": [
                                "B"
                            ]
                        },
                        "reducer": {
                            "params": [],
                            "type": "last"
                        },
                        "type": "query"
                    }
                ],
                "datasource": {
                    "type": "__expr__",
                    "uid": "__expr__"
                },
                "expression": "A",
                "intervalMs": 1000,
                "maxDataPoints": 43200,
                "reducer": "last",
                "refId": "B",
                "type": "reduce"
            }
        },
        {
            "refId": "C",
            "relativeTimeRange": {
                "from": time,
                "to": 0
            },
            "datasourceUid": "__expr__",
            "model": {
                "conditions": [
                    {
                       
                       "evaluator": {
                            "params": params,
                            "type": exp
                        },
                        "operator": {
                            "type": "and"
                        },
                        "query": {
                            "params": [
                                "C"
                            ]
                        },
                        "reducer": {
                            "params": [],
                            "type": "last"
                        },
                        "type": "query"
                    }
                ],
                "datasource": {
                    "type": "__expr__",
                    "uid": "__expr__"
                },
                "expression": "B",
                "intervalMs": 1000,
                "maxDataPoints": 43200,
                "refId": "C",
                "type": "threshold"
            }
        }
    ],
    "noDataState": "OK",
    "for": "60s",
    "labels": {
    "project_name": source.project_name,
    "dataset_name": source.dataset_name,
    "alert_type": "Volume_Check",
    "volume_check_threshold": volume_check_threshold,
    "env": silence_labels,
    "severity": source.alerting.severity,
    "dashboard_title": title,
    "panel_name": panelName,
    "channels": std.join("::", channels),
    },
    "annotations": {
        "__dashboardUid__": "21EiXdsfddd15H",
        "__panelId__": panelId
    },
};



local input_json = std.parseYaml(std.extVar("input"));
local dashboard_title = input_json.title;
local filtered_sources = filterSourceWithAlerting(input_json.sources);
local flat_sources = flatSources(filtered_sources);
local volume_threshold_alerts = filterVolumeAlertRows(flat_sources);
local volume_alerts_grafana = [convertToGrafanaAlertVolume(source, dashboard_title) for source in volume_threshold_alerts];

{
    "apiVersion": 1,
    "groups": [
        {
        "orgId": 1,
        "name": "Volume Data Observability " + input_json.title,
        "folder": "Data Observability",
        "interval": "30m",
        rules: volume_alerts_grafana,
        }
    ]
}