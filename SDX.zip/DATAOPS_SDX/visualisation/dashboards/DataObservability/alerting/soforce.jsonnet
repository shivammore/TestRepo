local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
 
local filterSourceWithAlerting(sources) = [ source for source in sources if std.objectHas(source, 'alerting') && source.alerting != null ];
 
local flatSources(objs) = [
  {
    project_name: if std.type(obj.project_name) == "string" then obj.project_name else pr,
    dataset_name: if std.type(obj.dataset_name) == "string" then obj.dataset_name else d,
    alerting: if std.type(obj.alerting) == "string" then obj.alerting else alerting,
  }
  for obj in objs
  for pr in if std.type(obj.project_name) == "array" then obj.project_name else [obj.project_name]
  for d in if std.type(obj.dataset_name) == "array" then obj.dataset_name else [obj.dataset_name]
  for alerting in if std.type(obj.alerting) == "array" then obj.alerting else [obj.alerting]
];

local filterDiffAlertRows(sources) = [
  source for source in sources
  if std.objectHas(source, 'alerting') &&  // Check if 'alerting' field exists
     source.alerting.type == 'APIM-Standardized'
];

local filterDiffAlertRows2(sources) = [
  source for source in sources
  if std.objectHas(source, 'alerting') &&  // Check if 'alerting' field exists
     source.alerting.type == 'APIM-Azure'
];

##-------------------------------------------------------------------------------------------------

local convertToGrafanaAlert1(source, title) =
  local channels = source.alerting.channels;
  local input_json = std.parseYaml(std.extVar("input"));
  local SoforceStandardizedSQL = "
      Select FORMAT(record_date, 'yyyy-MM-dd') as [TransactionDate],
      Sum(distinct record_count) as [Standardized Record Count] from observability.[soforce_custom_slo_metrics] 
      Where datediff(second, '1970-01-01 00:00:00', record_date) BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
              And REPLACE(dataset_name, '_', '') IN ('brandcdm','brandinfo','brandsevicemapping','localbrand','masterbrand','selectedservicelevel','servicelevel','services')
              And ingestion_layer = 'standardized'
      group by FORMAT(record_date, 'yyyy-MM-dd')
      order by FORMAT(record_date, 'yyyy-MM-dd') desc;
        ";

    local APIMKQL1 = |||
      requests
        | where timestamp >= startofday(now() - 1d) and timestamp < startofday(now())
        | where success == "True"
        | where tostring(customDimensions["API Name"]) has_any ('brandcdm','brandinfo','brandsevicemapping','localbrand','masterbrand','selectedservicelevel','servicelevel','services')
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey
        | summarize Count = count(), stamp = max(latest_timestamp) by bin(latest_timestamp, 1d)
        | project TransactionDate = format_datetime(stamp, "yyyy-MM-dd"), Count
        | order by TransactionDate desc
     |||;

    local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
    local silence_labels = std.join("::", envs);

 
   {
        "uid": std.md5(std.format("TrackingAPIMtoStandardizedZoneDifference %s",input_json.title)),
        "title": std.format("Tracking APIM to Standardized Zone Difference: %s", [input_json.title]),
        "condition": "D",
        "data": [
            {
                "refId": "A",
                "relativeTimeRange": {
                    "from": 172800,
                    "to": 86400
                },
                "datasourceUid": "AzureSQLServer",
                "model": {
                    "datasource": {
                        "type": "mssql",
                        "uid": "AzureSQLServer"
                    },
                    "format": "table",
                    "intervalMs": 60000,
                    "maxDataPoints": 43200,
                    "query": {
                        "alias": "Standardized Requests",
                        "format": "table",
                        "rawEditor": true,
                        "rawQuery": true,
                        "rawSql": SoforceStandardizedSQL
                    },
                    "rawMode": true,
                    "rawQuery": true,
                    "rawSql": SoforceStandardizedSQL,
                    "refId": "A"
                }
            },
            {
                "refId": "B",
                "queryType": "Azure Log Analytics",
                "relativeTimeRange": {
                    "from": 172800,
                    "to": 86400
                },
                "datasourceUid": "AzureMonitor",
                "model": {
                    "azureLogAnalytics": {
                        "dashboardTime": false,
                        "query": APIMKQL1,
                        "resources": [
                            "/subscriptions/cf25f2a1-4d40-45af-bb81-87ec46112b3e/resourceGroups/GLB-GLB-IENO-HIP-PRD-RG01/providers/microsoft.insights/components/azieai1kzf380"
                        ],
                        "resultFormat": "logs"
                    },
                    "azureMonitor": {
                        "allowedTimeGrainsMs": [],
                        "timeGrain": "auto"
                    },
                    "datasource": {
                        "type": "grafana-azure-monitor-datasource",
                        "uid": "AzureMonitor"
                    },
                    "hide": false,
                    "intervalMs": 1000,
                    "maxDataPoints": 43200,
                    "queryType": "Azure Log Analytics",
                    "refId": "B"
                }
            },
            {
                "refId": "C",
                "relativeTimeRange": {
                    "from": 600,
                    "to": 0
                },
                "datasourceUid": "__expr__",
                "model": {
                    "conditions": [
                        {
                            "evaluator": {
                                "params": [
                                    0,
                                    0
                                ],
                                "type": "gt"
                            },
                            "operator": {
                                "type": "and"
                            },
                            "query": {
                                "params": []
                            },
                            "reducer": {
                                "params": [],
                                "type": "avg"
                            },
                            "type": "query"
                        }
                    ],
                    "datasource": {
                        "name": "Expression",
                        "type": "__expr__",
                        "uid": "__expr__"
                    },
                    "expression": "$B - $A",
                    "hide": false,
                    "intervalMs": 1000,
                    "maxDataPoints": 43200,
                    "refId": "C",
                    "type": "math"
                }
            },
            {
                "refId": "D",
                "relativeTimeRange": {
                    "from": 600,
                    "to": 0
                },
                "datasourceUid": "__expr__",
                "model": {
                    "conditions": [
                        {
                            "evaluator": {
                                "params": [
                                    0,
                                    0
                                ],
                                "type": "outside_range"
                            },
                            "operator": {
                                "type": "and"
                            },
                            "query": {
                                "params": [
                                    "C"
                                ]
                            },
                            "reducer": {
                                "params": [],
                                "type": "last"
                            },
                            "type": "query"
                        }
                    ],
                    "datasource": {
                        "type": "__expr__",
                        "uid": "__expr__"
                    },
                    "expression": "C",
                    "hide": false,
                    "refId": "D",
                    "type": "threshold"
                }
            }
        ],
        "dashboardUid": "soforce-monitoring-tracker",
        "panelId": 3,
        "noDataState": "OK",
        "execErrState": "OK",
        "for": "5m",
        "labels": {
            "project_name": source.project_name,
            "alert_type": source.alerting.type,
            "env": silence_labels,
            "severity": source.alerting.severity,
            "dashboard_title": title,
            "channels": std.join("::", channels),
        },
        "annotations": {
            "__dashboardUid__": "soforce-monitoring-tracker",
            "__panelId__": "3"
        },
        "isPaused": false,
    };

local convertToGrafanaAlert2(source, title) =
  local channels = source.alerting.channels;
  local input_json = std.parseYaml(std.extVar("input"));
    local APIMKQL2 = |||
      requests
        | where timestamp >= startofday(now() - 1d) and timestamp < startofday(now())
        | where success == "True"
        | where tostring(customDimensions["API Name"]) has_any ("localbrand","masterbrand","servicelevel","selectedservicelevel")
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey
        | summarize APIM_Record_Count = count(), stamp = max(latest_timestamp) by bin(latest_timestamp, 1d)
        | project TransactionDate = format_datetime(stamp, "yyyy-MM-dd"), APIM_Record_Count
        | order by TransactionDate desc
    |||;

    local AZFunctionKQL = |||
      AppTraces
        | where TimeGenerated >= startofday(now() - 1d) and TimeGenerated < startofday(now())
        | where AppRoleName in ('aziefn1ovr888','aziefn1uvh676','aziefn1uve461')
        | where OperationName in ('cdm_http_trigger','servicebus_topic_brand_trigger','soforce_cdm_transform')
        | where isnotempty(Message)
        | extend msgjson = parse_json(Message)
        | extend rawMessage = tostring(msgjson["message"])
        | extend correlationId = extract(@"x-correlation-id=([^,]+)", 1, rawMessage)
        | where isnotempty(correlationId)
        | extend idempotencykey = extract(@"x-idempotency-key=([^,]+)", 1, rawMessage)
        | where isnotempty(idempotencykey)
        | extend countryOrigin = extract(@"x-country-of-origin=([^,]+)", 1, rawMessage)
        | extend region = extract(@"x-region=([^,]+)", 1, rawMessage)
        | extend sourceAppId = extract(@"x-source-application-id=([^,]+)", 1, rawMessage)
        | extend statuscode = extract(@"statusCode=([^,]+)", 1, rawMessage)
        | where statuscode == "200"
        | summarize latest_timestamp = max(TimeGenerated) by idempotencykey
        | summarize Azure_Function_record_count = count(), stamp = max(latest_timestamp) by bin(latest_timestamp, 1d)
        | project TransactionDate = format_datetime(latest_timestamp, "yyyy-MM-dd"), Azure_Function_record_count
        | order by TransactionDate desc
    |||;

    local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
    local silence_labels = std.join("::", envs);
 
                {
                    "uid": std.md5(std.format("TrackingAPIMtoAzureFunctionDifference %s",input_json.title)),
                    "title": std.format("Tracking APIM to Azure Function Difference: %s", [input_json.title]),
                    "condition": "D",
                    "data": [
                        {
                            "refId": "A",
                            "queryType": "Azure Log Analytics",
                            "relativeTimeRange": {
                                "from": 172800,
                                "to": 0
                            },
                            "datasourceUid": "AzureMonitor",
                            "model": {
                                "azureLogAnalytics": {
                                    "dashboardTime": false,
                                    "query": APIMKQL2,
                                    "resources": [
                                        "/subscriptions/cf25f2a1-4d40-45af-bb81-87ec46112b3e/resourceGroups/GLB-GLB-IENO-HIP-PRD-RG01/providers/microsoft.insights/components/azieai1kzf380"
                                    ],
                                    "resultFormat": "logs",
                                    "timeColumn": "",
                                    "workspace": ""
                                },
                                "datasource": {
                                    "type": "grafana-azure-monitor-datasource",
                                    "uid": "AzureMonitor"
                                },
                                "editorMode": "code",
                                "format": "table",
                                "intervalMs": 1000,
                                "maxDataPoints": 43200,
                                "queryType": "Azure Log Analytics",
                                "rawQuery": true,
                                "rawSql": "",
                                "refId": "A",
                                "sql": {
                                    "columns": [
                                        {
                                            "parameters": [],
                                            "type": "function"
                                        }
                                    ],
                                    "groupBy": [
                                        {
                                            "property": {
                                                "type": "string"
                                            },
                                            "type": "groupBy"
                                        }
                                    ],
                                    "limit": 50
                                }
                            }
                        },
                        {
                            "refId": "B",
                            "queryType": "Azure Log Analytics",
                            "relativeTimeRange": {
                                "from": 172800,
                                "to": 0
                            },
                            "datasourceUid": "AzureMonitor",
                            "model": {
                                "azureLogAnalytics": {
                                    "dashboardTime": false,
                                    "query": AZFunctionKQL,
                                    "resources": [
                                        "/subscriptions/cf25f2a1-4d40-45af-bb81-87ec46112b3e/resourceGroups/GLB-GLB-IENO-HIP-PRD-RG01/providers/Microsoft.OperationalInsights/workspaces/aziemm1ozv389"
                                    ],
                                    "resultFormat": "logs",
                                    "timeColumn": "",
                                    "workspace": ""
                                },
                                "dataset": "aziedb1kil452",
                                "datasource": {
                                    "type": "grafana-azure-monitor-datasource",
                                    "uid": "AzureMonitor"
                                },
                                "editorMode": "builder",
                                "format": "table",
                                "intervalMs": 1000,
                                "maxDataPoints": 43200,
                                "queryType": "Azure Log Analytics",
                                "rawSql": "",
                                "refId": "B"
                            }
                        },
                        {
                            "refId": "C",
                            "relativeTimeRange": {
                                "from": 0,
                                "to": 0
                            },
                            "datasourceUid": "__expr__",
                            "model": {
                                "conditions": [
                                    {
                                        "evaluator": {
                                            "params": [
                                                0,
                                                0
                                            ],
                                            "type": "gt"
                                        },
                                        "operator": {
                                            "type": "and"
                                        },
                                        "query": {
                                            "params": []
                                        },
                                        "reducer": {
                                            "params": [],
                                            "type": "avg"
                                        },
                                        "type": "query"
                                    }
                                ],
                                "datasource": {
                                    "name": "Expression",
                                    "type": "__expr__",
                                    "uid": "__expr__"
                                },
                                "expression": "$B - $A",
                                "hide": false,
                                "intervalMs": 1000,
                                "maxDataPoints": 43200,
                                "refId": "C",
                                "type": "math"
                            }
                        },
                        {
                            "refId": "D",
                            "relativeTimeRange": {
                                "from": 600,
                                "to": 0
                            },
                            "datasourceUid": "__expr__",
                            "model": {
                                "conditions": [
                                    {
                                        "evaluator": {
                                            "params": [
                                                0,
                                                0
                                            ],
                                            "type": "outside_range"
                                        },
                                        "operator": {
                                            "type": "and"
                                        },
                                        "query": {
                                            "params": [
                                                "C"
                                            ]
                                        },
                                        "reducer": {
                                            "params": [],
                                            "type": "last"
                                        },
                                        "type": "query"
                                    }
                                ],
                                "datasource": {
                                    "type": "__expr__",
                                    "uid": "__expr__"
                                },
                                "expression": "C",
                                "hide": false,
                                "refId": "D",
                                "type": "threshold"
                            }
                        }
                    ],
                    "dashboardUid": "soforce-monitoring-tracker",
                    "panelId": 4,
                    "noDataState": "OK",
                    "execErrState": "OK",
                    "for": "5m",
                    "annotations": {
                        "__dashboardUid__": "soforce-monitoring-tracker",
                        "__panelId__": "4"
                    },
                    "labels": {
                        "project_name": source.project_name,
                        "alert_type": source.alerting.type,
                        "env": silence_labels,
                        "severity": source.alerting.severity,
                        "dashboard_title": title,
                        "channels": std.join("::", channels),
                        },
                    "isPaused": false,
                };

local input_json = std.parseYaml(std.extVar("input"));
local dashboard_title = input_json.title;
local filtered_sources = filterSourceWithAlerting(input_json.sources);
local flat_sources = flatSources(filtered_sources);
local diff_threshold_alerts = filterDiffAlertRows(flat_sources);
local diff_alerts_grafana = [convertToGrafanaAlert1(source, dashboard_title) for source in diff_threshold_alerts];

local diff_threshold_alerts2 = filterDiffAlertRows2(flat_sources);
local diff_alerts_grafana2 = [convertToGrafanaAlert2(source, dashboard_title) for source in diff_threshold_alerts2];


{
  "apiVersion": 1,
  "groups": [
    {
      "orgId": 1,
      "name": "Volume Data Observability " + input_json.title,
      "folder": "Data Observability",
      "interval": "30m",
      rules: diff_alerts_grafana + diff_alerts_grafana2,
    },
  ]
}