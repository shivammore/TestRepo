local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local stat = grafana.statPanel;
local table = grafana.tablePanel;
local slo = 80;

//global filters
local projectTemplate =  tmpl.custom(
    name='project_name',
    current='all',
    query='oss.coe.de.mms_delegate_supply,oss.coe.glb.sap_fico',
    includeAll=true,
    multi=true,
    label="Application Source"
);

local datasetTemplate = tmpl.custom(
    name='dataset_name',
    query= 'additives, art2cat, article2add, artikel, besteller, buchhalt, ccsgroup, crvpoheader, crvpoline, fcurrency, his_pricequote, kostst, lager, lfartkat, liefer, lieferpos, menuplan   , menuplanpos, menuplanpos2add, mplposlang, mygcomponentgroup, mygspltemplate, orgclient, pq2cat, pqtocc, pricequote, pricequote2add, pricequotefuture, prodeinh, producer, rec_category, rec_explosion, rechnung, rechpos , rez2menu, rezeptur, rezepturitem, rezgruppe, reztoart, rvbookedreceiptwithpositions, rvcostcenter, sparte, spartegr, suppliergr, v_kategorie2, vendortocc, vpckeinh, warengruppe, bkpf_be, bkpf_de, bkpf_nl, bkpf_se_fi, bseg_be, bseg_de, bseg_nl, bseg_se_fi, t052u',
    current='all',
    includeAll=true,
    multi=true,
    label='Dataset Name'
);

local stageTemplate =  tmpl.custom(
    name='landing_zone',
    current='all',
    query='history,landing,standardized,transient',
    includeAll=true,
    multi=true,
    label="Zone"
);

local statusTemplate =  tmpl.custom(
    name='status',
    current='all',
    query='Succeeded,Failed,No New Data,Running,Skipped',
    includeAll=true,
    multi=true,
    label="Ingestion Status"
);

local HidedContext =
    grafana.template.new(
    name='context',
    datasource='Azure SQL Server',
    query="
        SELECT distinct(context_id)
        FROM [observability].[event]
        WHERE
    dataset_name IN ($dataset_name)
    AND landing_zone IN ($landing_zone)
    AND project_name IN ($project_name)
        ",
    current='all',
    refresh='load',
    hide = true,
    includeAll=true,
    multi=false,
    label='context'
);

//panels
local generatePanelCount =
  stat.new(
    title='Total Datasets',
    datasource='Azure SQL Server',
    description="@todo"
  )
  // Use the length of the sources list as the value to display
  .addTarget(
    target=grafana.sql.target(
      rawSql="with cte as (select '${dataset_name:csv}' as val)
	              select (LEN(val) - LEN(REPLACE(val, ',', ''))) + 1 from cte;",
      format='table'
    )
);

local SLOPanel = stat.new(
    title='SLO',
    datasource='Azure SQL Server',
    description="This is a benchmark defined by the proprietors or stakeholders of a data ingestion pipeline.
    It signifies the anticipated and aspired level of efficiency, reliability, and quality for data ingestion processes.
    Such a goal provides a tangible metric against which the actual performance of the data ingestion can be evaluated,ensuring that the pipeline operates in alignment with stakeholder expectations and requirements.")
    .addTarget(target=grafana.sql.target(rawSql= "SELECT 80 AS SLO", format='table'))
    .addOverridesByFieldName(field='SLO',properties=[{id: 'unit', value: 'percent'}]
);

local generateSLIPanel =
    local SLISqlQuery = "          
    WITH
        CombinedValues AS (
            SELECT *
            FROM (VALUES ('oss.coe.de.mms_delegate_supply',	'additives',	'history',	'oss.coe.de.mms_delegate_supply_additives_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'additives',	'landing',	'oss.coe.de.mms_delegate_supply_additives_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'additives',	'standardized',	'oss.coe.de.mms_delegate_supply_additives_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'additives',	'transient',	'oss.coe.de.mms_delegate_supply_additives_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'art2cat',	'history',	'oss.coe.de.mms_delegate_supply_art2cat_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'art2cat',	'landing',	'oss.coe.de.mms_delegate_supply_art2cat_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'art2cat',	'standardized',	'oss.coe.de.mms_delegate_supply_art2cat_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'art2cat',	'transient',	'oss.coe.de.mms_delegate_supply_art2cat_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'article2add',	'history',	'oss.coe.de.mms_delegate_supply_article2add_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'article2add',	'landing',	'oss.coe.de.mms_delegate_supply_article2add_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'article2add',	'standardized',	'oss.coe.de.mms_delegate_supply_article2add_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'artikel',	'history',	'oss.coe.de.mms_delegate_supply_artikel_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'artikel',	'landing',	'oss.coe.de.mms_delegate_supply_artikel_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'artikel',	'standardized',	'oss.coe.de.mms_delegate_supply_artikel_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'artikel',	'transient',	'oss.coe.de.mms_delegate_supply_artikel_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'besteller',	'history',	'oss.coe.de.mms_delegate_supply_besteller_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'besteller',	'landing',	'oss.coe.de.mms_delegate_supply_besteller_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'besteller',	'standardized',	'oss.coe.de.mms_delegate_supply_besteller_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'buchhalt',	'history',	'oss.coe.de.mms_delegate_supply_buchhalt_history',	604800),
                ('oss.coe.de.mms_delegate_supply',	'buchhalt',	'landing',	'oss.coe.de.mms_delegate_supply_buchhalt_landing',	604800),
                ('oss.coe.de.mms_delegate_supply',	'buchhalt',	'standardized',	'oss.coe.de.mms_delegate_supply_buchhalt_standardized',	604800),
                ('oss.coe.de.mms_delegate_supply',	'buchhalt',	'history',	'oss.coe.de.mms_delegate_supply_buchhalt_history',	604800),
                ('oss.coe.de.mms_delegate_supply',	'ccsgroup',	'landing',	'oss.coe.de.mms_delegate_supply_ccsgroup_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'ccsgroup',	'standardized',	'oss.coe.de.mms_delegate_supply_ccsgroup_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'ccsgroup',	'history',	'oss.coe.de.mms_delegate_supply_ccsgroup_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'ccsgroup',	'landing',	'oss.coe.de.mms_delegate_supply_ccsgroup_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'crvpoheader',	'standardized',	'oss.coe.de.mms_delegate_supply_crvpoheader_standardized',	604800),
                ('oss.coe.de.mms_delegate_supply',	'crvpoheader',	'history',	'oss.coe.de.mms_delegate_supply_crvpoheader_history',	604800),
                ('oss.coe.de.mms_delegate_supply',	'crvpoheader',	'landing',	'oss.coe.de.mms_delegate_supply_crvpoheader_landing',	604800),
                ('oss.coe.de.mms_delegate_supply',	'crvpoheader',	'standardized',	'oss.coe.de.mms_delegate_supply_crvpoheader_standardized',	604800),
                ('oss.coe.de.mms_delegate_supply',	'crvpoline',	'history',	'oss.coe.de.mms_delegate_supply_crvpoline_history',	604800),
                ('oss.coe.de.mms_delegate_supply',	'crvpoline',	'landing',	'oss.coe.de.mms_delegate_supply_crvpoline_landing',	604800),
                ('oss.coe.de.mms_delegate_supply',	'crvpoline',	'standardized',	'oss.coe.de.mms_delegate_supply_crvpoline_standardized',	604800),
                ('oss.coe.de.mms_delegate_supply',	'crvpoline',	'history',	'oss.coe.de.mms_delegate_supply_crvpoline_history',	604800),
                ('oss.coe.de.mms_delegate_supply',	'fcurrency',	'landing',	'oss.coe.de.mms_delegate_supply_fcurrency_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'fcurrency',	'standardized',	'oss.coe.de.mms_delegate_supply_fcurrency_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'fcurrency',	'history',	'oss.coe.de.mms_delegate_supply_fcurrency_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'fcurrency',	'landing',	'oss.coe.de.mms_delegate_supply_fcurrency_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'his_pricequote',	'standardized',	'oss.coe.de.mms_delegate_supply_his_pricequote_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'his_pricequote',	'history',	'oss.coe.de.mms_delegate_supply_his_pricequote_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'his_pricequote',	'landing',	'oss.coe.de.mms_delegate_supply_his_pricequote_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'his_pricequote',	'standardized',	'oss.coe.de.mms_delegate_supply_his_pricequote_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'kostst',	'history',	'oss.coe.de.mms_delegate_supply_kostst_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'kostst',	'landing',	'oss.coe.de.mms_delegate_supply_kostst_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'kostst',	'standardized',	'oss.coe.de.mms_delegate_supply_kostst_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'kostst',	'transient',	'oss.coe.de.mms_delegate_supply_kostst_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'lager',	'history',	'oss.coe.de.mms_delegate_supply_lager_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'lager',	'landing',	'oss.coe.de.mms_delegate_supply_lager_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'lager',	'standardized',	'oss.coe.de.mms_delegate_supply_lager_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'lfartkat',	'transient',	'oss.coe.de.mms_delegate_supply_lfartkat_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'lfartkat',	'history',	'oss.coe.de.mms_delegate_supply_lfartkat_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'lfartkat',	'landing',	'oss.coe.de.mms_delegate_supply_lfartkat_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'lfartkat',	'standardized',	'oss.coe.de.mms_delegate_supply_lfartkat_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'liefer',	'transient',	'oss.coe.de.mms_delegate_supply_liefer_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'liefer',	'history',	'oss.coe.de.mms_delegate_supply_liefer_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'liefer',	'landing',	'oss.coe.de.mms_delegate_supply_liefer_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'liefer',	'standardized',	'oss.coe.de.mms_delegate_supply_liefer_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'lieferpos',	'transient',	'oss.coe.de.mms_delegate_supply_lieferpos_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'lieferpos',	'history',	'oss.coe.de.mms_delegate_supply_lieferpos_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'lieferpos',	'landing',	'oss.coe.de.mms_delegate_supply_lieferpos_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'lieferpos',	'standardized',	'oss.coe.de.mms_delegate_supply_lieferpos_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'menuplan',	'transient',	'oss.coe.de.mms_delegate_supply_menuplan_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'menuplan',	'history',	'oss.coe.de.mms_delegate_supply_menuplan_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'menuplan',	'landing',	'oss.coe.de.mms_delegate_supply_menuplan_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'menuplanpos',	'standardized',	'oss.coe.de.mms_delegate_supply_menuplanpos_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'menuplanpos',	'transient',	'oss.coe.de.mms_delegate_supply_menuplanpos_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'menuplanpos',	'history',	'oss.coe.de.mms_delegate_supply_menuplanpos_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'menuplanpos2add',	'landing',	'oss.coe.de.mms_delegate_supply_menuplanpos2add_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'menuplanpos2add',	'standardized',	'oss.coe.de.mms_delegate_supply_menuplanpos2add_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'menuplanpos2add',	'transient',	'oss.coe.de.mms_delegate_supply_menuplanpos2add_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'mplposlang',	'history',	'oss.coe.de.mms_delegate_supply_mplposlang_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'mplposlang',	'landing',	'oss.coe.de.mms_delegate_supply_mplposlang_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'mplposlang',	'standardized',	'oss.coe.de.mms_delegate_supply_mplposlang_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'mygcomponentgroup',	'history',	'oss.coe.de.mms_delegate_supply_mygcomponentgroup_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'mygcomponentgroup',	'landing',	'oss.coe.de.mms_delegate_supply_mygcomponentgroup_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'mygcomponentgroup',	'standardized',	'oss.coe.de.mms_delegate_supply_mygcomponentgroup_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'mygspltemplate',	'transient',	'oss.coe.de.mms_delegate_supply_mygspltemplate_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'mygspltemplate',	'history',	'oss.coe.de.mms_delegate_supply_mygspltemplate_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'mygspltemplate',	'landing',	'oss.coe.de.mms_delegate_supply_mygspltemplate_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'orgclient',	'standardized',	'oss.coe.de.mms_delegate_supply_orgclient_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'orgclient',	'transient',	'oss.coe.de.mms_delegate_supply_orgclient_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'orgclient',	'history',	'oss.coe.de.mms_delegate_supply_orgclient_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'orgclient',	'landing',	'oss.coe.de.mms_delegate_supply_orgclient_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'pq2cat',	'standardized',	'oss.coe.de.mms_delegate_supply_pq2cat_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'pq2cat',	'transient',	'oss.coe.de.mms_delegate_supply_pq2cat_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'pq2cat',	'history',	'oss.coe.de.mms_delegate_supply_pq2cat_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'pq2cat',	'landing',	'oss.coe.de.mms_delegate_supply_pq2cat_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'pqtocc',	'standardized',	'oss.coe.de.mms_delegate_supply_pqtocc_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'pqtocc',	'history',	'oss.coe.de.mms_delegate_supply_pqtocc_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'pqtocc',	'landing',	'oss.coe.de.mms_delegate_supply_pqtocc_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'pqtocc',	'standardized',	'oss.coe.de.mms_delegate_supply_pqtocc_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'pricequote',	'history',	'oss.coe.de.mms_delegate_supply_pricequote_history',	604800),
                ('oss.coe.de.mms_delegate_supply',	'pricequote',	'landing',	'oss.coe.de.mms_delegate_supply_pricequote_landing',	604800),
                ('oss.coe.de.mms_delegate_supply',	'pricequote',	'standardized',	'oss.coe.de.mms_delegate_supply_pricequote_standardized',	604800),
                ('oss.coe.de.mms_delegate_supply',	'pricequote',	'history',	'oss.coe.de.mms_delegate_supply_pricequote_history',	604800),
                ('oss.coe.de.mms_delegate_supply',	'pricequote2add',	'landing',	'oss.coe.de.mms_delegate_supply_pricequote2add_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'pricequote2add',	'standardized',	'oss.coe.de.mms_delegate_supply_pricequote2add_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'pricequote2add',	'history',	'oss.coe.de.mms_delegate_supply_pricequote2add_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'pricequote2add ',	'landing',	'oss.coe.de.mms_delegate_supply_pricequote2add _landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'pricequotefuture',	'standardized',	'oss.coe.de.mms_delegate_supply_pricequotefuture_standardized',	604800),
                ('oss.coe.de.mms_delegate_supply',	'pricequotefuture',	'history',	'oss.coe.de.mms_delegate_supply_pricequotefuture_history',	604800),
                ('oss.coe.de.mms_delegate_supply',	'pricequotefuture',	'landing',	'oss.coe.de.mms_delegate_supply_pricequotefuture_landing',	604800),
                ('oss.coe.de.mms_delegate_supply',	'pricequotefuture',	'standardized',	'oss.coe.de.mms_delegate_supply_pricequotefuture_standardized',	604800),
                ('oss.coe.de.mms_delegate_supply',	'prodeinh',	'history',	'oss.coe.de.mms_delegate_supply_prodeinh_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'prodeinh',	'landing',	'oss.coe.de.mms_delegate_supply_prodeinh_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'prodeinh',	'standardized',	'oss.coe.de.mms_delegate_supply_prodeinh_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'producer',	'transient',	'oss.coe.de.mms_delegate_supply_producer_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'producer',	'history',	'oss.coe.de.mms_delegate_supply_producer_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'producer',	'landing',	'oss.coe.de.mms_delegate_supply_producer_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'producer',	'standardized',	'oss.coe.de.mms_delegate_supply_producer_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rec_category',	'transient',	'oss.coe.de.mms_delegate_supply_rec_category_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rec_category',	'history',	'oss.coe.de.mms_delegate_supply_rec_category_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rec_category',	'landing',	'oss.coe.de.mms_delegate_supply_rec_category_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rec_category',	'standardized',	'oss.coe.de.mms_delegate_supply_rec_category_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rec_explosion',	'transient',	'oss.coe.de.mms_delegate_supply_rec_explosion_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rec_explosion',	'history',	'oss.coe.de.mms_delegate_supply_rec_explosion_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rec_explosion',	'landing',	'oss.coe.de.mms_delegate_supply_rec_explosion_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rechnung',	'standardized',	'oss.coe.de.mms_delegate_supply_rechnung_standardized',	604800),
                ('oss.coe.de.mms_delegate_supply',	'rechnung',	'transient',	'oss.coe.de.mms_delegate_supply_rechnung_transient',	604800),
                ('oss.coe.de.mms_delegate_supply',	'rechnung',	'history',	'oss.coe.de.mms_delegate_supply_rechnung_history',	604800),
                ('oss.coe.de.mms_delegate_supply',	'rechnung',	'landing',	'oss.coe.de.mms_delegate_supply_rechnung_landing',	604800),
                ('oss.coe.de.mms_delegate_supply',	'rechpos',	'standardized',	'oss.coe.de.mms_delegate_supply_rechpos_standardized',	604800),
                ('oss.coe.de.mms_delegate_supply',	'rechpos',	'transient',	'oss.coe.de.mms_delegate_supply_rechpos_transient',	604800),
                ('oss.coe.de.mms_delegate_supply',	'rechpos',	'history',	'oss.coe.de.mms_delegate_supply_rechpos_history',	604800),
                ('oss.coe.de.mms_delegate_supply',	'rechpos',	'landing',	'oss.coe.de.mms_delegate_supply_rechpos_landing',	604800),
                ('oss.coe.de.mms_delegate_supply',	'rez2menu',	'standardized',	'oss.coe.de.mms_delegate_supply_rez2menu_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rez2menu',	'transient',	'oss.coe.de.mms_delegate_supply_rez2menu_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rez2menu',	'history',	'oss.coe.de.mms_delegate_supply_rez2menu_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rezeptur',	'landing',	'oss.coe.de.mms_delegate_supply_rezeptur_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rezeptur',	'standardized',	'oss.coe.de.mms_delegate_supply_rezeptur_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rezeptur',	'history',	'oss.coe.de.mms_delegate_supply_rezeptur_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rezepturitem',	'landing',	'oss.coe.de.mms_delegate_supply_rezepturitem_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rezepturitem',	'standardized',	'oss.coe.de.mms_delegate_supply_rezepturitem_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rezepturitem',	'transient',	'oss.coe.de.mms_delegate_supply_rezepturitem_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rezgruppe',	'history',	'oss.coe.de.mms_delegate_supply_rezgruppe_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rezgruppe',	'landing',	'oss.coe.de.mms_delegate_supply_rezgruppe_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rezgruppe',	'standardized',	'oss.coe.de.mms_delegate_supply_rezgruppe_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'reztoart',	'transient',	'oss.coe.de.mms_delegate_supply_reztoart_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'reztoart',	'history',	'oss.coe.de.mms_delegate_supply_reztoart_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'reztoart',	'landing',	'oss.coe.de.mms_delegate_supply_reztoart_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'reztoart',	'standardized',	'oss.coe.de.mms_delegate_supply_reztoart_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rvbookedreceiptwithpositions',	'history',	'oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_history',	604800),
                ('oss.coe.de.mms_delegate_supply',	'rvbookedreceiptwithpositions',	'landing',	'oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_landing',	604800),
                ('oss.coe.de.mms_delegate_supply',	'rvbookedreceiptwithpositions',	'standardized',	'oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_standardized',	604800),
                ('oss.coe.de.mms_delegate_supply',	'rvbookedreceiptwithpositions',	'transient',	'oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_transient',	604800),
                ('oss.coe.de.mms_delegate_supply',	'rvcostcenter',	'history',	'oss.coe.de.mms_delegate_supply_rvcostcenter_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rvcostcenter',	'landing',	'oss.coe.de.mms_delegate_supply_rvcostcenter_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rvcostcenter',	'standardized',	'oss.coe.de.mms_delegate_supply_rvcostcenter_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'rvcostcenter',	'transient',	'oss.coe.de.mms_delegate_supply_rvcostcenter_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'sparte',	'history',	'oss.coe.de.mms_delegate_supply_sparte_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'sparte',	'landing',	'oss.coe.de.mms_delegate_supply_sparte_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'sparte',	'standardized',	'oss.coe.de.mms_delegate_supply_sparte_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'sparte',	'history',	'oss.coe.de.mms_delegate_supply_sparte_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'spartegr',	'landing',	'oss.coe.de.mms_delegate_supply_spartegr_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'spartegr',	'standardized',	'oss.coe.de.mms_delegate_supply_spartegr_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'spartegr',	'history',	'oss.coe.de.mms_delegate_supply_spartegr_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'spartegr',	'landing',	'oss.coe.de.mms_delegate_supply_spartegr_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'suppliergr',	'standardized',	'oss.coe.de.mms_delegate_supply_suppliergr_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'suppliergr',	'history',	'oss.coe.de.mms_delegate_supply_suppliergr_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'suppliergr',	'landing',	'oss.coe.de.mms_delegate_supply_suppliergr_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'suppliergr',	'standardized',	'oss.coe.de.mms_delegate_supply_suppliergr_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'v_kategorie2',	'history',	'oss.coe.de.mms_delegate_supply_v_kategorie2_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'v_kategorie2',	'landing',	'oss.coe.de.mms_delegate_supply_v_kategorie2_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'v_kategorie2',	'standardized',	'oss.coe.de.mms_delegate_supply_v_kategorie2_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'v_kategorie2',	'transient',	'oss.coe.de.mms_delegate_supply_v_kategorie2_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'vendortocc',	'history',	'oss.coe.de.mms_delegate_supply_vendortocc_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'vendortocc',	'landing',	'oss.coe.de.mms_delegate_supply_vendortocc_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'vendortocc',	'standardized',	'oss.coe.de.mms_delegate_supply_vendortocc_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'vpckeinh',	'transient',	'oss.coe.de.mms_delegate_supply_vpckeinh_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'vpckeinh',	'history',	'oss.coe.de.mms_delegate_supply_vpckeinh_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'vpckeinh',	'landing',	'oss.coe.de.mms_delegate_supply_vpckeinh_landing',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'warengruppe',	'standardized',	'oss.coe.de.mms_delegate_supply_warengruppe_standardized',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'warengruppe',	'transient',	'oss.coe.de.mms_delegate_supply_warengruppe_transient',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'warengruppe',	'history',	'oss.coe.de.mms_delegate_supply_warengruppe_history',	2592000),
                ('oss.coe.de.mms_delegate_supply',	'warengruppe',	'landing',	'oss.coe.de.mms_delegate_supply_warengruppe_landing',	2592000),
                ('oss.coe.glb.sap_fico',	'bkpf_be',	'standardized',	'oss.coe.glb.sap_fico_bkpf_be_standardized',	86400),
                ('oss.coe.glb.sap_fico',	'bkpf_be',	'transient',	'oss.coe.glb.sap_fico_bkpf_be_transient',	86400),
                ('oss.coe.glb.sap_fico',	'bkpf_be',	'history',	'oss.coe.glb.sap_fico_bkpf_be_history',	86400),
                ('oss.coe.glb.sap_fico',	'bkpf_de',	'landing',	'oss.coe.glb.sap_fico_bkpf_de_landing',	86400),
                ('oss.coe.glb.sap_fico',	'bkpf_de',	'standardized',	'oss.coe.glb.sap_fico_bkpf_de_standardized',	86400),
                ('oss.coe.glb.sap_fico',	'bkpf_de',	'transient',	'oss.coe.glb.sap_fico_bkpf_de_transient',	86400),
                ('oss.coe.glb.sap_fico',	'bkpf_nl',	'history',	'oss.coe.glb.sap_fico_bkpf_nl_history',	86400),
                ('oss.coe.glb.sap_fico',	'bkpf_nl',	'landing',	'oss.coe.glb.sap_fico_bkpf_nl_landing',	86400),
                ('oss.coe.glb.sap_fico',	'bkpf_nl',	'standardized',	'oss.coe.glb.sap_fico_bkpf_nl_standardized',	86400),
                ('oss.coe.glb.sap_fico',	'bkpf_se_fi',	'transient',	'oss.coe.glb.sap_fico_bkpf_se_fi_transient',	86400),
                ('oss.coe.glb.sap_fico',	'bkpf_se_fi',	'history',	'oss.coe.glb.sap_fico_bkpf_se_fi_history',	86400),
                ('oss.coe.glb.sap_fico',	'bkpf_se_fi',	'landing',	'oss.coe.glb.sap_fico_bkpf_se_fi_landing',	86400),
                ('oss.coe.glb.sap_fico',	'bseg_be',	'standardized',	'oss.coe.glb.sap_fico_bseg_be_standardized',	86400),
                ('oss.coe.glb.sap_fico',	'bseg_be',	'history',	'oss.coe.glb.sap_fico_bseg_be_history',	86400),
                ('oss.coe.glb.sap_fico',	'bseg_be',	'landing',	'oss.coe.glb.sap_fico_bseg_be_landing',	86400),
                ('oss.coe.glb.sap_fico',	'bseg_de',	'standardized',	'oss.coe.glb.sap_fico_bseg_de_standardized',	86400),
                ('oss.coe.glb.sap_fico',	'bseg_de',	'transient',	'oss.coe.glb.sap_fico_bseg_de_transient',	86400),
                ('oss.coe.glb.sap_fico',	'bseg_de',	'history',	'oss.coe.glb.sap_fico_bseg_de_history',	86400),
                ('oss.coe.glb.sap_fico',	'bseg_nl',	'landing',	'oss.coe.glb.sap_fico_bseg_nl_landing',	86400),
                ('oss.coe.glb.sap_fico',	'bseg_nl',	'standardized',	'oss.coe.glb.sap_fico_bseg_nl_standardized',	86400),
                ('oss.coe.glb.sap_fico',	'bseg_nl',	'history',	'oss.coe.glb.sap_fico_bseg_nl_history',	86400),
                ('oss.coe.glb.sap_fico',	'bseg_se_fi',	'landing',	'oss.coe.glb.sap_fico_bseg_se_fi_landing',	86400),
                ('oss.coe.glb.sap_fico',	'bseg_se_fi',	'standardized',	'oss.coe.glb.sap_fico_bseg_se_fi_standardized',	86400),
                ('oss.coe.glb.sap_fico',	'bseg_se_fi',	'history',	'oss.coe.glb.sap_fico_bseg_se_fi_history',	86400),
                ('oss.coe.glb.sap_fico',	't052u',	'landing',	'oss.coe.glb.sap_fico_t052u_landing',	86400),
                ('oss.coe.glb.sap_fico',	't052u',	'standardized',	'oss.coe.glb.sap_fico_t052u_standardized',	86400),
                ('oss.coe.glb.sap_fico',	't052u',	'transient',	'oss.coe.glb.sap_fico_t052u_transient',	86400)
                ) AS t (project_name, dataset_name, landing_zone, context_id, ttl)
           WHERE context_id IN (${context:sqlstring}+'')
        ),
        RawEvents AS (
            SELECT
                [timestamp],
                context_id,
                job_id,
                metric_value
            FROM
                [observability].[event]
            WHERE
                metric_name = 'processing_exit_code'
                AND event_type = 'processingfinished'
                AND context_id IN (${context:sqlstring}+'')
                AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
        ),
        DistinctJobs AS (
            SELECT DISTINCT
                context_id,
                job_id,
                metric_value
            FROM
                RawEvents
        ),
        IngestionSum AS (
            SELECT
                context_id,
                SUM(CASE WHEN metric_value = 0 THEN 1 ELSE 0 END) AS Succeeded,
                SUM(CASE WHEN metric_value = 1 THEN 1 ELSE 0 END) AS No_Data,
                SUM(CASE WHEN metric_value = -1 THEN 1 ELSE 0 END) AS Failed
            FROM
                DistinctJobs
            GROUP BY
                context_id
        ),
        FilteredAndAdded AS (
            SELECT
                timestamp,
                context_id,
                metric_value
            FROM (
                SELECT
                    timestamp,
                    context_id,
                    metric_value
                FROM
                    RawEvents
                WHERE
                    metric_value = 0

                UNION ALL

                SELECT
                $__unixEpochTo() AS timestamp,  -- Current UTC timestamp as Unix time
                    context_id,
                    0 AS metric_value
                FROM
                    (SELECT DISTINCT context_id FROM RawEvents WHERE metric_value = 0) AS UniqueContexts

                UNION ALL

                SELECT
                $__unixEpochFrom() AS timestamp,  -- Current UTC timestamp as Unix time
                    context_id,
                    0 AS metric_value
                FROM (SELECT DISTINCT context_id FROM RawEvents WHERE metric_value = 0) AS UniqueContexts
            ) AS CombinedFilteredResults
        ),
        EventDifferences AS (
            SELECT
                context_id,
                timestamp,
                metric_value,
                LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) AS previous_timestamp,
                CASE
                    WHEN LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp) IS NOT NULL THEN
                        timestamp - LAG(timestamp) OVER (PARTITION BY context_id ORDER BY timestamp)
                    ELSE NULL
                END AS time_difference
            FROM
                FilteredAndAdded
            WHERE
                metric_value = 0
        ),
        Slis AS (
            SELECT
                cv.project_name AS 'Application Source',
                cv.dataset_name AS 'DatasetName',
                cv.landing_zone AS 'Zone',
                cv.ttl AS 'TTL',
                COALESCE(iso.Succeeded, 0) AS 'Succeeded',
                COALESCE(iso.No_Data, 0) AS 'No New Data',
                COALESCE(iso.Failed, 0) AS 'Failed',
                COALESCE(SUM(ed.time_difference - cv.ttl), 0) AS 'DownTime',
                CASE
                    WHEN COALESCE(iso.Succeeded, 0) = 0 THEN 0
                    WHEN COALESCE(SUM(ed.time_difference - cv.ttl), 0) = 0 THEN 100
                    ELSE 100 - (COALESCE(SUM(ed.time_difference - cv.ttl), 0) * 100.0 / ($__unixEpochTo() - $__unixEpochFrom()))
                END AS SLI
            FROM
                CombinedValues AS cv
            LEFT JOIN
                IngestionSum AS iso
            ON
                cv.context_id = iso.context_id
            LEFT JOIN
                EventDifferences AS ed
            ON
                cv.context_id = ed.context_id
                AND ed.time_difference > cv.ttl
            GROUP BY
                cv.project_name, cv.dataset_name, cv.landing_zone, cv.ttl, iso.Succeeded, iso.No_Data, iso.Failed
        )
        select AVG(SLI) as 'SLI Percentage'  from Slis
    
    ";

    stat.new(
        title='SLI',
        datasource='Azure SQL Server',
        description= "The SLI(Service Level Indicator) is a measurable metric closely monitored by stakeholders to
        evaluate the operational performance and efficiency of a data ingestion pipeline. It is calculated here as a 
        percentage of up-to-date ingestions, by calculating the percentage of ingestionDelay for ingestions against 
        the specific timeframe(by application source, dataset name, zone). An ingestion is up to date if the difference 
        between two ingestions is lower than the ttl. For Example, If there is no IngestionDelay for ingestions over 
        specific timeframe then SLI is 100.")
        .addTarget(target=grafana.sql.target(rawSql=SLISqlQuery, format='table'))
        .addOverridesByFieldName(
        field='SLI Percentage',
        properties=[{id: 'unit', value: 'percent'},
        {
            "id": "thresholds",
            "value": {
            "mode": "absolute",
            "steps": [
                { "color": "light-gray", "value": null },
                { "color": "light-red", "value": 0 },
                { "color": "light-yellow", "value": 80 },
                { "color": "light-green", "value": 80*1.1 }
            ]
            }
        }
        ]
);

local generateIngestionPipelinesByCondition(title, color, code) =
   local sqlQuery = std.format("  
        SELECT COUNT(*)
        FROM(
                SELECT distinct job_id, context_id
                FROM [observability].[event]
                WHERE metric_name='processing_exit_code'
                AND event_type='processingfinished'
                AND metric_value=%d
                AND context_id IN ('oss.coe.de.mms_delegate_supply_additives_history','oss.coe.de.mms_delegate_supply_additives_landing','oss.coe.de.mms_delegate_supply_additives_standardized','oss.coe.de.mms_delegate_supply_additives_transient','oss.coe.de.mms_delegate_supply_art2cat_history','oss.coe.de.mms_delegate_supply_art2cat_landing','oss.coe.de.mms_delegate_supply_art2cat_standardized','oss.coe.de.mms_delegate_supply_art2cat_transient','oss.coe.de.mms_delegate_supply_article2add_history','oss.coe.de.mms_delegate_supply_article2add_landing','oss.coe.de.mms_delegate_supply_article2add_standardized','oss.coe.de.mms_delegate_supply_artikel_history','oss.coe.de.mms_delegate_supply_artikel_landing','oss.coe.de.mms_delegate_supply_artikel_standardized','oss.coe.de.mms_delegate_supply_artikel_transient','oss.coe.de.mms_delegate_supply_besteller_history','oss.coe.de.mms_delegate_supply_besteller_landing','oss.coe.de.mms_delegate_supply_besteller_standardized','oss.coe.de.mms_delegate_supply_buchhalt_history','oss.coe.de.mms_delegate_supply_buchhalt_landing','oss.coe.de.mms_delegate_supply_buchhalt_standardized','oss.coe.de.mms_delegate_supply_buchhalt_transient','oss.coe.de.mms_delegate_supply_ccsgroup_history','oss.coe.de.mms_delegate_supply_ccsgroup_landing','oss.coe.de.mms_delegate_supply_ccsgroup_standardized','oss.coe.de.mms_delegate_supply_ccsgroup_transient','oss.coe.de.mms_delegate_supply_crvpoheader_history','oss.coe.de.mms_delegate_supply_crvpoheader_landing','oss.coe.de.mms_delegate_supply_crvpoheader_standardized','oss.coe.de.mms_delegate_supply_crvpoheader_transient','oss.coe.de.mms_delegate_supply_crvpoline_history','oss.coe.de.mms_delegate_supply_crvpoline_landing','oss.coe.de.mms_delegate_supply_crvpoline_standardized','oss.coe.de.mms_delegate_supply_crvpoline_transient','oss.coe.de.mms_delegate_supply_fcurrency_history','oss.coe.de.mms_delegate_supply_fcurrency_landing','oss.coe.de.mms_delegate_supply_fcurrency_standardized','oss.coe.de.mms_delegate_supply_fcurrency_transient','oss.coe.de.mms_delegate_supply_his_pricequote_history','oss.coe.de.mms_delegate_supply_his_pricequote_landing','oss.coe.de.mms_delegate_supply_his_pricequote_standardized','oss.coe.de.mms_delegate_supply_his_pricequote_transient','oss.coe.de.mms_delegate_supply_kostst_history','oss.coe.de.mms_delegate_supply_kostst_landing','oss.coe.de.mms_delegate_supply_kostst_standardized','oss.coe.de.mms_delegate_supply_kostst_transient','oss.coe.de.mms_delegate_supply_lager_history','oss.coe.de.mms_delegate_supply_lager_landing','oss.coe.de.mms_delegate_supply_lager_standardized','oss.coe.de.mms_delegate_supply_lfartkat_history','oss.coe.de.mms_delegate_supply_lfartkat_landing','oss.coe.de.mms_delegate_supply_lfartkat_standardized','oss.coe.de.mms_delegate_supply_lfartkat_transient','oss.coe.de.mms_delegate_supply_liefer_history','oss.coe.de.mms_delegate_supply_liefer_landing','oss.coe.de.mms_delegate_supply_liefer_standardized','oss.coe.de.mms_delegate_supply_liefer_transient','oss.coe.de.mms_delegate_supply_lieferpos_history','oss.coe.de.mms_delegate_supply_lieferpos_landing','oss.coe.de.mms_delegate_supply_lieferpos_standardized','oss.coe.de.mms_delegate_supply_lieferpos_transient','oss.coe.de.mms_delegate_supply_menuplan_history','oss.coe.de.mms_delegate_supply_menuplan_landing','oss.coe.de.mms_delegate_supply_menuplan_standardized','oss.coe.de.mms_delegate_supply_menuplanpos_history','oss.coe.de.mms_delegate_supply_menuplanpos_landing','oss.coe.de.mms_delegate_supply_menuplanpos_standardized','oss.coe.de.mms_delegate_supply_menuplanpos2add_history','oss.coe.de.mms_delegate_supply_menuplanpos2add_landing','oss.coe.de.mms_delegate_supply_menuplanpos2add_standardized','oss.coe.de.mms_delegate_supply_mplposlang_history','oss.coe.de.mms_delegate_supply_mplposlang_landing','oss.coe.de.mms_delegate_supply_mplposlang_standardized','oss.coe.de.mms_delegate_supply_mygcomponentgroup_history','oss.coe.de.mms_delegate_supply_mygcomponentgroup_landing','oss.coe.de.mms_delegate_supply_mygcomponentgroup_standardized','oss.coe.de.mms_delegate_supply_mygspltemplate_history','oss.coe.de.mms_delegate_supply_mygspltemplate_landing','oss.coe.de.mms_delegate_supply_mygspltemplate_standardized','oss.coe.de.mms_delegate_supply_orgclient_history','oss.coe.de.mms_delegate_supply_orgclient_landing','oss.coe.de.mms_delegate_supply_orgclient_standardized','oss.coe.de.mms_delegate_supply_orgclient_transient','oss.coe.de.mms_delegate_supply_pq2cat_history','oss.coe.de.mms_delegate_supply_pq2cat_landing','oss.coe.de.mms_delegate_supply_pq2cat_standardized','oss.coe.de.mms_delegate_supply_pq2cat_transient','oss.coe.de.mms_delegate_supply_pqtocc_history','oss.coe.de.mms_delegate_supply_pqtocc_landing','oss.coe.de.mms_delegate_supply_pqtocc_standardized','oss.coe.de.mms_delegate_supply_pqtocc_transient','oss.coe.de.mms_delegate_supply_pricequote_history','oss.coe.de.mms_delegate_supply_pricequote_landing','oss.coe.de.mms_delegate_supply_pricequote_standardized','oss.coe.de.mms_delegate_supply_pricequote_transient','oss.coe.de.mms_delegate_supply_pricequote2add _transient','oss.coe.de.mms_delegate_supply_pricequote2add_history','oss.coe.de.mms_delegate_supply_pricequote2add_landing','oss.coe.de.mms_delegate_supply_pricequote2add_standardized','oss.coe.de.mms_delegate_supply_pricequotefuture_history','oss.coe.de.mms_delegate_supply_pricequotefuture_landing','oss.coe.de.mms_delegate_supply_pricequotefuture_standardized','oss.coe.de.mms_delegate_supply_pricequotefuture_transient','oss.coe.de.mms_delegate_supply_prodeinh_history','oss.coe.de.mms_delegate_supply_prodeinh_landing','oss.coe.de.mms_delegate_supply_prodeinh_standardized','oss.coe.de.mms_delegate_supply_producer_history','oss.coe.de.mms_delegate_supply_producer_landing','oss.coe.de.mms_delegate_supply_producer_standardized','oss.coe.de.mms_delegate_supply_producer_transient','oss.coe.de.mms_delegate_supply_rec_category_history','oss.coe.de.mms_delegate_supply_rec_category_landing','oss.coe.de.mms_delegate_supply_rec_category_standardized','oss.coe.de.mms_delegate_supply_rec_category_transient','oss.coe.de.mms_delegate_supply_rec_explosion_history','oss.coe.de.mms_delegate_supply_rec_explosion_landing','oss.coe.de.mms_delegate_supply_rec_explosion_standardized','oss.coe.de.mms_delegate_supply_rechnung_history','oss.coe.de.mms_delegate_supply_rechnung_landing','oss.coe.de.mms_delegate_supply_rechnung_standardized','oss.coe.de.mms_delegate_supply_rechnung_transient','oss.coe.de.mms_delegate_supply_rechpos_history','oss.coe.de.mms_delegate_supply_rechpos_landing','oss.coe.de.mms_delegate_supply_rechpos_standardized','oss.coe.de.mms_delegate_supply_rechpos_transient','oss.coe.de.mms_delegate_supply_rez2menu_history','oss.coe.de.mms_delegate_supply_rez2menu_landing','oss.coe.de.mms_delegate_supply_rez2menu_standardized','oss.coe.de.mms_delegate_supply_rezeptur_history','oss.coe.de.mms_delegate_supply_rezeptur_landing','oss.coe.de.mms_delegate_supply_rezeptur_standardized','oss.coe.de.mms_delegate_supply_rezepturitem_history','oss.coe.de.mms_delegate_supply_rezepturitem_landing','oss.coe.de.mms_delegate_supply_rezepturitem_standardized','oss.coe.de.mms_delegate_supply_rezgruppe_history','oss.coe.de.mms_delegate_supply_rezgruppe_landing','oss.coe.de.mms_delegate_supply_rezgruppe_standardized','oss.coe.de.mms_delegate_supply_reztoart_history','oss.coe.de.mms_delegate_supply_reztoart_landing','oss.coe.de.mms_delegate_supply_reztoart_standardized','oss.coe.de.mms_delegate_supply_reztoart_transient','oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_history','oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_landing','oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_standardized','oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_transient','oss.coe.de.mms_delegate_supply_rvcostcenter_history','oss.coe.de.mms_delegate_supply_rvcostcenter_landing','oss.coe.de.mms_delegate_supply_rvcostcenter_standardized','oss.coe.de.mms_delegate_supply_rvcostcenter_transient','oss.coe.de.mms_delegate_supply_sparte_history','oss.coe.de.mms_delegate_supply_sparte_landing','oss.coe.de.mms_delegate_supply_sparte_standardized','oss.coe.de.mms_delegate_supply_sparte_transient','oss.coe.de.mms_delegate_supply_spartegr_history','oss.coe.de.mms_delegate_supply_spartegr_landing','oss.coe.de.mms_delegate_supply_spartegr_standardized','oss.coe.de.mms_delegate_supply_spartegr_transient','oss.coe.de.mms_delegate_supply_suppliergr_history','oss.coe.de.mms_delegate_supply_suppliergr_landing','oss.coe.de.mms_delegate_supply_suppliergr_standardized','oss.coe.de.mms_delegate_supply_suppliergr_transient','oss.coe.de.mms_delegate_supply_v_kategorie2_history','oss.coe.de.mms_delegate_supply_v_kategorie2_landing','oss.coe.de.mms_delegate_supply_v_kategorie2_standardized','oss.coe.de.mms_delegate_supply_v_kategorie2_transient','oss.coe.de.mms_delegate_supply_vendortocc_history','oss.coe.de.mms_delegate_supply_vendortocc_landing','oss.coe.de.mms_delegate_supply_vendortocc_standardized','oss.coe.de.mms_delegate_supply_vpckeinh_history','oss.coe.de.mms_delegate_supply_vpckeinh_landing','oss.coe.de.mms_delegate_supply_vpckeinh_standardized','oss.coe.de.mms_delegate_supply_warengruppe_history','oss.coe.de.mms_delegate_supply_warengruppe_landing','oss.coe.de.mms_delegate_supply_warengruppe_standardized','oss.coe.de.mms_delegate_supply_warengruppe_transient','oss.coe.glb.sap_fico_bkpf_be_history','oss.coe.glb.sap_fico_bkpf_be_landing','oss.coe.glb.sap_fico_bkpf_be_standardized','oss.coe.glb.sap_fico_bkpf_de_history','oss.coe.glb.sap_fico_bkpf_de_landing','oss.coe.glb.sap_fico_bkpf_de_standardized','oss.coe.glb.sap_fico_bkpf_nl_history','oss.coe.glb.sap_fico_bkpf_nl_landing','oss.coe.glb.sap_fico_bkpf_nl_standardized','oss.coe.glb.sap_fico_bkpf_se_fi_history','oss.coe.glb.sap_fico_bkpf_se_fi_landing','oss.coe.glb.sap_fico_bkpf_se_fi_standardized','oss.coe.glb.sap_fico_bseg_be_history','oss.coe.glb.sap_fico_bseg_be_landing','oss.coe.glb.sap_fico_bseg_be_standardized','oss.coe.glb.sap_fico_bseg_de_history','oss.coe.glb.sap_fico_bseg_de_landing','oss.coe.glb.sap_fico_bseg_de_standardized','oss.coe.glb.sap_fico_bseg_nl_history','oss.coe.glb.sap_fico_bseg_nl_landing','oss.coe.glb.sap_fico_bseg_nl_standardized','oss.coe.glb.sap_fico_bseg_se_fi_history','oss.coe.glb.sap_fico_bseg_se_fi_landing','oss.coe.glb.sap_fico_bseg_se_fi_standardized','oss.coe.glb.sap_fico_t052u_history','oss.coe.glb.sap_fico_t052u_landing','oss.coe.glb.sap_fico_t052u_standardized'+'')
                AND timestamp >= $__unixEpochFrom() AND timestamp < $__unixEpochTo()
                AND dataset_name IN ($dataset_name)
                AND landing_zone IN ($landing_zone)
                AND project_name IN ($project_name)
            ) AS SubQuery
        
        ", [code]
    );

    grafana.statPanel.new(title, datasource='Azure SQL Server', colorMode='background')
    .addThresholds([{ value: 0, color: color }])
    .addTarget(target=grafana.sql.target(rawSql=sqlQuery, format='table')
);

local GenerateSuccessRatio =
    local sqlQuery = " 
        SELECT
            CASE WHEN COUNT(*) = 0 THEN 100 
            ELSE COUNT(CASE WHEN metric_value != -1 THEN 1 ELSE NULL END) * 100.0 / COUNT(*) 
            END AS ratio
        FROM ( select distinct job_id, context_id, metric_value from[observability].[event]
                  WHERE metric_name= 'processing_exit_code'
                  AND event_type =  'processingfinished'
                AND context_id IN ('oss.coe.de.mms_delegate_supply_additives_history','oss.coe.de.mms_delegate_supply_additives_landing','oss.coe.de.mms_delegate_supply_additives_standardized','oss.coe.de.mms_delegate_supply_additives_transient','oss.coe.de.mms_delegate_supply_art2cat_history','oss.coe.de.mms_delegate_supply_art2cat_landing','oss.coe.de.mms_delegate_supply_art2cat_standardized','oss.coe.de.mms_delegate_supply_art2cat_transient','oss.coe.de.mms_delegate_supply_article2add_history','oss.coe.de.mms_delegate_supply_article2add_landing','oss.coe.de.mms_delegate_supply_article2add_standardized','oss.coe.de.mms_delegate_supply_artikel_history','oss.coe.de.mms_delegate_supply_artikel_landing','oss.coe.de.mms_delegate_supply_artikel_standardized','oss.coe.de.mms_delegate_supply_artikel_transient','oss.coe.de.mms_delegate_supply_besteller_history','oss.coe.de.mms_delegate_supply_besteller_landing','oss.coe.de.mms_delegate_supply_besteller_standardized','oss.coe.de.mms_delegate_supply_buchhalt_history','oss.coe.de.mms_delegate_supply_buchhalt_landing','oss.coe.de.mms_delegate_supply_buchhalt_standardized','oss.coe.de.mms_delegate_supply_buchhalt_transient','oss.coe.de.mms_delegate_supply_ccsgroup_history','oss.coe.de.mms_delegate_supply_ccsgroup_landing','oss.coe.de.mms_delegate_supply_ccsgroup_standardized','oss.coe.de.mms_delegate_supply_ccsgroup_transient','oss.coe.de.mms_delegate_supply_crvpoheader_history','oss.coe.de.mms_delegate_supply_crvpoheader_landing','oss.coe.de.mms_delegate_supply_crvpoheader_standardized','oss.coe.de.mms_delegate_supply_crvpoheader_transient','oss.coe.de.mms_delegate_supply_crvpoline_history','oss.coe.de.mms_delegate_supply_crvpoline_landing','oss.coe.de.mms_delegate_supply_crvpoline_standardized','oss.coe.de.mms_delegate_supply_crvpoline_transient','oss.coe.de.mms_delegate_supply_fcurrency_history','oss.coe.de.mms_delegate_supply_fcurrency_landing','oss.coe.de.mms_delegate_supply_fcurrency_standardized','oss.coe.de.mms_delegate_supply_fcurrency_transient','oss.coe.de.mms_delegate_supply_his_pricequote_history','oss.coe.de.mms_delegate_supply_his_pricequote_landing','oss.coe.de.mms_delegate_supply_his_pricequote_standardized','oss.coe.de.mms_delegate_supply_his_pricequote_transient','oss.coe.de.mms_delegate_supply_kostst_history','oss.coe.de.mms_delegate_supply_kostst_landing','oss.coe.de.mms_delegate_supply_kostst_standardized','oss.coe.de.mms_delegate_supply_kostst_transient','oss.coe.de.mms_delegate_supply_lager_history','oss.coe.de.mms_delegate_supply_lager_landing','oss.coe.de.mms_delegate_supply_lager_standardized','oss.coe.de.mms_delegate_supply_lfartkat_history','oss.coe.de.mms_delegate_supply_lfartkat_landing','oss.coe.de.mms_delegate_supply_lfartkat_standardized','oss.coe.de.mms_delegate_supply_lfartkat_transient','oss.coe.de.mms_delegate_supply_liefer_history','oss.coe.de.mms_delegate_supply_liefer_landing','oss.coe.de.mms_delegate_supply_liefer_standardized','oss.coe.de.mms_delegate_supply_liefer_transient','oss.coe.de.mms_delegate_supply_lieferpos_history','oss.coe.de.mms_delegate_supply_lieferpos_landing','oss.coe.de.mms_delegate_supply_lieferpos_standardized','oss.coe.de.mms_delegate_supply_lieferpos_transient','oss.coe.de.mms_delegate_supply_menuplan_history','oss.coe.de.mms_delegate_supply_menuplan_landing','oss.coe.de.mms_delegate_supply_menuplan_standardized','oss.coe.de.mms_delegate_supply_menuplanpos_history','oss.coe.de.mms_delegate_supply_menuplanpos_landing','oss.coe.de.mms_delegate_supply_menuplanpos_standardized','oss.coe.de.mms_delegate_supply_menuplanpos2add_history','oss.coe.de.mms_delegate_supply_menuplanpos2add_landing','oss.coe.de.mms_delegate_supply_menuplanpos2add_standardized','oss.coe.de.mms_delegate_supply_mplposlang_history','oss.coe.de.mms_delegate_supply_mplposlang_landing','oss.coe.de.mms_delegate_supply_mplposlang_standardized','oss.coe.de.mms_delegate_supply_mygcomponentgroup_history','oss.coe.de.mms_delegate_supply_mygcomponentgroup_landing','oss.coe.de.mms_delegate_supply_mygcomponentgroup_standardized','oss.coe.de.mms_delegate_supply_mygspltemplate_history','oss.coe.de.mms_delegate_supply_mygspltemplate_landing','oss.coe.de.mms_delegate_supply_mygspltemplate_standardized','oss.coe.de.mms_delegate_supply_orgclient_history','oss.coe.de.mms_delegate_supply_orgclient_landing','oss.coe.de.mms_delegate_supply_orgclient_standardized','oss.coe.de.mms_delegate_supply_orgclient_transient','oss.coe.de.mms_delegate_supply_pq2cat_history','oss.coe.de.mms_delegate_supply_pq2cat_landing','oss.coe.de.mms_delegate_supply_pq2cat_standardized','oss.coe.de.mms_delegate_supply_pq2cat_transient','oss.coe.de.mms_delegate_supply_pqtocc_history','oss.coe.de.mms_delegate_supply_pqtocc_landing','oss.coe.de.mms_delegate_supply_pqtocc_standardized','oss.coe.de.mms_delegate_supply_pqtocc_transient','oss.coe.de.mms_delegate_supply_pricequote_history','oss.coe.de.mms_delegate_supply_pricequote_landing','oss.coe.de.mms_delegate_supply_pricequote_standardized','oss.coe.de.mms_delegate_supply_pricequote_transient','oss.coe.de.mms_delegate_supply_pricequote2add _transient','oss.coe.de.mms_delegate_supply_pricequote2add_history','oss.coe.de.mms_delegate_supply_pricequote2add_landing','oss.coe.de.mms_delegate_supply_pricequote2add_standardized','oss.coe.de.mms_delegate_supply_pricequotefuture_history','oss.coe.de.mms_delegate_supply_pricequotefuture_landing','oss.coe.de.mms_delegate_supply_pricequotefuture_standardized','oss.coe.de.mms_delegate_supply_pricequotefuture_transient','oss.coe.de.mms_delegate_supply_prodeinh_history','oss.coe.de.mms_delegate_supply_prodeinh_landing','oss.coe.de.mms_delegate_supply_prodeinh_standardized','oss.coe.de.mms_delegate_supply_producer_history','oss.coe.de.mms_delegate_supply_producer_landing','oss.coe.de.mms_delegate_supply_producer_standardized','oss.coe.de.mms_delegate_supply_producer_transient','oss.coe.de.mms_delegate_supply_rec_category_history','oss.coe.de.mms_delegate_supply_rec_category_landing','oss.coe.de.mms_delegate_supply_rec_category_standardized','oss.coe.de.mms_delegate_supply_rec_category_transient','oss.coe.de.mms_delegate_supply_rec_explosion_history','oss.coe.de.mms_delegate_supply_rec_explosion_landing','oss.coe.de.mms_delegate_supply_rec_explosion_standardized','oss.coe.de.mms_delegate_supply_rechnung_history','oss.coe.de.mms_delegate_supply_rechnung_landing','oss.coe.de.mms_delegate_supply_rechnung_standardized','oss.coe.de.mms_delegate_supply_rechnung_transient','oss.coe.de.mms_delegate_supply_rechpos_history','oss.coe.de.mms_delegate_supply_rechpos_landing','oss.coe.de.mms_delegate_supply_rechpos_standardized','oss.coe.de.mms_delegate_supply_rechpos_transient','oss.coe.de.mms_delegate_supply_rez2menu_history','oss.coe.de.mms_delegate_supply_rez2menu_landing','oss.coe.de.mms_delegate_supply_rez2menu_standardized','oss.coe.de.mms_delegate_supply_rezeptur_history','oss.coe.de.mms_delegate_supply_rezeptur_landing','oss.coe.de.mms_delegate_supply_rezeptur_standardized','oss.coe.de.mms_delegate_supply_rezepturitem_history','oss.coe.de.mms_delegate_supply_rezepturitem_landing','oss.coe.de.mms_delegate_supply_rezepturitem_standardized','oss.coe.de.mms_delegate_supply_rezgruppe_history','oss.coe.de.mms_delegate_supply_rezgruppe_landing','oss.coe.de.mms_delegate_supply_rezgruppe_standardized','oss.coe.de.mms_delegate_supply_reztoart_history','oss.coe.de.mms_delegate_supply_reztoart_landing','oss.coe.de.mms_delegate_supply_reztoart_standardized','oss.coe.de.mms_delegate_supply_reztoart_transient','oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_history','oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_landing','oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_standardized','oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_transient','oss.coe.de.mms_delegate_supply_rvcostcenter_history','oss.coe.de.mms_delegate_supply_rvcostcenter_landing','oss.coe.de.mms_delegate_supply_rvcostcenter_standardized','oss.coe.de.mms_delegate_supply_rvcostcenter_transient','oss.coe.de.mms_delegate_supply_sparte_history','oss.coe.de.mms_delegate_supply_sparte_landing','oss.coe.de.mms_delegate_supply_sparte_standardized','oss.coe.de.mms_delegate_supply_sparte_transient','oss.coe.de.mms_delegate_supply_spartegr_history','oss.coe.de.mms_delegate_supply_spartegr_landing','oss.coe.de.mms_delegate_supply_spartegr_standardized','oss.coe.de.mms_delegate_supply_spartegr_transient','oss.coe.de.mms_delegate_supply_suppliergr_history','oss.coe.de.mms_delegate_supply_suppliergr_landing','oss.coe.de.mms_delegate_supply_suppliergr_standardized','oss.coe.de.mms_delegate_supply_suppliergr_transient','oss.coe.de.mms_delegate_supply_v_kategorie2_history','oss.coe.de.mms_delegate_supply_v_kategorie2_landing','oss.coe.de.mms_delegate_supply_v_kategorie2_standardized','oss.coe.de.mms_delegate_supply_v_kategorie2_transient','oss.coe.de.mms_delegate_supply_vendortocc_history','oss.coe.de.mms_delegate_supply_vendortocc_landing','oss.coe.de.mms_delegate_supply_vendortocc_standardized','oss.coe.de.mms_delegate_supply_vpckeinh_history','oss.coe.de.mms_delegate_supply_vpckeinh_landing','oss.coe.de.mms_delegate_supply_vpckeinh_standardized','oss.coe.de.mms_delegate_supply_warengruppe_history','oss.coe.de.mms_delegate_supply_warengruppe_landing','oss.coe.de.mms_delegate_supply_warengruppe_standardized','oss.coe.de.mms_delegate_supply_warengruppe_transient','oss.coe.glb.sap_fico_bkpf_be_history','oss.coe.glb.sap_fico_bkpf_be_landing','oss.coe.glb.sap_fico_bkpf_be_standardized','oss.coe.glb.sap_fico_bkpf_de_history','oss.coe.glb.sap_fico_bkpf_de_landing','oss.coe.glb.sap_fico_bkpf_de_standardized','oss.coe.glb.sap_fico_bkpf_nl_history','oss.coe.glb.sap_fico_bkpf_nl_landing','oss.coe.glb.sap_fico_bkpf_nl_standardized','oss.coe.glb.sap_fico_bkpf_se_fi_history','oss.coe.glb.sap_fico_bkpf_se_fi_landing','oss.coe.glb.sap_fico_bkpf_se_fi_standardized','oss.coe.glb.sap_fico_bseg_be_history','oss.coe.glb.sap_fico_bseg_be_landing','oss.coe.glb.sap_fico_bseg_be_standardized','oss.coe.glb.sap_fico_bseg_de_history','oss.coe.glb.sap_fico_bseg_de_landing','oss.coe.glb.sap_fico_bseg_de_standardized','oss.coe.glb.sap_fico_bseg_nl_history','oss.coe.glb.sap_fico_bseg_nl_landing','oss.coe.glb.sap_fico_bseg_nl_standardized','oss.coe.glb.sap_fico_bseg_se_fi_history','oss.coe.glb.sap_fico_bseg_se_fi_landing','oss.coe.glb.sap_fico_bseg_se_fi_standardized','oss.coe.glb.sap_fico_t052u_history','oss.coe.glb.sap_fico_t052u_landing','oss.coe.glb.sap_fico_t052u_standardized'+'')
                  AND context_id IN (${context:sqlstring}+'')
                  AND timestamp >= $__unixEpochFrom()
                  AND timestamp < $__unixEpochTo()
        ) As distinct_records
    
    ";
        
    grafana.statPanel.new(
    title='Success Ratio Indicator',
    datasource='Azure SQL Server',
    description= "The Pipeline Success Ratio Indicator provides a clear metric to gauge the effectiveness of
    a data ingestion pipeline by comparing successful operations against failures and no new data. "
    ).addTarget(target=grafana.sql.target(rawSql=sqlQuery,format='table'))
    .addOverridesByFieldName(field='ratio',properties=[{id: 'unit', value: 'percent'}]
);

local DatasetIngestionHistory = 
    local sqlQuery = "      
    WITH 
        FilteredEvents AS (
            SELECT
                job_id,
                context_id,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                timestamp,
                metric_name,
                metric_value
            FROM
                [observability].[event]
            WHERE
                context_id IN (${context:sqlstring}+'')
                AND dataset_name in ($dataset_name)
                AND landing_zone IN ($landing_zone)
                AND project_name in ($project_name)
                AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                AND metric_name IN ('processing_started_date', 'processing_finished_date', 'processing_exit_code', 'rows_count', 'content_latest_date')
        ),
        MergedEvents AS (
            SELECT
                job_id,
                context_id,
                timestamp,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                [processing_started_date] AS processing_started_date_value,
                [processing_finished_date] AS processing_finished_date_value,
                [processing_exit_code] AS processing_exit_code_value,
                [content_latest_date] AS content_latest_date,
                [rows_count] AS rows_count_value
            FROM
                FilteredEvents
            PIVOT (
                MAX(metric_value)
                FOR metric_name IN ([processing_started_date], [processing_finished_date], [processing_exit_code], [rows_count], [content_latest_date])
            ) AS PivotTable
        ),
        Finalevents as(
            SELECT
                MAX(project_name) AS 'Application Source',
                MAX(dataset_name) AS 'Dataset',
                MAX(landing_zone) AS 'Zone',
                MAX(
                    CASE subscription_id
                    WHEN '6b4a5b3f-1015-42da-a46a-2890a5abed30' THEN 'IFM CORE PROD'
                    WHEN '2698ca5b-bf81-43fb-8fe2-f0e21bf068e5' THEN 'IFM CORE UAT/TEST'
                    WHEN '746ac5b9-70eb-4c76-bdf4-0664bfdff2ea' THEN 'IFM CORE DEV'
                    WHEN 'cf25f2a1-4d40-45af-bb81-87ec46112b3e' THEN 'SDX STA/PRD'
                    WHEN 'c0978b9d-b809-45f4-aa76-391ceb2cfdba' THEN 'SDX DEV/TEST'
                    WHEN '8eaa3d95-3cd2-49d8-b44a-7ea47a6fb58b' THEN 'SDX SILVER'
                    WHEN 'daf86ec1-725c-493f-bf09-a1f129b8588a' THEN 'SDX INT/UAT'
                    WHEN 'fea1e9f0-0e20-426f-906e-bc76e5a566ad' THEN 'SDX Sandbox'
                    WHEN '6e3fc63f-851b-4fc7-8499-48f6a9c28a65' THEN 'SDX Global Shared Services'
                    ELSE 'Undefined'
                    END
                ) AS 'Subscription',
                MAX(takeoff_zone) + ' to ' + MAX(landing_zone) AS 'Activity',
                case 
                    when sum(case when processing_exit_code_value not in (0,1,2) then 1 else 0 end) > 0 then 'Failed'
                    when count(case when processing_exit_code_value = 0 then 1 end) > 0 then 'Succeeded'
                    when count(case when processing_exit_code_value = 1 then 1 end) > 0 then 'No New Data'
                    when count(case when processing_exit_code_value = 2 then 1 end) > 0 then 'Skipped'
                End as 'Status',
                DATEADD(SECOND, MAX([timestamp]), '1970-01-01') AS 'Landed at',
                DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([timestamp]) AS 'Landed Since',
                DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([content_latest_date]) AS 'Freshness',
                CAST(MAX(processing_finished_date_value) - MAX(processing_started_date_value) AS BIGINT) AS 'Duration',
                ISNULL(CAST(CAST(MAX(rows_count_value) AS BIGINT) AS VARCHAR), 'N/A') AS 'Rows'
            FROM MergedEvents
            GROUP BY job_id, context_id
        )
        Select[Application Source], Dataset,Zone, Subscription, Activity, Status,[Landed at] from Finalevents
        where Status in ($status)
        ORDER BY[Landed at] DESC
    
    ";
   table.new(
    title = 'Data Ingestion History - Overview',
    datasource = 'Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Landed Since',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Freshness',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Duration',properties=[{id: 'unit', value: 's'}]
    ).addOverridesByFieldName(field='Status',properties=[{ id: 'custom.displayMode', value: 'color-text' },{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'text', value: null }]}},{id: 'mappings',value: [{type: 'value',options: {'Failed': {color: 'red','index': 3},'No New Data': {color: 'yellow','index': 1},'Running': {color: 'gray','index': 2},'Succeeded': {color: 'green','index': 0}}}]}]

);

local DatasetFreshnessWithinThreshold = 
    local sqlQuery = "
    WITH 
        FilteredEvents AS (
            SELECT
                job_id,
                context_id,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                timestamp,
                metric_name,
                metric_value
            FROM
                [observability].[event]
            WHERE
                context_id IN ('oss.coe.de.mms_delegate_supply_additives_history','oss.coe.de.mms_delegate_supply_additives_landing','oss.coe.de.mms_delegate_supply_additives_standardized','oss.coe.de.mms_delegate_supply_additives_transient','oss.coe.de.mms_delegate_supply_art2cat_history','oss.coe.de.mms_delegate_supply_art2cat_landing','oss.coe.de.mms_delegate_supply_art2cat_standardized','oss.coe.de.mms_delegate_supply_art2cat_transient','oss.coe.de.mms_delegate_supply_article2add_history','oss.coe.de.mms_delegate_supply_article2add_landing','oss.coe.de.mms_delegate_supply_article2add_standardized','oss.coe.de.mms_delegate_supply_artikel_history','oss.coe.de.mms_delegate_supply_artikel_landing','oss.coe.de.mms_delegate_supply_artikel_standardized','oss.coe.de.mms_delegate_supply_artikel_transient','oss.coe.de.mms_delegate_supply_besteller_history','oss.coe.de.mms_delegate_supply_besteller_landing','oss.coe.de.mms_delegate_supply_besteller_standardized','oss.coe.de.mms_delegate_supply_buchhalt_history','oss.coe.de.mms_delegate_supply_buchhalt_landing','oss.coe.de.mms_delegate_supply_buchhalt_standardized','oss.coe.de.mms_delegate_supply_buchhalt_transient','oss.coe.de.mms_delegate_supply_ccsgroup_history','oss.coe.de.mms_delegate_supply_ccsgroup_landing','oss.coe.de.mms_delegate_supply_ccsgroup_standardized','oss.coe.de.mms_delegate_supply_ccsgroup_transient','oss.coe.de.mms_delegate_supply_crvpoheader_history','oss.coe.de.mms_delegate_supply_crvpoheader_landing','oss.coe.de.mms_delegate_supply_crvpoheader_standardized','oss.coe.de.mms_delegate_supply_crvpoheader_transient','oss.coe.de.mms_delegate_supply_crvpoline_history','oss.coe.de.mms_delegate_supply_crvpoline_landing','oss.coe.de.mms_delegate_supply_crvpoline_standardized','oss.coe.de.mms_delegate_supply_crvpoline_transient','oss.coe.de.mms_delegate_supply_fcurrency_history','oss.coe.de.mms_delegate_supply_fcurrency_landing','oss.coe.de.mms_delegate_supply_fcurrency_standardized','oss.coe.de.mms_delegate_supply_fcurrency_transient','oss.coe.de.mms_delegate_supply_his_pricequote_history','oss.coe.de.mms_delegate_supply_his_pricequote_landing','oss.coe.de.mms_delegate_supply_his_pricequote_standardized','oss.coe.de.mms_delegate_supply_his_pricequote_transient','oss.coe.de.mms_delegate_supply_kostst_history','oss.coe.de.mms_delegate_supply_kostst_landing','oss.coe.de.mms_delegate_supply_kostst_standardized','oss.coe.de.mms_delegate_supply_kostst_transient','oss.coe.de.mms_delegate_supply_lager_history','oss.coe.de.mms_delegate_supply_lager_landing','oss.coe.de.mms_delegate_supply_lager_standardized','oss.coe.de.mms_delegate_supply_lfartkat_history','oss.coe.de.mms_delegate_supply_lfartkat_landing','oss.coe.de.mms_delegate_supply_lfartkat_standardized','oss.coe.de.mms_delegate_supply_lfartkat_transient','oss.coe.de.mms_delegate_supply_liefer_history','oss.coe.de.mms_delegate_supply_liefer_landing','oss.coe.de.mms_delegate_supply_liefer_standardized','oss.coe.de.mms_delegate_supply_liefer_transient','oss.coe.de.mms_delegate_supply_lieferpos_history','oss.coe.de.mms_delegate_supply_lieferpos_landing','oss.coe.de.mms_delegate_supply_lieferpos_standardized','oss.coe.de.mms_delegate_supply_lieferpos_transient','oss.coe.de.mms_delegate_supply_menuplan_history','oss.coe.de.mms_delegate_supply_menuplan_landing','oss.coe.de.mms_delegate_supply_menuplan_standardized','oss.coe.de.mms_delegate_supply_menuplanpos_history','oss.coe.de.mms_delegate_supply_menuplanpos_landing','oss.coe.de.mms_delegate_supply_menuplanpos_standardized','oss.coe.de.mms_delegate_supply_menuplanpos2add_history','oss.coe.de.mms_delegate_supply_menuplanpos2add_landing','oss.coe.de.mms_delegate_supply_menuplanpos2add_standardized','oss.coe.de.mms_delegate_supply_mplposlang_history','oss.coe.de.mms_delegate_supply_mplposlang_landing','oss.coe.de.mms_delegate_supply_mplposlang_standardized','oss.coe.de.mms_delegate_supply_mygcomponentgroup_history','oss.coe.de.mms_delegate_supply_mygcomponentgroup_landing','oss.coe.de.mms_delegate_supply_mygcomponentgroup_standardized','oss.coe.de.mms_delegate_supply_mygspltemplate_history','oss.coe.de.mms_delegate_supply_mygspltemplate_landing','oss.coe.de.mms_delegate_supply_mygspltemplate_standardized','oss.coe.de.mms_delegate_supply_orgclient_history','oss.coe.de.mms_delegate_supply_orgclient_landing','oss.coe.de.mms_delegate_supply_orgclient_standardized','oss.coe.de.mms_delegate_supply_orgclient_transient','oss.coe.de.mms_delegate_supply_pq2cat_history','oss.coe.de.mms_delegate_supply_pq2cat_landing','oss.coe.de.mms_delegate_supply_pq2cat_standardized','oss.coe.de.mms_delegate_supply_pq2cat_transient','oss.coe.de.mms_delegate_supply_pqtocc_history','oss.coe.de.mms_delegate_supply_pqtocc_landing','oss.coe.de.mms_delegate_supply_pqtocc_standardized','oss.coe.de.mms_delegate_supply_pqtocc_transient','oss.coe.de.mms_delegate_supply_pricequote_history','oss.coe.de.mms_delegate_supply_pricequote_landing','oss.coe.de.mms_delegate_supply_pricequote_standardized','oss.coe.de.mms_delegate_supply_pricequote_transient','oss.coe.de.mms_delegate_supply_pricequote2add _transient','oss.coe.de.mms_delegate_supply_pricequote2add_history','oss.coe.de.mms_delegate_supply_pricequote2add_landing','oss.coe.de.mms_delegate_supply_pricequote2add_standardized','oss.coe.de.mms_delegate_supply_pricequotefuture_history','oss.coe.de.mms_delegate_supply_pricequotefuture_landing','oss.coe.de.mms_delegate_supply_pricequotefuture_standardized','oss.coe.de.mms_delegate_supply_pricequotefuture_transient','oss.coe.de.mms_delegate_supply_prodeinh_history','oss.coe.de.mms_delegate_supply_prodeinh_landing','oss.coe.de.mms_delegate_supply_prodeinh_standardized','oss.coe.de.mms_delegate_supply_producer_history','oss.coe.de.mms_delegate_supply_producer_landing','oss.coe.de.mms_delegate_supply_producer_standardized','oss.coe.de.mms_delegate_supply_producer_transient','oss.coe.de.mms_delegate_supply_rec_category_history','oss.coe.de.mms_delegate_supply_rec_category_landing','oss.coe.de.mms_delegate_supply_rec_category_standardized','oss.coe.de.mms_delegate_supply_rec_category_transient','oss.coe.de.mms_delegate_supply_rec_explosion_history','oss.coe.de.mms_delegate_supply_rec_explosion_landing','oss.coe.de.mms_delegate_supply_rec_explosion_standardized','oss.coe.de.mms_delegate_supply_rechnung_history','oss.coe.de.mms_delegate_supply_rechnung_landing','oss.coe.de.mms_delegate_supply_rechnung_standardized','oss.coe.de.mms_delegate_supply_rechnung_transient','oss.coe.de.mms_delegate_supply_rechpos_history','oss.coe.de.mms_delegate_supply_rechpos_landing','oss.coe.de.mms_delegate_supply_rechpos_standardized','oss.coe.de.mms_delegate_supply_rechpos_transient','oss.coe.de.mms_delegate_supply_rez2menu_history','oss.coe.de.mms_delegate_supply_rez2menu_landing','oss.coe.de.mms_delegate_supply_rez2menu_standardized','oss.coe.de.mms_delegate_supply_rezeptur_history','oss.coe.de.mms_delegate_supply_rezeptur_landing','oss.coe.de.mms_delegate_supply_rezeptur_standardized','oss.coe.de.mms_delegate_supply_rezepturitem_history','oss.coe.de.mms_delegate_supply_rezepturitem_landing','oss.coe.de.mms_delegate_supply_rezepturitem_standardized','oss.coe.de.mms_delegate_supply_rezgruppe_history','oss.coe.de.mms_delegate_supply_rezgruppe_landing','oss.coe.de.mms_delegate_supply_rezgruppe_standardized','oss.coe.de.mms_delegate_supply_reztoart_history','oss.coe.de.mms_delegate_supply_reztoart_landing','oss.coe.de.mms_delegate_supply_reztoart_standardized','oss.coe.de.mms_delegate_supply_reztoart_transient','oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_history','oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_landing','oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_standardized','oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_transient','oss.coe.de.mms_delegate_supply_rvcostcenter_history','oss.coe.de.mms_delegate_supply_rvcostcenter_landing','oss.coe.de.mms_delegate_supply_rvcostcenter_standardized','oss.coe.de.mms_delegate_supply_rvcostcenter_transient','oss.coe.de.mms_delegate_supply_sparte_history','oss.coe.de.mms_delegate_supply_sparte_landing','oss.coe.de.mms_delegate_supply_sparte_standardized','oss.coe.de.mms_delegate_supply_sparte_transient','oss.coe.de.mms_delegate_supply_spartegr_history','oss.coe.de.mms_delegate_supply_spartegr_landing','oss.coe.de.mms_delegate_supply_spartegr_standardized','oss.coe.de.mms_delegate_supply_spartegr_transient','oss.coe.de.mms_delegate_supply_suppliergr_history','oss.coe.de.mms_delegate_supply_suppliergr_landing','oss.coe.de.mms_delegate_supply_suppliergr_standardized','oss.coe.de.mms_delegate_supply_suppliergr_transient','oss.coe.de.mms_delegate_supply_v_kategorie2_history','oss.coe.de.mms_delegate_supply_v_kategorie2_landing','oss.coe.de.mms_delegate_supply_v_kategorie2_standardized','oss.coe.de.mms_delegate_supply_v_kategorie2_transient','oss.coe.de.mms_delegate_supply_vendortocc_history','oss.coe.de.mms_delegate_supply_vendortocc_landing','oss.coe.de.mms_delegate_supply_vendortocc_standardized','oss.coe.de.mms_delegate_supply_vpckeinh_history','oss.coe.de.mms_delegate_supply_vpckeinh_landing','oss.coe.de.mms_delegate_supply_vpckeinh_standardized','oss.coe.de.mms_delegate_supply_warengruppe_history','oss.coe.de.mms_delegate_supply_warengruppe_landing','oss.coe.de.mms_delegate_supply_warengruppe_standardized','oss.coe.de.mms_delegate_supply_warengruppe_transient','oss.coe.glb.sap_fico_bkpf_be_history','oss.coe.glb.sap_fico_bkpf_be_landing','oss.coe.glb.sap_fico_bkpf_be_standardized','oss.coe.glb.sap_fico_bkpf_de_history','oss.coe.glb.sap_fico_bkpf_de_landing','oss.coe.glb.sap_fico_bkpf_de_standardized','oss.coe.glb.sap_fico_bkpf_nl_history','oss.coe.glb.sap_fico_bkpf_nl_landing','oss.coe.glb.sap_fico_bkpf_nl_standardized','oss.coe.glb.sap_fico_bkpf_se_fi_history','oss.coe.glb.sap_fico_bkpf_se_fi_landing','oss.coe.glb.sap_fico_bkpf_se_fi_standardized','oss.coe.glb.sap_fico_bseg_be_history','oss.coe.glb.sap_fico_bseg_be_landing','oss.coe.glb.sap_fico_bseg_be_standardized','oss.coe.glb.sap_fico_bseg_de_history','oss.coe.glb.sap_fico_bseg_de_landing','oss.coe.glb.sap_fico_bseg_de_standardized','oss.coe.glb.sap_fico_bseg_nl_history','oss.coe.glb.sap_fico_bseg_nl_landing','oss.coe.glb.sap_fico_bseg_nl_standardized','oss.coe.glb.sap_fico_bseg_se_fi_history','oss.coe.glb.sap_fico_bseg_se_fi_landing','oss.coe.glb.sap_fico_bseg_se_fi_standardized','oss.coe.glb.sap_fico_t052u_history','oss.coe.glb.sap_fico_t052u_landing','oss.coe.glb.sap_fico_t052u_standardized'+'')
                AND dataset_name  in ($dataset_name)
                AND project_name  in ($project_name)
                AND metric_name IN ('processing_started_date', 'processing_finished_date', 'processing_exit_code', 'rows_count', 'content_latest_date')
        ),
        MergedEvents AS (
            SELECT
                job_id,
                context_id,
                timestamp,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                [processing_started_date] AS processing_started_date_value,
                [processing_finished_date] AS processing_finished_date_value,
                [processing_exit_code] AS processing_exit_code_value,
                [content_latest_date] AS content_latest_date,
                [rows_count] AS rows_count_value
            FROM
                FilteredEvents
            PIVOT (
                MAX(metric_value)
                FOR metric_name IN ([processing_started_date], [processing_finished_date], [processing_exit_code], [rows_count], [content_latest_date])
            ) AS PivotTable
        ),
        Finalevents as(
            SELECT
                MAX(project_name) AS 'Application Source',
                MAX(dataset_name) AS 'Dataset',
                MAX(landing_zone) AS 'Zone',
                MAX(
                    CASE subscription_id
                    WHEN '6b4a5b3f-1015-42da-a46a-2890a5abed30' THEN 'IFM CORE PROD'
                    WHEN '2698ca5b-bf81-43fb-8fe2-f0e21bf068e5' THEN 'IFM CORE UAT/TEST'
                    WHEN '746ac5b9-70eb-4c76-bdf4-0664bfdff2ea' THEN 'IFM CORE DEV'
                    WHEN 'cf25f2a1-4d40-45af-bb81-87ec46112b3e' THEN 'SDX STA/PRD'
                    WHEN 'c0978b9d-b809-45f4-aa76-391ceb2cfdba' THEN 'SDX DEV/TEST'
                    WHEN '8eaa3d95-3cd2-49d8-b44a-7ea47a6fb58b' THEN 'SDX SILVER'
                    WHEN 'daf86ec1-725c-493f-bf09-a1f129b8588a' THEN 'SDX INT/UAT'
                    WHEN 'fea1e9f0-0e20-426f-906e-bc76e5a566ad' THEN 'SDX Sandbox'
                    WHEN '6e3fc63f-851b-4fc7-8499-48f6a9c28a65' THEN 'SDX Global Shared Services'
                    ELSE 'Undefined'
                    END
                ) AS 'Subscription',
                MAX(takeoff_zone) + ' to ' + MAX(landing_zone) AS 'Activity',
                case 
                    when sum(case when processing_exit_code_value not in (0,1,2) then 1 else 0 end) > 0 then 'Failed'
                    when count(case when processing_exit_code_value = 0 then 1 end) > 0 then 'Succeeded'
                    when count(case when processing_exit_code_value = 1 then 1 end) > 0 then 'No New Data'
                    when count(case when processing_exit_code_value = 2 then 1 end) > 0 then 'Skipped'
                End as 'Status',
                DATEADD(SECOND, MAX([timestamp]), '1970-01-01') AS 'Landed at',
                DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([timestamp]) AS 'Landed Since',
                DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([content_latest_date]) AS 'Freshness',
                CAST(MAX(processing_finished_date_value) - MAX(processing_started_date_value) AS BIGINT) AS 'Duration',
                ISNULL(CAST(CAST(MAX(rows_count_value) AS BIGINT) AS VARCHAR), 'N/A') AS 'Rows'
            FROM MergedEvents
            GROUP BY job_id, context_id
        ),
        Eventsdata as(
            Select [Application Source] as ApplicationSource, Dataset,Zone, Subscription, Activity, Status,[Landed at] as LandedAt,[Landed Since] as LandedSince,[Freshness] as Freshness, Duration,[Rows] as IngestedRows from Finalevents
            where Status in ('Succeeded','Failed','No New Data','Running','Skipped')
        ),
        finaldata as (select
            ApplicationSource ,
            Dataset,
            case
                   when count(case when Activity = 'landing to history' and status = 'succeeded' then 1 end) >= 1
                   and count(case when Activity = 'history to standardized' and status = 'succeeded' then 1 end) >= 1
                then 'OK'        
                else 'NOT OK'
            end as [Overall Status],
            Subscription as [Datalake Location],
            case
                when count(case when Activity = 'landing to history' and status = 'succeeded' then 1 end) >= 1
                then 'OK'
                else 'NOT OK'
            end as [Bronze History Status],
            case
                when count(case when Activity = 'history to standardized' and status = 'succeeded' then 1 end) >= 1                    
        then 'OK'
                else 'NOT OK'
            end as [Bronze Standardized Status],    
            max(case
                when Activity = 'landing to history' then LandedAt
                end)
        as [Pipe Line Execution StartTime],
            max(case
                when Activity = 'history to standardized' then LandedAt
                end)
        as [Pipe Line Execution EndTime],
 
            datediff(second,
            min(case
                when Activity = 'landing to history' then LandedAt
                end),current_timestamp
            ) as [Pipe Line Executed Since],
            max(Freshness) as Freshness,
            datediff(second,
            min(case when Activity = 'landing to history' then landedAt end),
            max(case when Activity = 'history to standardized' then landedAt end)
           ) as 'Total Execution Time',
           convert(Date, LandedAt) as executedDate
        From Eventsdata
        group by ApplicationSource,
            Dataset,
            subscription,
            convert(Date, LandedAt)
        ),
        RankedData as
        (
            select  ApplicationSource,
                    Dataset,
                    [Datalake Location],
                    executedDate,
                    case
                    when executedDate < getdate()
                    then DatedIff(second,max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                        else
                        DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Overall Refresh Status],
                    case when executedDate < getdate()
                then DatedIff(second, max([Pipe Line Execution StartTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    else
                    DatedIff(second, max([Pipe Line Execution StartTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Bronze History Refresh Status],
                case when executedDate < getdate()
                then DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    else
                    DatedIff(second,max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Bronze Standardized Refresh Status],
                row_number() over (partition by ApplicationSource, Dataset order by executedDate desc) as rownum,
                    [Pipe Line Execution EndTime],
                [Pipe Line Execution StartTime],
                [Pipe Line Executed Since],
                    Freshness,
                    [Total Execution Time],
                case when Dataset in ('buchhalt', 'rechpos', 'rechnung', 'rvbookedreceiptwithpositions', 'crvpoline', 'crvpoheader', 'pricequotefuture', 'pricequote') then 604800
                     when Dataset in ('bkpf_be', 'bkpf_de', 'bkpf_nl', 'bkpf_se_fi', 'bseg_be', 'bseg_de', 'bseg_nl', 'bseg_se_fi', 't052u') then 604800
                     when Dataset not in ('buchhalt', 'rechpos', 'rechnung', 'rvbookedreceiptwithpositions', 'crvpoline', 'crvpoheader', 'pricequotefuture', 'pricequote') and ApplicationSource = 'oss.coe.de.mms_delegate_supply' and MONTH(GETDATE()) in (1,3,5,7,8,10,12) then 2678400
                     when Dataset not in ('buchhalt', 'rechpos', 'rechnung', 'rvbookedreceiptwithpositions', 'crvpoline', 'crvpoheader', 'pricequotefuture', 'pricequote') and ApplicationSource = 'oss.coe.de.mms_delegate_supply' and MONTH(GETDATE()) not in (1,3,5,7,8,10,12) then 2592000
                else 86400
            end as [Freshness Threshold]
        from finalData
            where  [Overall Status] = 'OK'
        )
        select ApplicationSource,
            Dataset,
            [Freshness Threshold] as 'Threshold',
            [Overall Refresh Status] as 'Freshness Refresh Status',
            [Bronze History Refresh Status],
            [Bronze Standardized Refresh Status],
            [Pipe Line Execution StartTime],
            [Pipe Line Execution EndTime],
            Freshness,
            ([Freshness Threshold] - [Overall Refresh Status]) AS Differenceintime,
			CASE
				WHEN ([Freshness Threshold] - [Overall Refresh Status]) < 0 THEN 1
				WHEN ([Freshness Threshold] - [Overall Refresh Status]) > 0 THEN 2
				ELSE 0
			END AS Colour_Code
        from RankedData
        where  rownum = 1 and ([Freshness Threshold] - [Overall Refresh Status]) > 0
        order by executedDate desc
    ";
   table.new(
    title = 'Dataset Freshness [Within Threshold] - Tabular View',
    datasource = 'Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Pipe Line Execution StartTime',properties=[{id: 'unit', value: 's'},{id: 'custom.width',value: 180}]
    ).addOverridesByFieldName(field='Pipe Line Execution EndTime',properties=[{id: 'unit', value: 's'},{id: 'custom.width',value: 180}]
    ).addOverridesByFieldName(field='ApplicationSource',properties=[{id: 'custom.width',value: 240}]
    ).addOverridesByFieldName(field='Dataset',properties=[{id: 'custom.width',value: 170}]
    ).addOverridesByFieldName(field='Threshold',properties=[{id: 'unit', value: 'dtdurations'},{id: 'custom.width',value: 100}]
    ).addOverridesByFieldName(field='Freshness Refresh Status',properties=[{id: 'unit',value: "s"},{id: 'custom.width',value: 100}]
    ).addOverridesByFieldName(field='Colour_Code',properties=[{id: 'custom.cellOptions',value: {type: 'color-background', applyToRow: true}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'green',value: null},{color: 'light-orange',value: 0},{color: 'light-red',value: 1},{color: 'super-light-green',value: 2}]}},{id: 'custom.hidden', value: true}]
    ).addOverridesByFieldName(field='Differenceintime',properties=[{id: 'custom.hidden',value: true}]
    ).addOverridesByFieldName(field='Freshness',properties=[{id: 'custom.hidden',value: true}]
    ).addOverridesByFieldName(field='Bronze History Refresh Status',properties=[{id: 'unit',value: "s"},{id: 'custom.width',value: 100}]
    ).addOverridesByFieldName(field='Bronze Standardized Refresh Status',properties=[{id: 'unit',value: "s"},{id: 'custom.width',value: 100}]
);

local DatasetFreshnessOutOfThreshold = 
    local sqlQuery = "
    WITH 
        FilteredEvents AS (
            SELECT
                job_id,
                context_id,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                timestamp,
                metric_name,
                metric_value
            FROM
                [observability].[event]
            WHERE
                context_id IN ('oss.coe.de.mms_delegate_supply_additives_history','oss.coe.de.mms_delegate_supply_additives_landing','oss.coe.de.mms_delegate_supply_additives_standardized','oss.coe.de.mms_delegate_supply_additives_transient','oss.coe.de.mms_delegate_supply_art2cat_history','oss.coe.de.mms_delegate_supply_art2cat_landing','oss.coe.de.mms_delegate_supply_art2cat_standardized','oss.coe.de.mms_delegate_supply_art2cat_transient','oss.coe.de.mms_delegate_supply_article2add_history','oss.coe.de.mms_delegate_supply_article2add_landing','oss.coe.de.mms_delegate_supply_article2add_standardized','oss.coe.de.mms_delegate_supply_artikel_history','oss.coe.de.mms_delegate_supply_artikel_landing','oss.coe.de.mms_delegate_supply_artikel_standardized','oss.coe.de.mms_delegate_supply_artikel_transient','oss.coe.de.mms_delegate_supply_besteller_history','oss.coe.de.mms_delegate_supply_besteller_landing','oss.coe.de.mms_delegate_supply_besteller_standardized','oss.coe.de.mms_delegate_supply_buchhalt_history','oss.coe.de.mms_delegate_supply_buchhalt_landing','oss.coe.de.mms_delegate_supply_buchhalt_standardized','oss.coe.de.mms_delegate_supply_buchhalt_transient','oss.coe.de.mms_delegate_supply_ccsgroup_history','oss.coe.de.mms_delegate_supply_ccsgroup_landing','oss.coe.de.mms_delegate_supply_ccsgroup_standardized','oss.coe.de.mms_delegate_supply_ccsgroup_transient','oss.coe.de.mms_delegate_supply_crvpoheader_history','oss.coe.de.mms_delegate_supply_crvpoheader_landing','oss.coe.de.mms_delegate_supply_crvpoheader_standardized','oss.coe.de.mms_delegate_supply_crvpoheader_transient','oss.coe.de.mms_delegate_supply_crvpoline_history','oss.coe.de.mms_delegate_supply_crvpoline_landing','oss.coe.de.mms_delegate_supply_crvpoline_standardized','oss.coe.de.mms_delegate_supply_crvpoline_transient','oss.coe.de.mms_delegate_supply_fcurrency_history','oss.coe.de.mms_delegate_supply_fcurrency_landing','oss.coe.de.mms_delegate_supply_fcurrency_standardized','oss.coe.de.mms_delegate_supply_fcurrency_transient','oss.coe.de.mms_delegate_supply_his_pricequote_history','oss.coe.de.mms_delegate_supply_his_pricequote_landing','oss.coe.de.mms_delegate_supply_his_pricequote_standardized','oss.coe.de.mms_delegate_supply_his_pricequote_transient','oss.coe.de.mms_delegate_supply_kostst_history','oss.coe.de.mms_delegate_supply_kostst_landing','oss.coe.de.mms_delegate_supply_kostst_standardized','oss.coe.de.mms_delegate_supply_kostst_transient','oss.coe.de.mms_delegate_supply_lager_history','oss.coe.de.mms_delegate_supply_lager_landing','oss.coe.de.mms_delegate_supply_lager_standardized','oss.coe.de.mms_delegate_supply_lfartkat_history','oss.coe.de.mms_delegate_supply_lfartkat_landing','oss.coe.de.mms_delegate_supply_lfartkat_standardized','oss.coe.de.mms_delegate_supply_lfartkat_transient','oss.coe.de.mms_delegate_supply_liefer_history','oss.coe.de.mms_delegate_supply_liefer_landing','oss.coe.de.mms_delegate_supply_liefer_standardized','oss.coe.de.mms_delegate_supply_liefer_transient','oss.coe.de.mms_delegate_supply_lieferpos_history','oss.coe.de.mms_delegate_supply_lieferpos_landing','oss.coe.de.mms_delegate_supply_lieferpos_standardized','oss.coe.de.mms_delegate_supply_lieferpos_transient','oss.coe.de.mms_delegate_supply_menuplan_history','oss.coe.de.mms_delegate_supply_menuplan_landing','oss.coe.de.mms_delegate_supply_menuplan_standardized','oss.coe.de.mms_delegate_supply_menuplanpos_history','oss.coe.de.mms_delegate_supply_menuplanpos_landing','oss.coe.de.mms_delegate_supply_menuplanpos_standardized','oss.coe.de.mms_delegate_supply_menuplanpos2add_history','oss.coe.de.mms_delegate_supply_menuplanpos2add_landing','oss.coe.de.mms_delegate_supply_menuplanpos2add_standardized','oss.coe.de.mms_delegate_supply_mplposlang_history','oss.coe.de.mms_delegate_supply_mplposlang_landing','oss.coe.de.mms_delegate_supply_mplposlang_standardized','oss.coe.de.mms_delegate_supply_mygcomponentgroup_history','oss.coe.de.mms_delegate_supply_mygcomponentgroup_landing','oss.coe.de.mms_delegate_supply_mygcomponentgroup_standardized','oss.coe.de.mms_delegate_supply_mygspltemplate_history','oss.coe.de.mms_delegate_supply_mygspltemplate_landing','oss.coe.de.mms_delegate_supply_mygspltemplate_standardized','oss.coe.de.mms_delegate_supply_orgclient_history','oss.coe.de.mms_delegate_supply_orgclient_landing','oss.coe.de.mms_delegate_supply_orgclient_standardized','oss.coe.de.mms_delegate_supply_orgclient_transient','oss.coe.de.mms_delegate_supply_pq2cat_history','oss.coe.de.mms_delegate_supply_pq2cat_landing','oss.coe.de.mms_delegate_supply_pq2cat_standardized','oss.coe.de.mms_delegate_supply_pq2cat_transient','oss.coe.de.mms_delegate_supply_pqtocc_history','oss.coe.de.mms_delegate_supply_pqtocc_landing','oss.coe.de.mms_delegate_supply_pqtocc_standardized','oss.coe.de.mms_delegate_supply_pqtocc_transient','oss.coe.de.mms_delegate_supply_pricequote_history','oss.coe.de.mms_delegate_supply_pricequote_landing','oss.coe.de.mms_delegate_supply_pricequote_standardized','oss.coe.de.mms_delegate_supply_pricequote_transient','oss.coe.de.mms_delegate_supply_pricequote2add _transient','oss.coe.de.mms_delegate_supply_pricequote2add_history','oss.coe.de.mms_delegate_supply_pricequote2add_landing','oss.coe.de.mms_delegate_supply_pricequote2add_standardized','oss.coe.de.mms_delegate_supply_pricequotefuture_history','oss.coe.de.mms_delegate_supply_pricequotefuture_landing','oss.coe.de.mms_delegate_supply_pricequotefuture_standardized','oss.coe.de.mms_delegate_supply_pricequotefuture_transient','oss.coe.de.mms_delegate_supply_prodeinh_history','oss.coe.de.mms_delegate_supply_prodeinh_landing','oss.coe.de.mms_delegate_supply_prodeinh_standardized','oss.coe.de.mms_delegate_supply_producer_history','oss.coe.de.mms_delegate_supply_producer_landing','oss.coe.de.mms_delegate_supply_producer_standardized','oss.coe.de.mms_delegate_supply_producer_transient','oss.coe.de.mms_delegate_supply_rec_category_history','oss.coe.de.mms_delegate_supply_rec_category_landing','oss.coe.de.mms_delegate_supply_rec_category_standardized','oss.coe.de.mms_delegate_supply_rec_category_transient','oss.coe.de.mms_delegate_supply_rec_explosion_history','oss.coe.de.mms_delegate_supply_rec_explosion_landing','oss.coe.de.mms_delegate_supply_rec_explosion_standardized','oss.coe.de.mms_delegate_supply_rechnung_history','oss.coe.de.mms_delegate_supply_rechnung_landing','oss.coe.de.mms_delegate_supply_rechnung_standardized','oss.coe.de.mms_delegate_supply_rechnung_transient','oss.coe.de.mms_delegate_supply_rechpos_history','oss.coe.de.mms_delegate_supply_rechpos_landing','oss.coe.de.mms_delegate_supply_rechpos_standardized','oss.coe.de.mms_delegate_supply_rechpos_transient','oss.coe.de.mms_delegate_supply_rez2menu_history','oss.coe.de.mms_delegate_supply_rez2menu_landing','oss.coe.de.mms_delegate_supply_rez2menu_standardized','oss.coe.de.mms_delegate_supply_rezeptur_history','oss.coe.de.mms_delegate_supply_rezeptur_landing','oss.coe.de.mms_delegate_supply_rezeptur_standardized','oss.coe.de.mms_delegate_supply_rezepturitem_history','oss.coe.de.mms_delegate_supply_rezepturitem_landing','oss.coe.de.mms_delegate_supply_rezepturitem_standardized','oss.coe.de.mms_delegate_supply_rezgruppe_history','oss.coe.de.mms_delegate_supply_rezgruppe_landing','oss.coe.de.mms_delegate_supply_rezgruppe_standardized','oss.coe.de.mms_delegate_supply_reztoart_history','oss.coe.de.mms_delegate_supply_reztoart_landing','oss.coe.de.mms_delegate_supply_reztoart_standardized','oss.coe.de.mms_delegate_supply_reztoart_transient','oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_history','oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_landing','oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_standardized','oss.coe.de.mms_delegate_supply_rvbookedreceiptwithpositions_transient','oss.coe.de.mms_delegate_supply_rvcostcenter_history','oss.coe.de.mms_delegate_supply_rvcostcenter_landing','oss.coe.de.mms_delegate_supply_rvcostcenter_standardized','oss.coe.de.mms_delegate_supply_rvcostcenter_transient','oss.coe.de.mms_delegate_supply_sparte_history','oss.coe.de.mms_delegate_supply_sparte_landing','oss.coe.de.mms_delegate_supply_sparte_standardized','oss.coe.de.mms_delegate_supply_sparte_transient','oss.coe.de.mms_delegate_supply_spartegr_history','oss.coe.de.mms_delegate_supply_spartegr_landing','oss.coe.de.mms_delegate_supply_spartegr_standardized','oss.coe.de.mms_delegate_supply_spartegr_transient','oss.coe.de.mms_delegate_supply_suppliergr_history','oss.coe.de.mms_delegate_supply_suppliergr_landing','oss.coe.de.mms_delegate_supply_suppliergr_standardized','oss.coe.de.mms_delegate_supply_suppliergr_transient','oss.coe.de.mms_delegate_supply_v_kategorie2_history','oss.coe.de.mms_delegate_supply_v_kategorie2_landing','oss.coe.de.mms_delegate_supply_v_kategorie2_standardized','oss.coe.de.mms_delegate_supply_v_kategorie2_transient','oss.coe.de.mms_delegate_supply_vendortocc_history','oss.coe.de.mms_delegate_supply_vendortocc_landing','oss.coe.de.mms_delegate_supply_vendortocc_standardized','oss.coe.de.mms_delegate_supply_vpckeinh_history','oss.coe.de.mms_delegate_supply_vpckeinh_landing','oss.coe.de.mms_delegate_supply_vpckeinh_standardized','oss.coe.de.mms_delegate_supply_warengruppe_history','oss.coe.de.mms_delegate_supply_warengruppe_landing','oss.coe.de.mms_delegate_supply_warengruppe_standardized','oss.coe.de.mms_delegate_supply_warengruppe_transient','oss.coe.glb.sap_fico_bkpf_be_history','oss.coe.glb.sap_fico_bkpf_be_landing','oss.coe.glb.sap_fico_bkpf_be_standardized','oss.coe.glb.sap_fico_bkpf_de_history','oss.coe.glb.sap_fico_bkpf_de_landing','oss.coe.glb.sap_fico_bkpf_de_standardized','oss.coe.glb.sap_fico_bkpf_nl_history','oss.coe.glb.sap_fico_bkpf_nl_landing','oss.coe.glb.sap_fico_bkpf_nl_standardized','oss.coe.glb.sap_fico_bkpf_se_fi_history','oss.coe.glb.sap_fico_bkpf_se_fi_landing','oss.coe.glb.sap_fico_bkpf_se_fi_standardized','oss.coe.glb.sap_fico_bseg_be_history','oss.coe.glb.sap_fico_bseg_be_landing','oss.coe.glb.sap_fico_bseg_be_standardized','oss.coe.glb.sap_fico_bseg_de_history','oss.coe.glb.sap_fico_bseg_de_landing','oss.coe.glb.sap_fico_bseg_de_standardized','oss.coe.glb.sap_fico_bseg_nl_history','oss.coe.glb.sap_fico_bseg_nl_landing','oss.coe.glb.sap_fico_bseg_nl_standardized','oss.coe.glb.sap_fico_bseg_se_fi_history','oss.coe.glb.sap_fico_bseg_se_fi_landing','oss.coe.glb.sap_fico_bseg_se_fi_standardized','oss.coe.glb.sap_fico_t052u_history','oss.coe.glb.sap_fico_t052u_landing','oss.coe.glb.sap_fico_t052u_standardized'+'')
                AND dataset_name  in ($dataset_name)
                AND project_name  in ($project_name)
                AND metric_name IN ('processing_started_date', 'processing_finished_date', 'processing_exit_code', 'rows_count', 'content_latest_date')
        ),
        MergedEvents AS (
            SELECT
                job_id,
                context_id,
                timestamp,
                project_name,
                dataset_name,
                landing_zone,
                subscription_id,
                takeoff_zone,
                [processing_started_date] AS processing_started_date_value,
                [processing_finished_date] AS processing_finished_date_value,
                [processing_exit_code] AS processing_exit_code_value,
                [content_latest_date] AS content_latest_date,
                [rows_count] AS rows_count_value
            FROM
                FilteredEvents
            PIVOT (
                MAX(metric_value)
                FOR metric_name IN ([processing_started_date], [processing_finished_date], [processing_exit_code], [rows_count], [content_latest_date])
            ) AS PivotTable
        ),
        Finalevents as(
            SELECT
                MAX(project_name) AS 'Application Source',
                MAX(dataset_name) AS 'Dataset',
                MAX(landing_zone) AS 'Zone',
                MAX(
                    CASE subscription_id
                    WHEN '6b4a5b3f-1015-42da-a46a-2890a5abed30' THEN 'IFM CORE PROD'
                    WHEN '2698ca5b-bf81-43fb-8fe2-f0e21bf068e5' THEN 'IFM CORE UAT/TEST'
                    WHEN '746ac5b9-70eb-4c76-bdf4-0664bfdff2ea' THEN 'IFM CORE DEV'
                    WHEN 'cf25f2a1-4d40-45af-bb81-87ec46112b3e' THEN 'SDX STA/PRD'
                    WHEN 'c0978b9d-b809-45f4-aa76-391ceb2cfdba' THEN 'SDX DEV/TEST'
                    WHEN '8eaa3d95-3cd2-49d8-b44a-7ea47a6fb58b' THEN 'SDX SILVER'
                    WHEN 'daf86ec1-725c-493f-bf09-a1f129b8588a' THEN 'SDX INT/UAT'
                    WHEN 'fea1e9f0-0e20-426f-906e-bc76e5a566ad' THEN 'SDX Sandbox'
                    WHEN '6e3fc63f-851b-4fc7-8499-48f6a9c28a65' THEN 'SDX Global Shared Services'
                    ELSE 'Undefined'
                    END
                ) AS 'Subscription',
                MAX(takeoff_zone) + ' to ' + MAX(landing_zone) AS 'Activity',
                case 
                    when sum(case when processing_exit_code_value not in (0,1,2) then 1 else 0 end) > 0 then 'Failed'
                    when count(case when processing_exit_code_value = 0 then 1 end) > 0 then 'Succeeded'
                    when count(case when processing_exit_code_value = 1 then 1 end) > 0 then 'No New Data'
                    when count(case when processing_exit_code_value = 2 then 1 end) > 0 then 'Skipped'
                End as 'Status',
                DATEADD(SECOND, MAX([timestamp]), '1970-01-01') AS 'Landed at',
                DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([timestamp]) AS 'Landed Since',
                DATEDIFF(s, '19700101', GETUTCDATE()) - MAX([content_latest_date]) AS 'Freshness',
                CAST(MAX(processing_finished_date_value) - MAX(processing_started_date_value) AS BIGINT) AS 'Duration',
                ISNULL(CAST(CAST(MAX(rows_count_value) AS BIGINT) AS VARCHAR), 'N/A') AS 'Rows'
            FROM MergedEvents
            GROUP BY job_id, context_id
        ),
        Eventsdata as(
            Select [Application Source] as ApplicationSource, Dataset,Zone, Subscription, Activity, Status,[Landed at] as LandedAt,[Landed Since] as LandedSince,[Freshness] as Freshness, Duration,[Rows] as IngestedRows from Finalevents
            where Status in ('Succeeded','Failed','No New Data','Running','Skipped')
        ),
        finaldata as (select
            ApplicationSource ,
            Dataset,
            case
                   when count(case when Activity = 'landing to history' and status = 'succeeded' then 1 end) >= 1
                   and count(case when Activity = 'history to standardized' and status = 'succeeded' then 1 end) >= 1
                then 'OK'        
                else 'NOT OK'
            end as [Overall Status],
            Subscription as [Datalake Location],
            case
                when count(case when Activity = 'landing to history' and status = 'succeeded' then 1 end) >= 1
                then 'OK'
                else 'NOT OK'
            end as [Bronze History Status],
            case
                when count(case when Activity = 'history to standardized' and status = 'succeeded' then 1 end) >= 1                    
        then 'OK'
                else 'NOT OK'
            end as [Bronze Standardized Status],    
            max(case
                when Activity = 'landing to history' then LandedAt
                end)
        as [Pipe Line Execution StartTime],
            max(case
                when Activity = 'history to standardized' then LandedAt
                end)
        as [Pipe Line Execution EndTime],
 
            datediff(second,
            min(case
                when Activity = 'landing to history' then LandedAt
                end),current_timestamp
            ) as [Pipe Line Executed Since],
            max(Freshness) as Freshness,
            datediff(second,
            min(case when Activity = 'landing to history' then landedAt end),
            max(case when Activity = 'history to standardized' then landedAt end)
           ) as 'Total Execution Time',
           convert(Date, LandedAt) as executedDate
        From Eventsdata
        group by ApplicationSource,
            Dataset,
            subscription,
            convert(Date, LandedAt)
        ),
        RankedData as
        (
            select  ApplicationSource,
                    Dataset,
                    [Datalake Location],
                    executedDate,
                    case
                    when executedDate < getdate()
                    then DatedIff(second,max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                        else
                        DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Overall Refresh Status],
                    case when executedDate < getdate()
                then DatedIff(second, max([Pipe Line Execution StartTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    else
                    DatedIff(second, max([Pipe Line Execution StartTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Bronze History Refresh Status],
                case when executedDate < getdate()
                then DatedIff(second, max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    else
                    DatedIff(second,max([Pipe Line Execution EndTime]) over (partition by ApplicationSource, Dataset), GetDate())
                    end as [Bronze Standardized Refresh Status],
                row_number() over (partition by ApplicationSource, Dataset order by executedDate desc) as rownum,
                    [Pipe Line Execution EndTime],
                [Pipe Line Execution StartTime],
                [Pipe Line Executed Since],
                    Freshness,
                    [Total Execution Time],
                case when Dataset in ('buchhalt', 'rechpos', 'rechnung', 'rvbookedreceiptwithpositions', 'crvpoline', 'crvpoheader', 'pricequotefuture', 'pricequote') then 604800
                     when Dataset in ('bkpf_be', 'bkpf_de', 'bkpf_nl', 'bkpf_se_fi', 'bseg_be', 'bseg_de', 'bseg_nl', 'bseg_se_fi', 't052u') then 604800
                     when Dataset not in ('buchhalt', 'rechpos', 'rechnung', 'rvbookedreceiptwithpositions', 'crvpoline', 'crvpoheader', 'pricequotefuture', 'pricequote') and ApplicationSource = 'oss.coe.de.mms_delegate_supply' and MONTH(GETDATE()) in (1,3,5,7,8,10,12) then 2678400
                     when Dataset not in ('buchhalt', 'rechpos', 'rechnung', 'rvbookedreceiptwithpositions', 'crvpoline', 'crvpoheader', 'pricequotefuture', 'pricequote') and ApplicationSource = 'oss.coe.de.mms_delegate_supply' and MONTH(GETDATE()) not in (1,3,5,7,8,10,12) then 2592000
                else 86400
            end as [Freshness Threshold]
        from finalData
            where  [Overall Status] = 'OK'
        )
        select ApplicationSource,
            Dataset,
            [Freshness Threshold] as 'Threshold',
            [Overall Refresh Status] as 'Freshness Refresh Status',
            [Bronze History Refresh Status],
            [Bronze Standardized Refresh Status],
            [Pipe Line Execution StartTime],
            [Pipe Line Execution EndTime],
            Freshness,
            ([Freshness Threshold] - [Overall Refresh Status]) AS Differenceintime,
			CASE
				WHEN ([Freshness Threshold] - [Overall Refresh Status]) < 0 THEN 1
				WHEN ([Freshness Threshold] - [Overall Refresh Status]) > 0 THEN 2
				ELSE 0
			END AS Colour_Code
        from RankedData
        where  rownum = 1 and ([Freshness Threshold] - [Overall Refresh Status]) < 0
        order by executedDate desc
    ";
   table.new(
    title = 'Dataset Freshness [Out Of Threshold] - Tabular View',
    datasource = 'Azure SQL Server'
    ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
    ).addOverridesByFieldName(field='Pipe Line Execution StartTime',properties=[{id: 'unit', value: 's'},{id: 'custom.width',value: 180}]
    ).addOverridesByFieldName(field='Pipe Line Execution EndTime',properties=[{id: 'unit', value: 's'},{id: 'custom.width',value: 180}]
    ).addOverridesByFieldName(field='ApplicationSource',properties=[{id: 'custom.width',value: 240}]
    ).addOverridesByFieldName(field='Dataset',properties=[{id: 'custom.width',value: 170}]
    ).addOverridesByFieldName(field='Threshold',properties=[{id: 'unit', value: 'dtdurations'},{id: 'custom.width',value: 100}]
    ).addOverridesByFieldName(field='Freshness Refresh Status',properties=[{id: 'unit',value: "s"},{id: 'custom.width',value: 100}]
    ).addOverridesByFieldName(field='Colour_Code',properties=[{id: 'custom.cellOptions',value: {type: 'color-background', applyToRow: true}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'green',value: null},{color: 'light-orange',value: 0},{color: 'light-red',value: 1},{color: 'super-light-green',value: 2}]}},{id: 'custom.hidden', value: true}]
    ).addOverridesByFieldName(field='Differenceintime',properties=[{id: 'custom.hidden',value: true}]
    ).addOverridesByFieldName(field='Freshness',properties=[{id: 'custom.hidden',value: true}]
    ).addOverridesByFieldName(field='Bronze History Refresh Status',properties=[{id: 'unit',value: "s"},{id: 'custom.width',value: 100}]
    ).addOverridesByFieldName(field='Bronze Standardized Refresh Status',properties=[{id: 'unit',value: "s"},{id: 'custom.width',value: 100}]
);

local getDashboardAlertsPanel(alertName) =
grafana.alertlist.new(
title = std.format("Dashboard Alerts Observability %s",alertName),
onlyAlertsOnDashboard = true,
)
+{
'options' :
    {
    "dashboardAlerts": false,
    "sortOrder" : 1,
    "maxItems": 20,
    "alertName": alertName,
    "stateFilter": {
          "firing": true,
          "pending": true,
          "noData": true,
          "normal": true,
          "error": true
        }
    }
}
+ {
"sortOrder": 1,
};

//row sections

grafana.dashboard.new(
  title='Supply',
  refresh='5m',
  time_from='now-7d',
  editable=true,
  timezone='utc',
  schemaVersion=37,
  uid='21EiXdsfddd15Z')

//global filters
.addTemplate(projectTemplate)
.addTemplate(datasetTemplate)
.addTemplate(stageTemplate)
.addTemplate(statusTemplate)
.addTemplate(HidedContext)

//panels
.addPanel(panel = generatePanelCount,gridPos={h:3,w:8,x:0,y:0})
.addPanel(panel = SLOPanel,gridPos={h:3,w:8,x:8,y:0})
.addPanel(panel = generateSLIPanel,gridPos={h:3,w:8,x:16,y:0})

.addPanel(generateIngestionPipelinesByCondition('Succeeded', 'green', 0),gridPos={h: 3, w: 6, x: 0, y: 5})
.addPanel(generateIngestionPipelinesByCondition('No New Data', 'yellow', 1),gridPos={h: 3, w: 6, x: 6, y: 5})
.addPanel(generateIngestionPipelinesByCondition('Failed', 'red', -1),gridPos={h: 3, w: 6, x: 12, y: 5})
.addPanel(panel = GenerateSuccessRatio,gridPos={h: 3, w: 6, x: 18, y: 5})

.addPanel(grafana.text.new(mode='markdown',content='Succeeded: Count of Ingestion Pipelines Run Successfully during the selected period for the selected dataset(s).',transparent= true),gridPos={h: 3, w: 6, x: 0, y: 6})
.addPanel(grafana.text.new(mode='markdown',content='No New Data: Count of Ingestion Pipelines triggered but no data pushed from Integration during the selected period for the selected dataset(s).',transparent= true),gridPos={h: 3, w: 6, x: 6, y: 6})
.addPanel(grafana.text.new(mode='markdown',content='Failed: Count of Ingestion Pipelines Failed during the selected period for the selected dataset(s).',transparent= true),gridPos={h: 3, w: 6, x: 12, y: 6})
.addPanel(grafana.text.new(mode='markdown',content='Success ratio: It is calculated as ((Success+ No New Data)/ (success + No New Data + Failed)) * 100.',transparent= true),gridPos={h: 3, w: 6, x: 18, y: 6})


.addPanel(
    row.new(
        title="Tracking Data Freshness",
        showTitle=true,
        collapse=true
    ).addPanel(panel = DatasetFreshnessWithinThreshold,gridPos={h:10,w:12,x:0,y:10}
    ).addPanel(panel = DatasetFreshnessOutOfThreshold,gridPos={h:10,w:12,x:12,y:10}),
    gridPos={h:1,w:24,x:0,y:10}
)

.addPanel(
    row.new(
        title="Dataset Ingestion History Overview",
        showTitle=true,
        collapse=true
    ).addPanel(panel = DatasetIngestionHistory,gridPos={h:10,w:24,x:0,y:25}),
    gridPos={h:1,w:24,x:0,y:20}
)
.addPanel(
    row.new(
        title="Dashboard Alerts",
        showTitle=true,
        collapse=true
    ).addPanel(panel = getDashboardAlertsPanel('supply'),gridPos={h:10,w:24,x:0,y:25}),
    gridPos={h:1,w:24,x:0,y:30}
)
