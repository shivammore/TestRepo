local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;
local tablePanel = grafana.tablePanel;
local logPanel =  grafana.logPanel;

############################ Dashboard Varaibles ############################

local projectName = "Innovorder";

local ProjectAppinsightsSubscription = tmpl.new(
    name='sub_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>AppinsightsSubscription'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Subscription of Application Insight",
    hide=true
);
local ProjectAppinsightsRG =  tmpl.new(
    name='rg_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>AppinsightsRG'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Resource Group of Application Insight",
    hide=true
);
local ProjectAppinsights =  tmpl.new(
    name='appinsights_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>Appinsights'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Application Insights",
    hide=true
);
local ProjectAppInsightsNamespace =  tmpl.custom(
    name='ns_appinsights',
    current='microsoft.insights/components',
    query='microsoft.insights/components',
    includeAll=false,
    multi=false,
    label="Project: AppInsights Namespace",
    hide=true
);
local ProjectServiceBus =  tmpl.new(
    name='resource_servicebus',
    datasource='Azure SQL Server',
    query="Select value from grafana.APIMetadataInformation where field = 'SoForceServiceBusName'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: ServiceBus",
    hide=true
);
local ProjectServiceBusNamespace =  tmpl.custom(
    name='ns_servicebus',
    current='microsoft.servicebus/namespaces',
    query='microsoft.servicebus/namespaces',
    includeAll=false,
    multi=false,
    label="Project: ServiceBus Namespace",
    hide=true
);
local ProjectLogAnalyticsWorkspace =  tmpl.new(
    name='loganalyticsworkspace_project',
    datasource='Azure SQL Server',
    query="Select value from grafana.APIMetadataInformation where field = 'SoForceLogAnalyticsWorkspace'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Log Analytics Workspace",
    hide=true
);
local LoganalyticsworkspaceNamespaceTemplate =  tmpl.custom(
    name='ns_loganalyticsworkspace',
    current='Microsoft.OperationalInsights/workspaces',
    query='Microsoft.OperationalInsights/workspaces',
    includeAll=false,
    multi=false,
    hide=true
);
############################ Dashboard filters ############################

local template_API =  tmpl.custom(
    name='apiName',
    current='all',
    query='brandcdm,brandinfo,brandsevicemapping,localbrand,masterbrand,selectedservicelevel,servicelevel,services',
    includeAll=true,
    multi=true,
    label='API Name'
);

local template_country =  tmpl.new(
    name='country',
    datasource='AzureMonitor',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Country',
    queryType='Azure Log Analytics',
    query=|||
            requests
            | where isnotempty(customDimensions)
            | extend country = tostring(customDimensions["Request-x-country-of-origin"])
            | where isnotempty(country)
            | distinct country
            | order by country asc
        |||,
    resources=[
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ]
);

local template_region =  tmpl.new(
    name='region',
    datasource='AzureMonitor',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Region',
    queryType='Azure Log Analytics',
    query=|||
            requests
            | where isnotempty(customDimensions)
            | extend region = tostring(customDimensions.["Request-x-region"])
            | where isnotempty(region)
            | distinct region
            | order by region asc
        |||,
    resources=[
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ]
);

local template_source =  tmpl.new(
    name='source',
    datasource='AzureMonitor',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Source App ID',
    queryType='Azure Log Analytics',
    query=|||
            requests
            | where isnotempty(customDimensions)
            | extend source = tostring(customDimensions.["Request-x-source-application-id"])
            | where isnotempty(source)
            | distinct source
            | order by source asc
        |||,
    resources=[
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ]
);

local template_correlationid = tmpl.text(
    name='correlationid',
	label='Correlation Id'
);

local template_functiontype =  tmpl.custom(
    name='functiontype',
    current='all',
    query='cdm_http_trigger,servicebus_topic_brand_trigger,soforce_cdm_transform',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Function Type'
);

local template_functionApp =  tmpl.new(
    name='functionApp',
    datasource='Azure SQL Server',
    query="SELECT value FROM grafana.APIMetadataInformation WHERE field IN ('SoForceFunctionApp1', 'SoForceFunctionApp2', 'SoForceFunctionApp3')",
    refresh='load',
    includeAll=true,
    multi=true,
    label="Function App",
);

local Source_functionApp =  tmpl.new(
    name='Source_functionApp',
    datasource='Azure SQL Server',
    query="SELECT value FROM grafana.APIMetadataInformation WHERE field IN ('SoForceFunctionApp1')",
    refresh='load',
    hide=true,
    label="Source Function App",
);

local Target_functionApp =  tmpl.new(
    name='Target_functionApp',
    datasource='Azure SQL Server',
    query="SELECT value FROM grafana.APIMetadataInformation WHERE field IN ('SoForceFunctionApp2')",
    refresh='load',
    hide=true,
    label="Target Function App",
);

############################ Summary panels ############################

local TotalRequestsPanels = statPanel.new(
  title="Total Ingested Records",
  datasource='-- Mixed --',
  description="This panel displays the total number of ingested records received across all services, including APIM, Azure Functions, Service Bus, Landing Zone,  History Zone and Standardized Zone, based on the selected timestamp.",
  graphMode='none',
  reducerFunction='sum',
  orientation="vertical",
  justifyMode= "center",
  transparent=true
)
.addThresholds(
  steps=[
    { "color": "red", "value": 0 },
    { "color": "green", "value": 1 },
  ]
)
.addTarget({
  refId: "A",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ],
    query: |||
      let correlationIds = split("$correlationid", ",");
      requests
      | where $__timeFilter(timestamp)
      | where success == "True"
      | where tostring(customDimensions.["Request-x-region"]) in ($region)
      | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
      | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
      | where tostring(customDimensions["API Name"]) has_any ($apiName)
      | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
      | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
      | where isnotempty(idempotencykey)
      | summarize latest_timestamp = max(timestamp) by idempotencykey
      | summarize ['API Requests'] = count()
    |||
  }
})
.addTarget({
  refId: "B",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"
    ],
    query: |||
      let correlationIds = split("$correlationid", ",");
      AppTraces
      | where $__timeFilter(TimeGenerated)
      | where AppRoleName in ($functionApp)
      | where OperationName in ($functiontype)
      | where isnotempty(Message)
      | extend msgjson = parse_json(Message)
      | extend rawMessage = tostring(msgjson["message"])
      | extend correlationId = extract(@"x-correlation-id=([^,]+)", 1, rawMessage)
      | where isempty("$correlationid") or correlationId in~ (correlationIds)
      | where isnotempty(correlationId)
      | extend idempotencykey = extract(@"x-idempotency-key=([^,]+)", 1, rawMessage)
      | where isnotempty(idempotencykey)
      | extend countryOrigin = extract(@"x-country-of-origin=([^,]+)", 1, rawMessage)
      | extend region = extract(@"x-region=([^,]+)", 1, rawMessage)
      | extend sourceAppId = extract(@"x-source-application-id=([^,]+)", 1, rawMessage)
      | where countryOrigin in ($country)
      | where region in ($region)
      | where sourceAppId in ($source)
      | extend statuscode = extract(@"statusCode=([^,]+)", 1, rawMessage)
      | where statuscode == "200"
      | summarize latest_timestamp = max(TimeGenerated) by idempotencykey
      | summarize ['Azure Function Requests'] = count()
    |||
  }
})
.addTarget({
  refId: "C",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Monitor",
  azureMonitor: {
    aggregation: "Total",
    alias: "Service Bus Requests",
    allowedTimeGrainsMs: [
      60000,
      300000,
      900000,
      1800000,
      3600000,
      21600000,
      43200000,
      86400000
    ],
    dimensionFilters: [
      {
        dimension: "EntityName",
        filters: [ "brand-topic" ],
        operator: "eq"
      }
    ],
    metricName: "IncomingMessages",
    metricNamespace: "$ns_servicebus",
    region: "",
    resources: [
      {
        metricNamespace: "$ns_servicebus",
        region: "",
        resourceGroup: "$rg_project",
        resourceName: "$resource_servicebus",
        subscription: "$sub_project"
      }
    ],
    timeGrain: "auto"
  },
  subscription: "$sub_project"
})
.addTarget({
  refId: "D",
  datasource: {
    type: "datasource",
    uid: "AzureSQLServer"
  },
  rawMode: true,
  format: "table",
  rawQuery: true,
  rawSql: "SELECT
            SUM(MaxRows) AS [Landing Zone Requests]
            FROM (
                SELECT
                    REPLACE(dataset_name, '_', '') AS dataset,
                    MAX(metric_value) AS MaxRows
                FROM [observability].[event]
                WHERE REPLACE(dataset_name, '_', '') IN ($apiName)
                    AND landing_zone IN ('landing')
                    AND metric_name = 'rows_count'
                    AND event_type = 'processingfinished'
                    AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                GROUP BY REPLACE(dataset_name, '_', '')
            ) AS sub",
  query: {
    alias: "Landing Requests",
    format: "table",
    rawEditor: true,
    rawQuery: true,
    rawSql: "SELECT
            SUM(MaxRows) AS [Landing Zone Requests]
            FROM (
                SELECT
                    REPLACE(dataset_name, '_', '') AS dataset,
                    MAX(metric_value) AS MaxRows
                FROM [observability].[event]
                WHERE REPLACE(dataset_name, '_', '') IN ($apiName)
                    AND landing_zone IN ('landing')
                    AND metric_name = 'rows_count'
                    AND event_type = 'processingfinished'
                    AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                GROUP BY REPLACE(dataset_name, '_', '')
            ) AS sub"
  }
})
.addTarget({
  refId: "E",
  datasource: {
    type: "datasource",
    uid: "AzureSQLServer"
  },
  rawMode: true,
  format: "table",
  rawQuery: true,
  rawSql: "SELECT
            SUM(max_record_count) AS [History Zone Requests]
            FROM (
              SELECT
              REPLACE(dataset_name, '_', '') AS dataset,
              MAX(record_count) AS max_record_count
              FROM [observability].[soforce_custom_slo_metrics]
              WHERE REPLACE(dataset_name, '_', '') IN ($apiName)
                  AND ingestion_layer IN ('history')
                  AND record_date BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                  AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') AS DATE)
              GROUP BY REPLACE(dataset_name, '_', '')
          ) AS sub",
  query: {
    alias: "History Requests",
    format: "table",
    rawEditor: true,
    rawQuery: true,
    rawSql: "SELECT
            SUM(max_record_count) AS [History Zone Requests]
            FROM (
              SELECT
              REPLACE(dataset_name, '_', '') AS dataset,
              MAX(record_count) AS max_record_count
              FROM [observability].[soforce_custom_slo_metrics]
              WHERE REPLACE(dataset_name, '_', '') IN ($apiName)
                  AND ingestion_layer IN ('history')
                  AND record_date BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                  AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') AS DATE)
              GROUP BY REPLACE(dataset_name, '_', '')
          ) AS sub"
  }
})
.addTarget({
  refId: "F",
  datasource: {
    type: "datasource",
    uid: "Azure SQL Server"
  },
  rawMode: true,
  format: "table",
  rawQuery: true,
  rawSql: "SELECT
            SUM(max_record_count) AS [Standardized Zone Requests]
            FROM (
              SELECT
              REPLACE(dataset_name, '_', '') AS dataset,
              MAX(record_count) AS max_record_count
              FROM [observability].[soforce_custom_slo_metrics]
              WHERE REPLACE(dataset_name, '_', '') IN ($apiName)
                  AND ingestion_layer IN ('standardized')
                  AND record_date BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                  AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') AS DATE)
              GROUP BY REPLACE(dataset_name, '_', '')
          ) AS sub",
  query: {
    alias: "Standardized Zone Requests",
    format: "table",
    rawEditor: true,
    rawQuery: true,
    rawSql: "SELECT
              SUM(max_record_count) AS [Standardized Zone Requests]
              FROM (
                SELECT
                REPLACE(dataset_name, '_', '') AS dataset,
                MAX(record_count) AS max_record_count
                FROM [observability].[soforce_custom_slo_metrics]
                WHERE REPLACE(dataset_name, '_', '') IN ($apiName)
                    AND ingestion_layer IN ('standardized')
                    AND record_date BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                    AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                GROUP BY REPLACE(dataset_name, '_', '')
            ) AS sub"
  }
})
.addOverridesByFieldName(
  field='Service Bus Requests',
  properties=[
    { id: 'unit' },
  ]
);

local TrankingSource = grafana.tablePanel.new(
  title="Tracking APIM to Standardized Zone Difference",
  datasource='-- Mixed --',
  description="This table panel displays the details of tracking APIM to standardized zone difference.",
)
.addTarget({
  refId: "B",
  datasource: {
    type: "datasource",
    uid: "Azure SQL Server"
  },
  rawMode: true,
  format: "table",
  rawQuery: true,
  rawSql: "
      select FORMAT(record_date, 'yyyy-MM-dd') as [TransactionDate], max(project_name) as [Application Source],
      'Source to Target Match' as [Threshold],
      sum(distinct record_count) as [Standardized Record Count] from observability.[soforce_custom_slo_metrics] where
      record_date BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') AS DATE)
              AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') AS DATE)
              and REPLACE(dataset_name, '_', '') IN ($apiName)
              and ingestion_layer = 'standardized'
      group by FORMAT(record_date, 'yyyy-MM-dd')
      order by FORMAT(record_date, 'yyyy-MM-dd') desc",
    query: {
    alias: "Standardized Requests",
    format: "table",
    rawEditor: true,
    rawQuery: true,
    rawSql: "
      select FORMAT(record_date, 'yyyy-MM-dd') as [TransactionDate], max(project_name) as [Application Source],
      'Source to Target Match' as [Threshold],
      sum(distinct record_count) as [Standardized Record Count] from observability.[soforce_custom_slo_metrics] where
      record_date BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') AS DATE)
              AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') AS DATE)
              and REPLACE(dataset_name, '_', '') IN ($apiName)
              and ingestion_layer = 'standardized'
      group by FORMAT(record_date, 'yyyy-MM-dd')
      order by FORMAT(record_date, 'yyyy-MM-dd') desc",
      }
})
.addTarget({
  refId: "B",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ],
    query: |||
      let correlationIds = split("$correlationid", ",");
      requests
      | where $__timeFilter(timestamp)
      | where success == "True"
      | where tostring(customDimensions.["Request-x-region"]) in ($region)
      | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
      | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
      | where tostring(customDimensions["API Name"]) has_any ($apiName)
      | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
      | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
      | where isnotempty(idempotencykey)
      | summarize latest_timestamp = max(timestamp) by idempotencykey
      | summarize APIM_Record_Count = count(), stamp = max(latest_timestamp) by bin(latest_timestamp, 1d)
      | project TransactionDate = format_datetime(stamp, "yyyy-MM-dd"), APIM_Record_Count
      | order by TransactionDate desc
    |||
  }
})
.addOverridesByFieldName(field='Difference',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'red',value: ''}]}},{id: 'mappings',value: [{options: {from: 0,result: {color: 'green',index: 1},to: 0}, type: 'range'}]}])
  {
  transformations: [
    {
      id: 'joinByField',
      options: {
        byField: 'TransactionDate',
        mode: 'inner',
      },
    },
    {
      id: 'calculateField',
      options: {
        alias: 'Difference',
        binary: {
          left: 'APIM_Record_Count',
          operator: '-',
          right: 'Standardized Record Count',
        },
        mode: 'binary',
        reduce: {
          reducer: 'sum',
        },
      },
    },
  ],
}
{   
  options: {
    showHeader: true,
    cellHeight: "sm",
    footer: {
    show: false,
    reducer: [
      "sum"
    ],
    countRows: false,
    fields: ""
    }
  }
};

local TrankingSourceAPIMtoAZ = grafana.tablePanel.new(
  title="Tracking APIM to Azure Function Difference",
  datasource='-- Mixed --',
  description="This table panel displays the details of tracking APIM to azure function difference.",
)
.addTarget({
  refId: "A",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ],
    query: |||
      let correlationIds = split("$correlationid", ",");
      requests
      | where $__timeFilter(timestamp)
      | where success == "True"
      | where tostring(customDimensions.["Request-x-region"]) in ($region)
      | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
      | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
      | where tostring(customDimensions["API Name"]) has_any ("localbrand","masterbrand","servicelevel","selectedservicelevel")
      | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
      | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
      | where isnotempty(idempotencykey)
      | summarize latest_timestamp = max(timestamp) by idempotencykey
      | summarize APIM_Record_Count = count(), stamp = max(latest_timestamp) by bin(latest_timestamp, 1d)
      | project TransactionDate = format_datetime(stamp, "yyyy-MM-dd"), APIM_Record_Count
      | order by TransactionDate desc
    |||
  }
})
.addTarget({
  refId: "B",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"
    ],
    query: |||
      let correlationIds = split("$correlationid", ",");
      AppTraces
      | where $__timeFilter(TimeGenerated)
      | where AppRoleName in ($functionApp)
      | where OperationName in ($functiontype)
      | where isnotempty(Message)
      | extend msgjson = parse_json(Message)
      | extend rawMessage = tostring(msgjson["message"])
      | extend correlationId = extract(@"x-correlation-id=([^,]+)", 1, rawMessage)
      | where isempty("$correlationid") or correlationId in~ (correlationIds)
      | where isnotempty(correlationId)
      | extend idempotencykey = extract(@"x-idempotency-key=([^,]+)", 1, rawMessage)
      | where isnotempty(idempotencykey)
      | extend countryOrigin = extract(@"x-country-of-origin=([^,]+)", 1, rawMessage)
      | extend region = extract(@"x-region=([^,]+)", 1, rawMessage)
      | extend sourceAppId = extract(@"x-source-application-id=([^,]+)", 1, rawMessage)
      | where countryOrigin in ($country)
      | where region in ($region)
      | where sourceAppId in ($source)
      | extend statuscode = extract(@"statusCode=([^,]+)", 1, rawMessage)
      | where statuscode == "200"
      | summarize latest_timestamp = max(TimeGenerated) by idempotencykey
      | summarize Azure_Function_record_count = count(), stamp = max(latest_timestamp) by bin(latest_timestamp, 1d)
      | project TransactionDate = format_datetime(latest_timestamp, "yyyy-MM-dd"), Azure_Function_record_count
      | order by TransactionDate desc
    |||
  }
})
.addOverridesByFieldName(field='Difference',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'red',value: ''}]}},{id: 'mappings',value: [{options: {from: 0,result: {color: 'green',index: 1},to: 0}, type: 'range'}]}])
  {
  transformations: [
    {
      id: 'joinByField',
      options: {
        byField: 'TransactionDate',
        mode: 'inner',
      },
    },
    {
      id: 'calculateField',
      options: {
        alias: 'Difference',
        binary: {
          left: 'APIM_Record_Count',
          operator: '-',
          right: 'Azure_Function_record_count',
        },
        mode: 'binary',
        reduce: {
          reducer: 'sum',
        },
      },
    },
  ],
}
{   
  options: {
    showHeader: true,
    cellHeight: "sm",
    footer: {
    show: false,
    reducer: [
      "sum"
    ],
    countRows: false,
    fields: ""
    }
  }
};

local TrankingSourcetoTarget = grafana.tablePanel.new(
  title="Tracking Azure Function Source to Target APIs Difference",
  datasource='-- Mixed --',
  description="This table panel displays the details of tracking azure function source to target APIs difference.",
)
.addTarget({
  refId: "A",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"
    ],
    query: |||
      let correlationIds = split("$correlationid", ",");
      AppTraces
      | where $__timeFilter(TimeGenerated)
      | where AppRoleName in ("${Source_functionApp}")
      | where isnotempty(Message)
      | extend msgjson = parse_json(Message)
      | extend rawMessage = tostring(msgjson["message"])
      | extend correlationId = extract(@"x-correlation-id=([^,]+)", 1, rawMessage)
      | where isempty("$correlationid") or correlationId in~ (correlationIds)
      | where isnotempty(correlationId)
      | extend idempotencykey = extract(@"x-idempotency-key=([^,]+)", 1, rawMessage)
      | where isnotempty(idempotencykey)
      | extend countryOrigin = extract(@"x-country-of-origin=([^,]+)", 1, rawMessage)
      | extend region = extract(@"x-region=([^,]+)", 1, rawMessage)
      | extend sourceAppId = extract(@"x-source-application-id=([^,]+)", 1, rawMessage)
      | where countryOrigin in ($country)
      | where region in ($region)
      | where sourceAppId in ($source)
      | summarize Source_Count = count(), stamp = max(TimeGenerated) by bin(TimeGenerated, 1d)
      | project TransactionDate = format_datetime(TimeGenerated, "yyyy-MM-dd"), Source_Count
      | order by TransactionDate desc
    |||
  }
})
.addTarget({
  refId: "B",
  datasource: {
    type: "datasource",
    uid: "AzureMonitor"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"
    ],
    query: |||
      let correlationIds = split("$correlationid", ",");
      AppTraces
      | where $__timeFilter(TimeGenerated)
      | where AppRoleName in ("${Target_functionApp}")
      | where isnotempty(Message)
      | extend msgjson = parse_json(Message)
      | extend rawMessage = tostring(msgjson["message"])
      | extend correlationId = extract(@"x-correlation-id=([^,]+)", 1, rawMessage)
      | where isempty("$correlationid") or correlationId in~ (correlationIds)
      | where isnotempty(correlationId)
      | extend idempotencykey = extract(@"x-idempotency-key=([^,]+)", 1, rawMessage)
      | where isnotempty(idempotencykey)
      | extend countryOrigin = extract(@"x-country-of-origin=([^,]+)", 1, rawMessage)
      | extend region = extract(@"x-region=([^,]+)", 1, rawMessage)
      | extend sourceAppId = extract(@"x-source-application-id=([^,]+)", 1, rawMessage)
      | where countryOrigin in ($country)
      | where region in ($region)
      | where sourceAppId in ($source)
      | summarize Target_Count = count(), stamp = max(TimeGenerated) by bin(TimeGenerated, 1d)
      | project TransactionDate = format_datetime(TimeGenerated, "yyyy-MM-dd"), Target_Count
      | order by TransactionDate desc
    |||
  }
})
.addOverridesByFieldName(field='Difference',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'red',value: ''}]}},{id: 'mappings',value: [{options: {from: 0,result: {color: 'green',index: 1},to: 0}, type: 'range'}]}])
  {
  transformations: [
    {
      id: 'joinByField',
      options: {
        byField: 'TransactionDate',
        mode: 'inner',
      },
    },
    {
      id: 'calculateField',
      options: {
        alias: 'Difference',
        binary: {
          left: 'Source_Count',
          operator: '-',
          right: 'Target_Count',
        },
        mode: 'binary',
        reduce: {
          reducer: 'sum',
        },
      },
    },
  ],
}
{   
  options: {
    showHeader: true,
    cellHeight: "sm",
    footer: {
    show: false,
    reducer: [
      "sum"
    ],
    countRows: false,
    fields: ""
    }
  }
};

############################ Status ############################

local ApimLastRequest = statPanel.new(
    title="APIM: Last Request",
    datasource='AzureMonitor',
    description="This panel displays the last request time send to APIM",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields="/.*/",
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | summarize tostring(format_datetime(max(timestamp),'yyyy-MM-dd HH:mm:ss'))
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/.*/"
      },
      graphMode: "none",
    }
};
local ApimLastSucessRequest = statPanel.new(
    title="APIM: Number of Successful Requests",
    datasource='AzureMonitor',
    description="This panel displays the number of successful requests in APIM",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where success == "True"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey
        | summarize Total_Success = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};
local ApimLastFailedRequest = statPanel.new(
    title="APIM: Number of Failed Requests",
    datasource='AzureMonitor',
    description="This panel displays the number of failed requests in APIM",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": null,
      },
  ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where success != "True"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey
        | summarize Total_Failed = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};

local AzfLastRun = statPanel.new(
    title="Azure Function: Last Run",
    datasource='AzureMonitor',
    description="This panel displays the last run time for Azure Function",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields="/.*/"
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        AppTraces
        | where $__timeFilter(TimeGenerated)
        | where AppRoleName in ($functionApp)
        | where OperationName in ($functiontype)
        | where isnotempty(Message)
        | extend msgjson = parse_json(Message)
        | extend rawMessage = tostring(msgjson["message"])
        | extend correlationId = extract(@"x-correlation-id=([^,]+)", 1, rawMessage)
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where isnotempty(correlationId)
        | extend idempotencykey = extract(@"x-idempotency-key=([^,]+)", 1, rawMessage)
        | where isnotempty(idempotencykey)
        | extend countryOrigin = extract(@"x-country-of-origin=([^,]+)", 1, rawMessage)
        | extend region = extract(@"x-region=([^,]+)", 1, rawMessage)
        | extend sourceAppId = extract(@"x-source-application-id=([^,]+)", 1, rawMessage)
        | where countryOrigin in ($country)
        | where region in ($region)
        | where sourceAppId in ($source)
        | summarize tostring(format_datetime(max(TimeGenerated),'yyyy-MM-dd HH:mm:ss'))
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"],
	resultFormat= 'logs'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/.*/"
      },
      graphMode: "none",
    }
};
local AzfLastSuccessRun = statPanel.new(
    title="Azure Function: Number of Successful Run",
    datasource='AzureMonitor',
    description="This panel displays the number of successful run in Azure Function",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        AppTraces
        | where $__timeFilter(TimeGenerated)
        | where AppRoleName in ($functionApp)
        | where OperationName in ($functiontype)
        | where isnotempty(Message)
        | extend msgjson = parse_json(Message)
        | extend rawMessage = tostring(msgjson["message"])
        | extend correlationId = extract(@"x-correlation-id=([^,]+)", 1, rawMessage)
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where isnotempty(correlationId)
        | extend idempotencykey = extract(@"x-idempotency-key=([^,]+)", 1, rawMessage)
        | where isnotempty(idempotencykey)
        | extend countryOrigin = extract(@"x-country-of-origin=([^,]+)", 1, rawMessage)
        | extend region = extract(@"x-region=([^,]+)", 1, rawMessage)
        | extend sourceAppId = extract(@"x-source-application-id=([^,]+)", 1, rawMessage)
        | where countryOrigin in ($country)
        | where region in ($region)
        | where sourceAppId in ($source)
        | extend statuscode = extract(@"statusCode=([^,]+)", 1, rawMessage)
        | where statuscode == "200"
        | summarize latest_timestamp = max(TimeGenerated) by idempotencykey
        | summarize Successcount = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};

local AzfLastFailedRun = statPanel.new(
    title="Azure Function: Number of Failed Run",
    datasource='AzureMonitor',
    description="This panel displays the number of failed run in Azure Function",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": null,
      }
  ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        AppTraces
        | where $__timeFilter(TimeGenerated)
        | where AppRoleName in ($functionApp)
        | where OperationName in ($functiontype)
        | where isnotempty(Message)
        | extend msgjson = parse_json(Message)
        | extend rawMessage = tostring(msgjson["message"])
        | extend correlationId = extract(@"x-correlation-id=([^,]+)", 1, rawMessage)
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where isnotempty(correlationId)
        | extend idempotencykey = extract(@"x-idempotency-key=([^,]+)", 1, rawMessage)
        | where isnotempty(idempotencykey)
        | extend countryOrigin = extract(@"x-country-of-origin=([^,]+)", 1, rawMessage)
        | extend region = extract(@"x-region=([^,]+)", 1, rawMessage)
        | extend sourceAppId = extract(@"x-source-application-id=([^,]+)", 1, rawMessage)
        | where countryOrigin in ($country)
        | where region in ($region)
        | where sourceAppId in ($source)
        | extend statuscode = extract(@"statusCode=([^,]+)", 1, rawMessage)
        | where statuscode != "200"
        | summarize latest_timestamp = max(TimeGenerated) by idempotencykey
        | summarize Failurecount = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};

local ServiceBusLastIncomingMessages = statPanel.new(
    title="ServiceBus: Last Incoming Messages",
    datasource='AzureMonitor',
    description="This panel displays the last incoming messages time for ServiceBus",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields='/^Time$/'
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='None',
    metricName='IncomingMessages',
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus",
    subscription="$sub_project",
    dimension="EntityName",
    dimensionFilters="brand-topic",
    dimensionOperator="eq",
    alias="Incoming Messages",
   )
).addTransformations([
		grafana.transformation.new(
      'filterByValue', 
      options={
        filters: [ 
          {
            config: {id: "equal",options: { value: 0  }}
          }
        ],
        match: "all",
        type: "exclude"
      }),
]) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};
local ServiceBusLastOutgoingMessages = statPanel.new(
    title="ServiceBus: Last Outgoing Messages",
    datasource='AzureMonitor',
    description="This panel displays the last outgoing messages time for ServiceBus",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields='/^Time$/'
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='None',
    metricName='OutgoingMessages',
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus",
    subscription="$sub_project",
    dimension="EntityName",
    dimensionFilters="brand-topic",
    dimensionOperator="eq",
    alias="Outgoing Messages",
   )
).addTransformations([
		grafana.transformation.new(
      'filterByValue', 
      options={
        filters: [ 
          {
            config: {id: "equal",options: { value: 0  }},
          }
        ],
        match: "all",
        type: "exclude"
      }),
]) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};

local ServiceBusUserErrors = statPanel.new(
    title="ServiceBus: User Errors",
    datasource='AzureMonitor',
    description="This panel displays the number of user errors in ServiceBus",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": null,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='Total',
    metricName='UserErrors',
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus",
    subscription="$sub_project",
    dimension="EntityName",
    dimensionFilters="brand-topic",
    dimensionOperator="eq",
    alias="User Errors",
   )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    },
};

local LandingLastSuccessIngestion =
  statPanel.new(
    title="Landing Zone: Last Successful Ingestion",
    fields='/^Time$/',
    datasource='Azure SQL Server',
    description="This panel displays the last successful ingestion time for landing zone",
    ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT
              top(1)
              DATEADD(SECOND, MAX([timestamp]), '1970-01-01')
          FROM
              [observability].[event]
          WHERE REPLACE(dataset_name, '_', '') in ($apiName)
            AND landing_zone IN ('landing')
            AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
            AND metric_name IN ('processing_finished_date')
            ",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};
local LandingSuccessCount =
  statPanel.new(
    title="Landing Zone: Total Successful Records",
    datasource='Azure SQL Server',
    description="This panel displays the total number of successful records in landing zone",
    colorMode='background'
    ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT
            SUM(MaxRows) AS [Landing Zone Requests]
            FROM (
                SELECT
                    REPLACE(dataset_name, '_', '') AS dataset,
                    MAX(metric_value) AS MaxRows
                FROM [observability].[event]
                WHERE REPLACE(dataset_name, '_', '') IN ($apiName)
                    AND landing_zone IN ('landing')
                    AND metric_name = 'rows_count'
                    AND event_type = 'processingfinished'
                    AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
                GROUP BY REPLACE(dataset_name, '_', '')
            ) AS sub",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: ""
      },
      graphMode: "none",
    }
};

local HistoryLastSuccessIngestion =
  statPanel.new(
    title="History Zone: Last Successful Ingestion",
    fields='/^TransactionDate$/',
    datasource='Azure SQL Server',
    description="This panel displays the last successful ingestion time for history zone",
    ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT
              top(1)
              MAX(record_date) AS [TransactionDate]
          FROM
              [observability].[soforce_custom_slo_metrics]
          WHERE
            REPLACE(dataset_name, '_', '') in ($apiName)
            AND ingestion_layer IN ('history')
            AND record_date BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                  AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') AS DATE)",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: "/^TransactionDate$/"
      },
      graphMode: "none",
    }
};
local HistorySuccessCount =
  statPanel.new(
    title="History Zone: Total Successful Records",
    datasource='Azure SQL Server',
    description="This panel displays the total number of successful records in history zone",
    colorMode='background'
    ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT
            SUM(max_record_count) AS [History Zone Requests]
            FROM (
              SELECT
              REPLACE(dataset_name, '_', '') AS dataset,
              MAX(record_count) AS max_record_count
              FROM [observability].[soforce_custom_slo_metrics]
              WHERE REPLACE(dataset_name, '_', '') IN ($apiName)
                  AND ingestion_layer IN ('history')
                  AND record_date BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                  AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') AS DATE)
              GROUP BY REPLACE(dataset_name, '_', '')
          ) AS sub",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: ""
      },
      graphMode: "none",
    }
};

local StandardizedLastSuccessIngestion =
  statPanel.new(
    title="Standardized Zone: Last Successful Ingestion",
    fields='/^TransactionDate$/',
    datasource='Azure SQL Server',
    description="This panel displays the last successful ingestion time for standardized zone",
    ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT
              top(1)
              MAX(record_date) AS [TransactionDate]
          FROM
              [observability].[soforce_custom_slo_metrics]
          WHERE
            REPLACE(dataset_name, '_', '') in ($apiName)
            AND ingestion_layer IN ('standardized')
            AND record_date BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                  AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') AS DATE)",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: "/^TransactionDate$/"
      },
      graphMode: "none",
    }
};
local StandardizedSuccessCount =
  statPanel.new(
    title="Standardized Zone: Total Successful Records",
    datasource='Azure SQL Server',
    description="This panel displays the total number of successful records in standardized zone",
    colorMode='background'
    ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT
            SUM(max_record_count) AS [Standardized Zone Requests]
            FROM (
              SELECT
              REPLACE(dataset_name, '_', '') AS dataset,
              MAX(record_count) AS max_record_count
              FROM [observability].[soforce_custom_slo_metrics]
              WHERE REPLACE(dataset_name, '_', '') IN ($apiName)
                  AND ingestion_layer IN ('standardized')
                  AND record_date BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                  AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') AS DATE)
              GROUP BY REPLACE(dataset_name, '_', '')
          ) AS sub",
      format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: ""
      },
      graphMode: "none",
    }
};

local Status = row.new(title="Status", collapse=true)
    .addPanel(ApimLastRequest,gridPos={h: 3, w: 8, x: 0, y: 19})
    .addPanel(ApimLastSucessRequest,gridPos={h: 3, w: 8, x: 8, y: 19})
    .addPanel(ApimLastFailedRequest,gridPos={h: 3, w: 8, x: 16, y: 19})
    .addPanel(AzfLastRun,gridPos={h: 3, w: 8, x: 0, y: 22})
    .addPanel(AzfLastSuccessRun,gridPos={h: 3, w: 8, x: 8, y: 22})
    .addPanel(AzfLastFailedRun,gridPos={h: 3, w: 8, x: 16, y: 22})
    .addPanel(ServiceBusLastIncomingMessages,gridPos={h: 3, w: 8, x: 0, y: 25})
    .addPanel(ServiceBusLastOutgoingMessages,gridPos={h: 3, w: 8, x: 8, y: 25})
    .addPanel(ServiceBusUserErrors,gridPos={h: 3, w: 8, x: 16, y: 25})
    .addPanel(LandingLastSuccessIngestion,gridPos={h: 3, w: 12, x: 0, y: 28})
    .addPanel(LandingSuccessCount,gridPos={h: 3, w: 12, x: 12, y: 28})
    .addPanel(HistoryLastSuccessIngestion,gridPos={h: 3, w: 12, x: 0, y: 31})
    .addPanel(HistorySuccessCount,gridPos={h: 3, w: 12, x: 12, y: 31})
    .addPanel(StandardizedLastSuccessIngestion,gridPos={h: 3, w: 12, x: 0, y: 34})
    .addPanel(StandardizedSuccessCount,gridPos={h: 3, w: 12, x: 12, y: 34});

############################ APIM ############################

local ApiTotalRequests = grafana.graphPanel.new(
    title="Total API Requests",
    datasource='AzureMonitor',
    description="This panel displays the total number of requests in APIM using Timeseries",
    fill=0,
    points=true,
    pointradius=5,
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
      let correlationIds = split("$correlationid", ",");
      requests
      | where $__timeFilter(timestamp)
      | where isnotempty(customDimensions)
      | where customDimensions has "API Name"
      | where tostring(customDimensions.["Request-x-region"]) in ($region)
      | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
      | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
      | where tostring(customDimensions["API Name"]) has_any ($apiName)
      | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
      | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
      | extend lastpart = tostring(customDimensions["API Name"])
      | where isnotempty(idempotencykey)
      | summarize latest_timestamp = max(timestamp) by idempotencykey, lastpart
      | summarize totalrequests = count() by bin(latest_timestamp, 5m), lastpart
      | order by latest_timestamp asc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          __systemRef: "hideSeriesFrom",
          matcher: {
            id: "byNames",
            options: {
              mode: "exclude",
              names: [
                "totalrequests"
              ],
              prefix: "All except:",
              readOnly: true
            }
          },
          properties: [
            {
              id: "custom.hideFrom",
              value: {
                legend: false,
                tooltip: false,
                viz: true
              }
            }
          ]
        },
        {
          matcher: {
            id: "byName",
            options: "totalrequests"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "blue",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local ApiRequestNumberByAPIName = grafana.barChart.new(
    title="Requests by API Name",
    description='This panel displays the total number of requests by API name in APIM using barchart',
    datasource='AzureMonitor',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where isnotempty(customDimensions)
        | where customDimensions has "API Name"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | extend lastpart = tostring(customDimensions["API Name"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey, lastpart
        | summarize totalrequests = count() by lastpart
        | order by totalrequests desc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "totalrequests"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "blue",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local ApiRequests = grafana.graphPanel.new(
    title="Requests (Successful & Failed)",
    datasource='AzureMonitor',
    description="This panel displays the total number of requests in APIM using Timeseries",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | extend lastpart = tostring(customDimensions["API Name"])
        | where isnotempty(idempotencykey)
        | extend ResultType = iff(success == true, "success", "Failure")
        | summarize latest_timestamp = max(timestamp) by idempotencykey, lastpart, ResultType
        | summarize totalrequests = count() by ResultType, bin(latest_timestamp, 5m)
        | order by latest_timestamp asc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "totalrequests success"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "green",
                mode: "fixed"
              }
            }
          ]
        },
        {
          matcher: {
            id: "byName",
            options: "totalrequests Failure"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "red",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local ApiRequestByStatusCode = grafana.pieChartPanel.new(
    title="Request by Status Code",
    datasource='AzureMonitor',
    description="This panel displays the request by status code using pie chart",
    legendType="Right side",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests 
        | where $__timeFilter(timestamp)
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | extend lastpart = tostring(customDimensions["API Name"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey, resultCode 
        | summarize Count=count() by resultCode
        | evaluate pivot(resultCode, sum(Count))
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "right",
      calcs: [],
      values: [
          "value", "percent"
        ]
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "401"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "red",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local ApimLastFailedRequestTable = tablePanel.new(
    title="Last Failed APIM Events",
    datasource='AzureMonitor',
    description="This panel displays the table of failed requests of each timestamp with their resultCode, duration, API Name, RequestSize, Correlation ID and IdemopotencyKey in a table format",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where success == False
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) has_any ($apiName)
        | project timestamp, resultCode, duration, APIName=customDimensions["API Name"], RequestSize=customMeasurements.["Request Size"], CorrelationId=customDimensions.["Request-x-correlation-id"], IdempotencyKey=customDimensions.["Request-x-idempotency-key"]
        | order by timestamp desc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
){
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "APIName"
          },
          properties: [
            {
              id: "custom.width",
              value: 284
            }
          ]
        }
      ]
  }
};

local ApiLogs = logPanel.new(
    title="API Unique Idempotency Key Error logs",
    datasource='AzureMonitor',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
      let correlationIds = split("$correlationid", ",");
      requests
      | where $__timeFilter(timestamp)
      | where success == "False"
      | where customDimensions has "API Name"
      | where tostring(customDimensions.["Request-x-region"]) in ($region)
      | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
      | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
      | where tostring(customDimensions["API Name"]) has_any ($apiName)
      | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
      | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
      | where isnotempty(idempotencykey)
      | extend statuscode = resultCode
      | where statuscode != 200
      | order by timestamp desc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
);

local APIM = row.new(title="APIM", collapse=true)
    .addPanel(ApiTotalRequests,gridPos={h: 8, w: 24, x: 0, y: 10})
    .addPanel(ApiRequestNumberByAPIName,gridPos={h: 8, w: 24, x: 0, y: 18})
    .addPanel(ApiRequests,gridPos={h: 8, w: 24, x: 0, y: 26})
    .addPanel(ApiRequestByStatusCode,gridPos={h: 8, w: 24, x: 0, y: 32})
    .addPanel(ApimLastFailedRequestTable,gridPos={h: 8, w: 24, x: 0, y: 40})
    .addPanel(ApiLogs,gridPos={h: 8, w: 24, x: 0, y: 48});

############################ Azure Function ############################

local AZTotalRequests = grafana.graphPanel.new(
    title="Total Azure Function Requests",
    datasource='AzureMonitor',
    description="This panel displays the total number of requests in Azure Function using Timeseries",
    fill=0,
    points=true,
    pointradius=5,
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        AppTraces
        | where $__timeFilter(TimeGenerated)
        | where AppRoleName in ($functionApp)
        | where OperationName in ($functiontype)
        | where isnotempty(Message)
        | extend msgjson = parse_json(Message)
        | extend rawMessage = tostring(msgjson["message"])
        | extend correlationId = extract(@"x-correlation-id=([^,]+)", 1, rawMessage)
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where isnotempty(correlationId)
        | extend idempotencykey = extract(@"x-idempotency-key=([^,]+)", 1, rawMessage)
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(TimeGenerated) by idempotencykey
        | summarize totalrequests = count() by bin(latest_timestamp, 5m)
        | order by latest_timestamp asc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "totalrequests"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "blue",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local AZRequests = grafana.barChart.new(
    title="Run by day (Failed & Successful)",
    datasource='AzureMonitor',
    description="This panel displays the number of run by day",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        AppTraces
        | where $__timeFilter(TimeGenerated)
        | where AppRoleName in ($functionApp)
        | where OperationName in ($functiontype)
        | where isnotempty(Message)
        | extend msgjson = parse_json(Message)
        | extend rawMessage = tostring(msgjson["message"])
        | extend correlationId = extract(@"x-correlation-id=([^,]+)", 1, rawMessage)
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where isnotempty(correlationId)
        | extend idempotencykey = extract(@"x-idempotency-key=([^,]+)", 1, rawMessage)
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(TimeGenerated) by idempotencykey
        | summarize RunNumber=count() by format_datetime(latest_timestamp,'MM/dd/yyyy')
        | order by latest_timestamp asc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "totalrequests"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "blue",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local AZDuplicateSuccessRequest = tablePanel.new(
    title="Duplicate key by Day",
    datasource='AzureMonitor',
    description="This panel displays the duplicate key by day",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        AppTraces
        | where $__timeFilter(TimeGenerated)
        | where AppRoleName in ($functionApp)
        | where OperationName in ($functiontype)
        | where isnotempty(Message)
        | extend msgjson = parse_json(Message)
        | extend rawMessage = tostring(msgjson["message"])
        | extend correlationId = extract(@"x-correlation-id=([^,]+)", 1, rawMessage)
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where isnotempty(correlationId)
        | extend idempotencykey = extract(@"x-idempotency-key=([^,]+)", 1, rawMessage)
        | where isnotempty(idempotencykey)
        | summarize Count=count() by idempotencykey , format_datetime(TimeGenerated,'MM/dd/yyyy')
        | where Count > 1
        | order by TimeGenerated desc    
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"],
	resultFormat= 'logs'
  )
);

local AZRequestByStatusCode = grafana.pieChartPanel.new(
    title="Request by Status Code",
    datasource='AzureMonitor',
    description="This panel displays the request by status code using pie chart",
    legendType="Right side",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        AppTraces
        | where $__timeFilter(TimeGenerated)
        | where AppRoleName in ($functionApp)
        | where OperationName in ($functiontype)
        | where isnotempty(Message)
        | extend msgjson = parse_json(Message)
        | extend rawMessage = tostring(msgjson["message"])
        | extend correlationId = extract(@"x-correlation-id=([^,]+)", 1, rawMessage)
        | where isempty("$correlationid") or correlationId in~ (correlationIds)
        | where isnotempty(correlationId)
        | extend idempotencykey = extract(@"x-idempotency-key=([^,]+)", 1, rawMessage)
        | where isnotempty(idempotencykey)
        | extend statuscode = extract(@"statusCode=([^,]+)", 1, rawMessage)
        | extend ResultType = iff(statuscode == 200, "success", "Failure")
        | summarize latest_timestamp = max(TimeGenerated) by idempotencykey, statuscode
        | summarize Count=count() by statuscode
        | evaluate pivot(statuscode, sum(Count)) 
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "right",
      calcs: [],
      values: [
          "value", "percent"
        ]
    }
  }
};

local AZLogs = logPanel.new(
    title="Azure Function Error logs",
    datasource='AzureMonitor',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
      let correlationIds = split("$correlationid", ",");
      AppTraces
      | where $__timeFilter(TimeGenerated)
      | where AppRoleName in ($functionApp)
      | where OperationName in ($functiontype)
      | where isnotempty(Message)
      | extend msgjson = parse_json(Message)
      | extend rawMessage = tostring(msgjson["message"])
      | extend correlationId = extract(@"x-correlation-id=([^,]+)", 1, rawMessage)
      | where isempty("$correlationid") or correlationId in~ (correlationIds)
      | where isnotempty(correlationId)
      | extend idempotencykey = extract(@"x-idempotency-key=([^,]+)", 1, rawMessage)
      | where isnotempty(idempotencykey)
      | extend statuscode = extract(@"statusCode=([^,]+)", 1, rawMessage)
      | where isnotempty(statuscode)
      | where statuscode != "200"
      | order by TimeGenerated desc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_loganalyticsworkspace/$loganalyticsworkspace_project"],
	resultFormat= 'logs'
  )
);

local AzureFunction = row.new(title="Azure Function", collapse=true)
    .addPanel(AZTotalRequests,gridPos={h: 8, w: 24, x: 0, y: 2})
    .addPanel(AZRequests,gridPos={h: 8, w: 12, x: 0, y: 19})
    .addPanel(AZDuplicateSuccessRequest,gridPos={h: 8, w: 12, x: 12, y: 19})
    .addPanel(AZRequestByStatusCode,gridPos={h: 8, w: 12, x: 0, y: 27})
    .addPanel(AZLogs,gridPos={h: 8, w: 12, x: 12, y: 27});

############################ Service Bus ############################

local ServiceBusIncommingMessages = grafana.graphPanel.new(
    title="Total Incoming Messages",
    datasource='AzureMonitor',
    description="This panel displays the total incoming messages graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='IncomingMessages',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus",
    dimension="EntityName",
    dimensionFilters="brand-topic",
    dimensionOperator="eq",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusOutgoingMessages = grafana.graphPanel.new(
    title="Total Outgoing Messages",
    datasource='AzureMonitor',
    description="This panel displays the total outgoing messages  graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='OutgoingMessages',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus",
    dimension="EntityName",
    dimensionFilters="brand-topic",
    dimensionOperator="eq",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusSuccessfulRequests = grafana.graphPanel.new(
    title="Total Successful Requests",
    datasource='AzureMonitor',
    description="This panel displays the total successful requests graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='SuccessfulRequests',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus",
    dimension="EntityName",
    dimensionFilters="brand-topic",
    dimensionOperator="eq",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusCompleteMessage = grafana.graphPanel.new(
    title="Complete Messages ",
    datasource='AzureMonitor',
    description="This panel displays the total complete messages graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='CompleteMessage',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus",
    dimension="EntityName",
    dimensionFilters="brand-topic",
    dimensionOperator="eq",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusActiveMessages = grafana.graphPanel.new(
    title="Count of Active Messages in a Queue",
    datasource='AzureMonitor',
    description="This panel displays the count of active messages in a queue graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='ActiveMessages',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus",
    dimension="EntityName",
    dimensionFilters="brand-topic",
    dimensionOperator="eq",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusScheduledMessages = grafana.graphPanel.new(
    title="Count of Scheduled Messages in a Queue",
    datasource='AzureMonitor',
    description="This panel displays the count of scheduled messages in a queue graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='ScheduledMessages',
    aggregation='Average',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus",
    dimension="EntityName",
    dimensionFilters="brand-topic",
    dimensionOperator="eq",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusCountOfUserErrors= grafana.pieChartPanel.new(
    title="Count Of User Errors",
    datasource='AzureMonitor',
    description="This panel displays the count of user errors graph for EventHub using Pie Chart",
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='UserErrors',
    aggregation='Total',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus",
    dimension="EntityName",
    dimensionFilters="brand-topic",
    dimensionOperator="eq",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "right",
        values: [
          "value", "percent"
        ]
      }
    }
};
local ServiceBusAverageRequestSize = grafana.graphPanel.new(
    title="Average Request Size",
    datasource='AzureMonitor',
    description="This panel displays the average request size graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='Size',
    aggregation='Average',
    subscription="$sub_project",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_project",
    resourceName="$resource_servicebus",
    dimension="EntityName",
    dimensionFilters="brand-topic",
    dimensionOperator="eq",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};

local ServiceBus = row.new(title="Service Bus", collapse=true)
    .addPanel(ServiceBusIncommingMessages,gridPos={h: 8, w: 12, x: 0, y:12})
    .addPanel(ServiceBusOutgoingMessages,gridPos={h: 8, w: 12, x: 12, y: 12})
    .addPanel(ServiceBusSuccessfulRequests,gridPos={h: 8, w: 12, x: 0, y: 20})
    .addPanel(ServiceBusCompleteMessage,gridPos={h: 8, w: 12, x: 12, y: 20})
    .addPanel(ServiceBusActiveMessages,gridPos={h: 8, w: 12, x: 0, y: 28})
    .addPanel(ServiceBusScheduledMessages,gridPos={h: 8, w: 12, x: 12, y: 28})
    .addPanel(ServiceBusCountOfUserErrors,gridPos={h: 8, w: 12, x: 0, y: 36})
    .addPanel(ServiceBusAverageRequestSize,gridPos={h: 8, w: 12, x: 12, y: 36});

############################ Standardized Zone ############################

local StandardizedZone = grafana.tablePanel.new(
  title='Standardized Ingestion Details - Table View',
  datasource='Azure SQL Server',
  description="This table panel displays the details of ingestion in the Standardized Zone."
).addTarget(
  target=sql_target(
    rawSql="
    SELECT
        project_name AS [Application Source],
        FORMAT(MAX(record_date), 'yyyy-MM-dd') AS [TransactionDate],
        REPLACE(dataset_name, '_', '') AS [Dataset Name],
        MAX(record_count) AS [Transaction Count]
    FROM
        [observability].[soforce_custom_slo_metrics]
    WHERE
        REPLACE(dataset_name, '_', '') IN ($apiName)
        AND ingestion_layer = 'standardized'
        AND record_date BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                    AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') AS DATE)
    GROUP BY
        project_name, dataset_name, record_date
    ORDER BY
        max(record_date) desc",
    format='table'
  )
);

local StandardizedZoneRow = row.new(title="Standardized Ingestion Details - Table View", collapse=true)
    .addPanel(panel=StandardizedZone,gridPos={h: 10, w: 24, x: 0, y: 30});

############################ Dashboard ############################

grafana.dashboard.new(
  title='Soforce Brand API monitoring ',
  time_from='now-24h',
  timezone="utc",
  editable='false',
  schemaVersion=37,
  uid='soforce-monitoring-tracker',
  tags=['monitoring', 'observability'])

.addTemplate(ProjectAppinsightsSubscription)
.addTemplate(ProjectAppinsightsRG)
.addTemplate(ProjectAppinsights)
.addTemplate(ProjectAppInsightsNamespace)

.addTemplate(ProjectServiceBus)
.addTemplate(ProjectServiceBusNamespace)
.addTemplate(ProjectLogAnalyticsWorkspace)
.addTemplate(LoganalyticsworkspaceNamespaceTemplate)

.addTemplate(template_API)
.addTemplate(template_functionApp)
.addTemplate(Source_functionApp)
.addTemplate(Target_functionApp)
.addTemplate(template_functiontype)
.addTemplate(template_country)
.addTemplate(template_region)
.addTemplate(template_source)
.addTemplate(template_correlationid)

.addPanel(panel=TotalRequestsPanels, gridPos={h: 4, w: 24, x: 0, y: 0})
.addPanel(panel=TrankingSource, gridPos={h: 7, w: 24, x: 0, y: 4})
.addPanel(panel=TrankingSourceAPIMtoAZ, gridPos={h: 7, w: 24, x: 0, y: 11})
.addPanel(panel=TrankingSourcetoTarget, gridPos={h: 7, w: 24, x: 0, y: 15})
.addPanel(panel=Status, gridPos={h: 1, w: 24, x: 0, y: 18})
.addPanel(panel=APIM, gridPos={h: 1, w: 24, x: 0, y: 19})
.addPanel(panel=AzureFunction, gridPos={h: 1, w: 24, x: 0, y: 20})
.addPanel(panel=ServiceBus, gridPos={h: 1, w: 24, x: 0, y: 21})
.addPanel(panel=StandardizedZoneRow, gridPos={h: 1, w: 24, x: 0, y: 22})