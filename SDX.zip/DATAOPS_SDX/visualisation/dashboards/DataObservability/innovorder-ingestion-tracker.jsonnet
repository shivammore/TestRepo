local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;
local tablePanel = grafana.tablePanel;
local logPanel =  grafana.logPanel;
local gaugePanel = grafana.gaugePanel;


############################ Dashboard config
local projectName = "Innovorder";

############################ Dashboard filters

local template_datadomain =  tmpl.new(
    name='data_domain',
    datasource='Azure SQL Server',
    query="SELECT distinct Domain_0 FROM [observability].[APIMetadataResponse] where Domain_0 !='' and Domain_0!='(Empty)' and Domain_0 ='Food Distribution'",
    refresh='load',
    includeAll=false,
    multi=false,
    label='Data Domain',
    hide=true
);

local template_category =  tmpl.new(
    name='category',
    datasource='Azure SQL Server',
    query="SELECT distinct case when  CDMCompliant='Yes' then 'CDM' else 'NonCDM' end as Category FROM [observability].[APIMetadataResponse] where Domain_0 in ('$data_domain')",
    refresh='load',
    includeAll=false,
    multi=false,
    label='Category',
    hide=true
);

local template_region =  tmpl.new(
    name='region',
    datasource='${ds}',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Region',
    queryType='Azure Log Analytics',
    query=|||
            requests
            | where url has "$ApiName"
            | extend region = tostring(customDimensions.["Request-x-region"])
            | where isnotempty(region)
            | distinct region
        |||,
    resources=[
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ]
);

local template_country =  tmpl.new(
    name='country',
    datasource='${ds}',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Country',
    queryType='Azure Log Analytics',
    query=|||
            requests
            | where url has "$ApiName"
            | extend country = tostring(customDimensions.["Request-x-country-of-origin"])
            | where isnotempty(country)
            | distinct country
        |||,
    resources=[
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ]
);

local template_source =  tmpl.new(
    name='source_system',
    datasource='${ds}',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Source System',
    queryType='Azure Log Analytics',
    query=|||
            requests
            | where url has "$ApiName"
            | extend source_system = tostring(customDimensions.["Request-x-source-application-id"])
            | where isnotempty(source_system)
            | distinct source_system
        |||,
    resources=[
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ]
);

############################ Project variables 
local EntityEventhubTemplate =  tmpl.custom(
    name='entity_eventhub',
    current='az-consumer-transactions-event-hub',
    query='az-consumer-transactions-event-hub',
    includeAll=false,
    multi=false,
    label="Eventhub Entity",
    hide=true
);

local ApiName =  tmpl.new(
    name='ApiName',
    datasource='Azure SQL Server',
    query="SELECT APIName from (SELECT APIName, case when  CDMCompliant='Yes' then 'CDM' else 'NonCDM' end as Category,Domain_0 FROM [observability].[APIMetadataResponse] where apiname is not null)a where Domain_0=('$data_domain') and Category=('$category') and APIName = 'consumer-transactions'",
    refresh='load',
    includeAll=false,
    multi=false,
    label='Data Object',
    hide=true
);
local CustomLogTable =  tmpl.custom(
    name='CustomLogTable',
    current='InnovorderConsumerTransactions_CL',
    query='InnovorderConsumerTransactions_CL',
    includeAll=false,
    multi=false,
    hide=true
);
local ProjectAppinsightsSubscription = tmpl.new(
    name='sub_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>AppinsightsSubscription'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Subscription of Application Insight",
    hide=true
);
local ProjectAppinsightsRG =  tmpl.new(
    name='rg_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>AppinsightsRG'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Resource Group of Application Insight",
    hide=true
);
local ProjectAppinsights =  tmpl.new(
    name='appinsights_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>Appinsights'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Application Insights",
    hide=true
);
local site =  tmpl.new(
    name='site',
    datasource='Azure SQL Server',
    query="SELECT distinct site_id FROM [observability].[food_distribution_consumer_transactions_custom_slo_metrics]",
    refresh='load',
    includeAll=true,
    multi=true,
    label="Site ID"
);
local template_functionApp =  tmpl.new(
    name='functionApp',
    datasource='Azure SQL Server',
    query="SELECT functionapp FROM [dbo].[FunctionAppDetails] where Apiname in ($source_system) ORDER BY functionapp ASC",
    refresh='load',
    includeAll=true,
    multi=true,
    label="Function App",
    hide=true
);

############################ Azure Monitor Namespaces
local ApimNamespaceTemplate =  tmpl.custom(
    name='ns_apim',
    current='Microsoft.ApiManagement/service',
    query='Microsoft.ApiManagement/service',
    includeAll=false,
    multi=false,
    hide=true
);
local EventhubNamespaceTemplate =  tmpl.custom(
    name='ns_eventhub',
    current='microsoft.eventhub/namespaces',
    query='microsoft.eventhub/namespaces',
    includeAll=false,
    multi=false,
    hide=true
);
local LoganalyticsworkspaceNamespaceTemplate =  tmpl.custom(
    name='ns_loganalyticsworkspace',
    current='Microsoft.OperationalInsights/workspaces',
    query='Microsoft.OperationalInsights/workspaces',
    includeAll=false,
    multi=false,
    hide=true
);
local AppInsightsNamespaceTemplate =  tmpl.custom(
    name='ns_appinsights',
    current='microsoft.insights/components',
    query='microsoft.insights/components',
    includeAll=false,
    multi=false,
    hide=true
);

############################ APIM variables
local datasourceTemplate =   tmpl.datasource(
    name='ds',
    current='Azure Monitor',
    query='grafana-azure-monitor-datasource',
    refresh='load',
    label='Datasource',
    hide=true
);

local ApimSubcriptionTemplate = tmpl.new(
    name='sub_apim',
    datasource='Azure SQL Server',
    query="Select value from grafana.APIMetadataInformation where field = 'ApimSubscription'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="APIM: Subscription",
    hide=true
  );
local ApimRgTemplate =  tmpl.new(
    name='rg_apim',
    datasource='Azure SQL Server',
    query="Select value from grafana.APIMetadataInformation where field = 'ApimResourceGroup'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="APIM: Resource Group",
    hide=true
);
local ApimServiceTemplate =  tmpl.new(
    name='resource_apim',
    datasource='Azure SQL Server',
    query="Select value from grafana.APIMetadataInformation where field = 'ApimServiceName'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="APIM: service",
    hide=true
);

############################ HIP variables
local HipSubcriptionTemplate =  tmpl.new(
    name='sub_hip',
    datasource='Azure SQL Server',
    query="Select value from grafana.APIMetadataInformation where field = 'HipSubcription'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="HIP: Subscription",
    hide=true
);
local HipRgTemplate =  tmpl.new(
    name='rg_hip',
    datasource='Azure SQL Server',
    query="Select value from grafana.APIMetadataInformation where field = 'HipResourceGroup'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="HIP: Resource Group",
    hide=true
);
local HipEventhubTemplate =  tmpl.new(
    name='resource_eventhub',
    datasource='Azure SQL Server',
    query="Select value from grafana.APIMetadataInformation where field = 'HipEventhubName'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="HIP: Eventhub",
    hide=true
);
local HipLoganalyticsworkspaceTemplate =  tmpl.new(
    name='resource_hip_loganalyticsworkspace',
    datasource='Azure SQL Server',
    query="Select value from grafana.APIMetadataInformation where field = 'HipLoganalyticsworkspace'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="HIP: Log Analytics Workspace",
    hide=true
);

############################Total Ingestion Panels 

local TotalRequestsPanels = statPanel.new(
  title="Total Ingested Records",
  datasource='-- Mixed --',
  description="This panel displays the total number of ingested records received across all services, including APIM, Azure Functions, Event Hub, Standardized Zone, and History Zone, based on the selected timestamp.",
  graphMode='none',
  reducerFunction='sum',
  orientation="vertical",
  justifyMode= "center",
  transparent=true
)
.addThresholds(
  steps=[
    { "color": "red", "value": 0 },
    { "color": "green", "value": 1 },
  ]
)
.addTarget({
  refId: "A",
  datasource: {
    type: "datasource",
    uid: "${ds}"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ],
    query: |||
      requests
        | where $__timeFilter(timestamp)
        | where url has "$ApiName"
        | where success == "True"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source_system)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey
        | summarize ['API Requests'] = count()
    |||
  }
})
.addTarget({
  refId: "B",
  datasource: {
    type: "datasource",
    uid: "${ds}"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"
    ],
    query: |||
      ${CustomLogTable}
        | where $__timeFilter(TimeGenerated)
        | where StatusCode_d in ('200', '201')
        | where SourceRegion_s in ($region)
        | where CountryOfOrigin_s in ($country)
        | where SourceApplicationId_s in ($source_system)
        | extend idempotencykey = IdempotencyKey_s
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(TimeGenerated) by idempotencykey
        | summarize ['Azure Function Requests'] = count() 
    |||
  }
})
.addTarget({
  refId: "C",
  datasource: {
    type: "datasource",
    uid: "${ds}"
  },
  queryType: "Azure Monitor",
  azureMonitor: {
    aggregation: "Total",
    alias: "Event Hub Requests",
    allowedTimeGrainsMs: [
      60000,
      300000,
      900000,
      1800000,
      3600000,
      21600000,
      43200000,
      86400000
    ],
    dimensionFilters: [
      {
        dimension: "EntityName",
        filters: [ "az-consumer-transactions-event-hub" ],
        operator: "eq"
      }
    ],
    metricName: "IncomingMessages",
    metricNamespace: "$ns_eventhub",
    region: "",
    resources: [
      {
        metricNamespace: "$ns_eventhub",
        region: "",
        resourceGroup: "$rg_hip",
        resourceName: "$resource_eventhub",
        subscription: "$sub_hip"
      }
    ],
    timeGrain: "auto"
  },
  subscription: "$sub_hip"
})
// .addTarget({
//   refId: "D",
//   datasource: {
//     type: "datasource",
//     uid: "Azure SQL Server"
//   },
//   rawMode: true,
//   format: "table",
//   rawQuery: true,
//   rawSql: "SELECT
//                     count(*) AS [CosmosDB Requests]
//                 FROM
//                     [observability].[event]
//                 WHERE
//                     context_id IN ('oss.glb.glb.cdm_food_distribution_consumer_transaction_silver', 'oss.glb.glb.cdm_food_distribution_consumer_transaction_bronze', 'oss.glb.glb.cdm_food_distribution_consumer_transaction_transient', 'oss.glb.glb.cdm_food_distribution_consumer_transaction_history', 'oss.glb.glb.cdm_food_distribution_consumer_transaction_standardized')
//                     AND dataset_name = 'consumer_transaction'
//                     AND landing_zone IN ('standardized')
//                     AND project_name= 'oss.glb.glb.cdm_food_distribution'
//                     AND metric_name='processing_exit_code'
//                     AND event_type='processingfinished'
//                     AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()",
//   query: {
//     alias: "CosmosDB Requests",
//     format: "table",
//     rawEditor: true,
//     rawQuery: true,
//     rawSql: "SELECT
//                     count(*) AS [CosmosDB Requests]
//                 FROM
//                     [observability].[event]
//                 WHERE
//                     context_id IN ('oss.glb.glb.cdm_food_distribution_consumer_transaction_silver', 'oss.glb.glb.cdm_food_distribution_consumer_transaction_bronze', 'oss.glb.glb.cdm_food_distribution_consumer_transaction_transient', 'oss.glb.glb.cdm_food_distribution_consumer_transaction_history', 'oss.glb.glb.cdm_food_distribution_consumer_transaction_standardized')
//                     AND dataset_name = 'consumer_transaction'
//                     AND landing_zone IN ('standardized')
//                     AND project_name= 'oss.glb.glb.cdm_food_distribution'
//                     AND metric_name='processing_exit_code'
//                     AND event_type='processingfinished'
//                     AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()"
//   }
// })
.addTarget({
  refId: "D",
  datasource: {
    type: "datasource",
    uid: "AzureSQLServer"
  },
  rawMode: true,
  format: "table",
  rawQuery: true,
  rawSql: "SELECT
                    SUM(metric_value) AS [Landing Ingested Records]
                FROM
                   (select distinct timestamp, metric_value from [observability].[event]
                WHERE
                    dataset_name = 'consumer_transaction'
                    AND landing_zone IN ('landing')
                    AND project_name= 'oss.glb.glb.cdm_food_distribution'
                    AND metric_name = 'rows_count'
                    AND timestamp BETWEEN ($__unixEpochFrom() + 86400) AND ($__unixEpochTo() + 86400)               
                   ) as distinct_records",
  query: {
    alias: "Landing Requests",
    format: "table",
    rawEditor: true,
    rawQuery: true,
    rawSql: "SELECT
                    SUM(metric_value) AS [Landing Ingested Records]
                FROM
                   (select distinct timestamp, metric_value from [observability].[event]
                WHERE
                    dataset_name = 'consumer_transaction'
                    AND landing_zone IN ('landing')
                    AND project_name= 'oss.glb.glb.cdm_food_distribution'
                    AND metric_name = 'rows_count'
                    AND timestamp BETWEEN ($__unixEpochFrom() + 86400) AND ($__unixEpochTo() + 86400)               
                   ) as distinct_records"
  }
})
.addTarget({
  refId: "E",
  datasource: {
    type: "datasource",
    uid: "AzureSQLServer"
  },
  rawMode: true,
  format: "table",
  rawQuery: true,
  rawSql: "SELECT 
                  SUM(total) AS [History Ingested Records]
                FROM (
                    SELECT DISTINCT ProcessedDate, total
                    FROM [dremio].[Innovorderhistorydata]
                    WHERE ProcessedDate BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') + 1 AS DATE)
                                            AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') + 1 AS DATE)
                ) AS distinct_records",
  query: {
    alias: "History Requests",
    format: "table",
    rawEditor: true,
    rawQuery: true,
    rawSql: "SELECT 
                  SUM(total) AS [History Ingested Records]
                FROM (
                    SELECT DISTINCT ProcessedDate, total
                    FROM [dremio].[Innovorderhistorydata]
                    WHERE ProcessedDate BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') + 1 AS DATE)
                                            AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') + 1 AS DATE)
                ) AS distinct_records"
  }
})
.addTarget({
  refId: "F",
  datasource: {
    type: "datasource",
    uid: "Azure SQL Server"
  },
  rawMode: true,
  format: "table",
  rawQuery: true,
  rawSql: "
  WITH region_cte AS (
      SELECT TRIM(value) AS region FROM STRING_SPLIT(ISNULL('${region:csv}', ''), ',')
    ),
    country_cte AS (
      SELECT TRIM(value) AS country FROM STRING_SPLIT(ISNULL('${country:csv}', ''), ',')
    ),
    source_cte AS (
      SELECT TRIM(value) AS source_system FROM STRING_SPLIT(ISNULL('${source_system:csv}', ''), ',')
    ),
    project_names AS (
      SELECT CONCAT('oss.', r.region, '.', c.country, '.', s.source_system) AS project_name
      FROM region_cte r
      CROSS JOIN country_cte c
      CROSS JOIN source_cte s
    )
  SELECT 
                SUM(maxrecord) AS [Standardized Ingested Records]
                FROM ( select site_id, record_date, max(record_count) as maxrecord
                from (
                    SELECT DISTINCT site_id, record_date, record_count
                    FROM [observability].[food_distribution_consumer_transactions_custom_slo_metrics]
                    WHERE record_date BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                                            AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                                            AND project_name IN (SELECT project_name FROM project_names)
                                            AND dataset_name = 'consumer_transaction'
                ) AS distinct_records
               group by site_id, record_date
) as maxrecordsperdate",
  query: {
    alias: "Standardized Requests",
    format: "table",
    rawEditor: true,
    rawQuery: true,
    rawSql: "
    WITH region_cte AS (
      SELECT TRIM(value) AS region FROM STRING_SPLIT(ISNULL('${region:csv}', ''), ',')
      ),
      country_cte AS (
        SELECT TRIM(value) AS country FROM STRING_SPLIT(ISNULL('${country:csv}', ''), ',')
      ),
      source_cte AS (
        SELECT TRIM(value) AS source_system FROM STRING_SPLIT(ISNULL('${source_system:csv}', ''), ',')
      ),
      project_names AS (
        SELECT CONCAT('oss.', r.region, '.', c.country, '.', s.source_system) AS project_name
        FROM region_cte r
        CROSS JOIN country_cte c
        CROSS JOIN source_cte s
      )
    SELECT 
                SUM(maxrecord) AS [Standardized Ingested Records]
                FROM ( select site_id, record_date, max(record_count) as maxrecord
                from (
                    SELECT DISTINCT site_id, record_date, record_count
                    FROM [observability].[food_distribution_consumer_transactions_custom_slo_metrics]
                    WHERE record_date BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                                            AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                                            AND project_name IN (SELECT project_name FROM project_names)
                                            AND dataset_name = 'consumer_transaction'
                ) AS distinct_records
               group by site_id, record_date
) as maxrecordsperdate"
  }
})
.addOverridesByFieldName(
  field='Event Hub Requests',
  properties=[
    { id: 'unit' },
  ]
);

local TrankingSource = grafana.tablePanel.new(
  title="Tracking APIM to Standardized Zone Difference",
  datasource='-- Mixed --',
  description="This table panel displays the details of tracking APIM to standardizes zone difference.",
)
.addTarget({
  refId: "B",
  datasource: {
    type: "datasource",
    uid: "Azure SQL Server"
  },
  rawMode: true,
  format: "table",
  rawQuery: true,
  rawSql: "
    WITH region_cte AS (
      SELECT TRIM(value) AS region
          FROM STRING_SPLIT(ISNULL('${region:csv}', ''), ',')
      ),
      country_cte AS (
          SELECT TRIM(value) AS country
          FROM STRING_SPLIT(ISNULL('${country:csv}', ''), ',')
      ),
      source_cte AS (
          SELECT TRIM(value) AS source_system
          FROM STRING_SPLIT(ISNULL('${source_system:csv}', ''), ',')
      ),
      project_names AS (
          SELECT
      CONCAT('oss.', r.region, '.', c.country, '.', s.source_system) AS project_name
          FROM region_cte r
          CROSS JOIN country_cte c
          CROSS JOIN source_cte s
      ),
     rankedrecords AS (
              SELECT
                  project_name AS 'Application Source',
                  dataset_name AS 'Dataset Name',
                  site_id AS 'Site ID',
                  record_date AS 'Transaction Date',
                  record_count AS 'Transaction Count',
                  ROW_NUMBER() OVER (PARTITION BY record_date, site_id ORDER BY record_count DESC) AS rn
              FROM [observability].[food_distribution_consumer_transactions_custom_slo_metrics]
              WHERE record_date BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                                    AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                    AND project_name  IN (SELECT project_name FROM project_names)
                    AND dataset_name = 'consumer_transaction'
          )
          SELECT
              [Dataset Name],
              FORMAT([Transaction Date], 'yyyy-MM-dd') AS 'TransactionDate',
              'Source To Target Perfect Match' AS 'Threshold',
              SUM([Transaction Count]) AS 'Standardized Record Count'
          FROM rankedrecords
          WHERE rn = 1
          GROUP BY [Dataset Name], [Transaction Date]
          ORDER BY FORMAT([Transaction Date], 'yyyy-MM-dd') DESC",
    query: {
    alias: "Standardized Requests",
    format: "table",
    rawEditor: true,
    rawQuery: true,
    rawSql: "
      WITH region_cte AS (
      SELECT TRIM(value) AS region
          FROM STRING_SPLIT(ISNULL('${region:csv}', ''), ',')
      ),
      country_cte AS (
          SELECT TRIM(value) AS country
          FROM STRING_SPLIT(ISNULL('${country:csv}', ''), ',')
      ),
      source_cte AS (
          SELECT TRIM(value) AS source_system
          FROM STRING_SPLIT(ISNULL('${source_system:csv}', ''), ',')
      ),
      project_names AS (
          SELECT
      CONCAT('oss.', r.region, '.', c.country, '.', s.source_system) AS project_name
          FROM region_cte r
          CROSS JOIN country_cte c
          CROSS JOIN source_cte s
      ),
     
     rankedrecords AS (
              SELECT
                  project_name AS 'Application Source',
                  dataset_name AS 'Dataset Name',
                  site_id AS 'Site ID',
                  record_date AS 'Transaction Date',
                  record_count AS 'Transaction Count',
                  ROW_NUMBER() OVER (PARTITION BY record_date, site_id ORDER BY record_count DESC) AS rn
              FROM [observability].[food_distribution_consumer_transactions_custom_slo_metrics]
              WHERE record_date BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                                    AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                    AND project_name  IN (SELECT project_name FROM project_names)
                    AND dataset_name = 'consumer_transaction'
          )
          SELECT
              [Dataset Name],
              FORMAT([Transaction Date], 'yyyy-MM-dd') AS 'TransactionDate',
              'Source To Target Perfect Match' AS 'Threshold',
              SUM([Transaction Count]) AS 'Standardized Record Count'
          FROM rankedrecords
          WHERE rn = 1
          GROUP BY [Dataset Name], [Transaction Date]
          ORDER BY FORMAT([Transaction Date], 'yyyy-MM-dd') DESC",
      }
})
.addTarget({
  refId: "B",
  datasource: {
    type: "datasource",
    uid: "${ds}"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ],
    query: |||
      requests
        | where $__timeFilter(timestamp)
        | where url has "$ApiName"
        | where success == "True"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source_system)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey
        | summarize APIM_Record_Count = count(), stamp = max(latest_timestamp) by bin(latest_timestamp, 1d)
        | project TransactionDate = format_datetime(stamp, "yyyy-MM-dd"), APIM_Record_Count
        | order by TransactionDate desc
    |||
  }
})
.addOverridesByFieldName(field='Difference',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'red',value: ''}]}},{id: 'mappings',value: [{options: {from: 0,result: {color: 'green',index: 1},to: 0}, type: 'range'}]}])
  {
  transformations: [
    {
      id: 'joinByField',
      options: {
        byField: 'TransactionDate',
        mode: 'inner',
      },
    },
    {
      id: 'calculateField',
      options: {
        alias: 'Difference',
        binary: {
          left: 'APIM_Record_Count',
          operator: '-',
          right: 'Standardized Record Count',
        },
        mode: 'binary',
        reduce: {
          reducer: 'sum',
        },
      },
    },
  ],
}
{   
  options: {
    showHeader: true,
    cellHeight: "sm",
    footer: {
    show: false,
    reducer: [
      "sum"
    ],
    countRows: false,
    fields: ""
    }
  }
};

local TrankingSourceAPIMtoAZ = grafana.tablePanel.new(
  title="Tracking APIM to Azure Function Difference",
  datasource='-- Mixed --',
  description="This table panel displays the details of tracking APIM to azure function difference.",
)
.addTarget({
  refId: "A",
  datasource: {
    type: "datasource",
    uid: "${ds}"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ],
    query: |||
     requests
        | where $__timeFilter(timestamp)
        | where url has "$ApiName"
        | where success == "True"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source_system)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey
        | summarize APIM_Record_Count = count(), stamp = max(latest_timestamp) by bin(latest_timestamp, 1d)
        | project TransactionDate = format_datetime(stamp, "yyyy-MM-dd"), APIM_Record_Count
        | order by TransactionDate desc
    |||
  }
})
.addTarget({
  refId: "B",
  datasource: {
    type: "datasource",
    uid: "${ds}"
  },
  queryType: "Azure Log Analytics",
  azureLogAnalytics: {
    resultFormat: "logs",
    dashboardTime: false,
    resources: [
      "/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"
    ],
    query: |||
      ${CustomLogTable}
        | where $__timeFilter(TimeGenerated)
        | where StatusCode_d in ('200', '201')
        | where SourceRegion_s in ($region)
        | where CountryOfOrigin_s in ($country)
        | where SourceApplicationId_s in ($source_system)
        | extend idempotencykey = IdempotencyKey_s
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(TimeGenerated) by idempotencykey
        | summarize Azure_Function_record_count = count(), stamp = max(latest_timestamp) by bin(latest_timestamp, 1d)
        | project TransactionDate = format_datetime(stamp, "yyyy-MM-dd"), Azure_Function_record_count
        | order by TransactionDate desc
    |||
  }
})
.addOverridesByFieldName(field='Difference',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'red',value: ''}]}},{id: 'mappings',value: [{options: {from: 0,result: {color: 'green',index: 1},to: 0}, type: 'range'}]}])
  {
  transformations: [
    {
      id: 'joinByField',
      options: {
        byField: 'TransactionDate',
        mode: 'outer',
      },
    },
    {
      id: 'calculateField',
      options: {
        alias: 'Difference',
        binary: {
          left: 'APIM_Record_Count',
          operator: '-',
          right: 'Azure_Function_record_count',
        },
        mode: 'binary',
        reduce: {
          reducer: 'sum',
        },
      },
    },
  ],
}
{   
  options: {
    showHeader: true,
    cellHeight: "sm",
    footer: {
    show: false,
    reducer: [
      "sum"
    ],
    countRows: false,
    fields: ""
    }
  }
};

local TrackingFreshness = grafana.tablePanel.new(
  title='Tracking Freshness',
  datasource='AzureSQLServer',
  description="This table panel displays the details of freshness"
).addTarget(
  target=sql_target(
    rawSql="
    WITH region_cte AS (
      SELECT TRIM(value) AS region
      FROM STRING_SPLIT(ISNULL('${region:csv}', ''), ',')
      ),
      country_cte AS (
          SELECT TRIM(value) AS country
          FROM STRING_SPLIT(ISNULL('${country:csv}', ''), ',')
      ),
      source_cte AS (
          SELECT TRIM(value) AS source_system
          FROM STRING_SPLIT(ISNULL('${source_system:csv}', ''), ',')
      ),
      project_names AS (
      SELECT CONCAT('oss.', r.region, '.', c.country, '.', s.source_system) AS project_name
          FROM region_cte r
          CROSS JOIN country_cte c
          CROSS JOIN source_cte s
      ),

    latestrecords as
      (
        select dataset_name as 'Dataset Name', Site_id as 'Site Id', project_name, Threshold = 259200, 
          max(case when record_count > 0 then record_date END) over (partition by site_id) As 'Last Updated Record', 
          record_date as 'Record Date',
          record_count as 'Record Count',
          row_number() over (partition by site_id order by record_date desc) as row_num from 
        [observability].[food_distribution_consumer_transactions_custom_slo_metrics] WHERE site_id in ($site)
      )
      select distinct lr.[Dataset name], 
              lr.[Site Id], 
          lr.Threshold,
    case 
       when GetDate() >= DATEADD(Day, 1 , CAST(lr.[Last Updated Record] AS DATE))       
       Then DATEDIFF(second, DATEADD(DAY, 1, CAST(lr.[Last Updated Record] AS DATE)), GetDate())
    else Datediff(second, CAST(lr.[Last Updated Record] AS DATE), GetDate())
    End as [Freshness Status]
      from latestrecords lr
      left join [observability].[food_distribution_consumer_transactions_custom_slo_metrics] pd 
          on lr.[Site Id] = pd.site_id
          and pd.record_date = DateAdd(Day, -1, lr.[Record Date])
      where lr.row_num = 1
      AND lr.project_name IN (SELECT project_name FROM project_names)",
    format='table'
    )
  ).addOverridesByFieldName(field='Threshold',properties=[{id: 'unit',value: "dtdurations"}]
  ).addOverridesByFieldName(field='Freshness Status',properties=[{id: 'custom.cellOptions',value: {type: 'color-background'}},{id: 'unit', value: 's'},{id: 'thresholds',value: {mode: 'absolute',steps: [{color: 'green',value: null},{color: 'red',value: 259200}]}}]
);

############################ Azure Function: CDM Mapper Consumer Transaction ############################
local AzureFunctionCDMLastRequest = statPanel.new(
    title="Azure Function: Last Run",
    datasource='AzureMonitor',
    description="This panel displays the last request time send to Azure Function",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields="/.*/",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let functionApps = dynamic([$functionApp]);
        traces
        | where $__timeFilter(timestamp)
        | where isempty(functionApps) or cloud_RoleName in (functionApps)
        | where isnotempty(message)
        | where message has "X-CORRELATION-ID"
        | extend correlationId = extract(@"X-CORRELATION-ID': '([^']+)'", 1, message)
        | where isnotempty(correlationId)
        | summarize tostring(format_datetime(max(timestamp),'yyyy-MM-dd HH:mm:ss'))
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/.*/"
      },
      graphMode: "none",
    }
};
local AzureFunctionCDMLastSucessRequest = statPanel.new(
    title="Azure Function: Number of Successful Requests",
    datasource='AzureMonitor',
    description="This panel displays the number of successful requests in Azure Function",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let functionApps = dynamic([$functionApp]);
        traces
        | where $__timeFilter(timestamp)
        | where isempty(functionApps) or cloud_RoleName in (functionApps)
        | where isnotempty(message)
        | where message has "X-CORRELATION-ID"
        | extend correlationId = extract(@"X-CORRELATION-ID': '([^']+)'", 1, message)
        | extend statuscode = toint(extract(@"Response status: (\d+)", 1, message))
        | where isnotempty(correlationId)
        | where statuscode == 200
        | summarize Successcount = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};
local AzureFunctionCDMLastFailedRequest = statPanel.new(
    title="Azure Function: Number of Failed Requests",
    datasource='AzureMonitor',
    description="This panel displays the number of failed requests in Azure Function",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": 0,
      },
      {
        "color": "red",
        "value": 1,
      },
  ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let functionApps = dynamic([$functionApp]);
        traces
        | where $__timeFilter(timestamp)
        | where isempty(functionApps) or cloud_RoleName in (functionApps)
        | where message contains "Error"
        | where message !contains "URL"
        | where message !contains "Host"
        | distinct message
        | summarize Failedcount = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};
local AzureFunctionCDMErrorList = tablePanel.new(
    title="Error/Exception details",
    datasource='AzureMonitor',
    description="This panel displays the Error/Exception details by timestamp in Azure Function",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let functionApps = dynamic([$functionApp]);
        traces
        | where $__timeFilter(timestamp)
        | where isempty(functionApps) or cloud_RoleName in (functionApps)
        | where message contains "Error"
        | where message !contains "URL"
        | where message !contains "Host"
        | extend ["Error Message"] = extract(@"Error\s*:\s*(.*)", 1, message)
        | where isnotempty(["Error Message"])
        | project-rename Timestamp = timestamp
        | distinct Timestamp, ["Error Message"]
        | order by Timestamp desc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
);
local AzureFunctionCDMLogs = logPanel.new(
    title="Error/Exception log details",
    datasource='AzureMonitor',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
      let functionApps = dynamic([$functionApp]);
      traces
      | where $__timeFilter(timestamp)
      | where isempty(functionApps) or cloud_RoleName in (functionApps)
      | where message contains "Error"
      | where message !contains "URL"
      | where message !contains "Host"
      | where isnotempty(message)
      | extend TimeStamp = format_datetime(timestamp, 'yyyy-MM-dd HH:mm:ss')
      | summarize arg_max(timestamp, TimeStamp, cloud_RoleName, operation_Name, severityLevel, customDimensions) by message
      | order by timestamp desc 
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
);

local AzureFunctionCDM = row.new(title="Azure Function: CDM Mapper Consumer Transaction", collapse=true)
    .addPanel(AzureFunctionCDMLastRequest,gridPos={h: 3, w: 8, x: 0, y: 0})
    .addPanel(AzureFunctionCDMLastSucessRequest,gridPos={h: 3, w: 8, x: 8, y: 0})
    .addPanel(AzureFunctionCDMLastFailedRequest,gridPos={h: 3, w: 8, x: 16, y: 0})
    .addPanel(AzureFunctionCDMErrorList,gridPos={h: 8, w: 12, x: 0, y: 28})
    .addPanel(AzureFunctionCDMLogs,gridPos={h: 8, w: 12, x: 12, y: 28});

############################ Status Panels
local ApimLastRequest = statPanel.new(
    title="APIM: Last Request",
    datasource='${ds}',
    description="This panel displays the last request time send to APIM",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields="/.*/",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where url has "$ApiName"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source_system)
        | summarize tostring(format_datetime(max(timestamp),'yyyy-MM-dd HH:mm:ss'))
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/.*/"
      },
      graphMode: "none",
    }
};
local ApimLastSucessRequest = statPanel.new(
    title="APIM: Number of Successful Requests",
    datasource='${ds}',
    description="This panel displays the number of successful requests in APIM",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where url has "$ApiName"
        | where success == "True"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source_system)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey
        | summarize Total_Success = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};
local ApimLastFailedRequest = statPanel.new(
    title="APIM: Number of Failed Requests",
    datasource='${ds}',
    description="This panel displays the number of failed requests in APIM",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": 0,
      },
      {
        "color": "red",
        "value": 1,
      },
  ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where url has "$ApiName"
        | where success != "True"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source_system)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey
        | summarize Total_Failed = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};

local AzfLastRun = statPanel.new(
    title="Azure Function: Last Run",
    datasource='${ds}',
    description="This panel displays the last run time for Azure Function",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields="/.*/",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        ${CustomLogTable}
        | where $__timeFilter(TimeGenerated )
        | where SourceRegion_s in ($region)
        | where CountryOfOrigin_s in ($country)
        | where SourceApplicationId_s in ($source_system)
        | summarize tostring(format_datetime(max(TimeGenerated),'yyyy-MM-dd HH:mm:ss'))
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'logs'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/.*/"
      },
      graphMode: "none",
    }
};
local AzfLastSuccessRun = statPanel.new(
    title="Azure Function: Number of Successful Run",
    datasource='${ds}',
    description="This panel displays the number of successful run in Azure Function",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        ${CustomLogTable}
        | where $__timeFilter(TimeGenerated)
        | where StatusCode_d in ('200', '201')
        | where SourceRegion_s in ($region)
        | where CountryOfOrigin_s in ($country)
        | where SourceApplicationId_s in ($source_system)
        | extend idempotencykey = IdempotencyKey_s
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(TimeGenerated) by idempotencykey
        | summarize Total_Success = count() 
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};
local EventHubLastIncomingMessages = statPanel.new(
    title="EventHub: Last Incoming Messages",
    datasource='${ds}',
    description="This panel displays the last incoming messages time for EventHub",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields='/^Time$/',
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='None',
    metricName='IncomingMessages',
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    subscription="$sub_hip",
    dimension="EntityName",
    dimensionFilters="$entity_eventhub",
    dimensionOperator="eq",
    alias="Incoming Messages",
   )
).addTransformations([
		grafana.transformation.new(
      'filterByValue', 
      options={
        filters: [ 
          {
            config: {id: "equal",options: { value: 0  }},
            fieldName: "Incoming Messages ${entity_eventhub}"
          }
        ],
        match: "all",
        type: "exclude"
      }),
]) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};
local EventHubLastOutgoingMessages = statPanel.new(
    title="EventHub: Last Outgoing Messages",
    datasource='${ds}',
    description="This panel displays the last outgoing messages time for EventHub",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields='/^Time$/',
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='None',
    metricName='OutgoingMessages',
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    subscription="$sub_hip",
    dimension="EntityName",
    dimensionFilters="$entity_eventhub",
    dimensionOperator="eq",
    alias="Outgoing Messages",
   )
).addTransformations([
		grafana.transformation.new(
      'filterByValue', 
      options={
        filters: [ 
          {
            config: {id: "equal",options: { value: 0  }},
            fieldName: "Outgoing Messages ${entity_eventhub}"
          }
        ],
        match: "all",
        type: "exclude"
      }),
]) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};
local EventHubServerError = statPanel.new(
    title="EventHub: Server Errors",
    datasource='${ds}',
    description="This panel displays the number of server errors in EventHub",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": 0,
      },
      {
        "color": "red",
        "value": 1,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='Total',
    metricName='ServerErrors',
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    subscription="$sub_hip",
    dimension="EntityName",
    dimensionFilters="$entity_eventhub",
    dimensionOperator="eq",
    alias="Server Errors",
   )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};
local EventHubUserErrors = statPanel.new(
    title="EventHub: User Errors",
    datasource='${ds}',
    description="This panel displays the number of user errors in EventHub",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": 0,
      },
      {
        "color": "red",
        "value": 1,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='Total',
    metricName='UserErrors',
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    subscription="$sub_hip",
    dimension="EntityName",
    dimensionFilters="$entity_eventhub",
    dimensionOperator="eq",
    alias="User Errors",
   )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};

local LandingLastSuccessIngestion =
  statPanel.new(
    title="Landing Zone: Last Successful Ingestion",
    fields='/^Time$/',
    datasource='Azure SQL Server',
    description="This panel displays the last successful ingestion time for Landing Zone",
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT
              top(1)
              DATEADD(SECOND, MAX([timestamp]), '1970-01-01')
          FROM
              [observability].[event]
          WHERE
              dataset_name = 'consumer_transaction'
              AND landing_zone IN ('landing')
              AND project_name= 'oss.glb.glb.cdm_food_distribution'
              AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
              AND metric_name IN ('processing_finished_date')
            ",
            format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};
  local LandingRecCount =
  statPanel.new(
    title="Landing Zone: Total Successful Records",
    datasource='Azure SQL Server',
    description="This panel displays the total number of successful records in landing zone",
    colorMode='background'
    ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT
                    SUM(metric_value) AS [Landing Ingested Records]
                FROM
                   (select distinct timestamp, metric_value from [observability].[event]
                WHERE
                    dataset_name = 'consumer_transaction'
                    AND landing_zone IN ('landing')
                    AND project_name= 'oss.glb.glb.cdm_food_distribution'
                    AND metric_name = 'rows_count'
                    AND timestamp BETWEEN ($__unixEpochFrom() + 86400) AND ($__unixEpochTo() + 86400)               
                   ) as distinct_records",
            format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: ""
      },
      graphMode: "none",
    }
};

local BronzeStdLastSuccessIngestion =
  statPanel.new(
    title="Standardized Zone: Last Successful Ingestion",
    fields='/^Time$/',
    datasource='Azure SQL Server',
    description="This panel displays the last successful ingestion time for Standardized Zone",
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT
              top(1)
              DATEADD(SECOND, MAX([timestamp]), '1970-01-01')
          FROM
              [observability].[event]
          WHERE
              context_id IN ('oss.glb.glb.cdm_food_distribution_consumer_transaction_silver', 'oss.glb.glb.cdm_food_distribution_consumer_transaction_bronze', 'oss.glb.glb.cdm_food_distribution_consumer_transaction_transient', 'oss.glb.glb.cdm_food_distribution_consumer_transaction_history', 'oss.glb.glb.cdm_food_distribution_consumer_transaction_standardized')
              AND dataset_name = 'consumer_transaction'
              AND landing_zone IN ('standardized')
              AND project_name= 'oss.glb.glb.cdm_food_distribution'
              AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
              AND metric_name IN ('processing_finished_date')
            ",
            format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};
local BronzeRecCount =
  statPanel.new(
    title="Standardized Zone: Total Successful Records",
    datasource='Azure SQL Server',
    description="This panel displays the total number of successful records in standardized zone",
    colorMode='background'
    ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="WITH region_cte AS (
      SELECT TRIM(value) AS region FROM STRING_SPLIT(ISNULL('${region:csv}', ''), ',')
        ),
        country_cte AS (
          SELECT TRIM(value) AS country FROM STRING_SPLIT(ISNULL('${country:csv}', ''), ',')
        ),
        source_cte AS (
          SELECT TRIM(value) AS source_system FROM STRING_SPLIT(ISNULL('${source_system:csv}', ''), ',')
        ),
        project_names AS (
        SELECT CONCAT('oss.', r.region, '.', c.country, '.', s.source_system) AS project_name
          FROM region_cte r
          CROSS JOIN country_cte c
          CROSS JOIN source_cte s
        )
        SELECT SUM(maxrecord) AS [Standardized Ingested Records]
        FROM (
          SELECT site_id, record_date, MAX(record_count) AS maxrecord
          FROM (
            SELECT DISTINCT site_id, record_date, record_count
            FROM [observability].[food_distribution_consumer_transactions_custom_slo_metrics]
            WHERE record_date BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') AS DATE)
              AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') AS DATE)
              AND project_name IN (SELECT project_name FROM project_names)
              AND dataset_name = 'consumer_transaction'
          ) AS distinct_records
          GROUP BY site_id, record_date
        ) AS maxrecordsperdate",
            format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: ""
      },
      graphMode: "none",
    }
};

local HistoryLastSuccessIngestion =
  statPanel.new(
    title="History Zone: Last Successful Ingestion",
    fields='/^Time$/',
    datasource='Azure SQL Server',
    description="This panel displays the last successful ingestion time for History Zone",
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT
              top(1)
              DATEADD(SECOND, MAX([timestamp]), '1970-01-01')
          FROM
              [observability].[event]
          WHERE
              context_id IN ('oss.glb.glb.cdm_food_distribution_consumer_transaction_silver', 'oss.glb.glb.cdm_food_distribution_consumer_transaction_bronze', 'oss.glb.glb.cdm_food_distribution_consumer_transaction_transient', 'oss.glb.glb.cdm_food_distribution_consumer_transaction_history', 'oss.glb.glb.cdm_food_distribution_consumer_transaction_standardized')
              AND dataset_name = 'consumer_transaction'
              AND landing_zone IN ('history')
              AND project_name= 'oss.glb.glb.cdm_food_distribution'
              AND timestamp BETWEEN $__unixEpochFrom() AND $__unixEpochTo()
              AND metric_name IN ('processing_finished_date')
            ",
            format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
  };

local HistoryRecCount =
  statPanel.new(
    title="History Zone: Total Successful Records",
    datasource='Azure SQL Server',
    description="This panel displays the total number of successful records in history zone",
    colorMode='background'
    ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT 
                  SUM(total) AS [History Ingested Records]
                FROM (
                    SELECT DISTINCT ProcessedDate, total
                    FROM [dremio].[Innovorderhistorydata]
                    WHERE ProcessedDate BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') + 1 AS DATE)
                                            AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') + 1 AS DATE)
                ) AS distinct_records",
            format='table'
    )
  ) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "mean"
      ],
      fields: ""
      },
      graphMode: "none",
    }
};

local Status = row.new(title="Status", collapse=true)
    .addPanel(ApimLastRequest,gridPos={h: 3, w: 8, x: 0, y: 0})
    .addPanel(ApimLastSucessRequest,gridPos={h: 3, w: 8, x: 8, y: 0})
    .addPanel(ApimLastFailedRequest,gridPos={h: 3, w: 8, x: 16, y: 0})
    .addPanel(AzfLastRun,gridPos={h: 3, w: 12, x: 0, y: 4})
    .addPanel(AzfLastSuccessRun,gridPos={h: 3, w: 12, x: 12, y: 4})
    .addPanel(EventHubLastIncomingMessages,gridPos={h: 3, w: 12, x: 0, y: 8})
    .addPanel(EventHubLastOutgoingMessages,gridPos={h: 3, w: 12, x: 0, y: 12})
    .addPanel(EventHubServerError,gridPos={h: 3, w: 12, x: 12, y: 8})
    .addPanel(EventHubUserErrors,gridPos={h: 3, w: 12, x: 12, y: 12})
    .addPanel(LandingLastSuccessIngestion,gridPos={h: 3, w: 12, x: 0, y: 24})
    .addPanel(LandingRecCount,gridPos={h: 3, w: 12, x: 12, y: 24})
    .addPanel(HistoryLastSuccessIngestion,gridPos={h: 3, w: 12, x: 0, y: 28})
    .addPanel(HistoryRecCount,gridPos={h: 3, w: 12, x: 12, y: 28})
    .addPanel(BronzeStdLastSuccessIngestion,gridPos={h: 3, w: 12, x: 0, y: 32})
    .addPanel(BronzeRecCount,gridPos={h: 3, w: 12, x: 12, y: 32});

############################ APIM Panels
local ApiFailedList = tablePanel.new(
    title="Last Failed Events",
    datasource='${ds}',
    description="This panel displays the last failed events in APIM",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where url has "$ApiName"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source_system)
        | where success == False
        | project timestamp, resultCode, duration, APIName=customDimensions["API Name"], RequestSize=customMeasurements.["Request Size"], CorrelationId=customDimensions.["Request-x-correlation-id"], IdempotencyKey=customDimensions.["Request-x-idempotency-key"]
        | order by timestamp desc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
);
local ApiStatusTimeSeries = grafana.graphPanel.new(
    title="Requests (Successful & Failed)",
    datasource='${ds}',
    description="This panel displays the Requests (Successful & Failed) in APIM",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where url has "$ApiName"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source_system)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | summarize Success=count() by success, bin(timestamp, 5m)
        | order by timestamp asc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
);
local ApiRequestNumberByDay = grafana.barChart.new(
    title="Total Number of Requests by Day (Successful & Failed)",
    description='This panel displays the total number of requests by day in APIM',
    datasource='${ds}',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where url has "$ApiName"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source_system)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | summarize RequestNB=count() by format_datetime(timestamp, "MM/dd/yyyy")
        | order by timestamp asc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
);
local ApiDuplicateSuccessRequest = tablePanel.new(
    title="Duplicate key by Day (Successful)",
    datasource='${ds}',
    description="This panel displays the successful requests duplicate key by day ",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where url has "$ApiName"
        | where success == "True"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source_system)
        | summarize Count=count() by IdempotencyKey=tostring(customDimensions.["Request-x-idempotency-key"]), format_datetime(timestamp, "MM/dd/yyyy")
        | where Count > 1
        | order by timestamp desc        
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
);
local ApiDuplicateFailedRequest = tablePanel.new(
    title="Duplicate key by Day (Failed)",
    datasource='${ds}',
    description="This panel displays the failed requests duplicate key by day ",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where url has "$ApiName"
        | where success == "False"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source_system)
        | summarize Count=count() by IdempotencyKey=tostring(customDimensions.["Request-x-idempotency-key"]), format_datetime(timestamp, "MM/dd/yyyy")
        | where Count > 1
        | order by timestamp desc        
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
);
local ApiLogs = logPanel.new(
    title="API Unique Idempotency Key Error logs",
    datasource='${ds}',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
      requests
      | where $__timeFilter(timestamp)
      | where url has "$ApiName"
      | where tostring(customDimensions.["Request-x-region"]) in ($region)
      | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
      | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source_system)
      | where success == "False"
      | extend
          request_APIName=customDimensions.["API Name"],
          request_CorrelationId=customDimensions.["Request-x-correlation-id"],
          request_IdempotencyKey=tostring(customDimensions.["Request-x-idempotency-key"]),
          request_SourceApplicationId=customDimensions.["Request-x-source-application-id"],
          request_size=customMeasurements.["Request Size"]
      | where isnotempty(request_IdempotencyKey)  
      | project
          request_timestamp=timestamp,
          request_CorrelationId,  
          request_IdempotencyKey,
          request_APIName,
          request_SourceApplicationId,
          request_name=name,
          request_url=url,
          request_success=success,
          request_resultCode=resultCode,
          request_duration=duration,
          request_performanceBucket=performanceBucket,
          request_size,
          request_operation_Name=operation_Name,
          operation_Id
      | join kind=inner (
          requests
          | where $__timeFilter(timestamp)
          | where url has "$ApiName"
          | where success == "False"
          | extend
              request_resultCode = resultCode,
              request_IdempotencyKey = tostring(customDimensions.["Request-x-idempotency-key"]),
              request_timestamp = timestamp
          | where isnotempty(request_IdempotencyKey)
          | summarize request_timestamp = max(timestamp) by request_IdempotencyKey, request_resultCode
      ) on request_IdempotencyKey, request_resultCode, request_timestamp
      | join kind=inner (exceptions | project operation_Id, timestamp, outerMessage, operation_Name, appName, _ResourceId) on operation_Id
      | summarize arg_max(request_timestamp, *) by request_IdempotencyKey
      | order by request_timestamp desc     
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
);
local ApiStatusPieChartPanel = grafana.pieChartPanel.new(
    title="Status Code Repartition",
    datasource='${ds}',
    description="This pie chart displays the status code repartition",
    legendType="Under graph",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests 
          | where $__timeFilter(timestamp)
          | where url has "$ApiName"
          | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source_system)
          | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
          | where isnotempty(idempotencykey)
          | summarize latest_timestamp = max(timestamp) by idempotencykey, resultCode    
          | summarize Count=count() by resultCode
          | evaluate pivot(resultCode, sum(Count))
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
);

local APIM = row.new(title="APIM: Consumer Transaction", collapse=true)
    .addPanel(ApiFailedList,gridPos={h: 5, w: 24, x: 0, y: 23})
    .addPanel(ApiStatusTimeSeries,gridPos={h: 8, w: 9, x: 0, y: 28})
    .addPanel(ApiRequestNumberByDay,gridPos={h: 8, w: 9, x: 9, y: 28})
    .addPanel(ApiStatusPieChartPanel,gridPos={h: 8, w: 6, x: 18, y: 28})
    .addPanel(ApiDuplicateSuccessRequest,gridPos={h: 8, w: 8, x: 0, y:40})
    .addPanel(ApiDuplicateFailedRequest,gridPos={h: 8, w: 8, x: 8, y:40})
    .addPanel(ApiLogs,gridPos={h: 8, w: 8, x: 16, y: 40});



############################ Azure function panels
local AzRequestNumberByDay = grafana.barChart.new(
    title="Run by day (Failed & Successful)",
    description='This panel displays the number of run by day',
    datasource='${ds}',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
      ${CustomLogTable}
      | where $__timeFilter(TimeGenerated)
      | where SourceRegion_s in ($region)
      | where CountryOfOrigin_s in ($country)
      | where SourceApplicationId_s in ($source_system)
      | extend idempotencykey = IdempotencyKey_s
      | where isnotempty(idempotencykey)
      | summarize RunNB=count() by format_datetime(TimeGenerated,'MM/dd/yyyy')
      | order by TimeGenerated asc
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'time_series'
  )
);
local AzDuplicateRequest = tablePanel.new(
    title="Duplicate key by day",
    datasource='${ds}',
    description="This panel displays the duplicate key by day",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
      ${CustomLogTable}
      | where SourceRegion_s in ($region)
      | where CountryOfOrigin_s in ($country)
      | where SourceApplicationId_s in ($source_system)
      | summarize Count=count() by IdempotencyKey_s , format_datetime(TimeGenerated,'MM/dd/yyyy')
      | where Count > 1
      | order by TimeGenerated desc
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'logs'
  )
);
local AzLogs = logPanel.new(
    title="AZ: Error logs",
    datasource='${ds}',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
      ${CustomLogTable}
      | extend idempotencykey = IdempotencyKey_s
      | where isnotempty(idempotencykey)
      | where StatusCode_d !in (200, 201)
      | order by TimeGenerated desc
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'logs'
  )
);

local AZF = row.new(title="Azure Function: Consumer Transaction", collapse=true)
    .addPanel(AzRequestNumberByDay,gridPos={h: 8, w: 8, x: 0, y: 0})
    .addPanel(AzDuplicateRequest,gridPos={h:8 , w:8 , x:8 , y:0})
    .addPanel(AzLogs,gridPos={h: 8, w: 8, x: 16, y: 0});


############################EventHub panels
local EventHubIncommingMessages = grafana.graphPanel.new(
    title="EventHub: Incoming Messages",
    datasource='${ds}',
    description="This panel displays the last incoming messages graph for EventHub",
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='IncomingMessages',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    dimension="EntityName",
    dimensionFilters="$entity_eventhub",
    dimensionOperator="eq",
    alias="Incoming Messages",
   )
);
local EventHubOutgoingMessages = grafana.graphPanel.new(
    title="EventHub: Outgoing Messages",
    datasource='${ds}',
    description="This panel displays the last outgoing messages graph for EventHub",
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='OutgoingMessages',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    dimension="EntityName",
    dimensionFilters="$entity_eventhub",
    dimensionOperator="eq",
    alias="Outgoing Messages",
   )
);

local EventHub = row.new(title="EventHub: Consumer Transaction", collapse=true)
    .addPanel(EventHubIncommingMessages,gridPos={h: 5, w: 6, x: 0, y: 19})
    .addPanel(EventHubOutgoingMessages,gridPos={h: 5, w: 6, x: 6, y: 19})
    .addPanel(EventHubServerError,gridPos={h: 5, w: 6, x: 12, y: 19})
    .addPanel(EventHubUserErrors,gridPos={h: 5, w: 6, x: 18, y: 19});

#############################Standardized Zone Panels

local StandardizedZone = grafana.tablePanel.new(
  title='Standardized Ingestion Details - Table View',
  datasource='Azure SQL Server',
  description="This table panel displays the details of ingestion in the Standardized Zone."
).addTarget(
  target=sql_target(
    rawSql="
    WITH region_cte AS (
      SELECT TRIM(value) AS region FROM STRING_SPLIT(ISNULL('${region:csv}', ''), ',')
    ),
    country_cte AS (
      SELECT TRIM(value) AS country FROM STRING_SPLIT(ISNULL('${country:csv}', ''), ',')
    ),
    source_cte AS (
      SELECT TRIM(value) AS source_system FROM STRING_SPLIT(ISNULL('${source_system:csv}', ''), ',')
    ),
    project_names AS (
      SELECT CONCAT('oss.', r.region, '.', c.country, '.', s.source_system) AS project_name
      FROM region_cte r
      CROSS JOIN country_cte c
      CROSS JOIN source_cte s
    ),
    rankedrecords AS (  
        SELECT  
            project_name AS [Application Source],  
            dataset_name AS [Dataset Name],  
            site_id AS [Site ID],  
            record_date AS [Transaction Date],  
            record_count AS [Transaction Count],  
            ROW_NUMBER() OVER (PARTITION BY record_date, site_id ORDER BY record_count DESC) AS rn  
        FROM [observability].[food_distribution_consumer_transactions_custom_slo_metrics]  
        WHERE record_date BETWEEN CAST(DATEADD(SECOND, CAST(${__from} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                                                            AND CAST(DATEADD(SECOND, CAST(${__to} / 1000 AS BIGINT), '1970-01-01') AS DATE)
                                                            AND project_name IN (SELECT project_name FROM project_names)
                                                            AND dataset_name = 'consumer_transaction'
                                                            AND site_id IN ($site)
      ),  
      site_counts AS (  
          SELECT  
              [Transaction Date],  
              COUNT(DISTINCT [Site ID]) AS [Distinct Site Count]  
          FROM rankedrecords  
          WHERE rn = 1  
          GROUP BY [Transaction Date]  
      )  
      SELECT  
          r.[Application Source],  
          r.[Dataset Name],  
          r.[Site ID],  
          FORMAT(r.[Transaction Date], 'yyyy-MM-dd') AS [Transaction Date],  
          r.[Transaction Count]
      FROM rankedrecords r  
      JOIN site_counts sc  
          ON r.[Transaction Date] = sc.[Transaction Date]  
      WHERE r.rn = 1  
      ORDER BY r.[Transaction Date] DESC, r.[Site ID]",
    format='table'
  )
);

local StandardizedZoneRow = row.new(title="Standardized Ingestion Details - Table View", collapse=true)
    .addPanel(panel=StandardizedZone,gridPos={h: 10, w: 24, x: 0, y: 30});

// local CosmosDB = row.new(title="CosmosDB", collapse=true)
//     .addPanel(CosmosDBLastSuccessIngestion,gridPos={h: 3, w: 8, x: 0, y: 22})
//     .addPanel(CosmosDbCount,gridPos={h: 3, w: 8, x: 8, y: 22})
//     .addPanel(CosmodDBFailedRecCount,gridPos={h: 3, w: 8, x: 16, y: 22});


############################ Dashboard
grafana.dashboard.new(
  title='Consumer Transaction End to End Observability',
  time_from='now-7d',
  timezone="utc",
  editable='false',
  schemaVersion=37,
  uid='innovorder-ingestion-tracker',
  tags=['monitoring', 'observability', 'consumer transaction api', 'innovorder'])

.addTemplate(ApimNamespaceTemplate)
.addTemplate(EventhubNamespaceTemplate)
.addTemplate(LoganalyticsworkspaceNamespaceTemplate)
.addTemplate(AppInsightsNamespaceTemplate)

.addTemplate(datasourceTemplate)
.addTemplate(ApimSubcriptionTemplate)
.addTemplate(ApimRgTemplate)
.addTemplate(ApimServiceTemplate)

.addTemplate(HipSubcriptionTemplate)
.addTemplate(HipRgTemplate)
.addTemplate(HipEventhubTemplate)
.addTemplate(HipLoganalyticsworkspaceTemplate)

.addTemplate(template_datadomain)
.addTemplate(template_category)
.addTemplate(EntityEventhubTemplate)
.addTemplate(ApiName)
.addTemplate(template_region)
.addTemplate(template_country)
.addTemplate(template_source)
.addTemplate(CustomLogTable)
.addTemplate(ProjectAppinsightsSubscription)
.addTemplate(ProjectAppinsightsRG)
.addTemplate(ProjectAppinsights)
.addTemplate(site)
.addTemplate(template_functionApp)

.addPanel(panel=TotalRequestsPanels, gridPos={h: 4, w: 24, x: 0, y: 0})
.addPanel(panel=TrankingSource, gridPos={h: 7, w: 24, x: 0, y: 4})
.addPanel(panel=TrankingSourceAPIMtoAZ, gridPos={h: 7, w: 24, x: 0, y: 11})
.addPanel(panel=TrackingFreshness, gridPos={h: 6, w: 24, x: 0, y: 18})
.addPanel(panel=StandardizedZoneRow, gridPos={h: 1, w: 24, x: 0, y: 20})
.addPanel(panel=AzureFunctionCDM, gridPos={h: 1, w: 24, x: 0, y: 28})
.addPanel(panel=Status, gridPos={h: 1, w: 24, x: 0, y: 30})
.addPanel(panel=APIM, gridPos={h: 1, w: 24, x: 0, y: 52})
.addPanel(panel=AZF, gridPos={h: 1, w: 24, x: 0, y: 76})
.addPanel(panel=EventHub, gridPos={h: 1, w: 24, x: 0, y: 100})
// .addPanel(panel=CosmosDB, gridPos={h: 1, w: 24, x: 0, y: 100})