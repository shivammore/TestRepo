local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;

local TemplateDataSource = tmpl.datasource(
  name='ds',
  label='Datasource',
  query='grafana-azure-monitor-datasource',
  current='Azure Monitor',
  refresh='load'
);

local TemplateSubscription = tmpl.new(
  name='sub',
  label='Subscription',
  datasource='${ds}',
  refresh='load',
  includeAll=false,
  query={
    grafanaTemplateVariableFn: {
      kind: 'SubscriptionsQuery',
      rawQuery: 'Subscriptions()'
    },
    queryType: 'Grafana Template Variable Function',
    refId: 'A',
    subscription: ''
  }
);

local TemplateWorkspace = tmpl.new(
  name='ws',
  label='Workspace',
  datasource='${ds}',
  refresh='load',
  includeAll=false,
  query={
    grafanaTemplateVariableFn: {
      kind: 'WorkspacesQuery',
      rawQuery: 'Workspaces($sub)',
      subscription: '$sub'
    },
    queryType: 'Grafana Template Variable Function',
    refId: 'A',
    subscription: ''
  }
);


local TemplateResourceGroups = tmpl.new(
  name='ResourceGroups',
  label='ResourceGroups',
  datasource='${ds}',
  refresh='load',
  includeAll=false,
  query={
    azureResourceGraph: {
            query: "resources | distinct resourceGroup"
    },
    grafanaTemplateVariableFn: {
      kind: 'WorkspacesQuery',
      rawQuery: 'Workspaces($sub)',
      subscription: '$sub'
    },
    queryType: "Azure Resource Graph",
    refId: 'A',
    subscription: ''
  }
);

local TemplateAKS = tmpl.new(
  name='AKS',
  label='AKS',
  datasource='Azure Monitor',
  refresh='load',
  includeAll=false,
  query='ResourceNames($ResourceGroups, Microsoft.ContainerService/managedClusters)'
);

local TemplateNamespace = tmpl.new(
  name='Namespace',
  label='Namespace',
  datasource='Azure Monitor',
  refresh='load',
  includeAll=false,
  query='KubePodInventory | where ClusterName == "$AKS" | summarize count() by Namespace | project Namespace'
);

local CurrentCPUUtlization = grafana.tablePanel.new(
    title="CPU Utlization - Current",
    datasource='Azure Monitor',
    description=""
  ).addTarget(
    target=grafana.azuremonitor.target(
      query=|||
                KubePodInventory | where TimeGenerated > ago(2m) | where ClusterName == "$AKS" | where Namespace == "$Namespace" | summarize arg_max(TimeGenerated, *) by ContainerName | project Name, ContainerName | join kind = inner ( Perf | where TimeGenerated > ago(2m) | where ObjectName == 'K8SContainer' | where CounterName == 'cpuLimitNanoCores' | where InstanceName contains '$AKS' | extend ContainerNameParts = split(InstanceName, '/') | extend ContainerNamePartCount = array_length(ContainerNameParts) | extend PodUIDIndex = ContainerNamePartCount - 2, ContainerNameIndex = ContainerNamePartCount - 1 | extend ContainerName = strcat(ContainerNameParts[PodUIDIndex], '/', ContainerNameParts[ContainerNameIndex]) | summarize arg_max(TimeGenerated, *) by ContainerName | project ContainerName, CpuLimit=CounterValue | join kind = inner ( Perf | where TimeGenerated > ago(2m) | where ObjectName == 'K8SContainer' | where CounterName == 'cpuUsageNanoCores' | where InstanceName contains '$AKS' | extend ContainerNameParts = split(InstanceName, '/') | extend ContainerNamePartCount = array_length(ContainerNameParts) | extend PodUIDIndex = ContainerNamePartCount - 2, ContainerNameIndex = ContainerNamePartCount - 1 | extend ContainerName = strcat(ContainerNameParts[PodUIDIndex], '/', ContainerNameParts[ContainerNameIndex]) | summarize arg_max(TimeGenerated, *) by ContainerName | project TimeGenerated, ContainerName, CpuUsage=CounterValue ) on ContainerName ) on ContainerName | order by Name asc | project Name, CpuLimit=(CpuLimit / 1000000), CpuUsage=(CpuUsage / 1000000)
            |||,
      resources=["$Workspace"],
	  resultFormat= 'table'
    )
).addOverridesByFieldName(
  field='Name',
  properties=[
    { id: 'custom.width', value: 300 }
  ]
).addOverridesByFieldName(
  field='CpuLimit',
  properties=[
    { id: 'custom.width', value: 80 },
    { id: 'custom.align', value: 'center' }
  ]
).addOverridesByFieldName(
  field='CpuUsage',
  properties=[
    { id: 'custom.width', value: 85 },
    { id: 'custom.align', value: 'center' }
  ]
);

local CPUUsagePerPod = grafana.graphPanel.new(
  title = 'CPU Usage Per Pod ( in millicores )',
  datasource = 'Azure Monitor',
  fill=0,
  linewidth=2,
  decimals=2,
  min=0,
  format='none',
  nullPointMode='connected',
  legend_values=true,
  legend_alignAsTable=true,
  legend_rightSide=true,
  legend_min=true,
  legend_max=true,
  legend_current=true,
  legend_total=true,
  legend_avg=true
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              KubePodInventory| where $__timeFilter(TimeGenerated)| where ClusterName == "$AKS"| where Namespace == "$Namespace"| summarize arg_max(TimeGenerated, *) by ContainerName| project Name, ContainerName| join kind = inner (    Perf    | where $__timeFilter(TimeGenerated)    | where ObjectName == 'K8SContainer'    | where CounterName == 'cpuUsageNanoCores'    | where InstanceName contains '$AKS'    | extend ContainerNameParts = split(InstanceName, '/')    | extend ContainerNamePartCount = array_length(ContainerNameParts)                | extend PodUIDIndex = ContainerNamePartCount - 2, ContainerNameIndex = ContainerNamePartCount - 1     | extend ContainerName = strcat(ContainerNameParts[PodUIDIndex], '/', ContainerNameParts[ContainerNameIndex])    | project TimeGenerated, ContainerName, CounterValue) on ContainerName| order by TimeGenerated asc| project TimeGenerated, Name, CounterValue=(CounterValue / 1000000)
          |||,
    resources=["$Workspace"],
	  resultFormat= 'time_series'
  )
);

local PercentageCPUUsageOverPodCPULimit = grafana.graphPanel.new(
  title = 'Percentage Pod CPU Usage over Pod CPU Limit',
  datasource = 'Azure Monitor',
  fill=0,
  linewidth=2,
  pointradius=2,
  decimals=2,
  min=0,
  format='percent',
  legend_values=true,
  legend_alignAsTable=true,
  legend_rightSide=true,
  legend_current=true,
  legend_sort='current',
  legend_sortDesc=true
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              KubePodInventory| where $__timeFilter(TimeGenerated)| where ClusterName == "$AKS"| where Namespace == "$Namespace"| summarize arg_max(TimeGenerated, *) by ContainerName| project Name, ContainerName| join kind = inner (Perf| where $__timeFilter(TimeGenerated)| where ObjectName == 'K8SContainer'| where CounterName == 'cpuLimitNanoCores'| where InstanceName contains '$AKS'| extend ContainerNameParts = split(InstanceName, '/')| extend ContainerNamePartCount = array_length(ContainerNameParts)| extend PodUIDIndex = ContainerNamePartCount - 2, ContainerNameIndex = ContainerNamePartCount - 1 | extend ContainerName = strcat(ContainerNameParts[PodUIDIndex], '/', ContainerNameParts[ContainerNameIndex])| summarize arg_max(TimeGenerated, *) by ContainerName| project ContainerName, CpuLimit=CounterValue| join kind = inner ( Perf | where $__timeFilter(TimeGenerated) | where ObjectName == 'K8SContainer' | where CounterName == 'cpuUsageNanoCores' | where InstanceName contains '$AKS' | extend ContainerNameParts = split(InstanceName, '/') | extend ContainerNamePartCount = array_length(ContainerNameParts)| extend PodUIDIndex = ContainerNamePartCount - 2, ContainerNameIndex = ContainerNamePartCount - 1| extend ContainerName = strcat(ContainerNameParts[PodUIDIndex], '/', ContainerNameParts[ContainerNameIndex]) | project TimeGenerated, ContainerName, CpuUsage=CounterValue) on ContainerName| project TimeGenerated, ContainerName, CpuPercentage=(CpuUsage / CpuLimit) * 100) on ContainerName| order by TimeGenerated asc| project TimeGenerated, Name, CpuPercentage
          |||,
    resources=["$Workspace"],
	  resultFormat= 'time_series'
  )
);

local PodCPURow = row.new(title="Pod CPU", collapse=true).addPanel(
  CurrentCPUUtlization,gridPos={h: 21, w: 7, x: 0, y: 1})
  .addPanel(CPUUsagePerPod,gridPos={h: 10, w: 17, x: 7, y: 1})
  .addPanel(PercentageCPUUsageOverPodCPULimit,gridPos={h: 11, w: 17, x: 7, y: 11});

local CurrentMemoryUsage = grafana.tablePanel.new(
    title="Memory Usage (Current)",
    datasource='Azure Monitor',
    description=""
  ).addTarget(
    target=grafana.azuremonitor.target(
      query=|||
                KubePodInventory| where TimeGenerated > ago(2m)| where ClusterName == "$AKS"| where Namespace == "$Namespace"| summarize arg_max(TimeGenerated, *) by ContainerName| project Name, ContainerName| join kind = inner ( Perf | where TimeGenerated > ago(2m) | where ObjectName == 'K8SContainer' | where CounterName == 'memoryLimitBytes' | where InstanceName contains '$AKS' | extend ContainerNameParts = split(InstanceName, '/') | extend ContainerNamePartCount = array_length(ContainerNameParts)    | extend PodUIDIndex = ContainerNamePartCount - 2, ContainerNameIndex = ContainerNamePartCount - 1  | extend ContainerName = strcat(ContainerNameParts[PodUIDIndex], '/', ContainerNameParts[ContainerNameIndex]) | summarize arg_max(TimeGenerated, *) by ContainerName | project ContainerName, MemLimit=CounterValue) on ContainerName| order by Name asc| project Name, MemLimit
            |||,
      resources=["$Workspace"],
	    resultFormat= 'table'
    )
).addOverridesByFieldName(
  field='Name',
  properties=[
    { id: 'custom.width', value: 175 }
  ]
).addOverridesByFieldName(
  field='MemLimit',
  properties=[
    { id: 'custom.width', value: 130 },
    { id: 'custom.align', value: 'center' },
    { id: 'unit', value: 'bits' },
    { id: 'thresholds',
      value: {
        mode: 'absolute',
        steps: [{ color: 'green', value: null }, { color: 'red', value: 80 }]
      }
    }
  ]
).addOverridesByFieldName(
  field='MemUsage',
  properties=[
    { id: 'custom.width', value: 95 },
    { id: 'custom.align', value: 'center' }
  ]
);

local RSSMemoryUsagePerPod = grafana.graphPanel.new(
  title = 'RSS Memory Usage Per Pod',
  datasource = 'Azure Monitor',
  fill=0,
  linewidth=2,
  decimals=2,
  min=0,
  format='bits',
  nullPointMode='connected',
  legend_values=true,
  legend_alignAsTable=true,
  legend_rightSide=true,
  legend_min=true,
  legend_max=true,
  legend_current=true,
  legend_total=true,
  legend_avg=true
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              KubePodInventory| where $__timeFilter(TimeGenerated)| where ClusterName == "$AKS"| where Namespace == "$Namespace"| summarize arg_max(TimeGenerated, *) by ContainerName| project Name, ContainerName| join kind = inner ( Perf | where $__timeFilter(TimeGenerated) | where ObjectName == 'K8SContainer' | where CounterName == 'memoryRssBytes'  | where InstanceName contains '$AKS' | extend ContainerNameParts = split(InstanceName, '/') | extend ContainerNamePartCount = array_length(ContainerNameParts) | extend PodUIDIndex = ContainerNamePartCount - 2, ContainerNameIndex = ContainerNamePartCount - 1  | extend ContainerName = strcat(ContainerNameParts[PodUIDIndex], '/', ContainerNameParts[ContainerNameIndex]) | project TimeGenerated, ContainerName, CounterValue) on ContainerName| order by TimeGenerated asc| project TimeGenerated, Name, CounterValue=(CounterValue)
          |||,
    resources=["$Workspace"],
	  resultFormat= 'time_series'
  )
);

local MemoryWorkingSetByPod = grafana.graphPanel.new(
  title = 'Memory Working Set by Pod',
  datasource = 'Azure Monitor',
  fill=10,
  format='bits',
  nullPointMode='connected'
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              KubePodInventory | where $__timeFilter(TimeGenerated) | where ClusterName == "$AKS" | where Namespace == "$Namespace" | summarize arg_max(TimeGenerated, *) by ContainerName | project Name, ContainerName | join kind = inner ( Perf | where $__timeFilter(TimeGenerated) | where ObjectName == 'K8SContainer' | where CounterName == 'memoryWorkingSetBytes'  | where InstanceName contains '$AKS' | extend ContainerNameParts = split(InstanceName, '/') | extend ContainerNamePartCount = array_length(ContainerNameParts)  | extend PodUIDIndex = ContainerNamePartCount - 2, ContainerNameIndex = ContainerNamePartCount - 1  | extend ContainerName = strcat(ContainerNameParts[PodUIDIndex], '/', ContainerNameParts[ContainerNameIndex]) | project TimeGenerated, ContainerName, CounterValue ) on ContainerName | order by TimeGenerated asc | project TimeGenerated, Name, CounterValue=(CounterValue)
          |||,
    resources=["$Workspace"],
	  resultFormat= 'time_series'
  )
);

local PercentageMemoryRSSUsageAgainstMemoryLimit = grafana.graphPanel.new(
  title = 'Percentage Memory(RSS) Usage against Memory Limit',
  datasource = 'Azure Monitor',
  fill=0,
  linewidth=2,
  decimals=2,
  min=0,
  format='percent',
  nullPointMode='connected',
  legend_values=true,
  legend_alignAsTable=true,
  legend_rightSide=true,
  legend_min=true,
  legend_max=true,
  legend_current=true,
  legend_total=true,
  legend_avg=true
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              KubePodInventory | where $__timeFilter(TimeGenerated) | where ClusterName == "$AKS" | where Namespace == "$Namespace" | summarize arg_max(TimeGenerated, *) by ContainerName | project Name, ContainerName | join kind = inner ( Perf | where $__timeFilter(TimeGenerated) | where ObjectName == 'K8SContainer' | where CounterName == 'memoryLimitBytes' | where InstanceName contains '$AKS' | extend ContainerNameParts = split(InstanceName, '/') | extend ContainerNamePartCount = array_length(ContainerNameParts)  | extend PodUIDIndex = ContainerNamePartCount - 2, ContainerNameIndex = ContainerNamePartCount - 1  | extend ContainerName = strcat(ContainerNameParts[PodUIDIndex], '/', ContainerNameParts[ContainerNameIndex]) | summarize arg_max(TimeGenerated, *) by ContainerName | project ContainerName, MemLimit=CounterValue | join kind = inner ( Perf | where $__timeFilter(TimeGenerated) | where ObjectName == 'K8SContainer' | where CounterName == 'memoryRssBytes' | where InstanceName contains '$AKS' | extend ContainerNameParts = split(InstanceName, '/') | extend ContainerNamePartCount = array_length(ContainerNameParts) | extend PodUIDIndex = ContainerNamePartCount - 2, ContainerNameIndex = ContainerNamePartCount - 1 | extend ContainerName = strcat(ContainerNameParts[PodUIDIndex], '/', ContainerNameParts[ContainerNameIndex]) | project TimeGenerated, ContainerName, MemUsage=CounterValue ) on ContainerName | project TimeGenerated, ContainerName, MemPercentage=(MemUsage / MemLimit) * 100 ) on ContainerName | order by TimeGenerated asc | project TimeGenerated, Name, MemPercentage
          |||,
    resources=["$Workspace"],
	  resultFormat= 'time_series'
  )
);

local PercentageMemoryWSUsageAgainstMemoryLimit = grafana.graphPanel.new(
  title = 'Percentage Memory(Working Set) Usage against Memory Limit',
  datasource = 'Azure Monitor',
  fill=0,
  linewidth=2,
  decimals=2,
  min=0,
  format='percent',
  nullPointMode='connected',
  legend_min=true,
  legend_max=true,
  legend_current=true,
  legend_total=true,
  legend_avg=true,
  legend_alignAsTable=true,
  legend_rightSide=true,
  legend_values=true
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              KubePodInventory| where $__timeFilter(TimeGenerated)| where ClusterName == "$AKS"| where Namespace == "$Namespace"| summarize arg_max(TimeGenerated, *) by ContainerName| project Name, ContainerName| join kind = inner ( Perf | where $__timeFilter(TimeGenerated) | where ObjectName == 'K8SContainer' | where CounterName == 'memoryLimitBytes' | where InstanceName contains '$AKS' | extend ContainerNameParts = split(InstanceName, '/') | extend ContainerNamePartCount = array_length(ContainerNameParts) | extend PodUIDIndex = ContainerNamePartCount - 2, ContainerNameIndex = ContainerNamePartCount - 1  | extend ContainerName = strcat(ContainerNameParts[PodUIDIndex], '/', ContainerNameParts[ContainerNameIndex]) | summarize arg_max(TimeGenerated, *) by ContainerName | project ContainerName, MemLimit=CounterValue | join kind = inner (  Perf  | where $__timeFilter(TimeGenerated)  | where ObjectName == 'K8SContainer'  | where CounterName == 'memoryWorkingSetBytes'  | where InstanceName contains '$AKS'  | extend ContainerNameParts = split(InstanceName, '/')  | extend ContainerNamePartCount = array_length(ContainerNameParts)  | extend PodUIDIndex = ContainerNamePartCount - 2, ContainerNameIndex = ContainerNamePartCount - 1   | extend ContainerName = strcat(ContainerNameParts[PodUIDIndex], '/', ContainerNameParts[ContainerNameIndex])  | project TimeGenerated, ContainerName, MemUsage=CounterValue ) on ContainerName | project TimeGenerated, ContainerName, MemPercentage=(MemUsage / MemLimit) * 100) on ContainerName| order by TimeGenerated asc| project TimeGenerated, Name, MemPercentage
          |||,
    resources=["$Workspace"],
	  resultFormat= 'time_series'
  )
);

local PodMemoryUsageRow = row.new(title="Pod Memory Usage Metrics", collapse=true).addPanel(
  CurrentMemoryUsage,gridPos={h: 21, w: 7, x: 0, y: 23})
  .addPanel(RSSMemoryUsagePerPod,gridPos={h: 11, w: 17, x: 7, y: 23})
  .addPanel(MemoryWorkingSetByPod,gridPos={h: 10, w: 17, x: 7, y: 34})
  .addPanel(PercentageMemoryRSSUsageAgainstMemoryLimit,gridPos={h: 10, w: 12, x: 0, y: 44})
  .addPanel(PercentageMemoryWSUsageAgainstMemoryLimit,gridPos={h: 10, w: 12, x: 12, y: 44});

local PodOverviewPanel = grafana.tablePanel.new(
    title="Pod Overview",
    datasource='Azure Monitor',
    description=""
  ).addTarget(
    target=grafana.azuremonitor.target(
      query=|||
                KubePodInventory | where TimeGenerated > ago(30m) | where ClusterName == "$AKS" | where Namespace == "$Namespace" | summarize arg_max(TimeGenerated, *) by Name | project Pod=Name, Namespace, PodStatus, Node=Computer, PodRestartCount, ContainerRestartCount, PodStartTime, ControllerKind
            |||,
      resources=["$Workspace"],
	    resultFormat= 'table'
    )
).addOverridesByFieldName(
  field='Node',
  properties=[
    { id: 'custom.width', value: 318 }
  ]
);

local PodsPerNamespaces = grafana.graphPanel.new(
  title = 'Pods per Namespaces',
  datasource = 'Azure Monitor',
  bars=true,
  lines=false,
  pointradius=2,
  legend_alignAsTable=true,
  legend_rightSide=true,
  show_xaxis=false,
  x_axis_mode='series',
  formatY1='none',
  min=0,
  decimalsY1=0,
  formatY2='none'
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              KubePodInventory | where TimeGenerated > ago(2m) | where ClusterName == "$AKS" | summarize arg_max(TimeGenerated, *) by Name | summarize qtd=count() by Namespace | project now(), Namespace, qtd
          |||,
    resources=["$Workspace"],
	  resultFormat= 'time_series'
  )
);

local PodCountByNamespace = grafana.graphPanel.new(
  title = 'Pod Count by Namespace',
  datasource = 'Azure Monitor',
  fill=0,
  linewidth=2,
  pointradius=2,
  legend_alignAsTable=true,
  legend_rightSide=true
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              KubePodInventory | where $__timeFilter(TimeGenerated) | where ClusterName == "$AKS" | summarize count() by TimeGenerated, Namespace | order by TimeGenerated asc
          |||,
    resources=["$Workspace"],
	  resultFormat= 'time_series'
  )
);

local PodOverviewRow = row.new(title="Pod Overview", collapse=true).addPanel(
  PodOverviewPanel,gridPos={h: 7, w: 24, x: 0, y: 9})
  .addPanel(PodsPerNamespaces,gridPos={h: 9, w: 6, x: 0, y: 16})
  .addPanel(PodCountByNamespace,gridPos={h: 9, w: 18, x: 6, y: 16});

grafana.dashboard.new(
  title= 'AKS Pods Metrics Monitor',
  time_from='now-1h',
  time_to='now',
  uid='21rD148loTpLs',
  schemaVersion=37,
  editable=false,
  graphTooltip=0,
  description='Azure Monitor for Containers sources collection of metrics as part of monitoring an AKS cluster. Out of the box, we can get dashboards for Node Level and Namespace level metrics in Grafana through App Insights and Log Analytics. This dashboard helps us to visualize pod level and container metric.',
  tags=['monitoring', 'sre', 'observability']
)
.addTemplate(TemplateDataSource)
.addTemplate(TemplateSubscription)
.addTemplate(TemplateWorkspace)
.addTemplate(TemplateResourceGroups)
.addTemplate(TemplateAKS)
.addTemplate(TemplateNamespace)
.addPanel(panel=PodCPURow, gridPos={h: 1, w: 24, x: 0, y: 0})
.addPanel(panel=PodMemoryUsageRow, gridPos={h: 1, w: 24, x: 0, y: 22})
.addPanel(panel=PodOverviewRow, gridPos={h: 1, w: 24, x: 0, y: 54})
