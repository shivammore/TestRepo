local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;
local gaugePanel = grafana.gaugePanel;


local LinkAMContainerInsights = {
  title:'Azure Monitor - Container Insights',
  url:'https://portal.azure.com/#@sodexo.onmicrosoft.com/resource$clusterid/infrainsights',
  tooltip:'Click here to open Azure Monitor Ux for this cluster',
  targetBlank:true,
  type:'link',
  asDropdown:true,
  includeVars:false,
  keepTime:false,
  tags:[]
};

local TemplateDataSource = tmpl.datasource(
  name='ds',
  label='Datasource',
  query='grafana-azure-monitor-datasource',
  current='Azure Monitor',
  refresh='load'
);

local TemplateSubscription = tmpl.new(
  name='sub',
  label='Subscription',
  datasource='${ds}',
  refresh='load',
  includeAll=false,
  query={
    grafanaTemplateVariableFn: {
      kind: 'SubscriptionsQuery',
      rawQuery: 'Subscriptions()'
    },
    queryType: 'Grafana Template Variable Function',
    refId: 'A',
    subscription: ''
  }
);

local TemplateWorkspace = tmpl.new(
  name='ws',
  label='Workspace',
  datasource='${ds}',
  refresh='load',
  includeAll=false,
  query={
    grafanaTemplateVariableFn: {
      kind: 'WorkspacesQuery',
      rawQuery: 'Workspaces($sub)',
      subscription: '$sub'
    },
    queryType: 'Grafana Template Variable Function',
    refId: 'A',
    subscription: ''
  }
);

local TemplateClusters = tmpl.new(
  name='clusterid',
  label='Cluster',
  datasource='${ds}',
  refresh='load',
  includeAll=false,
  query={
    azureLogAnalytics: {
      query: 'workspace("$ws").KubePodInventory | summarize n=count() by ClusterId |project ClusterId ',
      resource: '$ws'
    },
    queryType: 'Azure Log Analytics',
    refId: 'A',
    subscription: ''
  }
);

local TemplatePercentile = tmpl.custom(
  name='ptile',
  label='Percentile (applicable for percentile charts)',
  query='50,75,80,85,90,95,96,97,98,99,99.9',
  refresh='load',
  includeAll=false,
  current='99'
);

local ClusterCPUUtilization = gaugePanel.new(
  title='Cluster CPU Utilization',
  datasource='${ds}',
  description='% Allocatable CPU used across all nodes in the cluster',
  min=0,
  max=100
)
.addThresholds(steps=[
      { color: 'green', value: 0 },
      { color: 'red', value: 80 }
])
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
                  let allocatable = Perf | where ObjectName == "K8SNode" | where CounterName == "cpuCapacityNanoCores" | where $__timeFilter(TimeGenerated) | where InstanceName startswith "$clusterid" | summarize arg_max(TimeGenerated, * ) by Computer | summarize a=toreal(sum(CounterValue) /1000000) | project a, b="abc"; allocatable | join kind=inner (Perf | where ObjectName == "K8SNode" | where CounterName == "cpuUsageNanoCores" | where $__timeFilter(TimeGenerated) | where InstanceName startswith "$clusterid" | summarize arg_max(TimeGenerated, * ) by Computer | summarize x=toreal(sum(CounterValue) /1000000) | project x,y="abc") on $left.b == $right.y | project now(), (x/a) * 100
          |||,
    resources=["$ws"],
    resultFormat='time_series'
  )
);

local ClusterMemoryUtilization = gaugePanel.new(
  title='Cluster Memory Utilization',
  datasource='${ds}',
  description='% Allocatable memory (workingset) used across all nodes in the cluster',
  min=0,
  max=100
)
.addThresholds(steps=[
      { color: 'green', value: 0 },
      { color: 'red', value: 80 }
])
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
                  let allocatable = Perf | where ObjectName == "K8SNode" | where CounterName == "memoryCapacityBytes"  | where $__timeFilter(TimeGenerated)  | where InstanceName startswith '$clusterid' | summarize arg_max(TimeGenerated, * ) by Computer | summarize a=toreal(sum(CounterValue)) | project a, b="abc";  allocatable  | join kind=inner ( Perf | where ObjectName == "K8SNode" | where CounterName == "memoryWorkingSetBytes" | where $__timeFilter(TimeGenerated) | where InstanceName startswith '$clusterid' | summarize arg_max(TimeGenerated, * ) by Computer | summarize x=toreal(sum(CounterValue)) | project x,y="abc" ) on $left.b == $right.y |project now(), (x/a) * 100
          |||,
    resources=["$ws"],
    resultFormat='time_series'
  )
);

local NodeCountByStatus = barChart.new(
  title="Node Count by Status",
  description='Number of nodes in the cluster grouped by status',
  datasource='${ds}'
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
                  KubeNodeInventory | where ClusterId == '$clusterid' | where $__timeFilter(TimeGenerated) | summarize count() by bin(TimeGenerated, $__interval), Computer, Status | summarize arg_max(TimeGenerated, *) by Computer, Status | summarize nodecount=count() by Status | project nodecount, Status , now()
          |||,
    resources=["$ws"],
    resultFormat= 'time_series'
  )
);

local PodCountByStatus = barChart.new(
  title="Pod Count by Status",
  description='Pod count grouped by Pod Status',
  datasource='${ds}'
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
                  KubePodInventory | where ClusterId == '$clusterid' | where $__timeFilter(TimeGenerated) | summarize count() by bin(TimeGenerated, $__interval), PodUid, PodStatus | summarize arg_max(TimeGenerated, *) by PodUid, PodStatus | summarize podCount = count() by PodStatus | project podCount, PodStatus , now()
          |||,
    resources=["$ws"],
    resultFormat= 'time_series'
  )
);

local ControllerCountByControllerKind = barChart.new(
  title="Controller count by Controller Kind",
  description='Number of controllers in the cluster by Controller Kind',
  datasource='${ds}'
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
                  KubePodInventory | where ClusterId == '$clusterid' | where $__timeFilter(TimeGenerated) | summarize count() by bin(TimeGenerated, $__interval), PodUid, ControllerKind | summarize arg_max(TimeGenerated, *) by PodUid, ControllerKind | summarize controllerCount = count() by ControllerKind | extend ControllerKind=iif(isempty(ControllerKind), "None", ControllerKind) | project ControllerKind, controllerCount , now()
          |||,
    resources=["$ws"],
    resultFormat= 'time_series'
  )
);

local NodeDisksWithUsedSpaceOverThreshold = barChart.new(
  title="Node disks with > 80% used space",
  description='% Used Disk grouped by Disk in each node where usage > 80%',
  datasource='${ds}'
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
                  InsightsMetrics | extend tags=todynamic(Tags) | where Name =="used_percent" | where tags["container.azm.ms/clusterId"] == '$clusterid' | where $__timeFilter(TimeGenerated) | extend hostName=tags.hostName | extend device=tags.device | extend disk=strcat(device, "/" , hostName)  | summarize arg_max(TimeGenerated, *) by disk | where Val > 80.0 | sort by Val desc | project Val, disk, now()
          |||,
    resources=["$ws"],
    resultFormat= 'time_series'
  )
);

local ClusterOverviewUtilizationRow = row.new(title="Cluster - Overview and utilization", collapse=true).addPanel(
  ClusterCPUUtilization,gridPos={h: 8, w: 12, x: 0, y: 1})
  .addPanel(
  ClusterMemoryUtilization,gridPos={h: 8, w: 12, x: 12, y: 1})
  .addPanel(
  NodeCountByStatus,gridPos={h: 9, w: 8, x: 0, y: 9})
  .addPanel(
  PodCountByStatus,gridPos={h: 9, w: 8, x: 8, y: 9})
  .addPanel(
  ControllerCountByControllerKind,gridPos={h: 9, w: 8, x: 16, y: 9})
  .addPanel(
  NodeDisksWithUsedSpaceOverThreshold,gridPos={h: 8, w: 8, x: 0, y: 18});

local KubernetesNamespaceCount = statPanel.new(
  title="Kubernetes Namespace count",
  datasource='${ds}',
  description="Number of namespaces in the cluster",
  graphMode='none',
  orientation='horizontal',
  reducerFunction='lastNotNull',
  decimals=0
)
.addThresholds(steps=[
      { color: 'green', value: 0 },
      { color: 'red', value: 80 }
])
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
             KubePodInventory | where ClusterId == '$clusterid' | where $__timeFilter(TimeGenerated) | summarize count() by bin(TimeGenerated, $__interval), Namespace | summarize arg_max(TimeGenerated, *) by Namespace | summarize namespaceCount = count() | project namespaceCount,now()
           |||,
    resources=["$ws"],
	resultFormat= 'time_series'
  )
);

local PodCountByNamespace = barChart.new(
  title="Pod count by Kubernetes Namespace",
  description='Number of pods per namespace',
  datasource='${ds}'
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
             KubePodInventory | where ClusterId == '$clusterid' | where $__timeFilter(TimeGenerated) | summarize count() by bin(TimeGenerated, $__interval), PodUid, Namespace | summarize arg_max(TimeGenerated, *) by PodUid, Namespace | summarize namespaceCount = count() by Namespace | sort by namespaceCount desc | project namespaceCount, Namespace, now()
           |||,
    resources=["$ws"],
	resultFormat= 'time_series'
  )
);

local ControllerCountByNamespace = barChart.new(
  title="Controller count by Kubernetes Namespace",
  description='Number of controllers per namespace',
  datasource='${ds}'
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
             KubePodInventory | where ClusterId == '$clusterid' | where $__timeFilter(TimeGenerated) | summarize count() by bin(TimeGenerated, $__interval), PodUid, Namespace, ControllerKind | summarize arg_max(TimeGenerated, *) by PodUid, Namespace, ControllerKind | summarize controllerCountByNamespace = count() by Namespace, ControllerKind | sort by controllerCountByNamespace desc | project controllerCountByNamespace, Namespace, now()
           |||,
    resources=["$ws"],
	resultFormat= 'time_series'
  )
);

local ControllerCountByNamespaceByKind = barChart.new(
  title="Controller Kind by Kubernetes Namespace (namespace/controllerkind)",
  description='Number of controllers per namespace per kind',
  datasource='${ds}'
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
             KubePodInventory | where ClusterId == '$clusterid' | where $__timeFilter(TimeGenerated) | summarize count() by bin(TimeGenerated, $__interval), PodUid, Namespace, ControllerKind | summarize arg_max(TimeGenerated, *) by PodUid, nsc = strcat(Namespace,"/", ControllerKind) | summarize controllerCountByNamespace = count() by nsc | sort by controllerCountByNamespace desc | project controllerCountByNamespace, nsc, now()
           |||,
    resources=["$ws"],
	resultFormat= 'time_series'
  )
);

local CPUUtilizationByNamespace = barChart.new(
  title="Cluster CPU Utilization % by Kubernetes Namespace",
  description='CPU % utilized by each namespace',
  datasource='${ds}'
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              let allocatable = Perf | where ObjectName == "K8SNode" | where CounterName == "cpuCapacityNanoCores" 
              | where $__timeFilter(TimeGenerated) 
              | where InstanceName startswith '$clusterid'
              | summarize arg_max(TimeGenerated, * ) by Computer
              | summarize a=toreal(sum(CounterValue))
              | project a, b="abc";
              allocatable 
              | join kind=inner (
                  Perf | where ObjectName == "K8SContainer" | where CounterName == "cpuUsageNanoCores" 
                  | where $__timeFilter(TimeGenerated) 
                  | where InstanceName startswith '$clusterid'
                  | extend cnameArr = split(InstanceName, "/")
                  | extend h=array_length(cnameArr)-1
                  | extend l=array_length(cnameArr)-2
                  | extend cname = strcat(cnameArr[l], "/", cnameArr[h])
                  | extend x= CounterValue 
                  | summarize arg_max(TimeGenerated, * ) by cname 
                  | project x,y="abc", cname, TimeGenerated
                    | join kind=inner ( KubePodInventory
                    | where $__timeFilter(TimeGenerated) 
                    | where ClusterId == '$clusterid'
                    | summarize arg_max(TimeGenerated, *) by ContainerName
                    | project ContainerName, Namespace
                    ) on $left.cname == $right.ContainerName
                  ) on $left.b == $right.y 
                  | summarize xyz= toreal(sum(x)) by a, Namespace
                  | order by xyz desc
                  |project now(), (xyz/a) * 100, Namespace
           |||,
    resources=["$ws"],
	resultFormat= 'time_series'
  )
);

local MemoryUtilizationByNamespace = barChart.new(
  title="Cluster Memory Utilization % by Kubernetes Namespace",
  description='Memory usage (working set) by namespace',
  datasource='${ds}'
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              let allocatable = Perf | where ObjectName == "K8SNode" | where CounterName == "memoryCapacityBytes" 
              | where $__timeFilter(TimeGenerated) 
              | where InstanceName startswith '$clusterid'
              | summarize arg_max(TimeGenerated, * ) by Computer
              | summarize a=toreal(sum(CounterValue))
              | project a, b="abc";
              allocatable 
              | join kind=inner (
                  Perf | where ObjectName == "K8SContainer" | where CounterName == "memoryWorkingSetBytes" 
                  | where $__timeFilter(TimeGenerated) 
                  | where InstanceName startswith '$clusterid'
                  | extend cnameArr = split(InstanceName, "/")
                  | extend h=array_length(cnameArr)-1
                  | extend l=array_length(cnameArr)-2
                  | extend cname = strcat(cnameArr[l], "/", cnameArr[h])
                  | extend x= CounterValue 
                  | summarize arg_max(TimeGenerated, * ) by cname
                  | project x,y="abc", cname, TimeGenerated
                      | join kind=inner ( KubePodInventory
                      | where $__timeFilter(TimeGenerated) 
                      | where ClusterId == '$clusterid'
                      | summarize arg_max(TimeGenerated, *) by ContainerName
                      | project ContainerName, Namespace
                      ) on $left.cname == $right.ContainerName
                  ) on $left.b == $right.y 
                  | summarize xyz= toreal(sum(x)) by a, Namespace
                  | order by xyz desc
                  |project now(), (xyz/a) * 100, Namespace  
           |||,
    resources=["$ws"],
	resultFormat= 'time_series'
  )
);

local ClusterNamespacesRow = row.new(title="Cluster - Namespaces", collapse=true).addPanel(
  KubernetesNamespaceCount,gridPos={h: 8, w: 3, x: 0, y: 27})
  .addPanel(
  PodCountByNamespace,gridPos={h: 8, w: 6, x: 3, y: 27})
  .addPanel(
  ControllerCountByNamespace,gridPos={h: 8, w: 7, x: 9, y: 27})
  .addPanel(
  ControllerCountByNamespaceByKind,gridPos={h: 8, w: 8, x: 16, y: 27})
  .addPanel(
  CPUUtilizationByNamespace,gridPos={h: 8, w: 12, x: 0, y: 35})
  .addPanel(
  MemoryUtilizationByNamespace,gridPos={h: 8, w: 12, x: 12, y: 35});

local PercentileCPUUsageByNode = grafana.graphPanel.new(
  title = '$ptile-th Percentile % CPU usage by node',
  datasource = '${ds}',
  linewidth=2,
  format='percent',
  legend_alignAsTable=true,
  legend_rightSide=true,
  transparent=true
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              let nodeCpuCapacity=Perf | where CounterName == "cpuCapacityNanoCores" | where ObjectName == "K8SNode" | where InstanceName startswith '$clusterid' | where $__timeFilter(TimeGenerated)| summarize arg_max(TimeGenerated, *) by Computer| project Computer , cpuCapacity=CounterValue;
              let nodeCpuUsage=Perf | where CounterName == "cpuUsageNanoCores"| where ObjectName  == "K8SNode"| where InstanceName startswith '$clusterid'| where $__timeFilter(TimeGenerated) | summarize ptileCpuUsage=percentile(CounterValue, $ptile) by Computer, bin(TimeGenerated, $__interval);
                nodeCpuUsage|join kind=inner (nodeCpuCapacity) on $left.Computer == $right.Computer| extend ptileCpuUsagepercent=(ptileCpuUsage/cpuCapacity) * 100| order by TimeGenerated asc| project TimeGenerated, Computer, ptileCpuUsagepercent
           |||,
    resources=["$ws"],
	  resultFormat= 'time_series'
  )
);

local PercentileMemoryUsageByNode = grafana.graphPanel.new(
  title = '$ptile-th Percentile Memory (rss) usage by node',
  datasource = '${ds}',
  linewidth=2,
  decimals=0,
  format='percent',
  legend_alignAsTable=true,
  legend_rightSide=true,
  transparent=true
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              let nodeMemoryCapacity=Perf| where CounterName == "memoryCapacityBytes"| where ObjectName == "K8SNode" | where InstanceName startswith '$clusterid'| where $__timeFilter(TimeGenerated)| summarize arg_max(TimeGenerated, *) by Computer| project Computer , memoryCapacity=CounterValue;
              let nodeMemoryUsage= Perf | where CounterName == "memoryRssBytes"| where ObjectName  == "K8SNode"| where InstanceName startswith '$clusterid'| where $__timeFilter(TimeGenerated) | summarize ptileMemoryUsage=percentile(CounterValue, $ptile) by Computer, bin(TimeGenerated, $__interval);
                nodeMemoryUsage|join kind=inner (nodeMemoryCapacity) on $left.Computer == $right.Computer| extend ptileMemoryUsagepercent=(ptileMemoryUsage/memoryCapacity) * 100| order by TimeGenerated asc| project TimeGenerated, Computer, ptileMemoryUsagepercent
          |||,
    resources=["$ws"],
	  resultFormat= 'time_series'
  )
);

local NodeCPUAndMemoryRow = row.new(title="Node - CPU & Memory", collapse=true).addPanel(
  PercentileCPUUsageByNode,gridPos={h: 8, w: 12, x: 0, y: 44})
  .addPanel(
  PercentileMemoryUsageByNode,gridPos={h: 8, w: 12, x: 12, y: 44});

local PercentileDiskUsageByNode = grafana.graphPanel.new(
  title = '% Used Disk ($ptile-th percentile) by Disk/Node',
  description = '$ptile-th percentile, % Used Disk grouped by Disk in each node',
  datasource = '${ds}',
  linewidth=2,
  format='percent',
  legend_alignAsTable=true,
  legend_rightSide=true,
  transparent=true
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              InsightsMetrics| extend tags=todynamic(Tags) | where Name =="used_percent" | where tags["container.azm.ms/clusterId"] == '$clusterid' | where $__timeFilter(TimeGenerated) | extend hostName=tags.hostName | extend device=tags.device | extend disk=strcat(device, "/" , hostName) | summarize ptileDiskUsagePercentagebyNodeDisk = percentile(Val,$ptile) by bin(TimeGenerated, $__interval), disk | order by TimeGenerated asc | project TimeGenerated, disk, ptileDiskUsagePercentagebyNodeDisk
          |||,
    resources=["$ws"],
	  resultFormat= 'time_series'
  )
);

local PercentileIOpsInprogressByDiskPerNode = grafana.graphPanel.new(
  title = 'iops in progress ($ptile-th percentile) by Disk/Node',
  description = '$ptile-th percentile iops in progress grouped by Disk in each node',
  datasource = '${ds}',
  linewidth=2,
  legend_alignAsTable=true,
  legend_rightSide=true,
  transparent=true
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              InsightsMetrics | extend tags=todynamic(Tags)  | where Name =="iops_in_progress" | where tags["container.azm.ms/clusterId"] == '$clusterid' | where $__timeFilter(TimeGenerated)  | extend hostName=tags.hostName | extend device=tags.name | extend disk=strcat(device, "/" , hostName)  | summarize ptileDiskIopsInProgressbyNodeDisk = percentile(Val,$ptile) by bin(TimeGenerated, $__interval), disk | order by TimeGenerated asc | project TimeGenerated, disk, ptileDiskIopsInProgressbyNodeDisk
          |||,
    resources=["$ws"],
	  resultFormat= 'time_series'
  )
);

local PercentileDiskReadsPerSecByDiskPerNode = grafana.graphPanel.new(
  title = 'Disk reads/sec ($ptile-th percentile) by disk/node',
  description = 'Reads/sec ($ptile-th percentile) grouped by Disk in each node',
  datasource = '${ds}',
  linewidth=2,
  legend_alignAsTable=true,
  legend_rightSide=true,
  transparent=true
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              InsightsMetrics| where Origin == 'container.azm.ms/telegraf'| where Namespace == 'container.azm.ms/diskio'| where Name == 'reads'| where $__timeFilter(TimeGenerated) | extend Tags = todynamic(Tags)| extend HostName = tostring(Tags.hostName), Device = tostring(Tags.name), clusterId = tostring(Tags["container.azm.ms/clusterId"])| where clusterId == '$clusterid'| extend NodeDisk = strcat(Device, "/", HostName)| summarize Val=percentile(Val,$ptile) by NodeDisk, TimeGenerated=bin(TimeGenerated,$__interval)| order by NodeDisk asc, TimeGenerated asc| serialize| extend PrevVal = iif(prev(NodeDisk) != NodeDisk, 0.0, prev(Val)), PrevTimeGenerated = iif(prev(NodeDisk) != NodeDisk, datetime(null), prev(TimeGenerated))| where isnotnull(PrevTimeGenerated) and PrevTimeGenerated != TimeGenerated| extend Rate = iif(PrevVal > Val, Val / (datetime_diff('Second', TimeGenerated, PrevTimeGenerated) * 1), iif(PrevVal == Val, 0.0, (Val - PrevVal) / (datetime_diff('Second', TimeGenerated, PrevTimeGenerated) * 1)))| where isnotnull(Rate)| order by TimeGenerated asc| project TimeGenerated, NodeDisk, Rate|render timechart
          |||,
    resources=["$ws"],
	  resultFormat= 'table'
  )
);

local PercentileDiskWriteBytesPerSecByDiskPerNode = grafana.graphPanel.new(
  title = 'Disk write bytes/sec ($ptile-th percentile) by disk/node',
  description = 'Write bytes/sec ($ptile-th percentile) grouped by Disk in each node',
  datasource = '${ds}',
  linewidth=2,
  format='Bps',
  legend_alignAsTable=true,
  legend_rightSide=true,
  transparent=true
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              InsightsMetrics| where Origin == 'container.azm.ms/telegraf'| where Namespace == 'container.azm.ms/diskio'| where Name == 'write_bytes'| where $__timeFilter(TimeGenerated) | extend Tags = todynamic(Tags)| extend HostName = tostring(Tags.hostName), Device = tostring(Tags.name), clusterId = tostring(Tags["container.azm.ms/clusterId"])| where clusterId == '$clusterid'| extend NodeDisk = strcat(Device, "/", HostName)| summarize Val=percentile(Val,$ptile) by NodeDisk, TimeGenerated=bin(TimeGenerated,$__interval)| order by NodeDisk asc, TimeGenerated asc| serialize| extend PrevVal = iif(prev(NodeDisk) != NodeDisk, 0.0, prev(Val)), PrevTimeGenerated = iif(prev(NodeDisk) != NodeDisk, datetime(null), prev(TimeGenerated))| where isnotnull(PrevTimeGenerated) and PrevTimeGenerated != TimeGenerated| extend Rate = iif(PrevVal > Val, Val / (datetime_diff('Second', TimeGenerated, PrevTimeGenerated) * 1), iif(PrevVal == Val, 0.0, (Val - PrevVal) / (datetime_diff('Second', TimeGenerated, PrevTimeGenerated) * 1)))| where isnotnull(Rate)| order by TimeGenerated asc| project TimeGenerated, NodeDisk, Rate|render timechart
          |||,
    resources=["$ws"],
	  resultFormat= 'table'
  )
);

local NodeDiskUsageIORow = row.new(title="Node - Disk Usage & IO", collapse=true).addPanel(
  PercentileDiskUsageByNode,gridPos={h: 7, w: 12, x: 0, y: 53})
  .addPanel(
  PercentileIOpsInprogressByDiskPerNode,gridPos={h: 7, w: 12, x: 12, y: 53})
  .addPanel(
  PercentileDiskReadsPerSecByDiskPerNode,gridPos={h: 7, w: 12, x: 0, y: 60})
  .addPanel(
  PercentileDiskWriteBytesPerSecByDiskPerNode,gridPos={h: 7, w: 12, x: 12, y: 60});

local PercentileNetworkSentBytesPerSecByInterfacePerNode = grafana.graphPanel.new(
  title = 'Network sent bytes/sec ($ptile-th percentile) by interface/node',
  description = 'Sent bytes/sec ($ptile-th percentile) grouped by network interface in each node',
  datasource = '${ds}',
  linewidth=2,
  format='Bps',
  legend_alignAsTable=true,
  legend_rightSide=true,
  transparent=true
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              InsightsMetrics| where Origin == 'container.azm.ms/telegraf'| where Namespace == 'container.azm.ms/net'| where Name == 'bytes_sent'| where $__timeFilter(TimeGenerated) | extend Tags = todynamic(Tags)| extend HostName = tostring(Tags.hostName), Interface = tostring(Tags.interface), clusterId = tostring(Tags["container.azm.ms/clusterId"])| where clusterId == '$clusterid'| extend NodeInterface = strcat(Interface, "/", HostName)| summarize Val=percentile(Val,$ptile) by NodeInterface, TimeGenerated=bin(TimeGenerated,$__interval)| order by NodeInterface asc, TimeGenerated asc| serialize| extend PrevVal = iif(prev(NodeInterface) != NodeInterface, 0.0, prev(Val)), PrevTimeGenerated = iif(prev(NodeInterface) != NodeInterface, datetime(null), prev(TimeGenerated))| where isnotnull(PrevTimeGenerated) and PrevTimeGenerated != TimeGenerated| extend Rate = iif(PrevVal > Val, Val / (datetime_diff('Second', TimeGenerated, PrevTimeGenerated) * 1), iif(PrevVal == Val, 0.0, (Val - PrevVal) / (datetime_diff('Second', TimeGenerated, PrevTimeGenerated) * 1)))| where isnotnull(Rate)| order by TimeGenerated asc| project TimeGenerated, NodeInterface, Rate|render timechart
          |||,
    resources=["$ws"],
	  resultFormat= 'table'
  )
);

local PercentileNetworkReceivedBytesPerSecByInterfacePerNode = grafana.graphPanel.new(
  title = 'Network received bytes/sec ($ptile-th percentile)  by interface/node',
  description = 'Received bytes/sec ($ptile-th percentile) grouped by network interface in each node',
  datasource = '${ds}',
  linewidth=2,
  format='Bps',
  legend_alignAsTable=true,
  legend_rightSide=true,
  transparent=true
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              InsightsMetrics| where Origin == 'container.azm.ms/telegraf'| where Namespace == 'container.azm.ms/net'| where Name == 'bytes_recv'| where $__timeFilter(TimeGenerated) | extend Tags = todynamic(Tags)| extend HostName = tostring(Tags.hostName), Interface = tostring(Tags.interface), clusterId = tostring(Tags["container.azm.ms/clusterId"])| where clusterId == '$clusterid'| extend NodeInterface = strcat(Interface, "/", HostName)| summarize Val=percentile(Val,$ptile) by NodeInterface, TimeGenerated=bin(TimeGenerated,$__interval)| order by NodeInterface asc, TimeGenerated asc| serialize| extend PrevVal = iif(prev(NodeInterface) != NodeInterface, 0.0, prev(Val)), PrevTimeGenerated = iif(prev(NodeInterface) != NodeInterface, datetime(null), prev(TimeGenerated))| where isnotnull(PrevTimeGenerated) and PrevTimeGenerated != TimeGenerated| extend Rate = iif(PrevVal > Val, Val / (datetime_diff('Second', TimeGenerated, PrevTimeGenerated) * 1), iif(PrevVal == Val, 0.0, (Val - PrevVal) / (datetime_diff('Second', TimeGenerated, PrevTimeGenerated) * 1)))| where isnotnull(Rate)| order by TimeGenerated asc| project TimeGenerated, NodeInterface, Rate|render timechart
          |||,
    resources=["$ws"],
	  resultFormat= 'table'
  )
);

local PercentileNetworkSendErrorsByInterfacePerNode = grafana.graphPanel.new(
  title = 'Network send errors ($ptile-th percentle) by Interface/Node',
  description = 'Network send errors ($ptile-th percentile) grouped by interface in each node',
  datasource = '${ds}',
  linewidth=2,
  legend_alignAsTable=true,
  legend_rightSide=true,
  transparent=true
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              InsightsMetrics| extend tags=todynamic(Tags) | where Name =="err_out"| where tags["container.azm.ms/clusterId"] == '$clusterid'| where $__timeFilter(TimeGenerated) | extend hostName=tags.hostName| extend interface=tags.interface| extend nodeInterface=strcat(interface, "/" , hostName) | summarize ptileErrorsOutByNodeInterface = percentile(Val,$ptile) by bin(TimeGenerated, $__interval), nodeInterface| order by TimeGenerated asc| project TimeGenerated, nodeInterface, ptileErrorsOutByNodeInterface
          |||,
    resources=["$ws"],
	  resultFormat= 'time_series'
  )
);

local PercentileNetworkReceiveErrorsByInterfacePerNode = grafana.graphPanel.new(
  title = 'Network receive errors ($ptile-th percentle) by Interface/Node',
  description = 'Network receive errors ($ptile-th percentile) grouped by interface in each node',
  datasource = '${ds}',
  linewidth=2,
  legend_alignAsTable=true,
  legend_rightSide=true,
  transparent=true
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              InsightsMetrics | extend tags=todynamic(Tags)  | where Name =="err_in" | where tags["container.azm.ms/clusterId"] == '$clusterid' | where $__timeFilter(TimeGenerated)  | extend hostName=tags.hostName | extend interface=tags.interface | extend nodeInterface=strcat(interface, "/" , hostName)  | summarize ptileErrorsInByNodeInterface = percentile(Val,$ptile) by bin(TimeGenerated, $__interval), nodeInterface | order by TimeGenerated asc | project TimeGenerated, nodeInterface, ptileErrorsInByNodeInterface
          |||,
    resources=["$ws"],
	  resultFormat= 'time_series'
  )
);

local NodeNetworkRow = row.new(title="Node - Network", collapse=true).addPanel(
  PercentileNetworkSentBytesPerSecByInterfacePerNode,gridPos={h: 7, w: 11, x: 0, y: 68})
  .addPanel(
  PercentileNetworkReceivedBytesPerSecByInterfacePerNode,gridPos={h: 7, w: 13, x: 11, y: 68})
  .addPanel(
  PercentileNetworkSendErrorsByInterfacePerNode,gridPos={h: 6, w: 11, x: 0, y: 75})
  .addPanel(
  PercentileNetworkReceiveErrorsByInterfacePerNode,gridPos={h: 7, w: 13, x: 11, y: 75});

local PercentileKubeletDockerOpsPerSecByOperationPerNode = grafana.graphPanel.new(
  title = 'Kubelet Docker Ops/Sec ($ptile-th percentile) by operation/Node',
  description = 'Docker Operations/sec ($ptile-th percentile) grouped by operation in each node',
  datasource = '${ds}',
  linewidth=2,
  legend_alignAsTable=true,
  legend_rightSide=true,
  transparent=true
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              InsightsMetrics | where Origin == 'container.azm.ms/telegraf' | where Namespace == 'container.azm.ms/prometheus' | where Name == 'kubelet_runtime_operations_total' | where $__timeFilter(TimeGenerated) | extend Tags = todynamic(Tags) | extend HostName = tostring(Tags.hostName), optype = tostring(Tags.operation_type) , clusterId = tostring(Tags["container.azm.ms/clusterId"])| where clusterId == '$clusterid'| extend NodeOp = strcat(optype, "/", HostName) | summarize Val=percentile(Val,$ptile) by NodeOp, TimeGenerated=bin(TimeGenerated,$__interval) | order by NodeOp asc, TimeGenerated asc | serialize | extend PrevVal = iif(prev(NodeOp) != NodeOp, 0.0, prev(Val)), PrevTimeGenerated = iif(prev(NodeOp) != NodeOp, datetime(null), prev(TimeGenerated)) | where isnotnull(PrevTimeGenerated) and PrevTimeGenerated != TimeGenerated | extend Rate = iif(PrevVal > Val, Val / (datetime_diff('Second', TimeGenerated, PrevTimeGenerated) * 1), iif(PrevVal == Val, 0.0, (Val - PrevVal) / (datetime_diff('Second', TimeGenerated, PrevTimeGenerated) * 1))) | where isnotnull(Rate) | order by TimeGenerated asc | project TimeGenerated, NodeOp, Rate |render timechart
          |||,
    resources=["$ws"],
	  resultFormat= 'table'
  )
);

local PercentileKubeletDockerOpsErrorsPerSecByOperationPerNode = grafana.graphPanel.new(
  title = 'Kubelet Docker operation errors/Sec ($ptile-th percentile) by operation/Node',
  description = 'Docker Operation errors/sec ($ptile-th percentile) grouped by operation in each node',
  datasource = '${ds}',
  linewidth=2,
  legend_alignAsTable=true,
  legend_rightSide=true,
  transparent=true
)
.addTarget(
  target=grafana.azuremonitor.target(
    query=|||
              InsightsMetrics | where Origin == 'container.azm.ms/telegraf' | where Namespace == 'container.azm.ms/prometheus' | where Name == 'kubelet_runtime_operations_errors' | where $__timeFilter(TimeGenerated) | extend Tags = todynamic(Tags) | extend HostName = tostring(Tags.hostName), optype = tostring(Tags.operation_type) , clusterId = tostring(Tags["container.azm.ms/clusterId"])| where clusterId == '$clusterid'| extend NodeOp = strcat(optype, "/", HostName) | summarize Val=percentile(Val,$ptile) by NodeOp, TimeGenerated=bin(TimeGenerated,$__interval) | order by NodeOp asc, TimeGenerated asc | serialize | extend PrevVal = iif(prev(NodeOp) != NodeOp, 0.0, prev(Val)), PrevTimeGenerated = iif(prev(NodeOp) != NodeOp, datetime(null), prev(TimeGenerated)) | where isnotnull(PrevTimeGenerated) and PrevTimeGenerated != TimeGenerated | extend Rate = iif(PrevVal > Val, Val / (datetime_diff('Second', TimeGenerated, PrevTimeGenerated) * 1), iif(PrevVal == Val, 0.0, (Val - PrevVal) / (datetime_diff('Second', TimeGenerated, PrevTimeGenerated) * 1))) | where isnotnull(Rate) | order by TimeGenerated asc | project TimeGenerated, NodeOp, Rate |render timechart
          |||,
    resources=["$ws"],
	  resultFormat= 'table'
  )
);

local NodeKubeletDockerOperationsRow = row.new(title="Node - Kubelet Docker Operations", collapse=true).addPanel(
  PercentileKubeletDockerOpsPerSecByOperationPerNode,gridPos={h: 11, w: 12, x: 0, y: 83})
  .addPanel(
  PercentileKubeletDockerOpsErrorsPerSecByOperationPerNode,gridPos={h: 11, w: 12, x: 12, y: 83});

grafana.dashboard.new(
  title= 'AKS Containers Metrics Monitor',
  time_from='now-6h',
  time_to='now',
  uid='21vFsw143edZk',
  schemaVersion=37,
  editable=false,
  graphTooltip=0,
  description='Azure Monitor - Container Insights metrics for Kubernetes clusters. Cluster utilization, namespace utilization, Node cpu & memory, Node disk usage & disk io, node network & kubelet docker operation metrics. Many more metrics that are queriable from the log analytics workspace used by Azure monitor for containers!',
  tags=['monitoring', 'sre', 'observability']
)
.addLink(LinkAMContainerInsights)
.addTemplate(TemplateDataSource)
.addTemplate(TemplateSubscription)
.addTemplate(TemplateWorkspace)
.addTemplate(TemplateClusters)
.addTemplate(TemplatePercentile)
.addPanel(panel=ClusterOverviewUtilizationRow, gridPos={h: 1, w: 24, x: 0, y: 0})
.addPanel(panel=ClusterNamespacesRow, gridPos={h: 1, w: 24, x: 0, y: 26})
.addPanel(panel=NodeCPUAndMemoryRow, gridPos={h: 1, w: 24, x: 0, y: 43})
.addPanel(panel=NodeDiskUsageIORow, gridPos={h: 1, w: 24, x: 0, y: 52})
.addPanel(panel=NodeNetworkRow, gridPos={h: 1, w: 24, x: 0, y: 67})
.addPanel(panel=NodeKubeletDockerOperationsRow, gridPos={h: 1, w: 24, x: 0, y: 82})
