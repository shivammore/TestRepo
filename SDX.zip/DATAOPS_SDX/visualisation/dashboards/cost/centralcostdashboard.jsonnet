local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;

local projectTemplate =   tmpl.new(
    name='project',
    datasource='Azure SQL Server',
    query="SELECT DISTINCT project_name from observability.event where project_name = 'oss.noram.us.ukglabor'",
    refresh='load',
    includeAll=false,
    multi=true,
    label='Project Name'
  );

local monthTemplate =   tmpl.new(
    name='month',
    datasource='Azure SQL Server',
    query="SELECT DATENAME(Month,DATEADD(Month,[observability].[dab_event_cost].month -1, '1900-01-01')) As MonthName FROM [observability].[dab_event_cost]",
    refresh='load',
    includeAll=true,
    multi=true,
    label='Month'
  );

local yearTemplate =   tmpl.new(
    name='year',
    datasource='Azure SQL Server',
    query='Select year from [observability].[dab_event_cost]',
    refresh='load',
    includeAll=true,
    multi=false,
    label='Year'
  );

  local Totalprojectcost =
  statPanel.new(
    title='Total Project Cost',
    datasource='Azure SQL Server',
    description="This visualization showcases the combined cost of Data ingestion and Data storage and Dremio storage consumption of the selected project",
    colorMode='background',
    unit='€'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
            DECLARE @IngestionCount FLOAT;
                  SELECT @IngestionCount = SUM(total_successful_ingestions) FROM [observability].[dab_event_cost]
                          WHERE REPLACE(REPLACE(project_name, '_', '.'), '-', '.') IN ($project)  
                  AND DATENAME(Month, DATEADD(Month, [observability].[dab_event_cost].month - 1, '1900-01-01')) in ($month) 
              AND year IN ($year);

              DECLARE @IngestionCost FLOAT;
              SELECT @IngestionCost = 
              CASE 
                  WHEN @IngestionCount <= 300 THEN @IngestionCount * 0.60
                  WHEN @IngestionCount > 300 AND @IngestionCount <= 2000 THEN @IngestionCount * 0.57
                  WHEN @IngestionCount > 2000 AND @IngestionCount <= 4500 THEN @IngestionCount * 0.54
                  WHEN @IngestionCount > 4500 THEN @IngestionCount * 0.51
              ELSE 0 -- Ensure there's a default case if @IngestionCount is NULL
              END;

              DECLARE @StorageCost FLOAT;

              WITH Combined_Max_Size AS (
              -- Query for Bronze
              SELECT SUM(max_sourcesize) AS total_max_size
              FROM (
                  SELECT
                      storageyear,
                      storagemonth,
                      MAX(toatlsize) AS max_sourcesize
                  FROM (
                      SELECT ReportGenerationDate,
                      YEAR(ReportGenerationDate) AS storageyear, 
                      DATENAME(Month, ReportGenerationDate) AS storagemonth, 
                      SUM(SourceSize) AS toatlsize
                  FROM [reportdata].[bronzeSourceDetailsSDX]
                  WHERE 
                      BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + Replace(REPLACE(Source, '_', '.'), '-','.') IN ($project)
                      AND DATENAME(Month, ReportGenerationDate) in ($month) 
                      AND YEAR(ReportGenerationDate) in ($year)
                  GROUP BY ReportGenerationDate,YEAR(ReportGenerationDate), DATENAME(Month, ReportGenerationDate)
                  ) AS Total_size
                  GROUP BY storageyear, storagemonth
              ) AS max_size_by_month

              UNION ALL

              -- Query for Silver
              SELECT SUM(max_sourcesize) AS total_max_size
              FROM (
                  SELECT
                      storageyear,
                      storagemonth,
                      MAX(toatlsize) AS max_sourcesize
                  FROM (
                      SELECT ReportGenerationDate,
                      YEAR(ReportGenerationDate) AS storageyear, 
                      DATENAME(Month, ReportGenerationDate) AS storagemonth, 
                      SUM(SourceSize) AS toatlsize
                  FROM [reportdata].[silverSourceDetailsSDX]
                  WHERE 
                      BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + Replace(REPLACE(Source, '_', '.'), '-','.') IN ($project)
                      AND DATENAME(Month, ReportGenerationDate) in ($month) 
                      AND YEAR(ReportGenerationDate) in ($year)
                  GROUP BY ReportGenerationDate, YEAR(ReportGenerationDate), DATENAME(Month, ReportGenerationDate)
                      ) AS Total_size
                  GROUP BY storageyear, storagemonth
              ) AS max_size_by_month

              UNION ALL

              -- Query for Gold
              SELECT SUM(max_sourcesize) AS total_max_size
              FROM (
                  SELECT
                      storageyear,
                      storagemonth,
                      MAX(toatlsize) AS max_sourcesize
                  FROM (
                      SELECT ReportGenerationDate,
                      YEAR(ReportGenerationDate) AS storageyear, 
                      DATENAME(Month, ReportGenerationDate) AS storagemonth, 
                      SUM(SourceSize) AS toatlsize
                  FROM [reportdata].[goldSourceDetailsSDX]
                  WHERE 
                      BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + Replace(REPLACE(Source, '_', '.'), '-','.') IN ($project)
                      AND DATENAME(Month, ReportGenerationDate) in ($month) 
                      AND YEAR(ReportGenerationDate) in ($year)
                  GROUP BY ReportGenerationDate, YEAR(ReportGenerationDate), DATENAME(Month, ReportGenerationDate)
                      ) AS Total_size
                  GROUP BY storageyear, storagemonth
              ) AS max_size_by_month
          )

          SELECT @StorageCost = (SUM(total_max_size) / 1073741824.0) * 1.5
          FROM Combined_Max_Size;


        DECLARE @durationminutes float
          SELECT @durationminutes = Sum(duration_minutes)
          FROM [dremio].[dremio_jobs_cost]
          WHERE 
              (dataset_fullname like ('%us.ukglabor%') or dataset_fullname like ('%us_ukglabor%'))
              AND DATENAME(Month, DATEADD(Month, [dremio].[dremio_jobs_cost].month - 1, '1900-01-01')) in ($month) 
              AND [year] IN ($year);
          
          DECLARE @JobCost FLOAT;
          select @JobCost = CASE when @durationminutes >= 1 and @durationminutes <= 100 then @durationminutes * 2.50
              when @durationminutes > 100 and @durationminutes <= 400 then @durationminutes * 1.80
              when @durationminutes > 400 and @durationminutes <= 1000 then @durationminutes * 1.25
              When @durationminutes > 1000 then @durationminutes * 1.00
          end

          DECLARE @FinalCost FLOAT;
          SET @FinalCost = ISNULL(@IngestionCost, 0) + ISNULL(@StorageCost, 0) + ISNULL(@JobCost, 0);
          SELECT @FinalCost AS FinalCost;
      ",
      format='table'
    )
  );

  local Totalingestions =
  statPanel.new(
    title='Total Ingestions',
    datasource='Azure SQL Server',
    description="This metric defines the number of total ingestions on selected project",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'blue',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
          Select SUM(total_ingestions) from [observability].[dab_event_cost]
          where replace(REPLACE(project_name, '_', '.'), '-','.') in ($project) and
          DATENAME(Month,DATEADD(Month,[observability].[dab_event_cost].month -1, '1900-01-01')) in ($month) and
          year in ($year) 
      ",
      format='table'
    )
  );

  local Successfullingestions =
  statPanel.new(
    title='successfull Ingestions',
    datasource='Azure SQL Server',
    description="This metric defines the number of successfull ingestions on selected project",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
          Select SUM(total_Successful_ingestions) from [observability].[dab_event_cost]
            where replace(REPLACE(project_name, '_', '.'),'-','.') in ($project) and
            DATENAME(Month,DATEADD(Month,[observability].[dab_event_cost].month -1, '1900-01-01')) in ($month)  and
            year in ($year)   
      ",
      format='table'
    )
  );

  local Failedingestions =
  statPanel.new(
    title='Failed Ingestions',
    datasource='Azure SQL Server',
    description="This metric defines the number of Failed ingestions on selected project",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'red',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
          Select SUM(total_failed_ingestions) from [observability].[dab_event_cost]
            where replace(REPLACE(project_name, '_', '.'),'-','.') in ($project) and
            DATENAME(Month,DATEADD(Month,[observability].[dab_event_cost].month -1, '1900-01-01')) in ($month) and
            year in ($year)   
      ",
      format='table'
    )
  );

  local CostofSuccessfulIingestions =
  statPanel.new(
    title='Cost of Successful Ingestions',
    datasource='Azure SQL Server',
    description="This metric defines the Cost of Successful Ingestions on selected project",
    colorMode='background',
    unit='€'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'purple',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
            declare @IngestionCount int
            Select @IngestionCount = SUM(total_successful_ingestions) from [observability].[dab_event_cost]
                where replace(REPLACE(project_name, '_', '.'),'-','.')  in ($project) and
                    DATENAME(Month,DATEADD(Month,[observability].[dab_event_cost].month -1, '1900-01-01')) in ($month) and
                    year in ($year);  
            select CASE when @IngestionCount <= 300 then @IngestionCount * 0.60
                when @IngestionCount > 300 and @IngestionCount <= 2000 then @IngestionCount * 0.57
                when @IngestionCount > 2000 and @IngestionCount <= 4500 then @IngestionCount * 0.54
                When @IngestionCount > 4500 then @IngestionCount * 0.51
            end
      ",
      format='table'
    )
  );

  local PanelHistogramCost = grafana.barChart.new(
    title="Cost Yearly Representation",
    description='This graph represents the monthly cost evolution for the selected project',
    datasource='Azure SQL Server',
  ).addTarget(
    target=grafana.sql.target(
      rawSql="with cte1 as
      (
	      select SUM(total_successful_ingestions) as 'IngestionCount', datename(Month, DATEADD(Month,[observability].[dab_event_cost].month -1, '1970-01-01')) as 'MonthPart',
          datepart(Month, DATEADD(Month,[observability].[dab_event_cost].month -1, '1970-01-01')) as 'MonthNumber'
		  from [observability].[dab_event_cost]
		  where replace(REPLACE(project_name, '_', '.'),'-','.') in ($project) and
            year in ($year) 
	      group by
          datename(Month, DATEADD(Month,[observability].[dab_event_cost].month -1, '1970-01-01')),
          datepart(Month, DATEADD(Month,[observability].[dab_event_cost].month -1, '1970-01-01'))
      )
        select MonthPart, CASE when IngestionCount <= 300 then IngestionCount * 0.60
            when IngestionCount > 300 and IngestionCount <= 2000 then IngestionCount * 0.57
            when IngestionCount > 2000 and IngestionCount <= 4500 then IngestionCount * 0.54
            When IngestionCount > 4500 then IngestionCount * 0.51
            end as cost
          from cte1
        order by  MonthNumber",
      format='table'
    )
  );

  local TotalStorageSizeingestions =
  statPanel.new(
    title='Total Storage Size',
    datasource='Azure SQL Server',
    description="This metric defines the total storage size of selected project",
    colorMode='background',
    unit = 'bytes'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'blue',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
          WITH Combined_Max_Size AS (
          -- Query for Bronze
            SELECT SUM(max_sourcesize) AS total_max_size
            FROM (
                SELECT
                    storageyear,
                    storagemonth,
                    MAX(toatlsize) AS max_sourcesize
                FROM (
                    SELECT ReportGenerationDate,
                        YEAR(ReportGenerationDate) AS storageyear, 
                        DATENAME(Month, ReportGenerationDate) AS storagemonth, 
                        SUM(SourceSize) AS toatlsize
                    FROM [reportdata].[bronzeSourceDetailsSDX]
                    WHERE 
                        BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + replace(REPLACE(Source, '_', '.'), '-','.') IN ($project)
                        AND DATENAME(Month, ReportGenerationDate) in ($month) 
                        AND YEAR(ReportGenerationDate) in ($year)
                    GROUP BY ReportGenerationDate,YEAR(ReportGenerationDate), DATENAME(Month, ReportGenerationDate)
                ) AS Total_size
                GROUP BY storageyear, storagemonth
            ) AS max_size_by_month

            UNION ALL

            -- Query for Silver
            SELECT SUM(max_sourcesize) AS total_max_size
            FROM (
                SELECT
                    storageyear,
                    storagemonth,
                    MAX(toatlsize) AS max_sourcesize
                FROM (
                    SELECT ReportGenerationDate,
                        YEAR(ReportGenerationDate) AS storageyear, 
                        DATENAME(Month, ReportGenerationDate) AS storagemonth, 
                        SUM(SourceSize) AS toatlsize
                    FROM [reportdata].[silverSourceDetailsSDX]
                    WHERE 
                        BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + replace(REPLACE(Source, '_', '.'), '-','.') IN ($project)
                        AND DATENAME(Month, ReportGenerationDate) in ($month) 
                        AND YEAR(ReportGenerationDate) in ($year)
                    GROUP BY ReportGenerationDate,YEAR(ReportGenerationDate), DATENAME(Month, ReportGenerationDate)
                ) AS Total_size
                GROUP BY storageyear, storagemonth
            ) AS max_size_by_month

            UNION ALL

            -- Query for Gold
            SELECT SUM(max_sourcesize) AS total_max_size
            FROM (
                SELECT
                    storageyear,
                    storagemonth,
                    MAX(toatlsize) AS max_sourcesize
                FROM (
                    SELECT ReportGenerationDate,
                        YEAR(ReportGenerationDate) AS storageyear, 
                        DATENAME(Month, ReportGenerationDate) AS storagemonth, 
                        SUM(SourceSize) AS toatlsize
                    FROM [reportdata].[goldSourceDetailsSDX]
                    WHERE 
                        BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + replace(REPLACE(Source, '_', '.'), '-','.') IN ($project)
                        AND DATENAME(Month, ReportGenerationDate) in ($month) 
                        AND YEAR(ReportGenerationDate) in ($year)
                    GROUP BY ReportGenerationDate,YEAR(ReportGenerationDate), DATENAME(Month, ReportGenerationDate)
                ) AS Total_size
                GROUP BY storageyear, storagemonth
            ) AS max_size_by_month
        )

        SELECT SUM(total_max_size) AS final_total_max_size FROM Combined_Max_Size;
        ",
      format='table'
    )
  );

  local TotalNumberofDataSet =
  statPanel.new(
    title='Number of DataSet',
    datasource='Azure SQL Server',
    description="This metric defines the Number of Dataset affected of selected project",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
          WITH Combined_total_max_totaldataset AS (
            -- Query for Bronze
            SELECT SUM(max_totaldataset) AS total_max_totaldataset
            FROM (
                SELECT
                    storageyear,
                    storagemonth,
                    MAX(totaldataset) AS max_totaldataset
                FROM (
                    SELECT ReportGenerationDate,
                        YEAR(ReportGenerationDate) AS storageyear, 
                        DATENAME(Month, ReportGenerationDate) AS storagemonth, 
                        SUM(datasetNumber) AS totaldataset
                    FROM [reportdata].[bronzeSourceDetailsSDX]
                    WHERE 
                        BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + replace(REPLACE(Source, '_', '.'), '-','.') IN ($project)
                        AND DATENAME(Month, ReportGenerationDate) in ($month) 
                        AND YEAR(ReportGenerationDate) in ($year)
                    GROUP BY ReportGenerationDate,YEAR(ReportGenerationDate), DATENAME(Month, ReportGenerationDate)
                ) AS Total_size
                GROUP BY storageyear, storagemonth
            ) AS max_size_by_month

            UNION ALL

            -- Query for Silver
            SELECT SUM(max_totaldataset) AS total_max_totaldataset
            FROM (
                SELECT
                    storageyear,
                    storagemonth,
                    MAX(totaldataset) AS max_totaldataset
                FROM (
                    SELECT ReportGenerationDate,
                        YEAR(ReportGenerationDate) AS storageyear, 
                        DATENAME(Month, ReportGenerationDate) AS storagemonth, 
                        SUM(datasetNumber) AS totaldataset
                    FROM [reportdata].[silverSourceDetailsSDX]
                    WHERE 
                        BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + replace(REPLACE(Source, '_', '.'), '-','.') IN ($project)
                        AND DATENAME(Month, ReportGenerationDate) in ($month) 
                        AND YEAR(ReportGenerationDate) in ($year)
                    GROUP BY ReportGenerationDate, YEAR(ReportGenerationDate), DATENAME(Month, ReportGenerationDate)
                ) AS Total_size
                GROUP BY storageyear, storagemonth
            ) AS max_size_by_month

            UNION ALL

            -- Query for Gold
            SELECT SUM(max_totaldataset) AS total_max_totaldataset
            FROM (
                SELECT
                    storageyear,
                    storagemonth,
                    MAX(totaldataset) AS max_totaldataset
                FROM (
                    SELECT ReportGenerationDate,
                        YEAR(ReportGenerationDate) AS storageyear, 
                        DATENAME(Month, ReportGenerationDate) AS storagemonth, 
                        SUM(datasetNumber) AS totaldataset
                    FROM [reportdata].[goldSourceDetailsSDX]
                    WHERE 
                        BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + replace(REPLACE(Source, '_', '.'), '-','.') IN ($project)
                        AND DATENAME(Month, ReportGenerationDate) in ($month) 
                        AND YEAR(ReportGenerationDate) in ($year)
                    GROUP BY ReportGenerationDate, YEAR(ReportGenerationDate), DATENAME(Month, ReportGenerationDate)
                ) AS Total_size
                GROUP BY storageyear, storagemonth
            ) AS max_size_by_month
        )

        SELECT SUM(total_max_totaldataset) AS final_total_max_dataset FROM Combined_total_max_totaldataset;
        ",
      format='table'
    )
  );

  local CostoftotalStorage  =
  statPanel.new(
    title='Cost of total Storage ',
    datasource='Azure SQL Server',
    description="This metric defines the Cost of total Storage on selected project",
    colorMode='background',
    unit='€'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'purple',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
          WITH Combined_Max_Size AS (
            -- Query for Bronze
            SELECT SUM(max_sourcesize)   AS total_max_size
            FROM (
                SELECT
                    storageyear,
                    storagemonth,
                    MAX(toatlsize) AS max_sourcesize
                FROM (
                    SELECT ReportGenerationDate,
                        YEAR(ReportGenerationDate) AS storageyear, 
                        DATENAME(Month, ReportGenerationDate) AS storagemonth, 
                        SUM(SourceSize) AS toatlsize
                    FROM [reportdata].[bronzeSourceDetailsSDX]
                    WHERE 
                        BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + replace(REPLACE(Source, '_', '.'), '-','.') IN ($project)
                        AND DATENAME(Month, ReportGenerationDate) in ($month) 
                        AND YEAR(ReportGenerationDate) in ($year)
                    GROUP BY ReportGenerationDate,YEAR(ReportGenerationDate), DATENAME(Month, ReportGenerationDate)
                ) AS Total_size
                GROUP BY storageyear, storagemonth
            ) AS max_size_by_month

            UNION ALL

            -- Query for Silver
            SELECT SUM(max_sourcesize) AS total_max_size
            FROM (
                SELECT
                    storageyear,
                    storagemonth,
                    MAX(toatlsize) AS max_sourcesize
                FROM (
                    SELECT ReportGenerationDate,
                        YEAR(ReportGenerationDate) AS storageyear, 
                        DATENAME(Month, ReportGenerationDate) AS storagemonth, 
                        SUM(SourceSize) AS toatlsize
                    FROM [reportdata].[silverSourceDetailsSDX]
                    WHERE 
                        BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + replace(REPLACE(Source, '_', '.'), '-','.') IN ($project)
                        AND DATENAME(Month, ReportGenerationDate) in ($month) 
                        AND YEAR(ReportGenerationDate) in ($year)
                    GROUP BY ReportGenerationDate, YEAR(ReportGenerationDate), DATENAME(Month, ReportGenerationDate)
                ) AS Total_size
                GROUP BY storageyear, storagemonth
            ) AS max_size_by_month

            UNION ALL

            -- Query for Gold
            SELECT SUM(max_sourcesize) AS total_max_size
            FROM (
                SELECT
                    storageyear,
                    storagemonth,
                    MAX(toatlsize) AS max_sourcesize
                FROM (
                    SELECT ReportGenerationDate,
                        YEAR(ReportGenerationDate) AS storageyear, 
                        DATENAME(Month, ReportGenerationDate) AS storagemonth, 
                        SUM(SourceSize) AS toatlsize
                    FROM [reportdata].[goldSourceDetailsSDX]
                    WHERE 
                        BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + replace(REPLACE(Source, '_', '.'), '-','.') IN ($project)
                        AND DATENAME(Month, ReportGenerationDate) in ($month) 
                        AND YEAR(ReportGenerationDate) in ($year)
                    GROUP BY ReportGenerationDate, YEAR(ReportGenerationDate), DATENAME(Month, ReportGenerationDate)
                ) AS Total_size
                GROUP BY storageyear, storagemonth
            ) AS max_size_by_month
        )

        SELECT (SUM(total_max_size) / 1073741824.0) * 1.5 AS final_total_max_size FROM Combined_Max_Size;
        ",
      format='table'
    )
  );

  local totalsizebysourceStatistics = grafana.tablePanel.new(
    title="Total Size By Source",
    datasource='Azure SQL Server',
    description="This table lists total size by source monitored during the selected month"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
        WITH Combined_Max_Size AS (
                -- Query for Bronze
                SELECT Source, ContainerName, ZoneType, Sum(max_Source_Ratio) AS total_max_source_ratio, SUM(max_sourcesize) AS total_max_size 
                FROM (
                    SELECT
                        storageyear,
                        storagemonth,
                        MAX(toatlsize) AS max_sourcesize, Max(Source_Ratio) AS max_Source_Ratio, Source, ContainerName, ZoneType 
                    FROM (
                        SELECT ReportGenerationDate,
                            YEAR(ReportGenerationDate) AS storageyear, 
                            DATENAME(Month, ReportGenerationDate) AS storagemonth, 
                            BusinessLines + '.'  + RegionCode + '.' + CountryCode + '.' + Source AS 'Source', ContainerName, ZoneType, SUM(SourceRatio) AS Source_Ratio, SUM(SourceSize) AS toatlsize
                        FROM [reportdata].[bronzeSourceDetailsSDX]
                        WHERE 
                            BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + replace(REPLACE(Source, '_', '.'), '-','.') IN ($project)
                            AND DATENAME(Month, ReportGenerationDate) IN ($month) 
                            AND YEAR(ReportGenerationDate) IN ($year)
                        GROUP BY ReportGenerationDate, YEAR(ReportGenerationDate), DATENAME(Month, ReportGenerationDate), BusinessLines + '.'  + RegionCode + '.' + CountryCode + '.' + Source, ContainerName, ZoneType
                    ) AS Total_size
                    GROUP BY storageyear, storagemonth, Source, ContainerName, ZoneType
                ) AS max_size_by_month
                GROUP BY Source, ContainerName, ZoneType

                UNION ALL

                -- Query for Silver
                SELECT Source, ContainerName, ZoneType, Sum(max_Source_Ratio) AS total_max_source_ratio, SUM(max_sourcesize) AS total_max_size
                FROM (
                    SELECT
                        storageyear,
                        storagemonth,
                        MAX(toatlsize) AS max_sourcesize, Max(Source_Ratio) AS max_Source_Ratio, Source, ContainerName, ZoneType
                    FROM (
                        SELECT ReportGenerationDate,
                            YEAR(ReportGenerationDate) AS storageyear, 
                            DATENAME(Month, ReportGenerationDate) AS storagemonth, 
                            BusinessLines + '.'  + RegionCode + '.' + CountryCode + '.' + Source AS 'Source', ContainerName, ZoneType, SUM(SourceRatio) AS Source_Ratio, SUM(SourceSize) AS toatlsize
                        FROM [reportdata].[silverSourceDetailsSDX]
                        WHERE 
                            BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + replace(REPLACE(Source, '_', '.'), '-','.') IN ($project)
                            AND DATENAME(Month, ReportGenerationDate) IN ($month) 
                            AND YEAR(ReportGenerationDate) IN ($year)
                        GROUP BY ReportGenerationDate, YEAR(ReportGenerationDate), DATENAME(Month, ReportGenerationDate), BusinessLines + '.'  + RegionCode + '.' + CountryCode + '.' + Source, ContainerName, ZoneType
                    ) AS Total_size
                    GROUP BY storageyear, storagemonth, Source, ContainerName, ZoneType
                ) AS max_size_by_month
                GROUP BY Source, ContainerName, ZoneType

                UNION ALL

                -- Query for Gold
                SELECT Source, ContainerName, ZoneType, Sum(max_Source_Ratio) AS total_max_source_ratio, SUM(max_sourcesize) AS total_max_size
                FROM (
                    SELECT
                        storageyear,
                        storagemonth,
                        MAX(toatlsize) AS max_sourcesize, Max(Source_Ratio) AS max_Source_Ratio, Source, ContainerName, ZoneType
                    FROM (
                        SELECT ReportGenerationDate,
                            YEAR(ReportGenerationDate) AS storageyear, 
                            DATENAME(Month, ReportGenerationDate) AS storagemonth, 
                            BusinessLines + '.'  + RegionCode + '.' + CountryCode + '.' + Source AS 'Source', ContainerName, ZoneType, SUM(SourceRatio) AS Source_Ratio, SUM(SourceSize) AS toatlsize
                        FROM [reportdata].[goldSourceDetailsSDX]
                        WHERE 
                            BusinessLines + '.' + RegionCode + '.' + CountryCode + '.' + replace(REPLACE(Source, '_', '.'), '-','.') IN ($project)
                            AND DATENAME(Month, ReportGenerationDate) IN ($month) 
                            AND YEAR(ReportGenerationDate) IN ($year)
                        GROUP BY ReportGenerationDate,YEAR(ReportGenerationDate), DATENAME(Month, ReportGenerationDate), BusinessLines + '.'  + RegionCode + '.' + CountryCode + '.' + Source, ContainerName, ZoneType
                    ) AS Total_size
                    GROUP BY storageyear, storagemonth, Source, ContainerName, ZoneType
                ) AS max_size_by_month
                GROUP BY Source, ContainerName, ZoneType
            )

            SELECT Source, ContainerName, ZoneType, SUM(total_max_source_ratio) AS SourceRatio, SUM(total_max_size) AS Totalsize FROM Combined_Max_Size
                GROUP BY Source, ContainerName, ZoneType;
      ",
      format='table'
    )
 ).addOverridesByFieldName(
  field='Totalsize',
  properties=[
    { id: 'unit', value: 'bytes' },
  ]
);

  local TotalQueriesCount =
  statPanel.new(
    title='Total Queries Count',
    datasource='Azure SQL Server',
    description="This metric defines the number of queries triggered on selected project",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'blue',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
        SELECT Count(queries_count)
            FROM [dremio].[dremio_jobs_cost]
            WHERE 
                (dataset_fullname like ('%us.ukglabor%') or dataset_fullname like ('%us_ukglabor%'))
                AND DATENAME(Month, DATEADD(Month, [dremio].[dremio_jobs_cost].month - 1, '1900-01-01')) in ($month) 
                AND [year] IN ($year);
        ",
      format='table'
    )
  );

  local TotalTimeforSuccessfulQueries =
  statPanel.new(
    title='Total Time for Successful Queries',
    datasource='Azure SQL Server',
    description="This metric defines the total time taken for execution on Successful Queries",
    colorMode='background',
    unit='m'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
            SELECT Sum(duration_minutes)
            FROM [dremio].[dremio_jobs_cost]
            WHERE 
                (dataset_fullname like ('%us.ukglabor%') or dataset_fullname like ('%us_ukglabor%'))
                AND DATENAME(Month, DATEADD(Month, [dremio].[dremio_jobs_cost].month - 1, '1900-01-01')) in ($month) 
                AND [year] IN ($year);
          ",
      format='table'
    )
  );

  local CostofSuccessfulQueries =
  statPanel.new(
    title='Cost Of Successful Queries',
    datasource='Azure SQL Server',
    description="This metric defines Cost on Successful Queries",
    colorMode='background',
    unit='€'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'purple',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
          DECLARE @durationminutes FLOAT;
              SELECT @durationminutes = Sum(duration_minutes)
              FROM [dremio].[dremio_jobs_cost]
              WHERE 
                  (dataset_fullname like ('%us.ukglabor%') or dataset_fullname like ('%us_ukglabor%'))
                  AND DATENAME(Month, DATEADD(Month, [dremio].[dremio_jobs_cost].month - 1, '1900-01-01')) in ($month) 
                  AND [year] IN ($year)
                  select CASE when @durationminutes >= 1 and @durationminutes <= 100 then @durationminutes * 2.50
                      when @durationminutes > 100 and @durationminutes <= 400 then @durationminutes * 1.80
                      when @durationminutes > 400 and @durationminutes <= 1000 then @durationminutes * 1.25
                      When @durationminutes > 1000 then @durationminutes * 1.00
                  end;
              ",
      format='table'
    )
  );

  local userqueryDetailsStatistics = grafana.tablePanel.new(
    title="User Query Details",
    datasource='Azure SQL Server',
    description="This table lists User queried details on selected project"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
        SELECT a.user_name, sum(a.duration_minutes) as ExecutionTime,
        case when sum(a.duration_minutes) >= 1 and sum(a.duration_minutes) <= 100 then sum(a.duration_minutes) * 2.50
            when sum(a.duration_minutes) > 100 and sum(a.duration_minutes) <= 400 then sum(a.duration_minutes) * 1.80
            when sum(a.duration_minutes) > 400 and sum(a.duration_minutes) <= 1000 then sum(a.duration_minutes) * 1.25
            when sum(a.duration_minutes) > 1000 then sum(a.duration_minutes) * 1.00
        else 0
        end as ExecutionCost FROM [dremio].[dremio_jobs_cost] a 
        WHERE (a.dataset_fullname like ('%us.ukglabor%') or a.dataset_fullname like ('%us_ukglabor%'))
                    AND DATENAME(Month, DATEADD(Month, a.month - 1, '1900-01-01')) in ($month) 
                    AND [year] IN ($year)
        group by a.user_name;
      ",
      format='table'
    )
).addOverridesByFieldName(
  field='ExecutionTime',
  properties=[
    { id: 'unit', value: 'm' },
  ]
).addOverridesByFieldName(
  field='ExecutionCost',
  properties=[
    { id: 'unit', value: 'currencyEUR' },
  ]
);

local DataIngestionCostRow = row.new(title="Data Ingestion Cost", collapse=true).addPanel(
  Totalingestions,gridPos={h: 5, w: 6, x: 0, y: 5})
  .addPanel(
  Successfullingestions,gridPos={h: 5, w: 6, x: 6, y: 5})
  .addPanel(
  Failedingestions,gridPos={h: 5, w: 6, x: 12, y: 5})
  .addPanel(
  CostofSuccessfulIingestions,gridPos={h: 5, w: 6, x: 18, y: 5})
  .addPanel(
  PanelHistogramCost,gridPos={h: 9, w: 24, x: 0, y: 10});

local DataStorageCostRow = row.new(title="Data Storage Cost", collapse=true).addPanel(
  TotalStorageSizeingestions,gridPos={h: 5, w: 7, x: 0, y: 6})
  .addPanel(
  TotalNumberofDataSet,gridPos={h: 5, w: 8, x: 8, y: 6})
  .addPanel(
  CostoftotalStorage,gridPos={h: 5, w: 7, x: 17, y: 6})
  .addPanel(
  totalsizebysourceStatistics,gridPos={h: 7, w: 24, x: 0, y: 11});

local DremioConsumptionCostRow = row.new(title="Dremio Consumption Cost", collapse=true).addPanel(
  TotalQueriesCount,gridPos={h: 5, w: 8, x: 0, y: 7})
  .addPanel(
  TotalTimeforSuccessfulQueries,gridPos={h: 5, w: 8, x: 8, y: 7})
  .addPanel(
  CostofSuccessfulQueries,gridPos={h: 5, w: 8, x: 16, y: 7})
  .addPanel(
  userqueryDetailsStatistics,gridPos={h: 9, w: 24, x: 0, y: 12});

grafana.dashboard.new(
  title='UkG_PRO Cost Dashboard',
  editable='false',
  schemaVersion=37,
  uid='39LiVdsfrrr15R',
  tags=['monitoring', 'observability', 'SDX'])

.addTemplate(projectTemplate)
.addTemplate(monthTemplate)
.addTemplate(yearTemplate)

.addPanel(panel = Totalprojectcost, gridPos={h:4,w:6,x:0,y: 0})
.addPanel(panel=DataIngestionCostRow, gridPos={h: 1, w: 24, x: 0, y: 4})
.addPanel(panel=DataStorageCostRow, gridPos={h: 1, w: 24, x: 0, y: 5})
.addPanel(panel=DremioConsumptionCostRow, gridPos={h: 1, w: 24, x: 0, y: 6})
+ {
"timepicker": {
    "hidden": true
  }
}


