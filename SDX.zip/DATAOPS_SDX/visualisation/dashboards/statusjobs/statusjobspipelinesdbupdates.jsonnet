local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;

local dremioRun =
  statPanel.new(
    title="Dremio Data Last Updated",
    datasource='Azure SQL Server',
    description="Dremio Data Last Updated",
    fields="/.*/",
    allValues= true,
    colorMode='background',
    unit='short',
  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      With cte AS (
SELECT TOP (1) update_ts FROM [dremio].[dremio_jobs_cost] order by update_ts Desc)
SELECT cast(DATEDIFF(day,cte.update_ts,GETDATE() ) as varchar) + ' Days '  AS 'Lastupdated' from cte
      ",
      format='table'
    )
  );

local dremioIngestionRun =
  statPanel.new(
    title="Last Updated Timestamp",
    datasource='Azure SQL Server',
    description="Dremio Data Last Updated",
    fields="/.*/",
    allValues= true,
    colorMode='background',
    unit='short',
  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
        SELECT top(1) update_ts FROM [dremio].[dremio_jobs_cost] order by update_ts desc
      ",
      format='table'
    )
  );

local mergedAccessPanelStatistics = grafana.tablePanel.new(
    title="Latest Top 5 Updated Records",
    datasource='Azure SQL Server',
    description="This table lists all the role definition details"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
          SELECT top(5) * FROM [dremio].[dremio_jobs_cost] order by update_ts desc
      ",
      format='table'
    )
).addOverridesByFieldName(
  field='user_name',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='query_type',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='dataset_fullname',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='dataset_name',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='month',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='year',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='duration_minutes',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='cost',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='create_ts',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='update_ts',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='queries_count',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
);

local IngestionRun =
  statPanel.new(
    title="BI Ingestion Data Last Updated",
    datasource='Azure SQL Server',
    description=" BI Ingestion Data Last Updated",
    allValues= true,
    fields="/.*/",
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      With cte AS (
SELECT TOP (1) StartTime FROM [observability].[biplatform_ingestion] order by StartTime Desc)
SELECT  cast(DATEDIFF(day,cte.StartTime,GETDATE() ) as varchar) + ' Days ' AS 'Lastupdated' from cte
      ",
      format='table'
    )
  );


local BIIngestionRun =
  statPanel.new(
    title="Start Timestamp",
    datasource='Azure SQL Server',
    description="BI Data Last Updated",
    allValues= true,
    fields="/.*/",
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="

            SELECT TOP (1) StartTime FROM [observability].[biplatform_ingestion] order by StartTime Desc
      ",
      format='table'
    )
  );

  local BImergedAccessPanelStatistics = grafana.tablePanel.new(
    title="Latest Top 5 Ingestion Runs",
    datasource='Azure SQL Server',
    description="BI data latest top 5 Ingestion runs"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
          SELECT top(5) * FROM [observability].[biplatform_ingestion] order by StartTime Desc
      ",
      format='table'
    )
).addOverridesByFieldName(
  field='Schemaname',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='DatasetName',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='LoadingHistoryId',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='LoadingType',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='StartTime',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='EndTime',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='RowsCount',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='Status',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
);

local DABRun =
  statPanel.new(
    title="DAB Data Last Updated",
    datasource='Azure SQL Server',
    description="DAB Data Last Updated",
    allValues= true,
    fields="/.*/",
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      With cte AS (
SELECT TOP (1) timestamp FROM [observability].[event] order by timestamp DESC),
cte2 AS (
SELECT DATEDIFF(SECOND, '19700101', GETUTCDATE()) - cte.timestamp AS 'Lastupdated' from cte)
select cast(cte2.Lastupdated/60/60/24 as varchar) + ' days ' as days from cte2
",
      format='table'
    )
  );
local DABIngestionRun =
  statPanel.new(
    title="Last Updated Timestamp",
    datasource='Azure SQL Server',
    description="DAB Data Last Updated",
    allValues= true,
    fields="/.*/",
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT top(1) DATEADD(SECOND, timestamp ,'1970-01-01')  FROM [observability].[event] order by timestamp DESC
",
      format='table'
    )
  );
   local DABmergedAccessPanelStatistics = grafana.tablePanel.new(
    title="DAB Data Latest Top 5 Ingestion Runs",
    datasource='Azure SQL Server',
    description="latest top 5 Ingestion runs"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
          SELECT top(5)DATEADD(SECOND, timestamp ,'1970-01-01') as timestamp ,publisher_name,project_name,dataset_name,
          landing_zone,takeoff_zone,kind,event_type,job_id,metric_name,metric_value,event_id,context_id,subscription_id,err_message
          FROM [observability].[event] order by timestamp DESC
      ",
      format='table'
    )
).addOverridesByFieldName(
  field='timestamp',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='publisher_name',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='project_name',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='dataset_name',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='landing_zone',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='takeoff_zone',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='kind',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='event_type',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='job_id',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='metric_name',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='metric_value',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='event_id',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='context_id',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='subscription_id',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='err_message',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
)
;
//Bronze Data Lake  
local DatalakeRunBronze =
  statPanel.new(
    title="Bronze Data Last Updated",
    datasource='Azure SQL Server',
    description="Datalake Bronze Data Last Updated days",
    allValues= true,
    fields="/.*/",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'orange',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      With cte AS (
SELECT TOP (1) ReportGenerationDate FROM [reportdata].[bronzeSourceDetailsSDX] order by ReportGenerationDate Desc)
SELECT cast(DATEDIFF(day,cte.ReportGenerationDate,GETDATE() ) as varchar) + ' Days' AS 'Lastupdated' from cte
",
      format='table'
    )
  );

// timeStamp  
local DatalakeReportGenerationDateBronze =
  statPanel.new(
    title="Bronze Last Updated time stamp",
    datasource='Azure SQL Server',
    description="Datalake Bronze Report Last Updated time stamp",
    allValues= true,
    fields="/.*/",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'orange',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT TOP (1) ReportGenerationDate FROM [reportdata].[bronzeSourceDetailsSDX] order by ReportGenerationDate Desc
      ",
      format='table'
    )
  );
  
local BronzemergedAccessPanelStatistics = grafana.tablePanel.new(
    title="Bronze data latest top 5 Ingestion runs",
    datasource='Azure SQL Server',
    description="Latest Top 5 Ingestion Runs"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
          SELECT TOP (5)*  FROM [reportdata].[bronzeSourceDetailsSDX] order by ReportGenerationDate Desc
      ",
      format='table'
    )
).addOverridesByFieldName(
  field='StorageAccountName',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='ContainerName',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='ZoneType',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='ReportGenerationDate',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='DataProvenance',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='BusinessLines',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='RegionCode',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='CountryCode',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='Source',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='SourceSize',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='datasetNumber',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='BlobInventoryTotalSize',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='SourceRatio',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
);
  
  
  
  
// Silver Data Lake 
local DatalakeRunSilver =
  statPanel.new(
    title="Silver Data Last Updated",
    datasource='Azure SQL Server',
    description="Datalake Silver Data Last Updated days",
    allValues= true,
    fields="/.*/",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'silver',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      With cte AS (
SELECT TOP (1) ReportGenerationDate FROM [reportdata].[silverSourceDetailsSDX] order by ReportGenerationDate Desc)
SELECT cast(DATEDIFF(day,cte.ReportGenerationDate,GETDATE() ) as varchar) + ' Days' AS 'Lastupdated' from cte
",
      format='table'
    )
  );

//  Silver data timestamp
local DatalakeReportGenerationDateSilver =
  statPanel.new(
    title="Silver data Last Updated Time Stamp",
    datasource='Azure SQL Server',
    description="Datalake Silver last report Updated time stamp",
    allValues= true,
    fields="/.*/",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'silver',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      
SELECT TOP (1) ReportGenerationDate FROM [reportdata].[silverSourceDetailsSDX] order by ReportGenerationDate Desc
",
      format='table'
    )
  );
  
local SilvermergedAccessPanelStatistics = grafana.tablePanel.new(
    title="Silver Data Latest Top 5 Ingestion Runs",
    datasource='Azure SQL Server',
    description="Latest top 5 Ingestion runs"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
          SELECT TOP (5)* FROM [reportdata].[silverSourceDetailsSDX] order by ReportGenerationDate Desc
      ",
      format='table'
    )
).addOverridesByFieldName(
  field='StorageAccountName',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='ContainerName',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='ZoneType',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='ReportGenerationDate',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='DataProvenance',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='BusinessLines',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='RegionCode',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='CountryCode',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='Source',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='SourceSize',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='datasetNumber',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='BlobInventoryTotalSize',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='SourceRatio',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
);

  

// Gold data
local DatalakeRunGold =
  statPanel.new(
    title="Gold Data Last Updated",
    datasource='Azure SQL Server',
    description="Datalake Gold Data Last Updated days",
    allValues= true,
    fields="/.*/",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      With cte AS (
SELECT TOP (1) ReportGenerationDate FROM [reportdata].[goldSourceDetailsSDX] order by ReportGenerationDate Desc)
SELECT cast(DATEDIFF(day,cte.ReportGenerationDate,GETDATE() ) as varchar) + ' Days' AS 'Lastupdated' from cte
",
      format='table'
    )
  );
// Time stamp
local DatalakeReportGenerationDateGold =
  statPanel.new(
    title="Gold Data Last Updated Time Stamp",
    datasource='Azure SQL Server',
    description="Datalake Gold report Last Updated Time stamp",
    allValues= true,
    fields="/.*/",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT TOP (1) ReportGenerationDate FROM [reportdata].[goldSourceDetailsSDX] order by ReportGenerationDate Desc
",
      format='table'
    )
  );

local GoldmergedAccessPanelStatistics = grafana.tablePanel.new(
    title="Gold Latest Top 5 Ingestion Runs",
    datasource='Azure SQL Server',
    description="Latest top 5 Ingestion runs"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
          SELECT TOP (5)* FROM [reportdata].[goldSourceDetailsSDX] order by ReportGenerationDate Desc
      ",
      format='table'
    )
).addOverridesByFieldName(
  field='StorageAccountName',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='ContainerName',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='ZoneType',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='ReportGenerationDate',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='DataProvenance',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='BusinessLines',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='RegionCode',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='CountryCode',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='Source',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='SourceSize',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='datasetNumber',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='BlobInventoryTotalSize',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
).addOverridesByFieldName(
  field='SourceRatio',
  properties=[
    { id: 'custom.filterable', value: 'true' },
  ]
);
	
local dremioDataLastUpdated = row.new(title="Dremio Data", collapse=true)
  .addPanel(
  dremioRun,gridPos={h: 5, w: 7, x: 0, y: 5})
  .addPanel(
  dremioIngestionRun,gridPos={h: 5, w: 6, x: 18, y: 5})
  .addPanel(
  mergedAccessPanelStatistics,gridPos={h: 7, w: 25, x: 0, y: 10});
   
local IngestionRunUpdated = row.new(title="BI Ingestion Data", collapse=true).addPanel(
  IngestionRun,gridPos={h: 5, w: 7, x: 0, y: 5})
  .addPanel(
   BIIngestionRun,gridPos={h: 5, w: 6, x: 18, y: 5})
  .addPanel(
   BImergedAccessPanelStatistics,gridPos={h: 7, w: 25, x: 0, y: 10});

local DABRunUpadated = row.new(title="DAB Data", collapse=true).addPanel(
  DABRun,gridPos={h: 5, w: 7, x: 0, y: 5})
  .addPanel(
   DABIngestionRun,gridPos={h: 5, w: 6, x: 18, y: 5})
   .addPanel(
   DABmergedAccessPanelStatistics,gridPos={h: 7, w: 25, x: 0, y: 10});

local BronzeDataLakeStorage = row.new(title="Bronze Datalake Storage", collapse=true)
  .addPanel(
  DatalakeRunBronze,gridPos={h: 5, w: 7, x: 0, y: 5})
  .addPanel(
  DatalakeReportGenerationDateBronze,gridPos={h: 5, w: 6, x: 18, y: 5})
  .addPanel(
   BronzemergedAccessPanelStatistics,gridPos={h: 7, w: 25, x: 0, y: 10});
   
local SilverDataLakeStorage = row.new(title="Silver DataLake Storage", collapse=true)
  .addPanel(
  DatalakeRunSilver,gridPos={h: 5, w: 7, x: 0, y: 5})
  .addPanel(
  DatalakeReportGenerationDateSilver,gridPos={h: 5, w: 6, x: 18, y: 5})
  .addPanel(
   SilvermergedAccessPanelStatistics,gridPos={h: 7, w: 25, x: 0, y: 10});

local GoldDataLakeStorage = row.new(title="Gold DataLake Storage", collapse=true)
  .addPanel(
  DatalakeRunGold,gridPos={h: 5, w: 7, x: 0, y: 5})
  .addPanel(
  DatalakeReportGenerationDateGold,gridPos={h: 5, w: 6, x: 18, y: 5})
  .addPanel(
    GoldmergedAccessPanelStatistics,gridPos={h: 7, w: 25, x: 0, y: 10});



grafana.dashboard.new(
  title='Status Dashboard',
  editable='false',
  schemaVersion=37,
  uid='21EiXfffccn17D',
  tags=['monitoring', 'Status'])

.addPanel(panel = dremioDataLastUpdated, gridPos={h: 1, w: 7, x: 0, y: 0})
.addPanel(panel = IngestionRunUpdated, gridPos={h: 1, w: 7, x: 0, y: 1})
.addPanel(panel = DABRunUpadated, gridPos={h: 1, w: 7, x: 0, y: 2})
.addPanel(panel = BronzeDataLakeStorage, gridPos={h: 1, w: 7, x: 0, y: 3})
.addPanel(panel = SilverDataLakeStorage, gridPos={h: 1, w: 7, x: 0, y: 4})
.addPanel(panel = GoldDataLakeStorage, gridPos={h: 1, w: 7, x: 0, y: 5})


+ {
"timepicker": {
    "hidden": true
  }
}
