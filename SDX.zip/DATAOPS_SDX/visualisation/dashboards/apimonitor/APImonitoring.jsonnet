local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;
local tablePanel = grafana.tablePanel;
local logPanel =  grafana.logPanel;

############################ Dashboard APIM Varaibles ############################

local projectName = "Innovorder";

local ProjectAppinsightsSubscription = tmpl.new(
    name='sub_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>AppinsightsSubscription'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Subscription of Application Insight",
    hide=true
);
local ProjectAppinsightsRG =  tmpl.new(
    name='rg_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>AppinsightsRG'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Resource Group of Application Insight",
    hide=true
);
local ProjectAppinsights =  tmpl.new(
    name='appinsights_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.APIMetadataInformation where field = '<projectName>Appinsights'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Application Insights",
    hide=true
);
local AppInsightsNamespaceTemplate =  tmpl.custom(
    name='ns_appinsights',
    current='microsoft.insights/components',
    query='microsoft.insights/components',
    includeAll=false,
    multi=false,
    hide=true
);

############################ Dashboard Azure Function Varaibles ############################

local HipSubcriptionTemplate =  tmpl.new(
    name='sub_hip',
    datasource='Azure SQL Server',
    query="Select value from grafana.APIMetadataInformation where field = 'HipSubcription'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="HIP: Subscription",
    hide=true
);
local HipRgTemplate =  tmpl.new(
    name='rg_hip',
    datasource='Azure SQL Server',
    query="Select value from grafana.APIMetadataInformation where field = 'HipResourceGroup'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="HIP: Resource Group",
    hide=true
);
local HipLoganalyticsworkspaceTemplate =  tmpl.new(
    name='resource_hip_loganalyticsworkspace',
    datasource='Azure SQL Server',
    query="Select value from grafana.APIMetadataInformation where field = 'HipLoganalyticsworkspace'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="HIP: Log Analytics Workspace",
    hide=true
);
local LoganalyticsworkspaceNamespaceTemplate =  tmpl.custom(
    name='ns_loganalyticsworkspace',
    current='Microsoft.OperationalInsights/workspaces',
    query='Microsoft.OperationalInsights/workspaces',
    includeAll=false,
    multi=false,
    hide=true
);
local CustomLogTable =  tmpl.custom(
    name='CustomLogTable',
    current='InnovorderConsumerTransactions_CL',
    query='InnovorderConsumerTransactions_CL',
    includeAll=false,
    multi=false,
    hide=true
);

############################ Dashboard Service Bus Varaibles ############################

local HipServiceBusTemplate =  tmpl.new(
    name='resource_servicebus',
    datasource='Azure SQL Server',
    query="Select value from grafana.APIMetadataInformation where field = 'HipServiceBusName'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="HIP: ServiceBus",
    hide=true
);

local ServiceBusNamespaceTemplate =  tmpl.custom(
    name='ns_servicebus',
    current='microsoft.servicebus/namespaces',
    query='microsoft.servicebus/namespaces',
    includeAll=false,
    multi=false,
    hide=true
);

############################ Dashboard Event Hub Varaibles ############################

local HipEventhubTemplate =  tmpl.new(
    name='resource_eventhub',
    datasource='Azure SQL Server',
    query="Select value from grafana.APIMetadataInformation where field = 'HipEventhubName'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="HIP: Eventhub",
    hide=true
);

local EventhubNamespaceTemplate =  tmpl.custom(
    name='ns_eventhub',
    current='microsoft.eventhub/namespaces',
    query='microsoft.eventhub/namespaces',
    includeAll=false,
    multi=false,
    hide=true
);
############################ Dashboard filters ############################

local template_API =  tmpl.new(
    name='apiName',
    datasource='AzureMonitor',
    refresh='load',
    includeAll=true,
    multi=true,
    label='API Name',
    queryType='Azure Log Analytics',
    query=|||
            requests
            | where isnotempty(customDimensions)
            | where customDimensions has "API Name"
            | extend customDimensions
            | extend lastpart = tostring(customDimensions["API Name"])
            | where isnotempty(lastpart)
            | distinct lastpart
            | order by lastpart asc
        |||,
    resources=[
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ]
);

local template_country =  tmpl.new(
    name='country',
    datasource='AzureMonitor',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Country',
    queryType='Azure Log Analytics',
    query=|||
            requests
            | where isnotempty(customDimensions)
            | extend country = tostring(customDimensions["Request-x-country-of-origin"])
            | where isnotempty(country)
            | distinct country
            | order by country asc
        |||,
    resources=[
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ]
);

local template_region =  tmpl.new(
    name='region',
    datasource='AzureMonitor',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Region',
    queryType='Azure Log Analytics',
    query=|||
            requests
            | where isnotempty(customDimensions)
            | extend region = tostring(customDimensions.["Request-x-region"])
            | where isnotempty(region)
            | distinct region
            | order by region asc
        |||,
    resources=[
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ]
);

local template_source =  tmpl.new(
    name='source',
    datasource='AzureMonitor',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Source App ID',
    queryType='Azure Log Analytics',
    query=|||
            requests
            | where isnotempty(customDimensions)
            | extend source = tostring(customDimensions.["Request-x-source-application-id"])
            | where isnotempty(source)
            | distinct source
            | order by source asc
        |||,
    resources=[
      "/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"
    ]
);

local template_correlationid = tmpl.text(
    name='correlationid',
	label='Correlation Id'
);

############################ Status ############################

local ApimLastRequest = statPanel.new(
    title="APIM: Last Request",
    datasource='AzureMonitor',
    description="This panel displays the last request time send to APIM",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields="/.*/",
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) in ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | summarize tostring(format_datetime(max(timestamp),'yyyy-MM-dd HH:mm:ss'))
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/.*/"
      },
      graphMode: "none",
    }
};
local ApimLastSucessRequest = statPanel.new(
    title="APIM: Number of Successful Requests",
    datasource='AzureMonitor',
    description="This panel displays the number of successful requests in APIM",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where success == "True"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) in ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey
        | summarize Total_Success = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};
local ApimLastFailedRequest = statPanel.new(
    title="APIM: Number of Failed Requests",
    datasource='AzureMonitor',
    description="This panel displays the number of failed requests in APIM",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": null,
      },
  ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where success != "True"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) in ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey
        | summarize Total_Failed = count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};

local AzfLastRun = statPanel.new(
    title="Azure Function: Last Run",
    datasource='AzureMonitor',
    description="This panel displays the last run time for Azure Function",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields="/.*/"
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        ${CustomLogTable}
        | where $__timeFilter(TimeGenerated )
        | where SourceRegion_s in ($region)
        | where CountryOfOrigin_s in ($country)
        | where SourceApplicationId_s in ($source)
        | where isempty("$correlationid") or CorrelationId in~ (correlationIds)
        | summarize tostring(format_datetime(max(TimeGenerated),'yyyy-MM-dd HH:mm:ss'))
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'logs'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/.*/"
      },
      graphMode: "none",
    }
};
local AzfLastSuccessRun = statPanel.new(
    title="Azure Function: Number of Successful Run",
    datasource='AzureMonitor',
    description="This panel displays the number of successful run in Azure Function",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": 0,
      },
      {
        "color": "green",
        "value": 1,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        ${CustomLogTable}
        | where $__timeFilter(TimeGenerated)
        | where StatusCode_d == 200
        | where SourceRegion_s in ($region)
        | where CountryOfOrigin_s in ($country)
        | where SourceApplicationId_s in ($source)
        | where isempty("$correlationid") or CorrelationId in~ (correlationIds)
        | extend idempotencykey = IdempotencyKey_s
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(TimeGenerated) by idempotencykey
        | summarize Total_Success = count()
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};

local AzfLastFailedRun = statPanel.new(
    title="Azure Function: Number of Failed Run",
    datasource='AzureMonitor',
    description="This panel displays the number of failed run in Azure Function",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": null,
      }
  ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        ${CustomLogTable}
        | where $__timeFilter(TimeGenerated)
        | where StatusCode_d != 200
        | where SourceRegion_s in ($region)
        | where CountryOfOrigin_s in ($country)
        | where SourceApplicationId_s in ($source)
        | where isempty("$correlationid") or CorrelationId in~ (correlationIds)
        | extend idempotencykey = IdempotencyKey_s
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(TimeGenerated) by idempotencykey
        | summarize Total_Success = count()
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'time_series'
  )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};

local ServiceBusLastIncomingMessages = statPanel.new(
    title="ServiceBus: Last Incoming Messages",
    datasource='AzureMonitor',
    description="This panel displays the last incoming messages time for ServiceBus",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields='/^Time$/'
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='None',
    metricName='IncomingMessages',
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_hip",
    resourceName="$resource_servicebus",
    subscription="$sub_hip",
    alias="Incoming Messages",
   )
).addTransformations([
		grafana.transformation.new(
      'filterByValue', 
      options={
        filters: [ 
          {
            config: {id: "equal",options: { value: 0  }}
          }
        ],
        match: "all",
        type: "exclude"
      }),
]) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};
local ServiceBusLastOutgoingMessages = statPanel.new(
    title="ServiceBus: Last Outgoing Messages",
    datasource='AzureMonitor',
    description="This panel displays the last outgoing messages time for ServiceBus",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields='/^Time$/'
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='None',
    metricName='OutgoingMessages',
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_hip",
    resourceName="$resource_servicebus",
    subscription="$sub_hip",
    alias="Outgoing Messages",
   )
).addTransformations([
		grafana.transformation.new(
      'filterByValue', 
      options={
        filters: [ 
          {
            config: {id: "equal",options: { value: 0  }},
          }
        ],
        match: "all",
        type: "exclude"
      }),
]) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};

local ServiceBusUserErrors = statPanel.new(
    title="ServiceBus: User Errors",
    datasource='AzureMonitor',
    description="This panel displays the number of user errors in ServiceBus",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": null,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='Total',
    metricName='UserErrors',
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_hip",
    resourceName="$resource_servicebus",
    subscription="$sub_hip",
    alias="User Errors",
   )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    },
    fieldConfig: {
      overrides: [
        {
          matcher: {
            id: "byName",
            options: "User Errors"
          },
          properties: [
            {
              id: "unit"
            }
          ]
        }
      ]
  }
};

local EventHubLastIncomingMessages = statPanel.new(
    title="EventHub: Last Incoming Messages",
    datasource='AzureMonitor',
    description="This panel displays the last incoming messages time for EventHub",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields='/^Time$/',
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='None',
    metricName='IncomingMessages',
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    subscription="$sub_hip",
    alias="Incoming Messages",
   )
).addTransformations([
		grafana.transformation.new(
      'filterByValue', 
      options={
        filters: [ 
          {
            config: {id: "equal",options: { value: 0  }}
          }
        ],
        match: "all",
        type: "exclude"
      }),
]) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};
local EventHubLastOutgoingMessages = statPanel.new(
    title="EventHub: Last Outgoing Messages",
    datasource='AzureMonitor',
    description="This panel displays the last outgoing messages time for EventHub",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields='/^Time$/',
  ).addThresholds(
    steps=[
      {
        "color": "green",
        "value": null,
      },  
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='None',
    metricName='OutgoingMessages',
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    subscription="$sub_hip",
    alias="Outgoing Messages",
   )
).addTransformations([
		grafana.transformation.new(
      'filterByValue', 
      options={
        filters: [ 
          {
            config: {id: "equal",options: { value: 0  }}
          }
        ],
        match: "all",
        type: "exclude"
      }),
]) {
    options: {
      text: {
        valueSize: 35,
      },
      reduceOptions: {
        values: false,
        calcs: [
        "lastNotNull"
      ],
      fields: "/^Time$/"
      },
      graphMode: "none",
    }
};
local EventHubUserErrors = statPanel.new(
    title="EventHub: User Errors",
    datasource='AzureMonitor',
    description="This panel displays the number of user errors in EventHub",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(
    steps=[
      {
        "color": "red",
        "value": null,
      }
    ]
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='Total',
    metricName='UserErrors',
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    subscription="$sub_hip",
    alias="User Errors",
   )
) {
    options: {
      text: {
        valueSize: 35,
      },
      graphMode: "none",
    }
};

local Status = row.new(title="Status", collapse=true)
    .addPanel(ApimLastRequest,gridPos={h: 3, w: 8, x: 0, y: 0})
    .addPanel(ApimLastSucessRequest,gridPos={h: 3, w: 8, x: 8, y: 0})
    .addPanel(ApimLastFailedRequest,gridPos={h: 3, w: 8, x: 16, y: 0})
    .addPanel(AzfLastRun,gridPos={h: 3, w: 8, x: 0, y: 4})
    .addPanel(AzfLastSuccessRun,gridPos={h: 3, w: 8, x: 8, y: 4})
    .addPanel(AzfLastFailedRun,gridPos={h: 3, w: 8, x: 16, y: 4})
    .addPanel(ServiceBusLastIncomingMessages,gridPos={h: 3, w: 8, x: 0, y: 8})
    .addPanel(ServiceBusLastOutgoingMessages,gridPos={h: 3, w: 8, x: 8, y: 8})
    .addPanel(ServiceBusUserErrors,gridPos={h: 3, w: 8, x: 16, y: 8})
    .addPanel(EventHubLastIncomingMessages,gridPos={h: 3, w: 8, x: 0, y: 12})
    .addPanel(EventHubLastOutgoingMessages,gridPos={h: 3, w: 8, x: 8, y: 12})
    .addPanel(EventHubUserErrors,gridPos={h: 3, w: 8, x: 16, y: 12});

############################ APIM ############################

local ApiTotalRequests = grafana.graphPanel.new(
    title="Total API Requests",
    datasource='AzureMonitor',
    description="This panel displays the total number of requests in APIM using Timeseries",
    fill=0,
    points=true,
    pointradius=5,
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where isnotempty(customDimensions)
        | where customDimensions has "API Name"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) in ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | extend lastpart = tostring(customDimensions["API Name"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey, lastpart
        | summarize totalrequests = count() by bin(latest_timestamp, 5m), lastpart
        | order by latest_timestamp asc 
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          __systemRef: "hideSeriesFrom",
          matcher: {
            id: "byNames",
            options: {
              mode: "exclude",
              names: [
                "totalrequests"
              ],
              prefix: "All except:",
              readOnly: true
            }
          },
          properties: [
            {
              id: "custom.hideFrom",
              value: {
                legend: false,
                tooltip: false,
                viz: true
              }
            }
          ]
        },
        {
          matcher: {
            id: "byName",
            options: "totalrequests"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "blue",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local ApiRequestNumberByAPIName = grafana.barChart.new(
    title="Requests by API Name",
    description='This panel displays the total number of requests by API name in APIM using barchart',
    datasource='AzureMonitor',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where isnotempty(customDimensions)
        | where customDimensions has "API Name"
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) in ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | extend lastpart = tostring(customDimensions["API Name"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey, lastpart
        | summarize totalrequests = count() by lastpart
        | order by totalrequests desc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "totalrequests"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "blue",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local ApiRequests = grafana.graphPanel.new(
    title="Requests (Successful & Failed)",
    datasource='AzureMonitor',
    description="This panel displays the total number of requests in APIM using Timeseries",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests
        | where $__timeFilter(timestamp)
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) in ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | extend lastpart = tostring(customDimensions["API Name"])
        | where isnotempty(idempotencykey)
        | extend ResultType = iff(success == true, "success", "Failure")
        | summarize latest_timestamp = max(timestamp) by idempotencykey, lastpart, ResultType
        | summarize totalrequests = count() by ResultType, bin(latest_timestamp, 5m)
        | order by latest_timestamp asc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "totalrequests success"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "green",
                mode: "fixed"
              }
            }
          ]
        },
        {
          matcher: {
            id: "byName",
            options: "totalrequests Failure"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "red",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local ApiRequestByStatusCode = grafana.pieChartPanel.new(
    title="Request by Status Code",
    datasource='AzureMonitor',
    description="This panel displays the request by status code using pie chart",
    legendType="Right side",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        requests 
        | where $__timeFilter(timestamp)
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) in ($apiName)
        | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | extend lastpart = tostring(customDimensions["API Name"])
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(timestamp) by idempotencykey, resultCode 
        | summarize Count=count() by resultCode
        | evaluate pivot(resultCode, sum(Count))
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "right",
      calcs: [],
      values: [
          "value", "percent"
        ]
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "401"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "red",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local ApiStatistic = tablePanel.new(
    title="API Statistics",
    datasource='AzureMonitor',
    description="This panel displays the table of each API name with their request count, average response size, average duration, and success rate in a table format",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let latestRequests =
        requests
        | where $__timeFilter(timestamp)
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) in ($apiName)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | where isnotempty(idempotencykey)
        | summarize timestamp = max(timestamp) by idempotencykey;
        requests
        | where $__timeFilter(timestamp)
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | extend idempotencykey = tostring(customDimensions.["Request-x-idempotency-key"])
        | join kind= inner ( 
                latestRequests
        ) on idempotencykey, timestamp
        | where isnotempty(customDimensions)
        | where customDimensions has "API Name"
        | extend SuccessCode = iff(success=="False", 0, 1)
        | summarize RequestCount=count(),
            AverageResponseSize=avg(tolong(customMeasurements.["Request Size"])),
            AverageDuration=avg(duration)
        by ApiName=tostring(customDimensions.["API Name"])
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
);

local ApimLastFailedRequestTable = tablePanel.new(
    title="Last Failed APIM Events",
    datasource='AzureMonitor',
    description="This panel displays the table of failed requests of each timestamp with their resultCode, duration, API Name, RequestSize, Correlation ID and IdemopotencyKey in a table format",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where success == False
        | where tostring(customDimensions.["Request-x-region"]) in ($region)
        | where tostring(customDimensions.["Request-x-country-of-origin"]) in ($country)
        | where tostring(customDimensions.["Request-x-source-application-id"]) in ($source)
        | where tostring(customDimensions["API Name"]) in ($apiName)
        | project timestamp, resultCode, duration, APIName=customDimensions["API Name"], RequestSize=customMeasurements.["Request Size"], CorrelationId=customDimensions.["Request-x-correlation-id"], IdempotencyKey=customDimensions.["Request-x-idempotency-key"]
        | order by timestamp desc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
){
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "APIName"
          },
          properties: [
            {
              id: "custom.width",
              value: 284
            }
          ]
        }
      ]
  }
};

local ApiLogs = logPanel.new(
    title="API Unique Idempotency Key Error logs",
    datasource='AzureMonitor',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
      let correlationIds = split("$correlationid", ",");
      requests
      | where $__timeFilter(timestamp)
      | where success == "False"
      | where isempty("$correlationid") or tostring(customDimensions.["Request-x-correlation-id"]) in~ (correlationIds)
      | extend
          request_APIName=customDimensions.["API Name"],
          request_CorrelationId=customDimensions.["Request-x-correlation-id"],
          request_IdempotencyKey=tostring(customDimensions.["Request-x-idempotency-key"]),
          request_SourceApplicationId=customDimensions.["Request-x-source-application-id"],
          request_size=customMeasurements.["Request Size"]
      | where isnotempty(request_IdempotencyKey)  
      | project
          request_timestamp=timestamp,
          request_CorrelationId,  
          request_IdempotencyKey,
          request_APIName,
          request_SourceApplicationId,
          request_name=name,
          request_url=url,
          request_success=success,
          request_resultCode=resultCode,
          request_duration=duration,
          request_performanceBucket=performanceBucket,
          request_size,
          request_operation_Name=operation_Name,
          operation_Id
      | join kind=inner (
          requests
          | where $__timeFilter(timestamp)
          | where success == "False"
          | extend
              request_resultCode = resultCode,
              request_IdempotencyKey = tostring(customDimensions.["Request-x-idempotency-key"]),
              request_timestamp = timestamp
          | where isnotempty(request_IdempotencyKey)
          | summarize request_timestamp = max(timestamp) by request_IdempotencyKey, request_resultCode
      ) on request_IdempotencyKey, request_resultCode, request_timestamp
      | join kind=inner (exceptions | project operation_Id, timestamp, outerMessage, operation_Name, appName, _ResourceId) on operation_Id
      | summarize arg_max(request_timestamp, *) by request_IdempotencyKey
      | order by request_timestamp desc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
);

local APIM = row.new(title="APIM", collapse=true)
    .addPanel(ApiTotalRequests,gridPos={h: 8, w: 24, x: 0, y: 1})
    .addPanel(ApiRequestNumberByAPIName,gridPos={h: 8, w: 24, x: 0, y: 9})
    .addPanel(ApiRequests,gridPos={h: 8, w: 24, x: 0, y: 16})
    .addPanel(ApiRequestByStatusCode,gridPos={h: 8, w: 12, x: 0, y: 24})
    .addPanel(ApiStatistic,gridPos={h: 8, w: 12, x: 12, y: 24})
    .addPanel(ApimLastFailedRequestTable,gridPos={h: 8, w: 24, x: 0, y: 33})
    .addPanel(ApiLogs,gridPos={h: 8, w: 24, x: 0, y: 41});

############################ Azure Function ############################

local AZTotalRequests = grafana.graphPanel.new(
    title="Total Azure Function Requests",
    datasource='AzureMonitor',
    description="This panel displays the total number of requests in Azure Function using Timeseries",
    fill=0,
    points=true,
    pointradius=5,
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        ${CustomLogTable}
        | where $__timeFilter(TimeGenerated)
        | where SourceRegion_s in ($region)
        | where CountryOfOrigin_s in ($country)
        | where SourceApplicationId_s in ($source)
        | where isempty("$correlationid") or CorrelationId in~ (correlationIds)
        | extend idempotencykey = IdempotencyKey_s
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(TimeGenerated) by idempotencykey
        | summarize totalrequests = count() by bin(latest_timestamp, 5m)
        | order by latest_timestamp asc  
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "totalrequests"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "blue",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local AZRequests = grafana.graphPanel.new(
    title="Requests (Successful & Failed)",
    datasource='AzureMonitor',
    description="This panel displays the total number of requests in Azure Function using Timeseries",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        ${CustomLogTable}
        | where $__timeFilter(TimeGenerated)
        | where SourceRegion_s in ($region)
        | where CountryOfOrigin_s in ($country)
        | where SourceApplicationId_s in ($source)
        | where isempty("$correlationid") or CorrelationId in~ (correlationIds)
        | extend idempotencykey = IdempotencyKey_s
        | where isnotempty(idempotencykey)
        | extend ResultType = iff(StatusCode_d == 200, "success", "Failure")
        | summarize latest_timestamp = max(TimeGenerated) by idempotencykey, ResultType
        | summarize totalrequests = count() by ResultType, bin(latest_timestamp, 5m)
        | order by latest_timestamp asc
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "bottom",
      calcs: []
    }
  },
  fieldConfig: {
    overrides: [
        {
          matcher: {
            id: "byName",
            options: "totalrequests"
          },
          properties: [
            {
              id: "color",
              value: {
                fixedColor: "blue",
                mode: "fixed"
              }
            }
          ]
        }
      ]
  }
};

local AZRequestByStatusCode = grafana.pieChartPanel.new(
    title="Request by Status Code",
    datasource='AzureMonitor',
    description="This panel displays the request by status code using pie chart",
    legendType="Right side",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        let correlationIds = split("$correlationid", ",");
        ${CustomLogTable}
        | where $__timeFilter(TimeGenerated)
        | where SourceRegion_s in ($region)
        | where CountryOfOrigin_s in ($country)
        | where SourceApplicationId_s in ($source)
        | where isempty("$correlationid") or CorrelationId in~ (correlationIds)
        | extend idempotencykey = IdempotencyKey_s
        | where isnotempty(idempotencykey)
        | summarize latest_timestamp = max(TimeGenerated) by idempotencykey, StatusCode_d 
        | summarize Count=count() by StatusCode_d
        | evaluate pivot(StatusCode_d, sum(Count))
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'logs'
  )
){
  options: {
    legend: {
      showLegend: true,
      displayMode: "table",
      placement: "right",
      calcs: [],
      values: [
          "value", "percent"
        ]
    }
  }
};

local AZLogs = logPanel.new(
    title="Azure Function Error logs",
    datasource='AzureMonitor',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
      ${CustomLogTable}
      | extend idempotencykey = IdempotencyKey_s
      | where isnotempty(idempotencykey)
      | where StatusCode_d != 200
      | order by TimeGenerated desc
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'logs'
  )
);

local AzureFunction = row.new(title="Azure Function", collapse=true)
    .addPanel(AZTotalRequests,gridPos={h: 8, w: 24, x: 0, y: 2})
    .addPanel(AZRequests,gridPos={h: 8, w: 24, x: 0, y: 10})
    .addPanel(AZRequestByStatusCode,gridPos={h: 8, w: 12, x: 0, y: 18})
    .addPanel(AZLogs,gridPos={h: 8, w: 12, x: 12, y: 18});

############################ Service Bus ############################

local ServiceBusIncommingMessages = grafana.graphPanel.new(
    title="Total Incoming Messages",
    datasource='AzureMonitor',
    description="This panel displays the total incoming messages graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='IncomingMessages',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_hip",
    resourceName="$resource_servicebus",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusOutgoingMessages = grafana.graphPanel.new(
    title="Total Outgoing Messages",
    datasource='AzureMonitor',
    description="This panel displays the total outgoing messages  graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='OutgoingMessages',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_hip",
    resourceName="$resource_servicebus",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusSuccessfulRequests = grafana.graphPanel.new(
    title="Total Successful Requests",
    datasource='AzureMonitor',
    description="This panel displays the total successful requests graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='SuccessfulRequests',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_hip",
    resourceName="$resource_servicebus",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusCompleteMessage = grafana.graphPanel.new(
    title="Complete Messages ",
    datasource='AzureMonitor',
    description="This panel displays the total complete messages graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='CompleteMessage',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_hip",
    resourceName="$resource_servicebus",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusActiveMessages = grafana.graphPanel.new(
    title="Count of Active Messages in a Queue",
    datasource='AzureMonitor',
    description="This panel displays the count of active messages in a queue graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='ActiveMessages',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_hip",
    resourceName="$resource_servicebus",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusScheduledMessages = grafana.graphPanel.new(
    title="Count of Scheduled Messages in a Queue",
    datasource='AzureMonitor',
    description="This panel displays the count of scheduled messages in a queue graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='ScheduledMessages',
    aggregation='Average',
    subscription="$sub_hip",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_hip",
    resourceName="$resource_servicebus",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusCountOfServerErrors= grafana.pieChartPanel.new(
    title="Count Of Server Errors",
    datasource='AzureMonitor',
    description="This panel displays the count of server errors graph for EventHub using Pie Chart",
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='ServerErrors',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_hip",
    resourceName="$resource_servicebus",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "right",
        values: [
          "value", "percent"
        ]
      }
    }
};
local ServiceBusCountOfUserErrors= grafana.pieChartPanel.new(
    title="Count Of User Errors",
    datasource='AzureMonitor',
    description="This panel displays the count of user errors graph for EventHub using Pie Chart",
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='UserErrors',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_hip",
    resourceName="$resource_servicebus",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "right",
        values: [
          "value", "percent"
        ]
      }
    }
};
local ServiceBusAverageRequestSize = grafana.graphPanel.new(
    title="Average Request Size",
    datasource='AzureMonitor',
    description="This panel displays the average request size graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='Size',
    aggregation='Average',
    subscription="$sub_hip",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_hip",
    resourceName="$resource_servicebus",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local ServiceBusAverageMemoryUsage = grafana.graphPanel.new(
    title="Average Memory Usage",
    datasource='AzureMonitor',
    description="This panel displays the average memory usage graph for Service Bus",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='NamespaceMemoryUsage',
    aggregation='Average',
    subscription="$sub_hip",
    metricNamespace="$ns_servicebus",
    resourceGroup="$rg_hip",
    resourceName="$resource_servicebus",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};

local ServiceBus = row.new(title="Service Bus", collapse=true)
    .addPanel(ServiceBusIncommingMessages,gridPos={h: 8, w: 12, x: 0, y: 4})
    .addPanel(ServiceBusOutgoingMessages,gridPos={h: 8, w: 12, x: 12, y: 4})
    .addPanel(ServiceBusSuccessfulRequests,gridPos={h: 8, w: 12, x: 0, y: 12})
    .addPanel(ServiceBusCompleteMessage,gridPos={h: 8, w: 12, x: 12, y: 12})
    .addPanel(ServiceBusActiveMessages,gridPos={h: 8, w: 12, x: 0, y: 20})
    .addPanel(ServiceBusScheduledMessages,gridPos={h: 8, w: 12, x: 12, y: 20})
    .addPanel(ServiceBusCountOfUserErrors,gridPos={h: 8, w: 12, x: 0, y: 28})
    .addPanel(ServiceBusCountOfServerErrors,gridPos={h: 8, w: 12, x: 12, y: 28})
    .addPanel(ServiceBusAverageRequestSize,gridPos={h: 8, w: 12, x: 0, y: 36})
    .addPanel(ServiceBusAverageMemoryUsage,gridPos={h: 8, w: 12, x: 12, y: 36});

############################ Event Hub ############################

local EventHubIncommingMessages = grafana.graphPanel.new(
    title="EventHub: Incoming Messages",
    datasource='AzureMonitor',
    description="This panel displays the last incoming messages graph for EventHub",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='IncomingMessages',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local EventHubOutgoingMessages = grafana.graphPanel.new(
    title="EventHub: Outgoing Messages",
    datasource='AzureMonitor',
    description="This panel displays the last outgoing messages graph for EventHub",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='OutgoingMessages',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local EventHubSuccessfulRequests = grafana.graphPanel.new(
    title="Successful Requests",
    datasource='AzureMonitor',
    description="This panel displays the last outgoing messages graph for EventHub",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='SuccessfulRequests',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local EventHubCountOfServerErrors= grafana.pieChartPanel.new(
    title="Count Of Server Errors",
    datasource='AzureMonitor',
    description="This panel displays the count of server errors graph for EventHub using Pie Chart",
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='ServerErrors',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "right",
        values: [
          "value", "percent"
        ]
      }
    }
};
local EventHubCountOfUserErrors= grafana.pieChartPanel.new(
    title="Count Of User Errors",
    datasource='AzureMonitor',
    description="This panel displays the count of user errors graph for EventHub using Pie Chart",
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='UserErrors',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "right",
        values: [
          "value", "percent"
        ]
      }
    }
};
local EventHubAverageRequestSize = grafana.graphPanel.new(
    title="Average Request Size",
    datasource='AzureMonitor',
    description="This panel displays the average request size for EventHub",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='Size',
    aggregation='Average',
    subscription="$sub_hip",
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};
local EventHubIncomingBytes = grafana.graphPanel.new(
    title="Total Incomming Bytes",
    datasource='AzureMonitor',
    description="This panel displays the total incoming bytes for EventHub",
    fill=0,
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='IncomingBytes',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    dimension="EntityName",
    dimensionOperator="eq",
    dimensionFilters="*",
   )
){
    options: {
      legend: {
        showLegend: true,
        displayMode: "table",
        placement: "bottom"
      }
    }
};

local EventHub = row.new(title="Event Hub", collapse=true)
    .addPanel(EventHubIncommingMessages,gridPos={h: 8, w: 12, x: 0, y: 17})
    .addPanel(EventHubOutgoingMessages,gridPos={h: 8, w: 12, x: 12, y: 17})
    .addPanel(EventHubSuccessfulRequests,gridPos={h: 8, w: 24, x: 0, y: 25})
    .addPanel(EventHubCountOfServerErrors,gridPos={h: 7, w: 12, x: 0, y: 33})
    .addPanel(EventHubCountOfUserErrors,gridPos={h: 7, w: 12, x: 12, y: 33})
    .addPanel(EventHubAverageRequestSize,gridPos={h: 8, w: 12, x: 0, y: 40})
    .addPanel(EventHubIncomingBytes,gridPos={h: 8, w: 12, x: 12, y: 40});

############################ Dashboard ############################

grafana.dashboard.new(
  title='End to End API Monitoring',
  time_from='now-3h',
  timezone="utc",
  editable='false',
  schemaVersion=37,
  uid='api-monitoring-tracker',
  tags=['monitoring', 'observability'])

.addTemplate(ProjectAppinsightsSubscription)
.addTemplate(ProjectAppinsightsRG)
.addTemplate(ProjectAppinsights)
.addTemplate(AppInsightsNamespaceTemplate)

.addTemplate(HipSubcriptionTemplate)
.addTemplate(HipRgTemplate)
.addTemplate(HipLoganalyticsworkspaceTemplate)
.addTemplate(LoganalyticsworkspaceNamespaceTemplate)
.addTemplate(CustomLogTable)

.addTemplate(HipServiceBusTemplate)
.addTemplate(ServiceBusNamespaceTemplate)

.addTemplate(HipEventhubTemplate)
.addTemplate(EventhubNamespaceTemplate)

.addTemplate(template_API)
.addTemplate(template_country)
.addTemplate(template_region)
.addTemplate(template_source)
.addTemplate(template_correlationid)

.addPanel(panel=Status, gridPos={h: 1, w: 24, x: 0, y: 1})
.addPanel(panel=APIM, gridPos={h: 1, w: 24, x: 0, y: 2})
.addPanel(panel=AzureFunction, gridPos={h: 1, w: 24, x: 0, y: 3})
.addPanel(panel=ServiceBus, gridPos={h: 1, w: 24, x: 0, y: 4})
.addPanel(panel=EventHub, gridPos={h: 1, w: 24, x: 0, y: 5})
