local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;
local tablePanel = grafana.tablePanel;
local logPanel =  grafana.logPanel;
local gaugePanel = grafana.gaugePanel;


############################ Dashboard config
local projectName = "Innovorder";


############################ Project variables 
local EntityEventhubTemplate =  tmpl.custom(
    name='entity_eventhub',
    current='az-consumer-transactions-event-hub',
    query='az-consumer-transactions-event-hub',
    includeAll=false,
    multi=false,
    label="Eventhub Entity"
);
local TemplateTextSearch = tmpl.text(
    name='text_search',
	  label='Search Log'
);
local ApiName =  tmpl.custom(
    name='ApiName',
    current='consumer-transaction',
    query='consumer-transaction',
    includeAll=false,
    multi=false,
);
local CustomLogTable =  tmpl.custom(
    name='CustomLogTable',
    current='InnovorderConsumerTransactions_CL',
    query='InnovorderConsumerTransactions_CL',
    includeAll=false,
    multi=false,
);
local ProjectAppinsightsSubscription = tmpl.new(
    name='sub_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.variable where field = '<projectName>AppinsightsSubscription'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Subscription of Application Insight",
    hide=true
  );
local ProjectAppinsightsRG =  tmpl.new(
    name='rg_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.variable where field = '<projectName>AppinsightsRG'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Resource Group of Application Insight",
    hide=true
);
local ProjectAppinsights =  tmpl.new(
    name='appinsights_project',
    datasource='Azure SQL Server',
    query=std.strReplace("Select value from grafana.variable where field = '<projectName>Appinsights'", "<projectName>", projectName ),
    refresh='load',
    includeAll=false,
    multi=false,
    label="Project: Application Insights",
    hide=true
);

############################ Azure Monitor Namespaces
local ApimNamespaceTemplate =  tmpl.custom(
    name='ns_apim',
    current='Microsoft.ApiManagement/service',
    query='Microsoft.ApiManagement/service',
    includeAll=false,
    multi=false,
    hide=true
);
local EventhubNamespaceTemplate =  tmpl.custom(
    name='ns_eventhub',
    current='microsoft.eventhub/namespaces',
    query='microsoft.eventhub/namespaces',
    includeAll=false,
    multi=false,
    hide=true
);
local LoganalyticsworkspaceNamespaceTemplate =  tmpl.custom(
    name='ns_loganalyticsworkspace',
    current='Microsoft.OperationalInsights/workspaces',
    query='Microsoft.OperationalInsights/workspaces',
    includeAll=false,
    multi=false,
    hide=true
);
local AppInsightsNamespaceTemplate =  tmpl.custom(
    name='ns_appinsights',
    current='microsoft.insights/components',
    query='microsoft.insights/components',
    includeAll=false,
    multi=false,
    hide=true
);

############################ APIM variables
local datasourceTemplate =   tmpl.datasource(
    name='ds',
    current='Azure Monitor',
    query='grafana-azure-monitor-datasource',
    refresh='load',
    label='Datasource',
    hide=true
);

local ApimSubcriptionTemplate = tmpl.new(
    name='sub_apim',
    datasource='Azure SQL Server',
    query="Select value from grafana.variable where field = 'ApimSubscription'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="APIM: Subscription",
    hide=true
  );
local ApimRgTemplate =  tmpl.new(
    name='rg_apim',
    datasource='Azure SQL Server',
    query="Select value from grafana.variable where field = 'ApimResourceGroup'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="APIM: Resource Group",
    hide=true
);
local ApimServiceTemplate =  tmpl.new(
    name='resource_apim',
    datasource='Azure SQL Server',
    query="Select value from grafana.variable where field = 'ApimServiceName'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="APIM: service",
    hide=true
);
local ApimRGAppinsightsTemplate =  tmpl.new(
    name='rg_apim_appinsights',
    datasource='Azure SQL Server',
    query="Select value from grafana.variable where field = 'ApimAppinsightsResourceGroup'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="APIM: Resource Group AppInsights",
    hide=true
);
local ApimAppinsightsTemplate =  tmpl.new(
    name='resource_apim_appinsights',
    datasource='Azure SQL Server',
    query="Select value from grafana.variable where field = 'ApimAppinsights'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="APIM: Application Insights",
    hide=true
);

############################ HIP variables
local HipSubcriptionTemplate =  tmpl.new(
    name='sub_hip',
    datasource='Azure SQL Server',
    query="Select value from grafana.variable where field = 'HipSubcription'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="HIP: Subscription",
    hide=true
);
local HipRgTemplate =  tmpl.new(
    name='rg_hip',
    datasource='Azure SQL Server',
    query="Select value from grafana.variable where field = 'HipResourceGroup'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="HIP: Resource Group",
    hide=true
);
local HipEventhubTemplate =  tmpl.new(
    name='resource_eventhub',
    datasource='Azure SQL Server',
    query="Select value from grafana.variable where field = 'HipEventhubName'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="HIP: Eventhub",
    hide=true
);
local HipLoganalyticsworkspaceTemplate =  tmpl.new(
    name='resource_hip_loganalyticsworkspace',
    datasource='Azure SQL Server',
    query="Select value from grafana.variable where field = 'HipLoganalyticsworkspace'",
    refresh='load',
    includeAll=false,
    multi=false,
    label="HIP: Log Analytics Workspace",
    hide=true
);
 

############################ Overview Panels
local ApimLastRequest = statPanel.new(
    title="APIM: Last request",
    datasource='${ds}',
    description="Last request send to APIM",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields="/.*/",
    colorMode='background'
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp )
        | where url contains "$ApiName"
        | summarize tostring(format_datetime(max(timestamp),'yyyy-MM-dd HH:mm:ss'))
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
);
local ApimLastSucessRequest = statPanel.new(
    title="APIM: Number of success",
    datasource='${ds}',
    description="",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where url contains "$ApiName"
        | where success == True
        | summarize Success=count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
);
local ApimLastFailedRequest = statPanel.new(
    title="APIM: Number of failed",
    datasource='${ds}',
    description="",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(steps=[
      { color: 'green', value: 0 },
      { color: 'red', value: 1 }
  ]).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where url contains "$ApiName"
        | where success != True
        | summarize Success=count()
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
);

local AzfLastRun = statPanel.new(
    title="Azure Function: Last run",
    datasource='${ds}',
    description="",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields="/.*/",
    colorMode='background'
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        ${CustomLogTable}
        | where $__timeFilter(TimeGenerated )
        | summarize   tostring(format_datetime(max(TimeGenerated),'yyyy-MM-dd HH:mm:ss'))
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'logs'
  )
);
local AzfLastSuccessRun = statPanel.new(
    title="Azure Function: Nb of success run",
    datasource='${ds}',
    description="",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        ${CustomLogTable}
        | where $__timeFilter(TimeGenerated)
        | where StatusCode_d == 200
        | summarize RunNB=count()
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'time_series'
  )
);
local AzfLastFailedRun = statPanel.new(
    title="Azure Function: Nb of failed run",
    datasource='${ds}',
    description="",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addThresholds(steps=[
      { color: 'green', value: 0 },
      { color: 'red', value: 1 }
  ]).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        ${CustomLogTable}
        | where $__timeFilter(TimeGenerated)
        | where StatusCode_d != 200
        | summarize RunNB=count()
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'time_series'
  )
);
local EventHubLastIncomingMessages = statPanel.new(
    title="EventHub: Last Incoming Messages",
    datasource='${ds}',
    description="",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields='/^Time$/',
    colorMode='background',
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='None',
    metricName='IncomingMessages',
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    subscription="$sub_hip",
    dimension="EntityName",
    dimensionFilters="$entity_eventhub",
    dimensionOperator="eq",
    alias="{{dimensionvalue}}",
   )
).addTransformations([
		grafana.transformation.new(
      'filterByValue', 
      options={
        filters: [ 
          {
            config: {id: "equal",options: { value: 0  }},
            fieldName: "Incoming Messages ${entity_eventhub}"
          }
        ],
        match: "all",
        type: "exclude"
      }),
]);
local EventHubLastOutgoingMessages = statPanel.new(
    title="EventHub: Last Outgoing Messages",
    datasource='${ds}',
    description="",
    graphMode='none',
    reducerFunction='lastNotNull',
    fields='/^Time$/',
    colorMode='background',
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='None',
    metricName='OutgoingMessages',
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    subscription="$sub_hip",
    dimension="EntityName",
    dimensionFilters="$entity_eventhub",
    dimensionOperator="eq",
    alias="{{dimensionvalue}}",
   )
).addTransformations([
		grafana.transformation.new(
      'filterByValue', 
      options={
        filters: [ 
          {
            config: {id: "equal",options: { value: 0  }},
            fieldName: "Outgoing Messages ${entity_eventhub}"
          }
        ],
        match: "all",
        type: "exclude"
      }),
]);
local EventHubServerError = statPanel.new(
    title="EventHub: Server Errors",
    datasource='${ds}',
    description="",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='Total',
    metricName='ServerErrors',
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    subscription="$sub_hip",
    dimension="EntityName",
    dimensionFilters="$entity_eventhub",
    dimensionOperator="eq",
    alias="{{dimensionvalue}}",
   )
);
local EventHubQuotaExceededErrors = statPanel.new(
    title="EventHub: Quota Exceeded Errors",
    datasource='${ds}',
    description="",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='Total',
    metricName='QuotaExceededErrors',
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    subscription="$sub_hip",
    dimension="EntityName",
    dimensionFilters="$entity_eventhub",
    dimensionOperator="eq",
    alias="{{dimensionvalue}}",
   )
);
local EventHubUserErrors = statPanel.new(
    title="EventHub: User Errors",
    datasource='${ds}',
    description="",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='Total',
    metricName='UserErrors',
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    subscription="$sub_hip",
    dimension="EntityName",
    dimensionFilters="$entity_eventhub",
    dimensionOperator="eq",
    alias="{{dimensionvalue}}",
   )
);
local EventHubThrottledRequests = statPanel.new(
    title="EventHub: Throttled Requests",
    datasource='${ds}',
    description="",
    graphMode='none',
    reducerFunction='lastNotNull',
    colorMode='background'
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    aggregation='Total',
    metricName='ThrottledRequests',
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    subscription="$sub_hip",
    dimension="EntityName",
    dimensionFilters="$entity_eventhub",
    dimensionOperator="eq",
    alias="{{dimensionvalue}}",
   )
);


local Overview = row.new(title="Overview", collapse=true)
    .addPanel(ApimLastRequest,gridPos={h: 3, w: 10, x: 0, y: 0})
    .addPanel(ApimLastSucessRequest,gridPos={h: 3, w: 7, x: 10, y: 0})
    .addPanel(ApimLastFailedRequest,gridPos={h: 3, w: 7, x: 17, y: 0})
    .addPanel(AzfLastRun,gridPos={h: 3, w: 10, x: 0, y: 0})
    .addPanel(AzfLastSuccessRun,gridPos={h: 3, w: 7, x: 10, y: 0})
    .addPanel(AzfLastFailedRun,gridPos={h: 3, w: 7, x: 17, y: 0})
    .addPanel(EventHubLastIncomingMessages,gridPos={h: 3, w: 10, x: 0, y: 6})
    .addPanel(EventHubLastOutgoingMessages,gridPos={h: 3, w: 10, x: 0, y: 9})
    .addPanel(EventHubServerError,gridPos={h: 3, w: 7, x: 10, y: 6})
    .addPanel(EventHubQuotaExceededErrors,gridPos={h: 3, w: 7, x: 17, y: 6})
    .addPanel(EventHubUserErrors,gridPos={h: 3, w: 7, x: 10, y: 9})
    .addPanel(EventHubThrottledRequests,gridPos={h: 3, w: 7, x: 17, y: 9});



############################ APIM Panels
local ApimGlobalViewGauge = gaugePanel.new(
    title="APIM: Current Capacity",
    datasource='${ds}',
    description="",
    reducerFunction='lastNotNull',
    fields="",
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='Capacity',
    aggregation='Average',
    subscription="$sub_apim",
    metricNamespace="$ns_apim",
    resourceGroup="$rg_apim",
    resourceName="$resource_apim",
    )
  ).addThresholds(
    steps=[
      {
        value: 60,
        color: 'green',
        text: 'Warning',
      },
      {
        value: 70,
        color: 'yellow',
        text: 'Warning',
      },
      {
        value: 80,
        color: 'red',
        text: 'Warning',
      },
    ]
);
local ApimGlobalViewTimeSeries = grafana.graphPanel.new(
    title="APIM: Avg Capacity",
    datasource='${ds}',
    description="",
    thresholds=[{colorMode: 'critical', fill: true, area: true, op: 'gt', value: 80 },],
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='Capacity',
    aggregation='Average',
    subscription="$sub_apim",
    metricNamespace="$ns_apim",
    resourceGroup="$rg_apim",
    resourceName="$resource_apim",
   )
);
local ApiStatistics = tablePanel.new(
    title="API Statistics",
    datasource='${ds}',
    description="",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where url contains "$ApiName"
        | extend SuccessCode = iff(success=="False", 0, 1)
        | summarize RequestCount=count(customDimensions.["Request Id"]),
            AverageResponseSize=avg(tolong(customMeasurements.["Request Size"])),
            avg(duration),
            SuccessRate=avg(SuccessCode)
        by App_name=tostring(customDimensions.["API Name"])
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
);
local ApiFailedList = tablePanel.new(
    title="Last Failed events",
    datasource='${ds}',
    description="",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where url contains "$ApiName"
        | where success == False
        | project timestamp, resultCode, duration, APIName=customDimensions["API Name"], RequestSize=customMeasurements.["Request Size"], CorrelationId=customDimensions.["Request-x-correlation-id"], IdempotencyKey=customDimensions.["Request-x-idempotency-key"]
        | order by timestamp desc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
);
local ApiStatusTimeSeries = grafana.graphPanel.new(
    title="Requests (Failed & Successful)",
    datasource='${ds}',
    description="",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where url contains "$ApiName"
        | summarize Success=count() by success, bin(timestamp, 5m)
        | order by timestamp asc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
);
local ApiStatusPieChartPanel = grafana.pieChartPanel.new(
    title="Status code repartition",
    datasource='${ds}',
    description="",
    legendType="Under graph",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests 
        | where $__timeFilter(timestamp)
        | where url contains "$ApiName"
        | summarize Count=count() by Code=resultCode 
        | evaluate pivot(Code, sum(Count))
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
);
local ApiRequestNumberByDay = grafana.barChart.new(
    title="Requests by day (Failed & Successful)",
    description='Number of request by day',
    datasource='${ds}',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where url contains "$ApiName"
        | summarize RequestNB=count() by format_datetime(timestamp, "MM/dd/yyyy")
        | order by timestamp asc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
);
local ApiRequestSizeByDay = grafana.barChart.new(
    title="Requests size by day",
    description='Sum of request size by day',
    datasource='${ds}',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where url contains "$ApiName"
        | summarize Size=sum(todouble(customMeasurements.["Request Size"]))  by format_datetime(timestamp,"MM/dd/yyyy")
        | order by timestamp asc
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'time_series'
  )
);
local ApiDuplicateRequest = tablePanel.new(
    title="Duplicate key by day",
    datasource='${ds}',
    description="",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where url contains "$ApiName"
        | summarize Count=count() by IdempotencyKey=tostring(customDimensions.["Request-x-idempotency-key"]), format_datetime(timestamp, "MM/dd/yyyy")
        | where Count > 1
        | order by timestamp desc        
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
);
local ApiLogs = logPanel.new(
    title="API: Error logs",
    datasource='${ds}',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
        requests
        | where $__timeFilter(timestamp)
        | where url contains "$ApiName"
        | where success == False
        | extend 
            request_APIName=customDimensions.["API Name"], 
            request_CorrelationId=customDimensions.["Request-x-correlation-id"],
            request_IdempotencyKey=customDimensions.["Request-x-idempotency-key"],
            request_SourceApplicationId=customDimensions.["Request-x-source-application-id"],
            request_size=customMeasurements.["Request Size"]
        | where request_CorrelationId contains "$text_search"
        | project 
            request_timestamp=timestamp, 
            request_CorrelationId,  
            request_IdempotencyKey,
            request_APIName,
            request_SourceApplicationId, 
            request_name=name, 
            request_url=url, 
            request_success=success,
            request_resultCode=resultCode, 
            request_duration=duration,
            request_performanceBucket=performanceBucket, 
            request_size, 
            request_operation_Name=operation_Name, 
            operation_Id
        | join (exceptions) on operation_Id
        | order by request_timestamp desc     
    |||,
    resources=["/subscriptions/$sub_project/resourceGroups/$rg_project/providers/$ns_appinsights/$appinsights_project"],
	resultFormat= 'logs'
  )
);

local APIM = row.new(title="APIM: Consumer transaction", collapse=true)
    .addPanel(ApimGlobalViewGauge,gridPos={h: 8, w: 7, x: 0, y: 13})
    .addPanel(ApimGlobalViewTimeSeries,gridPos={h: 8, w: 17, x: 7, y: 13})
    .addPanel(ApiStatistics,gridPos={h: 4, w: 24, x: 0, y: 21})
    .addPanel(ApiFailedList,gridPos={h: 5, w: 24, x: 0, y: 25})
    .addPanel(ApiStatusTimeSeries,gridPos={h: 8, w: 19, x: 0, y: 30})
    .addPanel(ApiStatusPieChartPanel,gridPos={h: 8, w: 5, x: 19, y: 30})
    .addPanel(ApiRequestNumberByDay,gridPos={h: 6, w: 12, x: 0, y: 38})
    .addPanel(ApiRequestSizeByDay,gridPos={h: 6, w: 12, x: 12, y: 38})
    .addPanel(ApiDuplicateRequest,gridPos={h: 8, w: 7, x: 0, y: 44})
    .addPanel(ApiLogs,gridPos={h: 8, w: 17, x: 7, y: 44});



############################ Azure function panels
local AzRequestNumberByDay = grafana.barChart.new(
    title="Run by day (Failed & Successful)",
    description='Number of run by day',
    datasource='${ds}',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
      ${CustomLogTable}
      | where $__timeFilter(TimeGenerated)
      | summarize RunNB=count() by format_datetime(TimeGenerated,'MM/dd/yyyy')
      | order by TimeGenerated asc
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'time_series'
  )
);
local AzRequestPayloadSizeByDay = grafana.barChart.new(
    title="PayloadSize by day",
    datasource='${ds}',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
      ${CustomLogTable}
      | where $__timeFilter(TimeGenerated)
      | summarize RequestNB=sum(PayloadSize_d) by format_datetime(TimeGenerated,'MM/dd/yyyy')
      | order by TimeGenerated asc
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'time_series'
  )
);
local AzStatusPieChartPanel = grafana.pieChartPanel.new(
    title="Status code repartition",
    datasource='${ds}',
    description="",
    legendType="Under graph",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
      ${CustomLogTable}
      | where $__timeFilter(TimeGenerated )
      | summarize Count=count() by Code=StatusCode_d 
      | evaluate pivot(Code, sum(Count))
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'logs'
  )
);
local ApiDuplicateRequest = tablePanel.new(
    title="Duplicate key by day",
    datasource='${ds}',
    description="",
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
      ${CustomLogTable}
      | summarize Count=count() by IdempotencyKey_s , format_datetime(TimeGenerated,'MM/dd/yyyy')
      | where Count > 1
      | order by TimeGenerated desc
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'logs'
  )
);
local AzLogs = logPanel.new(
    title="AZ: Error logs",
    datasource='${ds}',
  ).addTarget(
  target=grafana.azuremonitor.target(
    query=|||
      ${CustomLogTable}
      | where StatusCode_d != 200
      | where CorrelationId contains "$text_search"
      | order by TimeGenerated desc
    |||,
    resources=["/subscriptions/$sub_hip/resourceGroups/$rg_hip/providers/$ns_loganalyticsworkspace/$resource_hip_loganalyticsworkspace"],
	resultFormat= 'logs'
  )
);

local AZF = row.new(title="Azure Function: Consumer transaction", collapse=true)
    .addPanel(AzRequestNumberByDay,gridPos={h: 6, w: 10, x: 0, y: 14})
    .addPanel(AzRequestPayloadSizeByDay,gridPos={h: 6, w: 10, x: 14, y: 14})
    .addPanel(AzStatusPieChartPanel,gridPos={h: 8, w: 5, x: 0, y: 20})
    .addPanel(ApiDuplicateRequest,gridPos={h:8 , w:8 , x:5 , y:59 })
    .addPanel(AzLogs,gridPos={h: 8, w: 11, x: 13, y: 59});


############################EventHub panels
local EventHubIncommingMessages = grafana.graphPanel.new(
    title="EventHub: Incoming Messages",
    datasource='${ds}',
    description="",
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='IncomingMessages',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    dimension="EntityName",
    dimensionFilters="$entity_eventhub",
    dimensionOperator="eq",
    alias="{{dimensionvalue}}",
   )
);
local EventHubOutgoingMessages = grafana.graphPanel.new(
    title="EventHub: Outgoing Messages",
    datasource='${ds}',
    description="",
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='OutgoingMessages',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    dimension="EntityName",
    dimensionFilters="$entity_eventhub",
    dimensionOperator="eq",
    alias="{{dimensionvalue}}",
   )
);
local EventHubIncommingBytes = grafana.graphPanel.new(
    title="EventHub: IncomingBytes Bytes",
    datasource='${ds}',
    description="",
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='IncomingBytes',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    dimension="EntityName",
    dimensionFilters="$entity_eventhub",
    dimensionOperator="eq",
    alias="{{dimensionvalue}}",
   )
);
local EventHubOutgoingBytes = grafana.graphPanel.new(
    title="EventHub: Outgoing Bytes",
    datasource='${ds}',
    description="",
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='OutgoingBytes',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    dimension="EntityName",
    dimensionFilters="$entity_eventhub",
    dimensionOperator="eq",
    alias="{{dimensionvalue}}",
   )
);
local EventHubSize = grafana.graphPanel.new(
    title="EventHub: Size",
    datasource='${ds}',
    description="",
  ).addTarget(
  target=grafana.azuremonitor.target(
    queryType='Azure Monitor',
    metricName='Size',
    aggregation='Total',
    subscription="$sub_hip",
    metricNamespace="$ns_eventhub",
    resourceGroup="$rg_hip",
    resourceName="$resource_eventhub",
    dimension="EntityName",
    dimensionFilters="$entity_eventhub",
    dimensionOperator="eq",
    alias="{{dimensionvalue}}",
   )
);

local EventHub = row.new(title="Eventhub: Consumer transaction", collapse=true)
    .addPanel(EventHubIncommingMessages,gridPos={h: 5, w: 6, x: 0, y: 19})
    .addPanel(EventHubOutgoingMessages,gridPos={h: 5, w: 6, x: 6, y: 19})
    .addPanel(EventHubIncommingBytes,gridPos={h: 5, w: 6, x: 12, y: 19})
    .addPanel(EventHubOutgoingBytes,gridPos={h: 5, w: 6, x: 18, y: 19})
    .addPanel(EventHubSize,gridPos={h: 6, w: 24, x: 0, y: 24});




############################ Dashboard
grafana.dashboard.new(
  title='API Consumer Transaction Dashboard',
  editable='false',
  schemaVersion=37,
  uid='apiconsumertransaction',
  tags=['monitoring', 'observability', 'consumer transaction' ])

.addTemplate(ApimNamespaceTemplate)
.addTemplate(EventhubNamespaceTemplate)
.addTemplate(LoganalyticsworkspaceNamespaceTemplate)
.addTemplate(AppInsightsNamespaceTemplate)

.addTemplate(datasourceTemplate)
.addTemplate(ApimSubcriptionTemplate)
.addTemplate(ApimRgTemplate)
.addTemplate(ApimServiceTemplate)
.addTemplate(ApimRGAppinsightsTemplate)
.addTemplate(ApimAppinsightsTemplate)

.addTemplate(HipSubcriptionTemplate)
.addTemplate(HipRgTemplate)
.addTemplate(HipEventhubTemplate)
.addTemplate(HipLoganalyticsworkspaceTemplate)

.addTemplate(EntityEventhubTemplate)
.addTemplate(TemplateTextSearch)
.addTemplate(ApiName)
.addTemplate(CustomLogTable)
.addTemplate(ProjectAppinsightsSubscription)
.addTemplate(ProjectAppinsightsRG)
.addTemplate(ProjectAppinsights)

.addPanel(panel=Overview, gridPos={h: 1, w: 24, x: 0, y: 0})
.addPanel(panel=APIM, gridPos={h: 1, w: 24, x: 0, y: 24})
.addPanel(panel=AZF, gridPos={h: 1, w: 24, x: 0, y: 48})
.addPanel(panel=EventHub, gridPos={h: 1, w: 24, x: 0, y: 72})


