local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;

local businessTemplate =   tmpl.new(
    name='Business',
    datasource='Azure SQL Server',
    query='select distinct(BusinessLines) from [reportdata].[bronzeSourceDetailsSDX]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='BusinessLine'
  );

local regionTemplate = tmpl.new(
    name='Region',
    datasource='Azure SQL Server',
    query='select distinct(regionCode) from [reportdata].[bronzeSourceDetailsSDX]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='RegionCode'
  );

local sourceTemplate = tmpl.new(
    name='Source',
    datasource='Azure SQL Server',
    query='select distinct(source) from [reportdata].[bronzeSourceDetailsSDX]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='SourceName'
  );

local MonthTemplate = tmpl.custom(
    name='month',
    query="January,February,March,April,May,June,July,August,September,October,November,December",
    current='January',
    includeAll=false,
    multi=false,
    label='Month'
  );

local YearTemplate = tmpl.new(
    name='year',
    datasource='Azure SQL Server',
    query="SELECT distinct YEAR(ReportGenerationDate) as 'Year' from [reportdata].[bronzeSourceDetailsSDX]",
    current='2023',
    includeAll=false,
    multi=false,
    label='Year',
    refresh='load'
  );

local sourcesizebronzemonthlyRun =
  statPanel.new(
    title="Total Source Size Monthly Visual",
    datasource='Azure SQL Server',
    description="Showcasing monthly statistics of data lake size for bronze layer",
    colorMode='background',
    unit='bytes',
  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      with CTE1 as (
        select 
          SUM(SourceSize) as 'TotalSize', 
          datename(Month, ReportGenerationDate) as 'MonthPart',
          datepart(Month, ReportGenerationDate) as 'MonthNumber'  
        from [reportdata].[bronzeSourceDetailsSDX] 
        where 
          BusinessLines in ($Business)
          And RegionCode in ($Region)
          And Source in ($Source)
          And datename(Month, ReportGenerationDate) = '$month'
          And Year(ReportGenerationDate) in  ($year)
        group by ReportGenerationDate, datename(Month, ReportGenerationDate), datepart(Month, ReportGenerationDate)
      ) 
      
      select MonthPart, AVG(TotalSize) as 'TotalSize' from CTE1 
      group by MonthPart, MonthNumber  
      order by MonthNumber
      ",
      format='table'
    )
  );

local PanelHistogrambronzesourcesizeyearly = grafana.barChart.new(
    title="Total Source Size yearly Visual",
    description='This graph represents Showcasing yearly statistics of data lake size  for bronze layer',
    datasource='Azure SQL Server',
    unit='bytes',
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      with CTE1 as (
        select 
          SUM(SourceSize) as 'TotalSize', 
          datename(Month, ReportGenerationDate) as 'MonthPart', 
          datepart(Month, ReportGenerationDate) as 'MonthNumber'  
        from [reportdata].[bronzeSourceDetailsSDX] 
        where 
          BusinessLines in ($Business) And 
          RegionCode in ($Region) And 
          Source in ($Source) And 
          Year(ReportGenerationDate) in ($year) 
        group by ReportGenerationDate, datename(Month, ReportGenerationDate), datepart(Month, ReportGenerationDate)
      ) 
      
      select MonthPart, Avg(TotalSize) as 'TotalSize' from CTE1 
      group by MonthPart, MonthNumber 
      order by MonthNumber
      ",
      format='table'
    )
  );

local sourceratiobronzeemonthlyRun =
  statPanel.new(
    title="Current Ratio Monthly Visual",
    datasource='Azure SQL Server',
    description="Showcasing Monthly statistics of current ratio",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      with CTE1 as( 
        SELECT  
          Sum(Sourceratio) as 'Sourceratio', 
          datename(Month, ReportGenerationDate) as 'MonthPart', 
          datepart(Month, ReportGenerationDate) as 'MonthNumber' 
        from [reportdata].[bronzeSourceDetailsSDX] 
        where 
          BusinessLines in ($Business) AND 
          RegionCode in ($Region) AND 
          Source in ($Source) And 
          datename(Month, ReportGenerationDate) = '$month' AND 
          Year(ReportGenerationDate) in ($year) 
        Group By ReportGenerationDate, datename(Month, ReportGenerationDate), datepart(Month, ReportGenerationDate)) 
      
      select MonthPart, Avg(Sourceratio) as 'Source ratio' from CTE1 
      group by  MonthPart, MonthNumber 
      Order By MonthNumber
      ",
      format='table'
    )
  );

local PanelHistogrambronzesourceratioyearly = grafana.barChart.new(
    title="Current Ratio Yearly Visual",
    description='This graph represents Showcasing Showcasing Yearly statistics of current ratio',
    datasource='Azure SQL Server',
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      with CTE1 as( 
        SELECT  
          Sum(Sourceratio) as 'Sourceratio', 
          datename(Month, ReportGenerationDate) as 'MonthPart', 
          datepart(Month, ReportGenerationDate) as 'MonthNumber' 
        from [reportdata].[bronzeSourceDetailsSDX] 
        where 
          BusinessLines in ($Business) AND 
          RegionCode in ($Region) AND 
          Source in ($Source) AND 
          Year(ReportGenerationDate) in ($year) 
        Group By ReportGenerationDate, datename(Month, ReportGenerationDate), datepart(Month, ReportGenerationDate)
      ) 
      
      select MonthPart, AVG(Sourceratio) as 'Source ratio' from CTE1 
      group by MonthPart, MonthNumber 
      Order By MonthNumber
      ",
      format='table'
    )
  );

local datasetbronzemonthlyRun =
  statPanel.new(
    title="Dataset Monthly Visual",
    datasource='Azure SQL Server',
    description="Affected datasets by ingestion monthly statistics",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      with CTE1 as( 
        SELECT  
          Sum(datasetNumber) as 'DatasetNumber', 
          datename(Month, ReportGenerationDate) as 'MonthPart', 
          datepart(Month, ReportGenerationDate) as 'MonthNumber' 
        from [reportdata].[bronzeSourceDetailsSDX] 
        where 
          BusinessLines in ($Business) AND 
          RegionCode in ($Region) AND 
          Source in ($Source) And 
          datename(Month, ReportGenerationDate) = '$month' AND 
          Year(ReportGenerationDate) in ($year) 
        Group By ReportGenerationDate, datename(Month, ReportGenerationDate), datepart(Month, ReportGenerationDate)
      ) 

      select MonthPart, Avg(DatasetNumber) as 'Dataset Number' from CTE1 
      group by MonthPart, 
      MonthNumber 
      Order By MonthNumber
      ",
      format='table'
    )
  );

local PanelHistogrambronzedatasetyearly = grafana.barChart.new(
    title="Dataset Yearly Visual",
    description='This graph represents Affected datasets by ingestion yearly statistics.',
    datasource='Azure SQL Server',
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      with CTE1 as(
        SELECT  
          Sum(datasetNumber) as 'datasetNumber', 
          datename(Month, ReportGenerationDate) as 'MonthPart', 
          datepart(Month, ReportGenerationDate) as 'MonthNumber' 
        from [reportdata].[bronzeSourceDetailsSDX] 
        where 
          BusinessLines in ($Business) AND 
          RegionCode in ($Region) AND 
          Source in ($Source) AND 
          Year(ReportGenerationDate) in ($year) 
        Group By ReportGenerationDate, datename(Month, ReportGenerationDate), datepart(Month, ReportGenerationDate)
      ) 
      
      select MonthPart, AVG(datasetNumber) as 'DataSet Number' from CTE1 
      GROUP BY MonthPart, MonthNumber 
      Order By MonthNumber
      ",
      format='table'
    )
  );

grafana.dashboard.new(
  title='Bronze Layer Dashboard',
  editable='false',
  schemaVersion=37,
  uid='21EiXdsfccn17D',
  tags=['monitoring', 'observability', 'obsolete'])

.addTemplate(businessTemplate)
.addTemplate(regionTemplate)
.addTemplate(sourceTemplate)
.addTemplate(MonthTemplate)
.addTemplate(YearTemplate)

.addPanel(panel = sourcesizebronzemonthlyRun, gridPos={h:7,w:6,x:0,y: 0})
.addPanel(panel = PanelHistogrambronzesourcesizeyearly, gridPos={h:7,w:18,x:6,y: 0})

.addPanel(panel = sourceratiobronzeemonthlyRun, gridPos={h:7,w:6,x:0,y: 7})
.addPanel(panel = PanelHistogrambronzesourceratioyearly, gridPos={h:7,w:18,x:6,y: 7})

.addPanel(panel = datasetbronzemonthlyRun, gridPos={h:7,w:6,x:0,y: 14})
.addPanel(panel = PanelHistogrambronzedatasetyearly, gridPos={h:7,w:18,x:6,y: 14})
+ {
"timepicker": {
    "hidden": true
  }
}