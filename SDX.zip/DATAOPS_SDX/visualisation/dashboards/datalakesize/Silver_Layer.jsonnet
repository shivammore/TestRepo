local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;

local businessTemplate =   tmpl.new(
    name='Business',
    datasource='Azure SQL Server',
    query='select distinct(BusinessLines) from [reportdata].[silverSourceDetailsSDX]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='BusinessLine'
  );

local regionTemplate = tmpl.new(
    name='Region',
    datasource='Azure SQL Server',
    query='select distinct(regionCode) from [reportdata].[silverSourceDetailsSDX]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='RegionCode'
  );

local sourceTemplate = tmpl.new(
    name='Source',
    datasource='Azure SQL Server',
    query='select distinct(source) from [reportdata].[silverSourceDetailsSDX]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='SourceName'
  );

local MonthTemplate = tmpl.custom(
    name='month',
    query="January,February,March,April,May,June,July,August,September,October,November,December",
    current='January',
    includeAll=false,
    multi=false,
    label='Month'
  );

local YearTemplate = tmpl.new(
    name='year',
    datasource='Azure SQL Server',
    query="SELECT distinct YEAR(ReportGenerationDate) as 'Year' from [reportdata].[silverSourceDetailsSDX]",
    current='2023',
    includeAll=false,
    multi=false,
    label='Year',
    refresh='load'
  );

local sourcesizesilvermonthlyRun =
  statPanel.new(
    title="Total Source Size Monthly Visual",
    datasource='Azure SQL Server',
    description="Showcasing monthly statistics of data lake size for silver layer",
    colorMode='background',
    unit='bytes',
  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      with CTE1 as (
        select 
          SUM(SourceSize) as 'TotalSize', 
          datename(Month, ReportGenerationDate) as 'MonthPart', 
          datepart(Month, ReportGenerationDate) as 'MonthNumber'  
        from [reportdata].[silverSourceDetailsSDX] 
        where 
          BusinessLines in ($Business)
          And RegionCode in ($Region)
          And Source in ($Source)
          And datename(Month, ReportGenerationDate) = '$month'
          And Year(ReportGenerationDate) in ($year)
        group by ReportGenerationDate, datename(Month, ReportGenerationDate), datepart(Month, ReportGenerationDate)
      ) 
      
      select MonthPart, AVG(TotalSize) as 'TotalSize' from CTE1 
      group by MonthPart, MonthNumber  
      order by MonthNumber
      ",
      format='table'
    )
  );

local PanelHistogramsilversourcesizeyearly = grafana.barChart.new(
    title="Total Source Size yearly Visual",
    description='This graph represents Showcasing yearly statistics of data lake size  for silver layer',
    datasource='Azure SQL Server',
    unit='bytes',
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      with CTE1 as (
        select 
          SUM(SourceSize) as 'TotalSize', 
          datename(Month, ReportGenerationDate) as 'MonthPart', 
          datepart(Month, ReportGenerationDate) as 'MonthNumber'  
        from [reportdata].[silverSourceDetailsSDX] 
        where 
          BusinessLines in ($Business) And 
          RegionCode in ($Region) And 
          Source in ($Source) And 
          Year(ReportGenerationDate) in ($year) 
        group by ReportGenerationDate, datename(Month, ReportGenerationDate), datepart(Month, ReportGenerationDate)
      ) 
      
      select MonthPart, Avg(TotalSize) as 'TotalSize' from CTE1 
      group by MonthPart, MonthNumber 
      order by MonthNumber
      ",
      format='table'
    )
  );

local sourceratiosilvermonthlyRun =
  statPanel.new(
    title="Current Ratio Monthly Visual",
    datasource='Azure SQL Server',
    description="Showcasing Monthly statistics of current ratio",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      with CTE1 as( 
        SELECT  
          Sum(Sourceratio) as 'Sourceratio', 
          datename(Month, ReportGenerationDate) as 'MonthPart', 
          datepart(Month, ReportGenerationDate) as 'MonthNumber' 
        from [reportdata].[silverSourceDetailsSDX] 
        where 
          BusinessLines in ($Business) AND 
          RegionCode in ($Region) AND 
          Source in ($Source) And 
          datename(Month, ReportGenerationDate) = '$month' AND 
          Year(ReportGenerationDate) in ($year) 
        Group By ReportGenerationDate, datename(Month, ReportGenerationDate), datepart(Month, ReportGenerationDate)
      ) 
      
      select MonthPart, Avg(Sourceratio) as 'Source ratio' from CTE1 
      group by  MonthPart, MonthNumber 
      Order By MonthNumber
      ",
      format='table'
    )
  );

local PanelHistogramsilversourceratioyearly = grafana.barChart.new(
    title="Current Ratio Yearly Visual",
    description='This graph represents Showcasing Showcasing Yearly statistics of current ratio',
    datasource='Azure SQL Server',
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      with CTE1 as( 
        SELECT  
          Sum(Sourceratio) as 'Sourceratio', 
          datename(Month, ReportGenerationDate) as 'MonthPart', 
          datepart(Month, ReportGenerationDate) as 'MonthNumber' 
        from [reportdata].[silverSourceDetailsSDX] 
        where 
          BusinessLines in ($Business) AND 
          RegionCode in ($Region) AND 
          Source in ($Source) AND 
          Year(ReportGenerationDate) in ($year) 
        Group By ReportGenerationDate, datename(Month, ReportGenerationDate), datepart(Month, ReportGenerationDate)
      ) 
      
      select MonthPart, AVG(Sourceratio) as 'Source ratio' from CTE1 
      group by MonthPart, MonthNumber 
      Order By MonthNumber
      ",
      format='table'
    )
  );

local datasetsilvermonthlyRun =
  statPanel.new(
    title="Dataset Monthly Visual",
    datasource='Azure SQL Server',
    description="Affected datasets by ingestion monthly statistics",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      with CTE1 as( 
        SELECT  
          Sum(datasetNumber) as 'DatasetNumber', 
          datename(Month, ReportGenerationDate) as 'MonthPart', 
          datepart(Month, ReportGenerationDate) as 'MonthNumber' 
        from [reportdata].[silverSourceDetailsSDX] 
        where 
          BusinessLines in ($Business) AND 
          RegionCode in ($Region) AND 
          Source in ($Source) And 
          datename(Month, ReportGenerationDate) = '$month' AND 
          Year(ReportGenerationDate) in ($year) 
        Group By ReportGenerationDate, datename(Month, ReportGenerationDate), 
        datepart(Month, ReportGenerationDate)
      ) 

      select MonthPart, Avg(DatasetNumber) as 'Dataset Number' from CTE1 
      group by MonthPart, 
      MonthNumber 
      Order By MonthNumber
      ",
      format='table'
    )
  );

local PanelHistogramsilverdatasetyearly = grafana.barChart.new(
    title="Dataset Yearly Visual",
    description='This graph represents Affected datasets by ingestion yearly statistics.',
    datasource='Azure SQL Server',
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      with CTE1 as(
        SELECT  
          Sum(datasetNumber) as 'datasetNumber', 
          datename(Month, ReportGenerationDate) as 'MonthPart', 
          datepart(Month, ReportGenerationDate) as 'MonthNumber' 
        from [reportdata].[silverSourceDetailsSDX] 
        where 
          BusinessLines in ($Business) AND 
          RegionCode in ($Region) AND 
          Source in ($Source) AND 
          Year(ReportGenerationDate) in ($year) 
        Group By ReportGenerationDate, datename(Month, ReportGenerationDate), datepart(Month, ReportGenerationDate)
        ) 
      
      select MonthPart, AVG(datasetNumber) as 'DataSet Number' from CTE1 
      GROUP BY MonthPart, MonthNumber 
      Order By MonthNumber
      ",
      format='table'
    )
  );

grafana.dashboard.new(
  title='Silver Layer Dashboard',
  editable='false',
  schemaVersion=37,
  uid='21EiXdlnswe19F',
  tags=['monitoring', 'observability', 'obsolete'])

.addTemplate(businessTemplate)
.addTemplate(regionTemplate)
.addTemplate(sourceTemplate)
.addTemplate(MonthTemplate)
.addTemplate(YearTemplate)

.addPanel(panel = sourcesizesilvermonthlyRun, gridPos={h:7,w:6,x:0,y: 0})
.addPanel(panel = PanelHistogramsilversourcesizeyearly, gridPos={h:7,w:18,x:6,y: 0})

.addPanel(panel = sourceratiosilvermonthlyRun, gridPos={h:7,w:6,x:0,y: 7})
.addPanel(panel = PanelHistogramsilversourceratioyearly, gridPos={h:7,w:18,x:6,y: 7})

.addPanel(panel = datasetsilvermonthlyRun, gridPos={h:7,w:6,x:0,y: 14})
.addPanel(panel = PanelHistogramsilverdatasetyearly, gridPos={h:7,w:18,x:6,y: 14})
+ {
"timepicker": {
    "hidden": true
  }
}