local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;

local projectTemplate =   tmpl.new(
    name='project',
    datasource='Azure SQL Server',
    query='select distinct project_name from [observability].[event]',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Application Source'
  );


local stageTemplate =  tmpl.custom(
    name='stage',
    current='silver',
    query='silver,bronze',
    includeAll=true,
    multi=true,
    label="Zone"
  );


local datasetTemplate = tmpl.new(
    name='dataset',
    datasource='Azure SQL Server',
    query='select distinct dataset_name from [observability].[event]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Dataset Name'
  );


local MonthTemplate = tmpl.custom(
    name='month',
    query="January,February,March,April,May,June,July,August,September,October,November,December",
    current='January',
    includeAll=false,
    multi=false,
    label='Month'
  );

local YearTemplate = tmpl.new(
    name='year',
    datasource='Azure SQL Server',
    query="SELECT distinct YEAR(dateadd(S, [timestamp], '1970-01-01')) as 'Year' FROM [observability].[event]",
    current='2023',
    includeAll=false,
    multi=false,
    label='Year',
    refresh='load'
  );


 local TimestampTemplate = tmpl.new(
  name='timestamp',
  datasource='Azure SQL Server',
  hide = 'true',
  query=|||
    DECLARE @MonthName NVARCHAR(50) = '$month'; -- Using Grafana variable
    DECLARE @Year INT = $year; -- Using Grafana variable
    DECLARE @MonthNumber INT = MONTH(CAST(@MonthName + ' 01 2023' AS DATETIME));
    SELECT DATEDIFF(SECOND, '19700101', DATEFROMPARTS(@Year, @MonthNumber, 1)) as 'Timestamp';
  |||,
  current='',  // Not setting a default current value
  includeAll=false,
  multi=false,
  label='Timestamp (UTC)',
  refresh='load'
);

local NextMonthTimestampTemplate = tmpl.new(
  name='next_month_timestamp',
  datasource='Azure SQL Server',
  hide = 'true',
  query=|||
    DECLARE @InitialTimestamp INT = $timestamp; -- Using Grafana variable for the original timestamp
    SELECT @InitialTimestamp + 2592000 as 'NextMonthTimestamp';  -- Adding 2,592,000 seconds
  |||,
  current='',  // Not setting a default current value
  includeAll=false,
  multi=false,
  label='Next Month Timestamp (UTC)',
  refresh='load'

);


local ContextTmplHided = tmpl.new(
  name='context',
  datasource='Azure SQL Server',
  query="

    SELECT distinct(context_id)
    FROM [observability].[event]
    WHERE
    project_name in ($project)
    and dataset_name in ($dataset)
    and landing_zone in ($stage)
    ",
  current='all',
  refresh='load',
  hide = 'true',
  includeAll=true,
  multi=false,
  label='Context'
);



local TotalApplicationSource =
  statPanel.new(
    title='Total Application Source',
    datasource='Azure SQL Server',
    description="This metric represents the number of sources that are monitored over a time slot",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'white',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT  COUNT(DISTINCT project_name) FROM [observability].[event]
      where metric_name= 'processing_exit_code'
      AND event_type =  'processingfinished'
      AND context_id in ($context)
      ",
      format='table'
    )
  );


local TotalDataSets =
  statPanel.new(
    title='Total Datasets',
    datasource='Azure SQL Server',
    description="this metric represents the number of datasets per source that are monitored over a time slot",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'white',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT  COUNT(DISTINCT dataset_name) FROM [observability].[event]
      where metric_name= 'processing_exit_code'
      AND event_type =  'processingfinished'
      AND context_id in ($context)
      ",
      format='table'
    )
  );


local TotalIngestionRun =
  statPanel.new(
    title="Total Ingestion's",
    datasource='Azure SQL Server',
    description="this metric represents the total number of ingestions calculated over a time slot",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'white',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT  COUNT(job_id) FROM [observability].[event]
      where metric_name= 'processing_exit_code'
      AND event_type =  'processingfinished'
      AND context_id in ($context)
      ANd datename(Month, dateadd(S, [timestamp], '1970-01-01')) = '$month';
      ",
      format='table'
    )
  );


local SuccessRun =
  statPanel.new(
    title="Succeded Ingestion's",
    datasource='Azure SQL Server',
    description="This metric represents new ingests in success over a time slot",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT  COUNT(job_id) FROM [observability].[event]
      where metric_name= 'processing_exit_code'
      AND event_type =  'processingfinished'
      AND metric_value =  0
      AND context_id in ($context)
      ANd datename(Month, dateadd(S, [timestamp], '1970-01-01')) = '$month';
      ",

      format='table'
    )
  );

local CostPanel =
  statPanel.new(
    title="Monthly Cost for Succeeded Ingestions",
    datasource='Azure SQL Server',
    description="@todo",
    colorMode='background',
    unit='currencyEUR'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      declare @IngestionCount int
      Select @IngestionCount = count(job_id) FROM [observability].[event]
      where metric_name= 'processing_exit_code'
      AND event_type = 'processingfinished'
	  AND context_id in ($context)
	  AND metric_value = 0
      ANd datename(Month, dateadd(S, [timestamp], '1970-01-01')) = '$month';
     select CASE when @IngestionCount <= 300 then @IngestionCount * 0.60
      when @IngestionCount > 300 and @IngestionCount <= 2000 then @IngestionCount * 0.57
       when @IngestionCount > 2000 and @IngestionCount <= 4500 then @IngestionCount * 0.54
        When @IngestionCount > 4500 and @IngestionCount <= 6500 then @IngestionCount * 0.51
         else 0
         end
      ",

      format='table'
    )
  );

local PanelStatistics = grafana.tablePanel.new(
    title="List of Succefull Ingestion's",
    datasource='Azure SQL Server',
    description="@todo"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      select job_id as 'Run ID', publisher_name,project_name as 'Application Source',dataset_name as 'Dataset Name',landing_zone as 'Landing Zone ', 'Success' as Status,  dateadd(S, [timestamp], '1970-01-01') as 'Date'
      FROM [observability].[event]  where metric_name= 'processing_exit_code'
      AND event_type = 'processingfinished'    AND metric_value = 0    AND context_id in ($context)
      ANd datename(Month, dateadd(S, [timestamp], '1970-01-01')) = '$month';
      ",
      format='table'
    )
  );

local PanelHistogramCost = grafana.barChart.new(
    title="Montly Cost Graphical Yearly Representation ",
    description='todo',
    datasource='Azure SQL Server',
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT COUNT(job_id) as 'Succeded Ingestions', datename(Month, dateadd(S, [timestamp], '1970-01-01')) AS 'IngestionMonth' FROM [observability].[event]
      where metric_name= 'processing_exit_code'
      AND event_type =  'processingfinished'
      AND metric_value =  0
      AND context_id in ($context)
      AND datename(Year, dateadd(S, [timestamp], '1970-01-01')) = '$year'
      group by datename(Month, dateadd(S, [timestamp], '1970-01-01')) 
      ORDER BY 
      CASE datename(Month, dateadd(S, [timestamp], '1970-01-01'))
            WHEN 'January' THEN 0
            WHEN 'February' THEN 1
            WHEN 'March' THEN 2
            WHEN 'April' THEN 3
            WHEN 'May' THEN 4
            WHEN 'June' THEN 5
            WHEN 'July' THEN 6
            WHEN 'August' THEN 7
            WHEN 'September' THEN 8
            WHEN 'October' THEN 9
            WHEN 'November' THEN 10
            ELSE 11
      END",
      format='table'
    )
  );

grafana.dashboard.new(
  title='Montly Cost Dashboard v2',
  editable='false',
  schemaVersion=37,
  uid='21EiXdsfddd14Dv2',
  tags=['monitoring', 'observability', 'internal', 'obsolete'])

.addTemplate(projectTemplate)
.addTemplate(datasetTemplate)
.addTemplate(stageTemplate)
.addTemplate(MonthTemplate)
.addTemplate(YearTemplate)
.addTemplate(ContextTmplHided)
.addTemplate(TimestampTemplate)
.addTemplate(NextMonthTimestampTemplate)

.addPanel(panel = SuccessRun, gridPos={h:4,w:4,x:0,y: 0})
.addPanel(panel = CostPanel, gridPos={h:4,w:4,x:4,y: 0})

.addPanel(panel = TotalApplicationSource, gridPos={h:4,w:4,x:11,y: 0})
.addPanel(panel = TotalDataSets, gridPos={h:4,w:4,x:15,y: 0})
.addPanel(panel = TotalIngestionRun, gridPos={h:4,w:5,x:19,y: 0})

.addPanel(panel = PanelHistogramCost, gridPos={h:10,w:24,x:0,y: 5})
.addPanel(panel = PanelStatistics, gridPos={h:20,w:24,x:0,y: 15})
+ {
"timepicker": {
    "hidden": true
  }
}

