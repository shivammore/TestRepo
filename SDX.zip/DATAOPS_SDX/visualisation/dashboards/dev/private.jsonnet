local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;
local template = grafana.template;


//Variable
local TemplateSchemaName = template.new(
    name='SchemaName',
    datasource='Azure SQL Server',
    query='
      select distinct SchemaName from (
        select SchemaName from [observability].[biplatform_ingestion_dailyreference] 
        union 
        select SchemaName from [observability].[biplatform_ingestion_weeklyreference] 
 	      union 
        select SchemaName from [observability].[biplatform_ingestion_monthlyreference] 
        ) t',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='SchemaName'
  );

local TemplateDatasetName = template.new(
    name='DatasetName',
    datasource='Azure SQL Server',
    query='
      select distinct DatasetName from (
        select DatasetName from [observability].[biplatform_ingestion_dailyreference] 
        union 
        select DatasetName from [observability].[biplatform_ingestion_weeklyreference] 
 	      union 
        select DatasetName from [observability].[biplatform_ingestion_monthlyreference] 
      ) t',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='DatasetName'
  );

local TemplateLoadingType = template.new(
    name='LoadingType',
    datasource='Azure SQL Server',
    query='select distinct LoadingType from [observability].[biplatform_ingestion]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='LoadingType'
  );

local TemplateStatus = template.new(
    name='Status',
    datasource='Azure SQL Server',
    query='select distinct CAST(Status AS tinyint) from [observability].[biplatform_ingestion]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Status'
  );


//Panels
local dataPanelDailyIngestionStatus = grafana.tablePanel.new(
    title="BI Platfrom: Last Daily Ingestion Status",
    datasource='Azure SQL Server',
    description="",
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
        With 
          DailySchedule as (
            select 
              *,
              (DATEDIFF(dd, 0,GETDATE()) + CONVERT(DATETIME, Schedule)) as DailySchedule
            from [observability].[biplatform_ingestion_dailyreference]
            where Frequency = 'day'
          ),
          LastIngestion as (
            SELECT 
              SchemaName,
              DatasetName,
              LoadingHistoryId,
              LoadingType,
              StartTime,
              EndTime,
              RowsCount,
              Status  
            FROM (
              SELECT 
                * ,
                ROW_NUMBER() OVER(PARTITION BY SchemaName, DatasetName ORDER BY EndTime DESC) AS ranked_order
              FROM [observability].[biplatform_ingestion]
              WHERE 
                SchemaName IN ($SchemaName)
                AND  DatasetName IN ($DatasetName)
                AND  LoadingType IN ($LoadingType)
                AND  Status IN ($Status)
            ) a
            WHERE a.ranked_order = 1
          )

        SELECT 
          DailySchedule.SchemaName,
          DailySchedule.DatasetName,
          LastIngestion.LoadingHistoryId,
          LastIngestion.LoadingType,
          LastIngestion.StartTime,
          LastIngestion.EndTime,
          LastIngestion.RowsCount,
          LastIngestion.Status,
          DailySchedule.Frequency,
          CAST(DailySchedule.Schedule as char) as ScheduleTime,
          DailySchedule.DailySchedule,
          DATEDIFF(MINUTE, DailySchedule.DailySchedule , LastIngestion.EndTime ) as Delay
        FROM LastIngestion 
        RIGHT JOIN DailySchedule
        ON DailySchedule.SchemaName = LastIngestion.SchemaName and DailySchedule.DatasetName = LastIngestion.DatasetName
        WHERE 
          DailySchedule.SchemaName IN ($SchemaName)
          AND  DailySchedule.DatasetName IN ($DatasetName)
      ",
      format='table',
    )
  ).addOverridesByFieldName(
  field='Delay',
  properties=[
    { id: 'custom.displayMode', value: 'color-background' },
    {
      id: 'thresholds',
      value: {
        mode: 'absolute',
        steps: 
         [
                {
                  "color": "red",
                  "value": 0
                },
                {
                  "value": -60,
                  "color": "green"
                }
        ]
      },
    },
  ]
).addOverridesByFieldName(
  field='Status',
  properties=[
    { id: 'custom.displayMode', value: 'color-background' },
    {
      id: 'thresholds',
      value: {
        mode: 'absolute',
        steps: 
         [
                {
                  "color": "green",
                  "value": null
                },
                {
                  "value": 1,
                  "color": "red"
                }
        ]
      },
    },
  ]
).addOverridesByFieldName(
  field='RowsCount',
  properties=[
    { id: 'custom.displayMode', value: 'color-background' },
    {
      id: 'thresholds',
      value: {
        mode: 'absolute',
        steps: 
         [
                {
                  "color": "red",
                  "value": null
                },
                {
                  "value": 1,
                  "color": "green"
                }
        ]
      },
    },
  ]
);



//add row in grafana
local LastDailyIngestions = row.new(title="BI PLATFORM: Daily Ingestion", collapse=true).addPanel(
  panel=dataPanelDailyIngestionStatus,gridPos={h: 20, w: 24, x: 0, y: 30}
);


//dashboard
grafana.dashboard.new(
  title='Private dashboard test',
  editable='false',
  schemaVersion=37,
  timezone='utc',
  uid='123PRIVATEfXXXX',
  tags=['monitoring', 'observability'])
.addTemplate(TemplateSchemaName)
.addTemplate(TemplateDatasetName)
.addTemplate(TemplateLoadingType)
.addTemplate(TemplateStatus)
.addPanel(panel =LastDailyIngestions , gridPos={h:14,w:24,x:0,y: 15})

