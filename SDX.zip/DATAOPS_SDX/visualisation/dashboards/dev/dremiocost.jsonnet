 local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;


local ResourceTemplate =  tmpl.new(
    name='selectedresource',
    datasource='Azure SQL Server',
    query= "SELECT TOP 1  value  FROM dbo.conf WHERE [key] = 'DREMIO_CONSUMPTION_URI_AZURE_MONITOR' ORDER BY [timestamp] DESC",
   refresh='load',
   includeAll=true,
   multi=true,
   label='Resource',
  );


local projectTemplate =  tmpl.new(
    name='Source',
    datasource='Azure Monitor',
    queryType='Azure Log Analytics',
    query=|||
              traces
              | extend message = parse_json(message)
              | mv-expand dataset = message.parentsList
              | extend Source = tostring(dataset.name)
              | extend datatsetName = tostring(split(Source, '.')[array_length(split(Source, '.')) - 1]) 
              | extend Applicationsource = substring(Source, 0, strlen(Source) - strlen(datatsetName) - 1)
              | extend datasetZone = case(split(dataset.name, ".").[0] in ('Gold', 'Bronze', 'Silver', 'gold', 'silver', 'bronze'),split(dataset.name, ".")[0],split(dataset.name, ".")[1])
              | where datasetZone in ('bronze','silver','gold')
              | project Applicationsource
           |||,
   refresh='load',
   includeAll=true,
   multi=true,
   label='Application Source',
   resources= ["$selectedresource"],
  );

local datasetTemplate =  tmpl.new(
    name='Dataset',
    datasource='Azure Monitor',
    queryType='Azure Log Analytics',
    query=|||
              traces
              | extend message = parse_json(message)
              | mv-expand dataset = message.parentsList
              | extend Source = dataset.name
              | extend datasetName = split(Source, '.')[array_length(split(Source, '.')) - 1]
              | extend datasetZone = case(split(dataset.name, ".").[0] in ('Gold', 'Bronze', 'Silver', 'gold', 'silver', 'bronze'),split(dataset.name, ".")[0],split(dataset.name, ".")[1])
              | where datasetZone in ('bronze','silver','gold')
              | project datasetName
           |||,
   refresh='load',
   includeAll=true,
   multi=true,
   label='Dataset Name',
   resources=["$selectedresource"],
  );


local stageTemplate =  tmpl.custom(
    name='stage',
    current='silver',
    query='silver,bronze,gold',
    includeAll=true,
    multi=true,
    label="Stage"
  );

local MonthTemplate = tmpl.custom(
    name='Month',
    query="January,February,March,April,May,June,July,August,September,October,November,December",
    current='April',
    includeAll=false,
    multi=false,
    label='Month'
  );

local YearTemplate =  tmpl.new(
    name='year',
    datasource='Azure Monitor',
    queryType='Azure Log Analytics',
    query=|||
              traces
              | extend message = parse_json(message)
              | extend startdate = unixtime_seconds_todatetime(todouble(message.start)/1000)
              | extend year = tostring(getyear(startdate))
              | where year != ''
              | project year
           |||,
   refresh='load',
   includeAll=true,
   multi=true,
   label='Year',
   resources=["$selectedresource"],
  );

local MonthlyCost = statPanel.new(
    title="Monthly Cost for Succeded Queries",
    datasource='Azure Monitor',
    description="This metric represent the Cost of Succeded queries for the selected month",
    colorMode='background',
    unit='currencyEUR'
  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.azuremonitor.target(
     query=|||
              let months = dynamic({"1":"January", "2":"February", "3":"March","4":"April","5":"May","6":"June","7":"July","8":"August","9":"September","10":"October","11":"November","12":"December"});
                let initailquery = materialize(traces
                | extend message = parse_json(message)
                | extend startdate = unixtime_seconds_todatetime(todouble(message.start)/1000)
                | extend year = tostring(getyear(startdate))
                | mv-expand dataset = message.parentsList
                | extend Source = tostring(dataset.name)
                | extend datatsetName = tostring(split(Source, '.')[array_length(split(Source, '.')) - 1])
                | extend Applicationsource = substring(Source, 0, strlen(Source) - strlen(datatsetName) - 1)
                | extend outcome = message.outcome
                | extend month = months[tostring(getmonth(startdate))]
                | extend username = message.username, runningTime= todouble(message.runningTime)
                | extend datasetZone = case(split(dataset.name, ".").[0] in ('Gold', 'Bronze', 'Silver', 'gold', 'silver', 'bronze'),  split(dataset.name, ".")[0],split(dataset.name, ".")[1])
                  | where datatsetName in ($Dataset) and Applicationsource in ($Source) and outcome == 'COMPLETED' and username !in ('data_core_services') and datasetZone  in ($stage) and year in ($year) and month in ('$Month')
                | summarize Processing_time = todecimal(sum(runningTime) / 60000) by Applicationsource, Monthname = tostring(month)
                );
                initailquery
                | extend cost = case(
                        Processing_time <= 100.00 , todouble(Processing_time) * 4,
                        Processing_time > 100.00 and Processing_time <= 400.00, todouble(Processing_time) * 3,
                        Processing_time > 400.00 and Processing_time <= 1000.00, todouble(Processing_time) * 2,
                        Processing_time > 1000.00, todouble(Processing_time) * 1.5, 0.0)
                | summarize sum(cost) by Monthname
            |||,
     resources=["$selectedresource"],
    )
  );

local YearlylHistogramCost = grafana.barChart.new(
    title="Yearly Cost for Succeeded Queries",
    description='This graph represents the Yearly cost evolution for the Succeeded queries',
    datasource='Azure Monitor',
    unit='currencyEUR'
  ).addTarget(
     target=grafana.azuremonitor.target(
     query=|||
              let months = dynamic({"1":"January", "2":"February", "3":"March","4":"April","5":"May","6":"June","7":"July","8":"August","9":"September","10":"October","11":"November","12":"December"});
              let initailquery = materialize(traces
              | extend message = parse_json(message)
              | extend startdate = unixtime_seconds_todatetime(todouble(message.start)/1000)
              | extend year = tostring(getyear(startdate))
              | mv-expand dataset = message.parentsList
              | extend Source = tostring(dataset.name)
              | extend datatsetName = tostring(split(Source, '.')[array_length(split(Source, '.')) - 1])
              | extend Applicationsource = substring(Source, 0, strlen(Source) - strlen(datatsetName) - 1)
              | extend outcome = message.outcome
              | extend month = months[tostring(getmonth(startdate))]
              | extend username = message.username, runningTime= todouble(message.runningTime)
              | extend datasetZone = case(split(dataset.name, ".").[0] in ('Gold', 'Bronze', 'Silver', 'gold', 'silver', 'bronze'),  split(dataset.name, ".")[0],split(dataset.name, ".")[1])
              | where datatsetName in ($Dataset) and Applicationsource in ($Source) and outcome == 'COMPLETED' and username !in ('data_core_services') and datasetZone  in ($stage) and year in ($year)
              | summarize Processing_time = todecimal(sum(runningTime) / 60000) by Applicationsource, Month = tostring(month)
              );
              initailquery
              | extend cost = case(
                      Processing_time <= 100.00 , todouble(Processing_time) * 4,
                      Processing_time > 100.00 and Processing_time <= 400.00, todouble(Processing_time) * 3,
                      Processing_time > 400.00 and Processing_time <= 1000.00, todouble(Processing_time) * 2,
                      Processing_time > 1000.00, todouble(Processing_time) * 1.5, 0.0)
              | summarize Cost = sum(cost) by Month
              | order by Month asc 
            |||,
     resources=["$selectedresource"],
    )
 );

local ApplicationSourcetemplate = grafana.tablePanel.new(
    title="Cost By Application Source",
    datasource='Azure Monitor',
    description="This visualization represents the cost evolution for the Succeeded queries by selected application source"
  ).addTarget(
    target=grafana.azuremonitor.target(
      query=|||
                  let months = dynamic({"1":"January", "2":"February", "3":"March","4":"April","5":"May","6":"June","7":"July","8":"August","9":"September","10":"October","11":"November","12":"December"});
                  let initailquery = materialize(traces
                  | extend message = parse_json(message)
                  | mv-expand dataset = message.parentsList
                  | extend Source = tostring(dataset.name)
                  | extend datatsetName = tostring(split(Source, '.')[array_length(split(Source, '.')) - 1])
                  | extend Applicationsource = substring(Source, 0, strlen(Source) - strlen(datatsetName) - 1)
                  | extend outcome = message.outcome
                  | extend startdate = unixtime_seconds_todatetime(todouble(message.start)/1000)
                  | extend year = tostring(getyear(startdate))
                  | extend month = months[tostring(getmonth(startdate))]
                  | extend username = message.username, runningTime= todouble(message.runningTime)
                  | extend datasetZone = case(split(dataset.name, ".").[0] in ('Gold', 'Bronze', 'Silver', 'gold', 'silver', 'bronze'),  split(dataset.name, ".")[0],split(dataset.name, ".")[1])
                  | where datatsetName in ($Dataset) and Applicationsource in ($Source) and outcome == 'COMPLETED' and username !in ('data_core_services') and datasetZone  in ($stage) and year in ($year) and month in ('$Month')
                  | summarize Processing_time = todecimal(sum(runningTime) / 60000) by Applicationsource
                  );
                  initailquery
                  | extend cost = case(
                          Processing_time <= 100.00 , todouble(Processing_time) * 4,
                          Processing_time > 100.00 and Processing_time <= 400.00, todouble(Processing_time) * 3,
                          Processing_time > 400.00 and Processing_time <= 1000.00, todouble(Processing_time) * 2,
                          Processing_time > 1000.00, todouble(Processing_time) * 1.5, 0.0)
                  | project Applicationsource, processingtime = Processing_time, cost
                  | order by Applicationsource
            |||,
      resources=["$selectedresource"],
    )
).addOverridesByFieldName(
  field='processingtime',
  properties=[
    { id: 'unit', value: 'm' },
  ]
).addOverridesByFieldName(
  field='cost',
  properties=[
    { id: 'unit', value: 'currencyEUR' },
  ]
);

local Datasettemplate = grafana.tablePanel.new(
    title="Cost By Dataset",
    datasource='Azure Monitor',
    description="This visualization represents the cost evolution for the Succeeded queries by selected Dataset"
  ).addTarget(
    target=grafana.azuremonitor.target(
      query=|||
              let months = dynamic({"1":"January", "2":"February", "3":"March","4":"April","5":"May","6":"June","7":"July","8":"August","9":"September","10":"October","11":"November","12":"December"});
              let initailquery = materialize(traces
              | extend message = parse_json(message)
              | mv-expand dataset = message.parentsList
              | extend Source = tostring(dataset.name)
                | extend datatsetName = tostring(split(Source, '.')[array_length(split(Source, '.')) - 1])
                | extend Applicationsource = substring(Source, 0, strlen(Source) - strlen(datatsetName) - 1)
              | extend outcome = message.outcome
              | extend startdate = unixtime_seconds_todatetime(todouble(message.start)/1000)
              | extend year = tostring(getyear(startdate))
              | extend month = months[tostring(getmonth(startdate))]
              | extend username = message.username, runningTime= todouble(message.runningTime)
              | extend datasetZone = case(split(dataset.name, ".").[0] in ('Gold', 'Bronze', 'Silver', 'gold', 'silver', 'bronze'),  split(dataset.name, ".")[0],split(dataset.name, ".")[1])
              | where datatsetName in ($Dataset) and Applicationsource in ($Source) and outcome == 'COMPLETED' and username !in ('data_core_services') and datasetZone  in ($stage) and year in ($year) and month in ('$Month')
              | summarize Processing_time = todecimal(sum(runningTime) / 60000) by datatsetName
              );
              initailquery
              | extend cost = case(
                      Processing_time <= 100.00 , todouble(Processing_time) * 4,
                      Processing_time > 100.00 and Processing_time <= 400.00, todouble(Processing_time) * 3,
                      Processing_time > 400.00 and Processing_time <= 1000.00, todouble(Processing_time) * 2,
                      Processing_time > 1000.00, todouble(Processing_time) * 1.5, 0.0)
              | project datatsetName, processingtime = Processing_time, cost
              | order by datatsetName
          |||,
      resources=["$selectedresource"],
    )
).addOverridesByFieldName(
  field='processingtime',
  properties=[
    { id: 'unit', value: 'm' },
  ]
).addOverridesByFieldName(
  field='cost',
  properties=[
    { id: 'unit', value: 'currencyEUR' },
  ]
);

local Queriestemplate = grafana.tablePanel.new(
    title="Query Details",
    datasource='Azure Monitor',
    description="This visualization represents the Succeeded queries Data"
  ).addTarget(
    target=grafana.azuremonitor.target(
      query=|||
              let months = dynamic({"1":"January", "2":"February", "3":"March","4":"April","5":"May","6":"June","7":"July","8":"August","9":"September","10":"October","11":"November","12":"December"});
              traces
              | extend message = parse_json(message)
              | mv-expand dataset = message.parentsList
              | extend Source = tostring(dataset.name)
              | extend datatsetName = tostring(split(Source, '.')[array_length(split(Source, '.')) - 1])
              | extend Applicationsource = substring(Source, 0, strlen(Source) - strlen(datatsetName) - 1)
              | extend outcome = message.outcome
              | extend query = message.queryText
              | extend startdate = unixtime_seconds_todatetime(todouble(message.start)/1000)
              | extend year = tostring(getyear(startdate))
              | extend month = months[tostring(getmonth(startdate))]
              | extend username = message.username, runningTime= todouble(message.runningTime)
              | extend datasetZone = case(split(dataset.name, ".").[0] in ('Gold', 'Bronze', 'Silver', 'gold', 'silver', 'bronze'),  split(dataset.name, ".")[0],split(dataset.name, ".")[1])
              | extend processing_time_in_min = todouble(message.runningTime)/60000
              | where datatsetName in ($Dataset) and Applicationsource in ($Source) and username !in ('data_core_services') and datasetZone  in ($stage) and year in ($year) and month in ('$Month')
              | project username, Applicationsource,datatsetName, datasetZone, query, outcome, startdate, processingtime = processing_time_in_min
              | order by datatsetName
          |||,
      resources=["$selectedresource"],
    )
).addOverridesByFieldName(
  field='processingtime',
  properties=[
    { id: 'unit', value: 'm' },
  ]
);

grafana.dashboard.new(
  title='Dremio Consumption Cost Dashboard',
  editable='false',
  schemaVersion=37,
  uid='75RiDdTfl7714a',
  tags=['monitoring', 'observability', 'internal', 'obsolete'])


.addTemplate(projectTemplate)
.addTemplate(datasetTemplate)
.addTemplate(stageTemplate)
.addTemplate(MonthTemplate)
.addTemplate(YearTemplate)
.addTemplate(ResourceTemplate)

.addPanel(panel = MonthlyCost, gridPos={h:7,w:5,x:0,y: 0})
.addPanel(panel = YearlylHistogramCost, gridPos={h:7,w:19,x:5,y: 0})
.addPanel(panel = ApplicationSourcetemplate, gridPos={h:8,w:24,x:0,y: 7})
.addPanel(panel = Datasettemplate, gridPos={h:8,w:24,x:0,y: 15})
.addPanel(panel = Queriestemplate, gridPos={h:8,w:24,x:0,y: 23})
+ {
"timepicker": {
    "hidden": true
  }
}

