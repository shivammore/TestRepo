local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;

local projectTemplate =   tmpl.new(
    name='project',
    datasource='Azure SQL Server',
    query='select distinct project_name from [observability].[event]',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Application Source'
  );


local stageTemplate =  tmpl.custom(
    name='stage',
    current='silver',
    query='silver,bronze',
    includeAll=true,
    multi=true,
    label="Zone"
  );


local datasetTemplate = tmpl.new(
    name='dataset',
    datasource='Azure SQL Server',
    query='select distinct dataset_name from [observability].[event]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Dataset Name'
  );


local MonthTemplate = tmpl.custom(
    name='month',
    query="January,February,March,April,May,June,July,August,September,October,November,December",
    current='January',
    includeAll=false,
    multi=false,
    label='Month'
  );

local YearTemplate = tmpl.new(
    name='year',
    datasource='Azure SQL Server',
    query="SELECT distinct YEAR(dateadd(S, [timestamp], '1970-01-01')) as 'Year' FROM [observability].[event]",
    current='2023',
    includeAll=false,
    multi=false,
    label='Year',
    refresh='load'
  );


 local TimestampTemplate = tmpl.new(
  name='timestamp',
  datasource='Azure SQL Server',
  hide = 'true',
  query=|||
    DECLARE @MonthName NVARCHAR(50) = '$month'; -- Using Grafana variable
    DECLARE @Year INT = $year; -- Using Grafana variable
    DECLARE @MonthNumber INT = MONTH(CAST(@MonthName + ' 01 2023' AS DATETIME));
    SELECT DATEDIFF(SECOND, '19700101', DATEFROMPARTS(@Year, @MonthNumber, 1)) as 'Timestamp';
  |||,
  current='',  // Not setting a default current value
  includeAll=false,
  multi=false,
  label='Timestamp (UTC)',
  refresh='load'
);

local NextMonthTimestampTemplate = tmpl.new(
  name='next_month_timestamp',
  datasource='Azure SQL Server',
  hide = 'true',
  query=|||
    DECLARE @InitialTimestamp INT = $timestamp; -- Using Grafana variable for the original timestamp
    SELECT @InitialTimestamp + 2592000 as 'NextMonthTimestamp';  -- Adding 2,592,000 seconds
  |||,
  current='',  // Not setting a default current value
  includeAll=false,
  multi=false,
  label='Next Month Timestamp (UTC)',
  refresh='load'

);


local ContextTmplHided = tmpl.new(
  name='context',
  datasource='Azure SQL Server',
  query="

    SELECT distinct(context_id)
    FROM [observability].[event]
    WHERE
    project_name in ($project)
    and dataset_name in ($dataset)
    and landing_zone in ($stage)
    ",
  current='all',
  refresh='load',
  hide = 'true',
  includeAll=true,
  multi=false,
  label='Context'
);



local TotalApplicationSource =
  statPanel.new(
    title='Total Application Source',
    datasource='Azure SQL Server',
    description="This metric represents the number of sources that are monitored during the selected month",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'white',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT  COUNT(DISTINCT project_name) FROM [observability].[event]
      where metric_name= 'processing_exit_code'
      AND event_type =  'processingfinished'
      AND context_id in ($context)
      ",
      format='table'
    )
  );


local TotalDataSets =
  statPanel.new(
    title='Total Datasets',
    datasource='Azure SQL Server',
    description="This metric represents the number of datasets that are monitored during the selected month and for the selected source(s)",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'white',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT  COUNT(DISTINCT dataset_name) FROM [observability].[event]
      where metric_name= 'processing_exit_code'
      AND event_type =  'processingfinished'
      AND context_id in ($context)
      ",
      format='table'
    )
  );


local TotalIngestionRun =
  statPanel.new(
    title="Total Ingestions",
    datasource='Azure SQL Server',
    description="This metric represents the total number of ingestions that are monitored during the selected month and for the selected source(s)",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'white',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT  COUNT(job_id) FROM [observability].[event]
      where metric_name= 'processing_exit_code'
      AND event_type =  'processingfinished'
      AND context_id in ($context)
      ANd datename(Month, dateadd(S, [timestamp], '1970-01-01')) = '$month';
      ",
      format='table'
    )
  );


local SuccessRun =
  statPanel.new(
    title="Successful Ingestions",
    datasource='Azure SQL Server',
    description="This metric represent the number of ingestion that has the Success status for the selected month",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      SELECT  COUNT(job_id) FROM [observability].[event]
      where metric_name= 'processing_exit_code'
      AND event_type =  'processingfinished'
      AND metric_value =  0
      AND context_id in ($context)
      ANd datename(Month, dateadd(S, [timestamp], '1970-01-01')) = '$month';
      ",

      format='table'
    )
  );

local CostPanel =
  statPanel.new(
    title="Monthly Cost for Successful Ingestions",
    datasource='Azure SQL Server',
    description="Monthly Cost for Successful Ingestions based on the pricing framework defined by D&A team",
    colorMode='background',
    unit='€'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      declare @IngestionCount int
      Select @IngestionCount = count(job_id) FROM [observability].[event]
      where metric_name= 'processing_exit_code'
      AND event_type = 'processingfinished'
	  AND context_id in ($context)
	  AND metric_value = 0
      ANd datename(Month, dateadd(S, [timestamp], '1970-01-01')) = '$month';
     select CASE when @IngestionCount <= 300 then @IngestionCount * 0.60
      when @IngestionCount > 300 and @IngestionCount <= 2000 then @IngestionCount * 0.57
       when @IngestionCount > 2000 and @IngestionCount <= 4500 then @IngestionCount * 0.54
        When @IngestionCount > 4500 then @IngestionCount * 0.51
         end
      ",

      format='table'
    )
  );

local PanelStatistics = grafana.tablePanel.new(
    title="List of Successful Ingestions",
    datasource='Azure SQL Server',
    description="This table lists all the successfuls ingestions monitored during the selected month for the selected source(s)"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
      select job_id as 'Run ID', publisher_name,project_name as 'Application Source',dataset_name as 'Dataset Name',landing_zone as 'Landing Zone ', 'Success' as Status,  dateadd(S, [timestamp], '1970-01-01') as 'Date'
      FROM [observability].[event]  where metric_name= 'processing_exit_code'
      AND event_type = 'processingfinished'    AND metric_value = 0    AND context_id in ($context)
      ANd datename(Month, dateadd(S, [timestamp], '1970-01-01')) = '$month';
      ",
      format='table'
    )
  );

local PanelHistogramCost = grafana.barChart.new(
    title="Cost Yearly Representation",
    description='This graph represents the monthly cost evolution for the selected source(s)',
    datasource='Azure SQL Server',
  ).addTarget(
    target=grafana.sql.target(
      rawSql="with cte1 as
      (
	      SELECT COUNT(job_id) as 'IngestionCount', datename(Month, dateadd(S, [timestamp], '1970-01-01')) as 'MonthPart',
     	    datepart(Month, dateadd(S, [timestamp], '1970-01-01')) as 'MonthNumber'
	      FROM [observability].[event]
	      where
          metric_name= 'processing_exit_code'
          AND event_type =  'processingfinished'
          AND metric_value =  0
          AND context_id in ($context)
          AND datename(Year, dateadd(S, [timestamp], '1970-01-01')) = '$year'
	      group by
          datename(Month, dateadd(S, [timestamp], '1970-01-01')),
          datepart(Month, dateadd(S, [timestamp], '1970-01-01'))
      )
        select MonthPart, CASE when IngestionCount <= 300 then IngestionCount * 0.60
            when IngestionCount > 300 and IngestionCount <= 2000 then IngestionCount * 0.57
            when IngestionCount > 2000 and IngestionCount <= 4500 then IngestionCount * 0.54
            When IngestionCount > 4500 then IngestionCount * 0.51
            end
          from cte1
        order by  MonthNumber",
      format='table'
    )
  );

grafana.dashboard.new(
  title='Montly Cost Dashboard',
  editable='false',
  schemaVersion=37,
  uid='21EiXdsfddd14D',
  tags=['monitoring', 'observability', 'internal', 'obsolete'])

.addTemplate(projectTemplate)
.addTemplate(datasetTemplate)
.addTemplate(stageTemplate)
.addTemplate(MonthTemplate)
.addTemplate(YearTemplate)
.addTemplate(ContextTmplHided)
.addTemplate(TimestampTemplate)
.addTemplate(NextMonthTimestampTemplate)

.addPanel(panel = SuccessRun, gridPos={h:4,w:4,x:0,y: 0})
.addPanel(panel = CostPanel, gridPos={h:4,w:4,x:4,y: 0})

.addPanel(panel = TotalApplicationSource, gridPos={h:4,w:4,x:11,y: 0})
.addPanel(panel = TotalDataSets, gridPos={h:4,w:4,x:15,y: 0})
.addPanel(panel = TotalIngestionRun, gridPos={h:4,w:5,x:19,y: 0})

.addPanel(panel = PanelHistogramCost, gridPos={h:10,w:24,x:0,y: 5})
.addPanel(panel = PanelStatistics, gridPos={h:20,w:24,x:0,y: 15})
+ {
"timepicker": {
    "hidden": true
  }
}

