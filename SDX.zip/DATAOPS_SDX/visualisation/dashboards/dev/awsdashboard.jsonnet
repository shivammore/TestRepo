local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;

local awsTemplate =   tmpl.new(
    name='workspace_name',
    datasource='Azure SQL Server',
    query="SELECT DISTINCT workspace_name FROM [dbo].[aws_cost_view] where workspace_name <> ''",
    refresh='load',
    includeAll=false,
    multi=true,
    label='Analytic Workspaces'
  );

local monthTemplate =   tmpl.new(
    name='month',
    datasource='Azure SQL Server',
    query="SELECT DATENAME(Month,DATEADD(Month,[observability].[dab_event_cost].month -1, '1900-01-01')) As MonthName FROM [observability].[dab_event_cost]",
    refresh='load',
    includeAll=true,
    multi=true,
    label='Month'
  );

local yearTemplate = tmpl.new(
    name='year',
    datasource='Azure SQL Server',
    query='Select year from [observability].[dab_event_cost]',
    refresh='load',
    includeAll=true,
    multi=false,
    label='Year'
  );

local statsTotalAwsCost =
  statPanel.new(
    title='Total Analytics Workspace Cost',
    datasource='Azure SQL Server',
    description="This visualization showcases the combined cost of Data ingestion and Data storage and Dremio storage consumption of the selected projects for selected Analytics Workspace",
    colorMode='background',
    unit='€'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT  SUM(cost) FROM [dbo].[aws_cost_view] where workspace_name in ($workspace_name) and year in ($year) and  DateName( month, DateAdd( month, month , 0 ) - 1 ) in ($month)",
      format='table'
    )
  );

local tableChartAWSProjectWise = grafana.barChart.new(
   title="Projectwise Breakup of Total Analytics Workspace Cost",
   datasource='Azure SQL Server',
   description='This graph represents project wise breakup of total cost of analytics workspace',
  ).addTarget(
    target=grafana.sql.target(
      rawSql="WITH maincost AS (SELECT project_name, Sum(cost) AS cost
          FROM   [dbo].[aws_cost_view]
          WHERE  workspace_name in ($workspace_name) and year in ($year) and DateName( month, DateAdd( month, month , 0 ) - 1 ) in ($month)
          GROUP  BY project_name
          UNION ALL
          SELECT DISTINCT aws_project_name AS project_name,
                          0                AS cost
          FROM   [dbo].[aws_cost_view]
          WHERE  project_name IS NULL
                  AND  workspace_name in ($workspace_name))
        SELECT project_name AS 'Project Name',
              cost         AS 'Total Cost'
        FROM   maincost
        WHERE  project_name <> '' "
      ,
      format='table'
    )
  );

grafana.dashboard.new(
  title='Analytics Workspace Cost Dashboard',
  editable='false',
  schemaVersion=88,
  uid='39LiVdsfrrr888',
  tags=['monitoring', 'observability', 'SDX', 'workinprogress'])

.addTemplate(awsTemplate)
.addTemplate(monthTemplate)
.addTemplate(yearTemplate)

.addPanel(panel = statsTotalAwsCost, gridPos={h:4,w:6,x:0,y: 0})
.addPanel(panel = tableChartAWSProjectWise, gridPos={h:8,w:23,x:0,y:6})

+ {
"timepicker": {
    "hidden": true
  }
}


