local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;
local template = grafana.template;

local TemplateJobName = template.new(
    name='jobname',
    datasource='Azure SQL Server',
    query='select distinct [observability].[FlowLogs].Name from [observability].[FlowLogs]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Job Name'
  );

local TemplateResource = template.new(
    name='Resource',
    datasource='Azure SQL Server',
    query='SELECT distinct [observability].[FlowLogs].AzureResource FROM [observability].[FlowLogs]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Resource'
  );

local TemplateStatus = template.new(
    name='Status',
    datasource='Azure SQL Server',
    query='select distinct [observability].[FlowLogs].Status from [observability].[FlowLogs]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Status'
  );

local SuccessRun =
  statPanel.new(
    title="Succeeded Jobs",
    datasource='Azure SQL Server',
    description="This metric represent the number of Jobs that has the Success status",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="select count(*) from [observability].[FlowLogs] 
                where [observability].[FlowLogs].Status = 'Succeeded' and 
                [observability].[FlowLogs].Name in ($jobname) and
                [observability].[FlowLogs].AzureResource in ($Resource) and 
                DATEDIFF(second, '1970-01-01', [observability].[FlowLogs].Startdate) >= $__unixEpochFrom() and 
                DATEDIFF(second, '1970-01-01', [observability].[FlowLogs].Startdate) < $__unixEpochTo();
            ",
      format='table'
    )
  );

local FailedRun =
  statPanel.new(
    title="Failed Jobs",
    datasource='Azure SQL Server',
    description="This metric represent the number of Jobs that has the Failed status",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'semi-dark-red',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="select count(*) from [observability].[FlowLogs] 
                where [observability].[FlowLogs].Status = 'Failed' and 
                        [observability].[FlowLogs].Name in ($jobname) and
                        [observability].[FlowLogs].AzureResource in ($Resource) and 
                        DATEDIFF(second, '1970-01-01', [observability].[FlowLogs].Startdate) >= $__unixEpochFrom() and 
                DATEDIFF(second, '1970-01-01', [observability].[FlowLogs].Startdate) < $__unixEpochTo();
            ",
      format='table'
    )
  );

local CancelledRun =
  statPanel.new(
    title="Cancelled Jobs",
    datasource='Azure SQL Server',
    description="This metric represent the number of Jobs that has the Cancelled status",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'purple',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="select count(*) from [observability].[FlowLogs] 
                where [observability].[FlowLogs].Status = 'Cancelled' and 
                        [observability].[FlowLogs].Name in ($jobname) and
                        [observability].[FlowLogs].AzureResource in ($Resource) and 
                        DATEDIFF(second, '1970-01-01', [observability].[FlowLogs].Startdate) >= $__unixEpochFrom() and 
                DATEDIFF(second, '1970-01-01', [observability].[FlowLogs].Startdate) < $__unixEpochTo();
            ",
      format='table'
    )
  );

local RunningRun =
  statPanel.new(
    title="Running Jobs",
    datasource='Azure SQL Server',
    description="This metric represent the number of Jobs that has the Running status",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'orange',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="select count(*) from [observability].[FlowLogs] 
                where [observability].[FlowLogs].Status = 'Running' and 
                        [observability].[FlowLogs].Name in ($jobname) and
                        [observability].[FlowLogs].AzureResource in ($Resource) and 
                        DATEDIFF(second, '1970-01-01', [observability].[FlowLogs].Startdate) >= $__unixEpochFrom() and 
                DATEDIFF(second, '1970-01-01', [observability].[FlowLogs].Startdate) < $__unixEpochTo();
            ",
      format='table'
    )
  );

local JobDetailsPanelStatistics = grafana.tablePanel.new(
    title="Job Details",
    datasource='Azure SQL Server',
    description="This table lists all the Jobs for the selected sources"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
            SELECT [observability].[FlowLogs].Name as 'Job Name', 
            [observability].[FlowLogs].Startdate as 'Start Date', 
            [observability].[FlowLogs].EndDate as 'End Date', 
            [observability].[FlowLogs].Status as 'Job Status', 
            [observability].[FlowLogs].AzureResource as 'Resource' FROM [observability].[FlowLogs] 
            where  [observability].[FlowLogs].Name in ($jobname) and 
            [observability].[FlowLogs].Status in ($Status) and 
            [observability].[FlowLogs].AzureResource in ($Resource) and 
            DATEDIFF(second, '1970-01-01', [observability].[FlowLogs].Startdate) >= $__unixEpochFrom() and 
            DATEDIFF(second, '1970-01-01', [observability].[FlowLogs].Startdate) < $__unixEpochTo()
            order by [observability].[FlowLogs].Startdate desc; 
      ",
      format='table'
    )
  );


grafana.dashboard.new(
title='BI PLATFORM: Internal Jobs Monitoring',
time_from='now-24h',
editable='false',
schemaVersion=37,
uid='57Eildsfccr14R',
tags=['monitoring', 'observability', 'external', 'run_team'])

.addTemplate(TemplateJobName)
.addTemplate(TemplateResource)
.addTemplate(TemplateStatus)

.addPanel(panel = SuccessRun, gridPos={h:5,w:6,x:0,y: 1})
.addPanel(panel = FailedRun, gridPos={h:5,w:6,x:6,y: 1})
.addPanel(panel = CancelledRun, gridPos={h:5,w:6,x:12,y: 1})
.addPanel(panel = RunningRun, gridPos={h:5,w:6,x:18,y: 1})
.addPanel(panel = JobDetailsPanelStatistics, gridPos={h:15,w:24,x:0,y: 6})
