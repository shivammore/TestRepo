local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;
local template = grafana.template;


//Variable
local TemplateSchemaName = template.new(
    name='SchemaName',
    datasource='Azure SQL Server',
    query='
      select distinct SchemaName from (
        select SchemaName from [observability].[biplatform_ingestion_dailyreference] 
        union 
        select SchemaName from [observability].[biplatform_ingestion_weeklyreference] 
 	      union 
        select SchemaName from [observability].[biplatform_ingestion_monthlyreference] 
        ) t',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='SchemaName'
  );

local TemplateDatasetName = template.new(
    name='DatasetName',
    datasource='Azure SQL Server',
    query='
      select distinct DatasetName from (
        select DatasetName from [observability].[biplatform_ingestion_dailyreference] 
        union 
        select DatasetName from [observability].[biplatform_ingestion_weeklyreference] 
 	      union 
        select DatasetName from [observability].[biplatform_ingestion_monthlyreference] 
      ) t',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='DatasetName'
  );

local TemplateLoadingType = template.new(
    name='LoadingType',
    datasource='Azure SQL Server',
    query='select distinct LoadingType from [observability].[biplatform_ingestion]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='LoadingType'
  );

local TemplateStatus = template.new(
    name='Status',
    datasource='Azure SQL Server',
    query='select distinct CAST(Status AS tinyint) from [observability].[biplatform_ingestion]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Status'
  );


//Panels
local dataPanelIngestionHistory = grafana.tablePanel.new(
    title="BI Platfrom: Ingestion History",
    datasource='Azure SQL Server',
    description=""
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
        SELECT    
            SchemaName,
            DatasetName,
            LoadingType,
            StartTime,
            EndTime,
            RowsCount,
            Status,
            LoadingHistoryId
        FROM [observability].[biplatform_ingestion]
        WHERE 
          SchemaName IN ($SchemaName)
          AND  DatasetName IN ($DatasetName)
          AND  LoadingType IN ($LoadingType)
          AND  Status IN ($Status)
          AND $__timeFilter(StartTime)
        ORDER BY StartTime DESC
      ",
      format='table',
    )
  );

local dataPanelDailyIngestionStatus = grafana.tablePanel.new(
    title="BI Platfrom: Last Daily Ingestion Status",
    datasource='Azure SQL Server',
    description="",
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
        With 
          DailySchedule as (
            select 
              *,
              (DATEDIFF(dd, 0,GETDATE()) + CONVERT(DATETIME, Schedule)) as DailySchedule
            from [observability].[biplatform_ingestion_dailyreference]
            where Frequency = 'day'
          ),
          LastIngestion as (
            SELECT 
              SchemaName,
              DatasetName,
              LoadingHistoryId,
              LoadingType,
              StartTime,
              EndTime,
              RowsCount,
              Status  
            FROM (
              SELECT 
                * ,
                ROW_NUMBER() OVER(PARTITION BY SchemaName, DatasetName ORDER BY EndTime DESC) AS ranked_order
              FROM [observability].[biplatform_ingestion]
              WHERE 
                SchemaName IN ($SchemaName)
                AND  DatasetName IN ($DatasetName)
                AND  LoadingType IN ($LoadingType)
                AND  Status IN ($Status)
            ) a
            WHERE a.ranked_order = 1
          )

        SELECT 
          DailySchedule.SchemaName,
          DailySchedule.DatasetName,
          LastIngestion.LoadingHistoryId,
          LastIngestion.LoadingType,
          LastIngestion.StartTime,
          LastIngestion.EndTime,
          LastIngestion.RowsCount,
          LastIngestion.Status,
          DailySchedule.Frequency,
          CAST(DailySchedule.Schedule as char) as ScheduleTime,
          DailySchedule.DailySchedule,
          DATEDIFF(MINUTE, DailySchedule.DailySchedule , LastIngestion.EndTime ) as Delay
        FROM LastIngestion 
        RIGHT JOIN DailySchedule
        ON DailySchedule.SchemaName = LastIngestion.SchemaName and DailySchedule.DatasetName = LastIngestion.DatasetName
        WHERE 
          DailySchedule.SchemaName IN ($SchemaName)
          AND  DailySchedule.DatasetName IN ($DatasetName)
      ",
      format='table',
    )
  ).addOverridesByFieldName(
  field='Delay',
  properties=[
    { id: 'custom.displayMode', value: 'color-background' },
    {
      id: 'thresholds',
      value: {
        mode: 'absolute',
        steps: 
         [
                {
                  "color": "red",
                  "value": 0
                },
                {
                  "value": -60,
                  "color": "green"
                }
        ]
      },
    },
  ]
).addOverridesByFieldName(
  field='Status',
  properties=[
    { id: 'custom.displayMode', value: 'color-background' },
    {
      id: 'thresholds',
      value: {
        mode: 'absolute',
        steps: 
         [
                {
                  "color": "green",
                  "value": null
                },
                {
                  "value": 1,
                  "color": "red"
                }
        ]
      },
    },
  ]
).addOverridesByFieldName(
  field='RowsCount',
  properties=[
    { id: 'custom.displayMode', value: 'color-background' },
    {
      id: 'thresholds',
      value: {
        mode: 'absolute',
        steps: 
         [
                {
                  "color": "red",
                  "value": null
                },
                {
                  "value": 1,
                  "color": "green"
                }
        ]
      },
    },
  ]
);


local dataPanelWeeklyIngestionStatus = grafana.tablePanel.new(
    title="BI Platfrom: Last Weekly Ingestion Status",
    datasource='Azure SQL Server',
    description="",
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
        With 
            WeeklySchedule as (
                select 
                    *,
                    DATEDIFF(dd, 0,DATEADD(wk, DATEDIFF(wk,weekday,GETDATE()), weekday)) + CONVERT(DATETIME, Schedule) 
        as WeeklySchedule
                from [observability].[biplatform_ingestion_weeklyreference]
            ),
            LastIngestion as (
                SELECT 
                    SchemaName,
                    DatasetName,
                    LoadingHistoryId,
                    LoadingType,
                    StartTime,
                    EndTime,
                    RowsCount,
                    Status  
                FROM (
                    SELECT 
                        * ,
                        ROW_NUMBER() OVER(PARTITION BY SchemaName, DatasetName ORDER BY EndTime DESC) AS ranked_order
                    FROM [observability].[biplatform_ingestion]
                    WHERE 
                      SchemaName IN ($SchemaName)
                      AND  DatasetName IN ($DatasetName)
                      AND  LoadingType IN ($LoadingType)
                      AND  Status IN ($Status)
                ) a
                WHERE a.ranked_order = 1
            )
        SELECT 
            WeeklySchedule.SchemaName,
            WeeklySchedule.DatasetName,
            LastIngestion.LoadingHistoryId,
            LastIngestion.LoadingType,
            LastIngestion.StartTime,
            LastIngestion.EndTime,
            LastIngestion.RowsCount,
            LastIngestion.Status,
            CAST(WeeklySchedule.Schedule as char) as ScheduleTime,
            DATENAME(weekday,WeeklySchedule.Weekday) as Weekday,
            WeeklySchedule.WeeklySchedule,
            DATEDIFF(MINUTE, WeeklySchedule.WeeklySchedule , LastIngestion.EndTime ) as Delay
        FROM LastIngestion 
        RIGHT JOIN WeeklySchedule
        ON WeeklySchedule.SchemaName = LastIngestion.SchemaName and WeeklySchedule.DatasetName = LastIngestion.DatasetName
        WHERE 
          WeeklySchedule.SchemaName IN ($SchemaName)
          AND  WeeklySchedule.DatasetName IN ($DatasetName)",
      format='table',
    )
  ).addOverridesByFieldName(
  field='Delay',
  properties=[
    { id: 'custom.displayMode', value: 'color-background' },
    {
      id: 'thresholds',
      value: {
        mode: 'absolute',
        steps: 
         [
                {
                  "color": "red",
                  "value": 0
                },
                {
                  "value": -60,
                  "color": "green"
                }
        ]
      },
    },
  ]
).addOverridesByFieldName(
  field='Status',
  properties=[
    { id: 'custom.displayMode', value: 'color-background' },
    {
      id: 'thresholds',
      value: {
        mode: 'absolute',
        steps: 
         [
                {
                  "color": "green",
                  "value": null
                },
                {
                  "value": 1,
                  "color": "red"
                }
        ]
      },
    },
  ]
).addOverridesByFieldName(
  field='RowsCount',
  properties=[
    { id: 'custom.displayMode', value: 'color-background' },
    {
      id: 'thresholds',
      value: {
        mode: 'absolute',
        steps: 
         [
                {
                  "color": "red",
                  "value": null
                },
                {
                  "value": 1,
                  "color": "green"
                }
        ]
      },
    },
  ]
);


local dataPanelMonthlyIngestionStatus = grafana.tablePanel.new(
    title="BI Platfrom: Last Monthly Ingestion Status",
    datasource='Azure SQL Server',
    description="",
  ).addTarget(
    target=grafana.sql.target(
      rawSql="
        With 
            MonthlySchedule as (
              select 
                *,
                CASE
                  WHEN monthday > 0 THEN DATEDIFF(dd, 0,DATEADD(day, (monthday - day(GETDATE())), GETDATE())) + CONVERT(DATETIME, Schedule) 
                  WHEN monthday < 0 THEN DATEADD(dd, monthday,DATEADD(mm, DATEDIFF(m,0,GETDATE())+1,0)) + CONVERT(DATETIME, Schedule) 
                END as MonthlySchedule
              from [observability].[biplatform_ingestion_monthlyreference]
            ),
            LastIngestion as (
                SELECT 
                    SchemaName,
                    DatasetName,
                    LoadingHistoryId,
                    LoadingType,
                    StartTime,
                    EndTime,
                    RowsCount,
                    Status  
                FROM (
                    SELECT 
                        * ,
                        ROW_NUMBER() OVER(PARTITION BY SchemaName, DatasetName ORDER BY EndTime DESC) AS ranked_order
                    FROM [observability].[biplatform_ingestion]
                    WHERE 
                      SchemaName IN ($SchemaName)
                      AND  DatasetName IN ($DatasetName)
                      AND  LoadingType IN ($LoadingType)
                      AND  Status IN ($Status)
                ) a
                WHERE a.ranked_order = 1
            )
        SELECT 
            MonthlySchedule.SchemaName,
            MonthlySchedule.DatasetName,
            LastIngestion.LoadingHistoryId,
            LastIngestion.LoadingType,
            LastIngestion.StartTime,
            LastIngestion.EndTime,
            LastIngestion.RowsCount,
            LastIngestion.Status,
            CAST(MonthlySchedule.Schedule as char) as ScheduleTime,
            CASE 
              WHEN MonthlySchedule.Monthday > 0 THEN MonthlySchedule.Monthday
			        WHEN MonthlySchedule.Monthday < 0 THEN DAY(EOMONTH(GETDATE())) + MonthlySchedule.Monthday + 1
            END as Monthday,
            MonthlySchedule.MonthlySchedule,
            DATEDIFF(MINUTE, MonthlySchedule.MonthlySchedule , LastIngestion.EndTime ) as Delay
        FROM LastIngestion 
        RIGHT JOIN MonthlySchedule
        ON MonthlySchedule.SchemaName = LastIngestion.SchemaName and MonthlySchedule.DatasetName = LastIngestion.DatasetName
        WHERE 
          MonthlySchedule.SchemaName IN ($SchemaName)
          AND  MonthlySchedule.DatasetName IN ($DatasetName)
      ",
      format='table',
    )
  ).addOverridesByFieldName(
  field='Delay',
  properties=[
    { id: 'custom.displayMode', value: 'color-background' },
    {
      id: 'thresholds',
      value: {
        mode: 'absolute',
        steps: 
         [
                {
                  "color": "red",
                  "value": 0
                },
                {
                  "value": -60,
                  "color": "green"
                }
        ]
      },
    },
  ]
).addOverridesByFieldName(
  field='Status',
  properties=[
    { id: 'custom.displayMode', value: 'color-background' },
    {
      id: 'thresholds',
      value: {
        mode: 'absolute',
        steps: 
         [
                {
                  "color": "green",
                  "value": null
                },
                {
                  "value": 1,
                  "color": "red"
                }
        ]
      },
    },
  ]
).addOverridesByFieldName(
  field='RowsCount',
  properties=[
    { id: 'custom.displayMode', value: 'color-background' },
    {
      id: 'thresholds',
      value: {
        mode: 'absolute',
        steps: 
         [
                {
                  "color": "red",
                  "value": null
                },
                {
                  "value": 1,
                  "color": "green"
                }
        ]
      },
    },
  ]
);


//add row in grafana
local LastDailyIngestions = row.new(title="BI PLATFORM: Daily Ingestion", collapse=true).addPanel(
  panel=dataPanelDailyIngestionStatus,gridPos={h: 20, w: 24, x: 0, y: 30}
);
local LastWeeklyIngestions = row.new(title="BI PLATFORM: Weekly Ingestion", collapse=true).addPanel(
  panel=dataPanelWeeklyIngestionStatus,gridPos={h: 20, w: 24, x: 0, y: 30}
);
local LastMonthlyIngestions = row.new(title="BI PLATFORM: Monthly Ingestion", collapse=true).addPanel(
  panel=dataPanelMonthlyIngestionStatus,gridPos={h: 20, w: 24, x: 0, y: 30}
);
local IngestionsHistoryRow = row.new(title="BI PLATFORM: Ingestion History", collapse=true).addPanel(
  panel=dataPanelIngestionHistory,gridPos={h: 20, w: 24, x: 0, y: 30}
);



//dashboard
grafana.dashboard.new(
  title='BI PLATFORM: Ingestion Monitoring',
  editable='false',
  schemaVersion=37,
  timezone='utc',
  uid='123BIPLATfXXXX',
  tags=['monitoring', 'observability', 'external', 'run_team'])
.addTemplate(TemplateSchemaName)
.addTemplate(TemplateDatasetName)
.addTemplate(TemplateLoadingType)
.addTemplate(TemplateStatus)

.addPanel(panel =LastDailyIngestions , gridPos={h:14,w:24,x:0,y: 15})
.addPanel(panel =LastWeeklyIngestions , gridPos={h:14,w:24,x:0,y: 15})
.addPanel(panel =LastMonthlyIngestions , gridPos={h:14,w:24,x:0,y: 15})
.addPanel(panel=IngestionsHistoryRow, gridPos={h: 8, w: 24, x: 0, y: 20})
