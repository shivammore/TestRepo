local grafana = import 'grafonnet/grafana.libsonnet';

local filterSourceWithAlerting(sources) = [ source for source in sources if std.objectHas(source, 'alerting') && source.alerting != null ];

local flatSources(objs) = [
    {
        alerting: if std.type(obj.alerting) == "string" then obj.alerting else alerting,
    }
    for obj in objs
    for alerting in if std.type(obj.alerting) == "array" then obj.alerting else [obj.alerting]
];

local filterVolumeAlertRows(sources) = [
    source for source in sources
    if std.objectHas(source, 'alerting') &&  // Check if 'alerting' field exists
        source.alerting.type == 'threshold' &&
        std.objectHas(source.alerting, 'volume_check_threshold')
];

local convertToGrafanaAlertVolume(source, title) = 
    local volume_check_threshold = source.alerting.volume_check_threshold;
    local panelId = source.alerting.panel;
    local panelName = source.alerting.panelName;
    local channels = source.alerting.channels;
    local time = source.alerting.relativeTimeRange;

local RefreshJobRunSummary = "
    SELECT [Job Name] as 'Job_Name',FORMAT([Start Date], 'yyyy-MM-dd HH:mm:ss') as 'Start_Date', [Job Status] as 'Job_Status',
    case when status_color_code = 1 then 'Succeded but out of threshold' when status_color_code = 2 then 'Job run Failed' else 'With in the Threshold' end
    as 'Reason',status_color_code
    From Observability.bifinance_30days
    where DATEDIFF(second, '1970-01-01',[Start Date] ) >= $__unixEpochFrom() and 
        DATEDIFF(second, '1970-01-01',[Start Date] ) < $__unixEpochTo() and [Job Status] != 'Cancelled' and status_color_code > 0
    Group By [Job Name],[Start Date], [End Date], Threshold, Duration, [Job Status],[Flow Instance ID],[status_color_code]
    order by [Start Date]    
    ";

local FailedJobrunSummary = "
    select [Job Name] as 'Job_Name',FORMAT([Start Date], 'yyyy-MM-dd HH:mm:ss') as 'Start_Date', [Job Status] as 'Job_Status',[Flow Step Type] as 'Flow_Step_Type',[Type],Message,failed_status_color_code
    from observability.bifinance_30days
    where DATEDIFF(second, '1970-01-01',[Start date]) >= $__unixEpochFrom() and 
    DATEDIFF(second, '1970-01-01',[Start date]) < $__unixEpochTo() and [job status] = 'Failed'
    group by [Job Name],FORMAT([Start Date], 'yyyy-MM-dd HH:mm:ss'), [Job Status],[Flow Step Type],[Type],Message,failed_status_color_code
    order by FORMAT([Start Date], 'yyyy-MM-dd HH:mm:ss') desc
    ";

local rawSql = if panelId == 3 then RefreshJobRunSummary else FailedJobrunSummary;

local envs = if std.objectHas(source.alerting, 'silence') then source.alerting.silence else ['prod'];
local silence_labels = std.join("::", envs);

    {
        "uid": std.md5(std.format("Threshold_Alerts_%s",panelName)),
        "title": std.format("Threshold Alert: %s ──── %s", [title,panelName]),
        "condition": "C",
        "data": [
            {
                "refId": "A",
                "datasourceUid": "AzureSQLServer",
                "relativeTimeRange": { "from": time, "to": 0 },
                "model": {
                "format": "table",
                "hide": false,
                "intervalMs": 1000,
                "maxDataPoints": 43200,
                "rawQuery": true,
                "rawSql": rawSql,
                }
            },
            {
                "refId": "B",
                "relativeTimeRange": {
                    "from": 172800,
                    "to": 0
                },
                "datasourceUid": "__expr__",
                "model": {
                    "conditions": [
                        {
                            "evaluator": {
                                "params": [volume_check_threshold],
                                "type": "gt"
                            },
                            "operator": {
                                "type": "and"
                            },
                            "query": {
                                "params": [
                                    "B"
                                ]
                            },
                            "reducer": {
                                "params": [],
                                "type": "last"
                            },
                            "type": "query"
                        }
                    ],
                    "datasource": {
                        "type": "__expr__",
                        "uid": "__expr__"
                    },
                    "expression": "A",
                    "intervalMs": 1000,
                    "maxDataPoints": 43200,
                    "reducer": "last",
                    "refId": "B",
                    "type": "reduce"
                }
            },
            {
                "refId": "C",
                "relativeTimeRange": {
                    "from": 172800,
                    "to": 0
                },
                "datasourceUid": "__expr__",
                "model": {
                    "conditions": [
                        {
                            "evaluator": {
                                "params": [
                                    volume_check_threshold
                                ],
                                "type": "gt"
                            },
                            "operator": {
                                "type": "and"
                            },
                            "query": {
                                "params": [
                                    "C"
                                ]
                            },
                            "reducer": {
                                "params": [],
                                "type": "last"
                            },
                            "type": "query"
                        }
                    ],
                    "datasource": {
                        "type": "__expr__",
                        "uid": "__expr__"
                    },
                    "expression": "B",
                    "intervalMs": 1000,
                    "maxDataPoints": 43200,
                    "refId": "C",
                    "type": "threshold"
                }
            }
        ],
        "noDataState": "OK",
        "execErrState": "Alerting",
        "for": "1s",
        "annotations": {
            "__dashboardUid__": if panelId == 3 then "aeby66a90fls0g" else "aeby66a90fls0k",
            "__panelId__": panelId
        },
        "labels": {
            "alert_type": source.alerting.type,
            "env": silence_labels,
            "severity": source.alerting.severity,
            "dashboard_title": title,
            "panel_name" : panelName,
            "channels": std.join("::", channels),
        },
        "isPaused": false,
    };



local input_json = std.parseYaml(std.extVar("input"));
local dashboard_title = input_json.title;
local filtered_sources = filterSourceWithAlerting(input_json.sources);
local flat_sources = flatSources(filtered_sources);
local volume_threshold_alerts = filterVolumeAlertRows(flat_sources);
local volume_alerts_grafana = [convertToGrafanaAlertVolume(source, dashboard_title) for source in volume_threshold_alerts];
local interval = input_json.sources.alerting.interval;

{
    "apiVersion": 1,
    "groups": [
        {
        "orgId": 1,
        "name": input_json.title + " " + input_json.type,
        "folder": input_json.folder,
        "interval": input_json.interval,
        rules: volume_alerts_grafana,
        }
    ]
}