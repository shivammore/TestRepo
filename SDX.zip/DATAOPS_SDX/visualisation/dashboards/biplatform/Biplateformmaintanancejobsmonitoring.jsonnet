local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;
local template = grafana.template;

local TemplateJobName = template.new(
    name='jobname',
    datasource='Azure SQL Server',
    query='select distinct [observability].[JobLogs].Name from [observability].[JobLogs]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Job Name'
  );

local TemplateActivity = template.new(
    name='activity',
    datasource='Azure SQL Server',
    query='select distinct [observability].[JobLogs].Steps from [observability].[JobLogs]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Activity'
  );

local TemplateResource = template.new(
    name='Resource',
    datasource='Azure SQL Server',
    query='SELECT distinct [observability].[JobLogs].AzureResource FROM [observability].[JobLogs]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Resource'
  );

local TemplateStatus = template.new(
    name='Status',
    datasource='Azure SQL Server',
    query='select distinct [observability].[JobLogs].Status from [observability].[JobLogs]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Status'
  );

local SuccessRun =
  statPanel.new(
    title="Succeeded Jobs",
    datasource='Azure SQL Server',
    description="This metric represent the number of Jobs that has the Success status",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="select count(*) from [observability].[JobLogs] 
                where [observability].[JobLogs].Status = 'Succeeded' and
                [observability].[JobLogs].Name in ($jobname) and 
                [observability].[JobLogs].Steps in ($activity) and
                [observability].[JobLogs].AzureResource in ($Resource) and
                DATEDIFF(second, '1970-01-01', [observability].[JobLogs].Startdate) >= $__unixEpochFrom() and 
                DATEDIFF(second, '1970-01-01', [observability].[JobLogs].Startdate) < $__unixEpochTo();
            ",
      format='table'
    )
  );

local FailedRun =
  statPanel.new(
    title="Failed Jobs",
    datasource='Azure SQL Server',
    description="This metric represent the number of Jobs that has the Failed status",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'semi-dark-red',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="select count(*) from [observability].[JobLogs] 
                where [observability].[JobLogs].Status = 'Failed' and
                [observability].[JobLogs].Name in ($jobname) and 
                [observability].[JobLogs].Steps in ($activity) and
                [observability].[JobLogs].AzureResource in ($Resource) and
                DATEDIFF(second, '1970-01-01', [observability].[JobLogs].Startdate) >= $__unixEpochFrom() and 
                DATEDIFF(second, '1970-01-01', [observability].[JobLogs].Startdate) < $__unixEpochTo();
            ",
      format='table'
    )
  );

local JobDetailsPanelStatistics = grafana.tablePanel.new(
    title="Job Details",
    datasource='Azure SQL Server',
    description="This table lists all the Jobs for the selected source(s)"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT [observability].[JobLogs].Name as 'Job Name',
        [observability].[JobLogs].Steps as 'Activity',
		[observability].[JobLogs].StartDate as 'Start Date',
		[observability].[JobLogs].EndDate as 'End Date',
    [observability].[JobLogs].AzureResource as 'Resource',
		[observability].[JobLogs].Status as 'Job Status' FROM [observability].[JobLogs]
		where [observability].[JobLogs].Name in ($jobname) and 
					[observability].[JobLogs].Steps in ($activity) and
					[observability].[JobLogs].Status in ($Status) and
          [observability].[JobLogs].AzureResource in ($Resource) and
		DATEDIFF(second, '1970-01-01', [observability].[JobLogs].Startdate) >= $__unixEpochFrom() and 
        DATEDIFF(second, '1970-01-01', [observability].[JobLogs].Startdate) < $__unixEpochTo()
		order by [observability].[JobLogs].StartDate desc;
      ",
      format='table'
    )
  );


grafana.dashboard.new(
title='BI PLATFORM: Maintenance Jobs Monitoring',
time_from='now-24h',
editable='false',
schemaVersion=37,
uid='33Rilsxfccr15R',
tags=['monitoring', 'observability', 'external', 'run_team'])

.addTemplate(TemplateJobName)
.addTemplate(TemplateActivity)
.addTemplate(TemplateResource)
.addTemplate(TemplateStatus)

.addPanel(panel = SuccessRun, gridPos={h:6,w:6,x:0,y: 0})
.addPanel(panel = FailedRun, gridPos={h:6,w:6,x:18,y: 0})
.addPanel(panel = JobDetailsPanelStatistics, gridPos={h:9,w:24,x:0,y: 6})
