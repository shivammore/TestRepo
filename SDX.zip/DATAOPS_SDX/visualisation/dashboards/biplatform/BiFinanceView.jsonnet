local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local table = grafana.tablePanel;

//global filters
local regionTemplate =  tmpl.custom(
    name='region',
    current='all',
    query='COE,NORAM,APMEA,BRAZIL,FRANCE,LATAM,UKI',
    includeAll=true,
    multi=true,
    label="Region"
);

local jobTemplate = tmpl.custom(
    name='jobname',
    query= 'ConstraintsCheck,Data_Quality_Model_Refresh,Fact_SoftDelete,Global_Refresh,Optimize,Refresh,RLS_Load',
    current='all',
    includeAll=true,
    multi=true,
    label='Job Name'
);

local JobRunSummary =
    local sqlQuery = "
    SELECT [Job Name],[Flow Instance ID],[Start Date], [End Date], Threshold, Duration, [Job Status],[status_color_code] as Colour_Code
    From observability.bifinance_30days
    where DATEDIFF(second, '1970-01-01', [observability].[bifinance_30days].[Start date]) >= $__unixEpochFrom() and
    DATEDIFF(second, '1970-01-01', [observability].[bifinance_30days].[Start date]) < $__unixEpochTo()
    Group By [Job Name],[Start Date], [End Date], Threshold, Duration, [Job Status],[Flow Instance ID],[status_color_code]
    order by [Start Date] desc 
    ";

    table.new(
        title='Refresh Job Run Summary',
        datasource='Azure SQL Server',
        description="Summary of all Job Runs"
        ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
        ).addOverridesByFieldName(field='Colour_Code',properties= [{id: 'custom.cellOptions',value: {applyToRow : true,mode: 'gradient',type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'super-light-green', value: null },{ color: 'super-light-green', value: 0 },{ color: 'super-light-orange', value: 1 },{ color: '#ff969e', value: 2 }]}},{id : 'custom.hidden',value : true}]
        ).addOverridesByFieldName(field='Threshold',properties=[{ id: 'custom.filterable', value: 'true' },{id: 'unit', value: 's'},{id: 'unit', value: 'dthms'}]
        ).addOverridesByFieldName(field='Duration',properties=[{ id: 'custom.filterable', value: 'true' },{id: 'unit', value: 'dthms'}]
        ).addOverridesByFieldName(field='Job Name',properties=[{id: 'custom.width', value: 225},{ id: 'custom.filterable', value: 'true' },]
        ).addOverridesByFieldName(field='Flow Instance ID',properties=[{ id: 'custom.filterable', value: 'true' },]
        ).addOverridesByFieldName(field='Start Date',properties=[{ id: 'custom.filterable', value: 'true' },]
        ).addOverridesByFieldName(field='End Date',properties=[{ id: 'custom.filterable', value: 'true' },]
        ).addOverridesByFieldName(field='Job Status',properties=[{ id: 'custom.filterable', value: 'true' },]
);

local HistoricalJobRunSummary =
    local sqlQuery = "
    SELECT [Job Name],[Flow Instance ID],[Start Date], [End Date], Threshold, Duration, [Job Status],[status_color_code] as Colour_Code
    From observability.bifinance_30days
    Group By [Job Name],[Start Date], [End Date], Threshold, Duration, [Job Status],[Flow Instance ID],[status_color_code]
    order by [Start Date] desc  
    ";

    table.new(
        title='30 Days Refresh Job Run Summary',
        datasource='Azure SQL Server',
        description="Summary of all Job Runs"
        ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
        ).addOverridesByFieldName(field='Colour_Code',properties= [{id: 'custom.cellOptions',value: {applyToRow : true,mode: 'gradient',type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'super-light-green', value: null },{ color: 'super-light-green', value: 0 },{ color: 'super-light-orange', value: 1 },{ color: '#ff969e', value: 2 }]}},{id : 'custom.hidden',value : true}]
        ).addOverridesByFieldName(field='Threshold',properties=[{ id: 'custom.filterable', value: 'true' },{id: 'unit', value: 's'},{id: 'unit', value: 'dthms'}]
        ).addOverridesByFieldName(field='Duration',properties=[{ id: 'custom.filterable', value: 'true' },{id: 'unit', value: 'dthms'}]
        ).addOverridesByFieldName(field='Job Name',properties=[{id: 'custom.width', value: 225},{ id: 'custom.filterable', value: 'true' },]
        ).addOverridesByFieldName(field='Flow Instance ID',properties=[{ id: 'custom.filterable', value: 'true' },]
        ).addOverridesByFieldName(field='Start Date',properties=[{ id: 'custom.filterable', value: 'true' },]
        ).addOverridesByFieldName(field='End Date',properties=[{ id: 'custom.filterable', value: 'true' },]
        ).addOverridesByFieldName(field='Job Status',properties=[{ id: 'custom.filterable', value: 'true' },]
);

local JobRunTableView =
    local sqlQuery="   
    select [Job Name],[Flow Instance ID],[Start Date], [End Date], [Job Status],Type,[Flow Step Type],Message,[failed_status_color_code] as Colour_Code
    from [observability].[bifinance_30days]
    where [job status] = 'Failed' and  
    DATEDIFF(second, '1970-01-01', [observability].[bifinance_30days].[Start date]) >= $__unixEpochFrom() and
    DATEDIFF(second, '1970-01-01', [observability].[bifinance_30days].[Start date]) < $__unixEpochTo()
    order by [start date] desc
    ";
    
    table.new(
        title='Failed Job Run Detail View',
        datasource='Azure SQL Server',
        description="Detailed Table View of Failed Job Runs"
        ).addTarget(target=grafana.sql.target(rawSql = sqlQuery ,format='table')
        ).addOverridesByFieldName(field='Colour_Code',properties= [{id: 'custom.cellOptions',value: {applyToRow : true,mode: 'gradient',type: 'color-background'}},{id: 'thresholds',value: {mode: 'absolute',steps: [{ color: 'super-light-green', value: null },{ color: 'super-light-green', value: 0},{ color: 'super-light-orange', value: 1 },{ color: '#ff969e', value: 2 }]}},{id : 'custom.hidden',value : true}]
        ).addOverridesByFieldName(field='Job Name',properties=[{ id: 'custom.filterable', value: 'true' },{id: 'custom.width', value: 225}]
        ).addOverridesByFieldName(field='Flow Instance ID',properties=[{ id: 'custom.filterable', value: 'true' },]
        ).addOverridesByFieldName(field='Start Date',properties=[{ id: 'custom.filterable', value: 'true' },]
        ).addOverridesByFieldName(field='End Date',properties=[{ id: 'custom.filterable', value: 'true' },]
        ).addOverridesByFieldName(field='Job Status',properties=[{ id: 'custom.filterable', value: 'true' },]
        ).addOverridesByFieldName(field='Type',properties=[{ id: 'custom.filterable', value: 'true' },]
        ).addOverridesByFieldName(field='Flow Step Type',properties=[{ id: 'custom.filterable', value: 'true' },]
        ).addOverridesByFieldName(field='Message',properties=[{ id: 'custom.filterable', value: 'true' },{ id: 'custom.inspect', value: 'true' }]
        
);

grafana.dashboard.new(
  title='BI Finance Dashboard',
  refresh='5m',
  time_from='now-7d',
  editable=true,
  timezone='utc',
  schemaVersion=37,
  uid='aeby66a90fls0g')
/*
//global filters
.addTemplate(regionTemplate)
.addTemplate(jobTemplate)
*/

//panels
.addPanel(
    row.new(
        title="Refresh Job Run Summary",
        showTitle=true,
        collapse=true
    ).addPanel(panel = JobRunSummary,gridPos={h:10,w:24,x:0,y:1}),
    gridPos={h:1,w:24,x:0,y:0},
)
.addPanel(
    row.new(
        title="Failed Job Run Detail View",
        showTitle=true,
        collapse=true
    ).addPanel(panel = JobRunTableView,gridPos={h:10,w:24,x:0,y:16}),
    gridPos={h:1,w:24,x:0,y:15},
)
.addPanel(
    row.new(
        title="30 Days Job Run Summary",
        showTitle=true,
        collapse=true
    ).addPanel(panel = HistoricalJobRunSummary,gridPos={h:10,w:24,x:0,y:1}),
    gridPos={h:1,w:24,x:0,y:20},
)
