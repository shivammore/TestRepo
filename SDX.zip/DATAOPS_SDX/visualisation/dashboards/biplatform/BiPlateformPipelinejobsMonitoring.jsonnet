local grafana = import 'grafonnet/grafana.libsonnet';
local tmpl = grafana.template;
local row = grafana.row;
local sql_target = grafana.sql.target;
local statPanel = grafana.statPanel;
local barChart = grafana.barChart;
local template = grafana.template;

local TemplateJobName = template.new(
    name='jobname',
    datasource='Azure SQL Server',
    query='select distinct [observability].[insights-diagnostics-logs].Name from [observability].[insights-diagnostics-logs]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Job Name'
  );

local TemplateCategory = template.new(
    name='Category',
    datasource='Azure SQL Server',
    query='select distinct [observability].[insights-diagnostics-logs].Category from [observability].[insights-diagnostics-logs]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Pipeline Category'
  );

local TemplateResource = template.new(
    name='Resource',
    datasource='Azure SQL Server',
    query='SELECT distinct [observability].[insights-diagnostics-logs].AzureResource FROM [observability].[insights-diagnostics-logs]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Resource'
  );

local TemplateStatus = template.new(
    name='Status',
    datasource='Azure SQL Server',
    query='select distinct [observability].[insights-diagnostics-logs].Status from [observability].[insights-diagnostics-logs]',
    current='all',
    refresh='load',
    includeAll=true,
    multi=true,
    label='Status'
  );

local SuccessRun =
  statPanel.new(
    title="Succeeded Jobs",
    datasource='Azure SQL Server',
    description="This metric represent the number of Jobs that has the Success status",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'green',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="select count(*) from [observability].[insights-diagnostics-logs] 
                where [observability].[insights-diagnostics-logs].Status = 'Succeeded' and
                [observability].[insights-diagnostics-logs].Name in ($jobname) and 
                [observability].[insights-diagnostics-logs].Category in ($Category) and
                [observability].[insights-diagnostics-logs].AzureResource in ($Resource) and
                DATEDIFF(second, '1970-01-01', [insights-diagnostics-logs].Startdate) >= $__unixEpochFrom() and 
                DATEDIFF(second, '1970-01-01', [insights-diagnostics-logs].Startdate) < $__unixEpochTo();
            ",
      format='table'
    )
  );

local FailedRun =
  statPanel.new(
    title="Failed Jobs",
    datasource='Azure SQL Server',
    description="This metric represent the number of Jobs that has the Failed status",
    colorMode='background'

  ).addThresholds(
    steps=[
      {
        value: 0,
        color: 'semi-dark-red',
        text: 'Warning',
      },
    ]
  ).addTarget(
    target=grafana.sql.target(
      rawSql="select count(*) from [observability].[insights-diagnostics-logs] 
                where [observability].[insights-diagnostics-logs].Status = 'Failed' and
                [observability].[insights-diagnostics-logs].Name in ($jobname) and 
                [observability].[insights-diagnostics-logs].Category in ($Category) and
                [observability].[insights-diagnostics-logs].AzureResource in ($Resource) and
                DATEDIFF(second, '1970-01-01', [insights-diagnostics-logs].Startdate) >= $__unixEpochFrom() and 
                DATEDIFF(second, '1970-01-01', [insights-diagnostics-logs].Startdate) < $__unixEpochTo();
            ",
      format='table'
    )
  );

local JobDetailsPanelStatistics = grafana.tablePanel.new(
    title="Job Details",
    datasource='Azure SQL Server',
    description="This table lists all the Jobs for the selected source(s)"
  ).addTarget(
    target=grafana.sql.target(
      rawSql="SELECT [observability].[insights-diagnostics-logs].Name as 'Job Name', 
                [observability].[insights-diagnostics-logs].Category as 'Category',
                [observability].[insights-diagnostics-logs].StartDate as 'Start Date',
                [observability].[insights-diagnostics-logs].EndDate as 'End Date',
                [observability].[insights-diagnostics-logs].AzureResource as 'Resource',
                [observability].[insights-diagnostics-logs].Status as 'Job Status' FROM [observability].[insights-diagnostics-logs]
                where [observability].[insights-diagnostics-logs].Name in ($jobname) and 
                    [observability].[insights-diagnostics-logs].Category in ($Category) and
                    [observability].[insights-diagnostics-logs].Status in ($Status) and
                    [observability].[insights-diagnostics-logs].AzureResource in ($Resource) and
                    DATEDIFF(second, '1970-01-01', [insights-diagnostics-logs].Startdate) >= $__unixEpochFrom() and 
                    DATEDIFF(second, '1970-01-01', [insights-diagnostics-logs].Startdate) < $__unixEpochTo()
                order by  [observability].[insights-diagnostics-logs].StartDate desc;
      ",
      format='table'
    )
  );


grafana.dashboard.new(
title='BI PLATFORM: Pipeline Jobs Monitoring',
time_from='now-24h',
editable='false',
schemaVersion=37,
uid='23Rilvcfder17R',
tags=['monitoring', 'observability', 'external', 'run_team'])

.addTemplate(TemplateJobName)
.addTemplate(TemplateCategory)
.addTemplate(TemplateResource)
.addTemplate(TemplateStatus)

.addPanel(panel = SuccessRun, gridPos={h:6,w:6,x:0,y: 0})
.addPanel(panel = FailedRun, gridPos={h:6,w:6,x:18,y: 0})
.addPanel(panel = JobDetailsPanelStatistics, gridPos={h:9,w:24,x:0,y: 6})
